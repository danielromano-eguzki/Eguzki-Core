import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, FolderOpen, ListChecks, CalendarCheck, ClipboardCheck, FileDown } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AuditProgramManagement from '@/components/auditoria/AuditProgramManagement';
import AuditRequirements from '@/components/auditoria/AuditRequirements';
import AuditPlanning from '@/components/auditoria/AuditPlanning';
import AuditComplianceAnalysis from '@/components/auditoria/AuditComplianceAnalysis';
import AuditReportGenerator from '@/components/auditoria/AuditReportGenerator';
import { useEvidencias } from '@/hooks/useEvidencias.js';

const AuditoriaInternaContent = ({ 
  showToast, 
  isReadOnly,
  selectedClientId,
  userId,
  auditoriaInternaHook,
}) => {
  const {
    auditPrograms,
    addAuditProgram,
    updateAuditProgram,
    deleteAuditProgram,
    loading: loadingAuditoriaInterna,
    fetchProgramData
  } = auditoriaInternaHook;

  const [selectedProgramId, setSelectedProgramId] = useState('');
  
  const { evidences, loading: loadingEvidencias } = useEvidencias(userId, selectedClientId, showToast);

  useEffect(() => {
    if (auditPrograms && auditPrograms.length > 0 && !selectedProgramId) {
      setSelectedProgramId(auditPrograms[0].id);
    } else if (!auditPrograms || auditPrograms.length === 0) {
      setSelectedProgramId('');
    }
  }, [auditPrograms, selectedProgramId]);

  useEffect(() => {
    if (selectedProgramId) {
      fetchProgramData(selectedProgramId);
    }
  }, [selectedProgramId, fetchProgramData]);

  const selectedProgram = auditPrograms.find(p => p.id === selectedProgramId);

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6 md:space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-2xl md:text-3xl font-bold text-gray-900 flex items-center">
          <BookOpen className="w-7 h-7 md:w-8 md:h-8 mr-3 text-gradient" />Auditoría Interna
        </h1>
      </div>
      
      <AuditProgramManagement
        auditPrograms={auditPrograms}
        selectedProgramId={selectedProgramId}
        setSelectedProgramId={setSelectedProgramId}
        addAuditProgram={addAuditProgram}
        updateAuditProgram={updateAuditProgram}
        deleteAuditProgram={deleteAuditProgram}
        isReadOnly={isReadOnly}
        showToast={showToast}
      />
      
      {(loadingAuditoriaInterna || loadingEvidencias) && (
        <div className="flex justify-center items-center h-64">
          <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full"></motion.div>
        </div>
      )}
      
      {!loadingAuditoriaInterna && !selectedProgramId && auditPrograms && auditPrograms.length > 0 && (
        <p className="text-center text-gray-600 py-8 bg-white/30 backdrop-blur-sm rounded-lg shadow p-6">
          Por favor, selecciona un programa de auditoría para ver sus detalles.
        </p>
      )}
      
      {!loadingAuditoriaInterna && (!auditPrograms || auditPrograms.length === 0) && (
        <div className="text-center py-10 text-gray-500 bg-white/50 p-8 rounded-lg shadow">
            <FolderOpen className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <p className="text-xl mb-2">No hay programas de auditoría.</p>
            <p className="mb-4">Crea tu primer programa de auditoría para empezar.</p>
        </div>
      )}

      {selectedProgramId && !loadingAuditoriaInterna && !loadingEvidencias && (
        <Tabs defaultValue="planning" className="w-full">
          <TabsList className="grid w-full grid-cols-1 sm:grid-cols-2 md:grid-cols-4">
            <TabsTrigger value="requirements"><ListChecks className="w-4 h-4 mr-2" />Requisitos</TabsTrigger>
            <TabsTrigger value="planning"><CalendarCheck className="w-4 h-4 mr-2" />Planificación</TabsTrigger>
            <TabsTrigger value="compliance"><ClipboardCheck className="w-4 h-4 mr-2" />Análisis de Cumplimiento</TabsTrigger>
            <TabsTrigger value="report"><FileDown className="w-4 h-4 mr-2" />Informe</TabsTrigger>
          </TabsList>
          
          <TabsContent value="requirements" className="mt-6">
            <AuditRequirements hook={auditoriaInternaHook} programId={selectedProgramId} isReadOnly={isReadOnly} />
          </TabsContent>
          
          <TabsContent value="planning" className="mt-6">
            <AuditPlanning hook={auditoriaInternaHook} programId={selectedProgramId} isReadOnly={isReadOnly} />
          </TabsContent>

          <TabsContent value="compliance" className="mt-6">
            <AuditComplianceAnalysis hook={auditoriaInternaHook} programId={selectedProgramId} evidences={evidences} isReadOnly={isReadOnly} />
          </TabsContent>

          <TabsContent value="report" className="mt-6">
            <AuditReportGenerator hook={auditoriaInternaHook} program={selectedProgram} />
          </TabsContent>

        </Tabs>
      )}
    </motion.div>
  );
};

const AuditoriaInternaPage = (props) => {
  if (!props.selectedClientId) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center bg-white/50 p-8 rounded-lg shadow">
        <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-400" />
        <h2 className="text-2xl font-semibold text-gray-700">Auditoría Interna</h2>
        <p className="mt-2 text-gray-500">Por favor, selecciona un cliente en la cabecera para gestionar sus auditorías.</p>
      </div>
    );
  }

  return <AuditoriaInternaContent {...props} />;
};

export default AuditoriaInternaPage;