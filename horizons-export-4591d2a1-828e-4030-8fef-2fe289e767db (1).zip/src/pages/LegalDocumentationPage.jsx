import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Scale, PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog.jsx";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog.jsx";
import ExportMenu from '@/components/common/ExportMenu.jsx';
import LegalDocumentForm from '@/components/legal/LegalDocumentForm.jsx';
import LegalDocumentsTable from '@/components/legal/LegalDocumentsTable.jsx';

const legalDocumentHeaders = [
  { label: 'Nombre', key: 'name' },
  { label: 'Tipo', key: 'type' },
  { label: 'Descripción', key: 'description' },
  { label: 'Fecha de Revisión', key: 'review_date' },
  { label: 'Estado', key: 'status' },
  { label: 'Fecha Creación', key: 'created_at' }
];

const LegalDocumentationPage = ({
  legalDocumentsHook,
  showToast,
  isReadOnly,
  selectedClientId,
}) => {
  const { documents, addDocument, updateDocument, deleteDocument, loading, getFileUrl } = legalDocumentsHook;
  
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingDocument, setEditingDocument] = useState(null);
  const [documentToDelete, setDocumentToDelete] = useState(null);

  const handleFormSubmit = async (formData, attachmentFile) => {
    if (editingDocument) {
      await updateDocument(editingDocument.id, formData, attachmentFile);
    } else {
      await addDocument(formData, attachmentFile);
    }
    setIsFormModalOpen(false);
    setEditingDocument(null);
  };

  const openFormForNew = () => {
    if (!selectedClientId) {
      showToast("Acción Requerida", "Por favor, selecciona un cliente primero para poder añadir un documento.", "destructive");
      return;
    }
    setEditingDocument(null);
    setIsFormModalOpen(true);
  };

  const openFormForEdit = (doc) => {
    setEditingDocument(doc);
    setIsFormModalOpen(true);
  };

  const openDeleteDialog = (doc) => {
    setDocumentToDelete(doc);
  };

  const confirmDelete = async () => {
    if (documentToDelete) {
      await deleteDocument(documentToDelete.id);
      setDocumentToDelete(null);
    }
  };
  
  const handleDownloadFile = async (filePath, desiredName) => {
    const url = await getFileUrl(filePath);
    if (url) {
      try {
        const response = await fetch(url);
        const blob = await response.blob();
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = desiredName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(link.href);
      } catch (error) {
        showToast("Error de Descarga", "No se pudo descargar el archivo.", "destructive");
        console.error("Download error:", error);
      }
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center">
          Documentación Legal
        </h2>
        <div className="flex items-center space-x-2">
          <ExportMenu 
            data={documents} 
            headers={legalDocumentHeaders} 
            filenamePrefix="documentacion_legal" 
            reportTitle="Inventario de Documentación Legal"
            disabled={loading}
          />
          <Button onClick={openFormForNew} disabled={isReadOnly}>
            <PlusCircle className="mr-2 h-4 w-4" /> Nuevo Documento
          </Button>
        </div>
      </div>
      
      <LegalDocumentsTable 
        documents={documents}
        onEdit={openFormForEdit}
        onDelete={openDeleteDialog}
        onDownloadFile={handleDownloadFile}
        isReadOnly={isReadOnly}
        loading={loading}
      />

      <Dialog open={isFormModalOpen} onOpenChange={(isOpen) => { if (!isOpen) setEditingDocument(null); setIsFormModalOpen(isOpen); }}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader><DialogTitle>{editingDocument ? 'Editar' : 'Nuevo'} Documento Legal</DialogTitle></DialogHeader>
          <LegalDocumentForm 
            onSubmit={handleFormSubmit} 
            onCancel={() => setIsFormModalOpen(false)} 
            existingDocument={editingDocument}
            isReadOnly={isReadOnly}
          />
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={!!documentToDelete} onOpenChange={() => setDocumentToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Estás seguro?</AlertDialogTitle></AlertDialogHeader>
          <AlertDialogDescription>Esta acción no se puede deshacer. Esto eliminará permanentemente el documento y su archivo asociado.</AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Sí, eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </motion.div>
  );
};

export default LegalDocumentationPage;