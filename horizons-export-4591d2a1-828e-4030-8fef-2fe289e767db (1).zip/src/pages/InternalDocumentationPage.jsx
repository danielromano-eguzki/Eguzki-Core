import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { FileText, BookOpen, Folder, FilePlus, Upload } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog.jsx";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog.jsx";

import CuerpoNormativoPage from '@/pages/CuerpoNormativoPage.jsx';
import LegalDocumentationPage from '@/pages/LegalDocumentationPage.jsx';
import TemplateForm from '@/components/cuerpo_normativo/TemplateForm.jsx';
import TemplatesTable from '@/components/cuerpo_normativo/TemplatesTable.jsx';
import { useDocumentTemplates } from '@/hooks/useDocumentTemplates.js';

const InternalDocumentationPage = (props) => {
  const { userId, showToast, isReadOnly } = props;
  const templatesHook = useDocumentTemplates(userId, showToast);
  const [isTemplateFormOpen, setIsTemplateFormOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [templateToDelete, setTemplateToDelete] = useState(null);
  const fileInputRef = useRef(null);

  const handleNewTemplate = () => {
    setEditingTemplate(null);
    setIsTemplateFormOpen(true);
  };

  const handleEditTemplate = (template) => {
    setEditingTemplate(template);
    setIsTemplateFormOpen(true);
  };

  const handleDeleteTemplate = (template) => {
    setTemplateToDelete(template);
  };

  const confirmDeleteTemplate = async () => {
    if (templateToDelete) {
      await templatesHook.deleteTemplate(templateToDelete.id);
      setTemplateToDelete(null);
    }
  };

  const handleTemplateFormSubmit = async (formData, file) => {
    if (editingTemplate) {
      await templatesHook.updateTemplate(editingTemplate.id, formData, file);
    } else {
      await templatesHook.addTemplate(formData, file);
    }
    setIsTemplateFormOpen(false);
    setEditingTemplate(null);
  };

  const handleBulkUploadClick = () => {
    fileInputRef.current.click();
  };

  const getCategoryFromFilename = (filename) => {
    const lowerCaseName = filename.toLowerCase();
    if (lowerCaseName.includes('seguridad')) return 'Seguridad';
    if (lowerCaseName.includes('rrhh') || lowerCaseName.includes('recursos humanos')) return 'RRHH';
    if (lowerCaseName.includes('it') || lowerCaseName.includes('tecnología')) return 'IT';
    if (lowerCaseName.includes('legal')) return 'Legal';
    if (lowerCaseName.includes('financiero')) return 'Financiero';
    return 'General';
  };

  const getDocTypeFromFilename = (filename) => {
    const lowerCaseName = filename.toLowerCase();
    if (lowerCaseName.includes('política')) return 'Política';
    if (lowerCaseName.includes('procedimiento')) return 'Procedimiento';
    if (lowerCaseName.includes('instrucción')) return 'Instrucción Técnica';
    return 'Documento Interno';
  };

  const handleFileChange = async (event) => {
    const files = event.target.files;
    if (!files || files.length === 0) {
      return;
    }

    showToast('Subida en progreso', `Subiendo ${files.length} plantillas...`, 'default');

    const uploadPromises = Array.from(files).map(file => {
      const cleanName = file.name.replace(/\.[^/.]+$/, "").replace(/_/g, ' ');
      const formData = {
        title: cleanName,
        description: `Plantilla para ${cleanName}`,
        document_type: getDocTypeFromFilename(file.name),
        category: getCategoryFromFilename(file.name),
      };
      return templatesHook.addTemplate(formData, file, true);
    });

    try {
      await Promise.all(uploadPromises);
      showToast('Éxito', `${files.length} plantillas subidas y categorizadas correctamente.`, 'success');
      templatesHook.refetchTemplates();
    } catch (error) {
      showToast('Error', 'Hubo un problema al subir algunas plantillas.', 'destructive');
      console.error("Bulk upload error:", error);
    }

    // Reset file input
    event.target.value = null;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="h-full"
    >
      <Tabs defaultValue="cuerpo-normativo" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="cuerpo-normativo">
            <BookOpen className="mr-2 h-4 w-4" />
            Cuerpo Normativo
          </TabsTrigger>
          <TabsTrigger value="documentacion-legal">
            <FileText className="mr-2 h-4 w-4" />
            Documentación Legal
          </TabsTrigger>
          <TabsTrigger value="plantillas">
            <Folder className="mr-2 h-4 w-4" />
            Plantillas
          </TabsTrigger>
        </TabsList>
        <TabsContent value="cuerpo-normativo" className="mt-4">
          <CuerpoNormativoPage {...props} />
        </TabsContent>
        <TabsContent value="documentacion-legal" className="mt-4">
          <LegalDocumentationPage {...props} />
        </TabsContent>
        <TabsContent value="plantillas" className="mt-4">
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-800">Gestor de Plantillas</h2>
              <div className="flex space-x-2">
                <input
                  type="file"
                  multiple
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  className="hidden"
                  accept=".doc,.docx,.pdf,.xls,.xlsx,.ppt,.pptx,.txt"
                />
                <Button onClick={handleBulkUploadClick} disabled={isReadOnly} variant="outline">
                  <Upload className="mr-2 h-4 w-4" /> Añadir Plantillas
                </Button>
                <Button onClick={handleNewTemplate} disabled={isReadOnly}>
                  <FilePlus className="mr-2 h-4 w-4" /> Nueva Plantilla (Manual)
                </Button>
              </div>
            </div>
            <TemplatesTable
              templates={templatesHook.templates}
              loading={templatesHook.loading}
              onEdit={handleEditTemplate}
              onDelete={handleDeleteTemplate}
              onDownload={templatesHook.getFileUrl}
              isReadOnly={isReadOnly}
            />
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={isTemplateFormOpen} onOpenChange={(isOpen) => { if (!isOpen) setEditingTemplate(null); setIsTemplateFormOpen(isOpen); }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingTemplate ? 'Editar' : 'Nueva'} Plantilla de Documento</DialogTitle>
          </DialogHeader>
          <TemplateForm
            onSubmit={handleTemplateFormSubmit}
            onCancel={() => setIsTemplateFormOpen(false)}
            existingTemplate={editingTemplate}
            isReadOnly={isReadOnly}
          />
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!templateToDelete} onOpenChange={() => setTemplateToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Estás seguro?</AlertDialogTitle></AlertDialogHeader>
          <AlertDialogDescription>Esta acción no se puede deshacer. Esto eliminará permanentemente la plantilla y su archivo asociado.</AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteTemplate} className="bg-red-600 hover:bg-red-700">Sí, eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );
};

export default InternalDocumentationPage;