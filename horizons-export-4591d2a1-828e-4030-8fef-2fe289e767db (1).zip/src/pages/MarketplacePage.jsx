import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';
import { Sparkles, FileText, Shield, AlertTriangle, ShieldAlert, GraduationCap, UserCheck } from 'lucide-react';
import AddonCard from '@/components/marketplace/AddonCard';

const chispas = [
  {
    id: 'policy-templates',
    title: 'Plantillas de Políticas',
    description: 'Accede a una biblioteca completa de políticas de seguridad, listas para adaptar e implementar en tu organización.',
    price: 'Incluido',
    icon: <FileText className="w-8 h-8 text-blue-500" />,
    category: 'Repositorio Normativo',
    features: [
      'Políticas de Seguridad de la Información',
      'Políticas de Control de Acceso',
      'Políticas de Uso Aceptable',
      'Y muchas más...',
    ],
  },
  {
    id: 'hardening-guides',
    title: 'Guías de Hardening',
    description: 'Utiliza guías y scripts predefinidos para asegurar tus sistemas operativos y aplicaciones críticas.',
    price: 'Incluido',
    icon: <Shield className="w-8 h-8 text-green-500" />,
    category: 'Gestión de IT',
    features: [
      'Guías para Windows Server y Linux',
      'Benchmarks de CIS',
      'Plantillas de GPO para Endpoints',
    ],
  },
  {
    id: 'risk-analysis-templates',
    title: 'Análisis de Riesgos Predefinido',
    description: 'Importa una matriz con 20 riesgos de ciberseguridad comunes para acelerar tu análisis inicial.',
    price: 'Incluido',
    icon: <AlertTriangle className="w-8 h-8 text-yellow-500" />,
    category: 'Gestión de Riesgos',
    features: [
      'Riesgos de Phishing, Ransomware, etc.',
      'Clasificación por probabilidad e impacto',
      'Base para tu análisis de riesgos personalizado',
    ],
  },
  {
    id: 'business-continuity-templates',
    title: 'Plantillas de Continuidad de Negocio',
    description: 'Accede a plantillas para desarrollar tu Análisis de Impacto en el Negocio (BIA) y Planes de Recuperación (DRP).',
    price: 'Consultar',
    icon: <ShieldAlert className="w-8 h-8 text-red-500" />,
    category: 'Continuidad de Negocio',
    features: [
      'Plantilla de BIA',
      'Estructura para Plan de Continuidad (BCP)',
      'Modelo de Plan de Recuperación (DRP)',
    ],
  },
  {
    id: 'training-courses',
    title: 'Cursos y Planes de Formación',
    description: 'Planes de formación y cursos de concienciación en ciberseguridad para tus empleados.',
    price: 'Consultar',
    icon: <GraduationCap className="w-8 h-8 text-indigo-500" />,
    category: 'Formación y Concienciación',
    features: [
      'Cursos sobre Phishing y Contraseñas Seguras',
      'Planes de formación anuales',
      'Material de concienciación personalizable',
    ],
  },
  {
    id: 'dedicated-consultant',
    title: 'Consultor Dedicado',
    description: 'Contrata una bolsa de horas para tener a un experto a tu disposición para resolver dudas y ayudarte en la implementación.',
    price: 'Desde 90€/hora',
    icon: <UserCheck className="w-8 h-8 text-teal-500" />,
    category: 'Servicios Profesionales',
    features: [
      'Soporte experto bajo demanda',
      'Ayuda con la personalización de la plataforma',
      'Asesoramiento estratégico en GRC',
    ],
  },
];

const MarketplacePage = ({ showToast }) => {
  return (
    <>
      <Helmet>
        <title>Marketplace - Eguzki Core</title>
        <meta name="description" content="Descubre y adquiere Chispas para potenciar Eguzki Core." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-8"
      >
        <div className="text-center">
          <Sparkles className="w-16 h-16 mx-auto mb-4 text-gradient-green" />
          <h1 className="text-4xl font-bold text-gray-800">Marketplace de Chispas</h1>
          <p className="mt-2 text-lg text-gray-600">Enciende el potencial de tu plataforma con nuevas plantillas y servicios.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {chispas.map((chispa, index) => (
            <motion.div
              key={chispa.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <AddonCard addon={chispa} onPurchase={() => showToast()} />
            </motion.div>
          ))}
        </div>
      </motion.div>
    </>
  );
};

export default MarketplacePage;