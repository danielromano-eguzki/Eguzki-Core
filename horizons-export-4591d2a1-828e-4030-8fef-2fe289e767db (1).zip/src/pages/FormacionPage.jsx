import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';
import { GraduationCap, PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog.jsx";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog.jsx";

import AwarenessGuides from '@/components/formacion/AwarenessGuides.jsx';
import TrainingForm from '@/components/formacion/TrainingForm.jsx';
import TrainingsTable from '@/components/formacion/TrainingsTable.jsx';

const FormacionPage = ({
  showToast,
  trainingsHook,
  selectedClientId
}) => {
  const { trainings, addTraining, updateTraining, deleteTraining, loading, getFileUrl } = trainingsHook || {};

  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingTraining, setEditingTraining] = useState(null);
  const [trainingToDelete, setTrainingToDelete] = useState(null);

  const handleFormSubmit = async (formData, attachmentFile) => {
    if (editingTraining) {
      await updateTraining(editingTraining.id, formData, attachmentFile);
    } else {
      await addTraining(formData, attachmentFile);
    }
    setIsFormModalOpen(false);
    setEditingTraining(null);
  };

  const openFormForNew = () => {
    if (!selectedClientId) {
      showToast("Acción Requerida", "Por favor, selecciona un cliente primero para poder añadir una formación.", "destructive");
      return;
    }
    setEditingTraining(null);
    setIsFormModalOpen(true);
  };

  const openFormForEdit = (training) => {
    setEditingTraining(training);
    setIsFormModalOpen(true);
  };

  const openDeleteDialog = (training) => {
    setTrainingToDelete(training);
  };

  const confirmDelete = async () => {
    if (trainingToDelete) {
      await deleteTraining(trainingToDelete.id);
      setTrainingToDelete(null);
    }
  };
  
  const handleDownloadFile = async (filePath, desiredName) => {
    const url = await getFileUrl(filePath);
    if (url) {
      try {
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', desiredName);
        document.body.appendChild(link);
        link.click();
        link.parentNode.removeChild(link);
      } catch (error) {
        showToast("Error de Descarga", "No se pudo iniciar la descarga. Por favor, revisa la consola.", "destructive");
        console.error("Download error:", error);
      }
    }
  };

  return (
    <>
      <Helmet>
        <title>Formación - Eguzki Core</title>
        <meta name="description" content="Gestiona la formación y concienciación en ciberseguridad." />
      </Helmet>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-800 flex items-center">
            <GraduationCap className="w-8 h-8 mr-3 text-gradient-green" />
            Formación y Concienciación
          </h1>
          <Button onClick={openFormForNew} disabled={!selectedClientId}>
            <PlusCircle className="mr-2 h-4 w-4" /> Nueva Formación
          </Button>
        </div>

        {!selectedClientId ? (
          <div className="flex flex-col items-center justify-center h-full text-center bg-white/50 p-8 rounded-lg shadow">
            <GraduationCap className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h2 className="text-2xl font-semibold text-gray-700">Formación y Concienciación</h2>
            <p className="mt-2 text-gray-500">Por favor, selecciona un cliente en la cabecera para ver o gestionar sus formaciones.</p>
          </div>
        ) : (
          <>
            <AwarenessGuides />
            
            <h2 className="text-xl font-semibold text-gray-800 pt-4">Inventario de Formaciones Realizadas</h2>

            {loading && (
              <div className="flex justify-center items-center h-64">
                <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-12 h-12 border-4 border-green-500 border-t-transparent rounded-full"></motion.div>
              </div>
            )}

            {!loading && trainings && trainings.length === 0 && (
              <div className="text-center py-16 text-gray-500 bg-white/50 p-8 rounded-lg shadow">
                <p className="text-xl">No hay formaciones registradas para este cliente.</p>
                <p>Puedes añadir una nueva usando el botón de "Nueva Formación".</p>
              </div>
            )}
            
            {!loading && trainings && trainings.length > 0 && (
               <TrainingsTable 
                  trainings={trainings}
                  onEdit={openFormForEdit}
                  onDelete={openDeleteDialog}
                  onDownloadFile={handleDownloadFile}
               />
            )}
          </>
        )}

        <Dialog open={isFormModalOpen} onOpenChange={(isOpen) => { if (!isOpen) setEditingTraining(null); setIsFormModalOpen(isOpen); }}>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader><DialogTitle>{editingTraining ? 'Editar' : 'Nueva'} Formación</DialogTitle></DialogHeader>
            <TrainingForm onSubmit={handleFormSubmit} onCancel={() => setIsFormModalOpen(false)} existingTraining={editingTraining} />
          </DialogContent>
        </Dialog>
        
        <AlertDialog open={!!trainingToDelete} onOpenChange={() => setTrainingToDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader><AlertDialogTitle>¿Estás seguro?</AlertDialogTitle></AlertDialogHeader>
            <AlertDialogDescription>Esta acción no se puede deshacer. Esto eliminará permanentemente el registro de formación y su archivo asociado.</AlertDialogDescription>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Sí, eliminar</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </motion.div>
    </>
  );
};

export default FormacionPage;