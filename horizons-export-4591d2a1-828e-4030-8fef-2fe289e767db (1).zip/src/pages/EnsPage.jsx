import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Anchor, ShieldCheck, ClipboardList, FileText, AlertOctagon, BarChart2, ShieldQuestion, CheckSquare, ShieldEllipsis } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import EnsDashboard from '@/components/ens/EnsDashboard';
import EnsRequirementsLevelTab from '@/components/ens/EnsRequirementsLevelTab';
import EnsEvidencesTab from '@/components/ens/EnsEvidencesTab';
import FullReportTab from '@/components/common/FullReportTab';

const EnsPage = ({ showToast, ensHook, evidenciasHook, selectedClientId, isReadOnly, clientsHook }) => {
  const {
    requirements,
    stats,
    loading,
    seedEnsRequirements,
    certifications,
  } = ensHook;

  const { clients } = clientsHook;
  const [activeMainTab, setActiveMainTab] = useState('dashboard');
  const [activeMatrixTab, setActiveMatrixTab] = useState('Bajo');

  if (!selectedClientId) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center bg-white/50 p-8 rounded-lg shadow">
        <AlertOctagon className="w-16 h-16 mx-auto mb-4 text-gray-400" />
        <h2 className="text-2xl font-semibold text-gray-700">Esquema Nacional de Seguridad (ENS)</h2>
        <p className="mt-2 text-gray-500">Por favor, selecciona un cliente para gestionar su cumplimiento con el ENS.</p>
      </div>
    );
  }

  const currentClientName = clients?.find(c => c.id === selectedClientId)?.name || 'Cliente';
  const hasEnsCertification = certifications.some(c => c.name === 'Esquema Nacional de Seguridad');

  const {
    addRequirement,
    updateRequirement,
    deleteRequirement,
    linkEvidenceToRequirement,
    unlinkEvidenceFromRequirement,
  } = ensHook;
  
  const requirementsHookForTable = {
    addRequirement,
    updateRequirement,
    deleteRequirement,
    linkEvidenceToRequirement,
    unlinkEvidenceFromRequirement,
  };

  const { evidences, getEvidenceFileUrl } = evidenciasHook;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-800 flex items-center">
          <Anchor className="w-8 h-8 mr-3 text-gradient-green" />
          Esquema Nacional de Seguridad (ENS)
        </h1>
      </div>

      <Tabs value={activeMainTab} onValueChange={setActiveMainTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="dashboard"><BarChart2 className="w-4 h-4 mr-2" />Dashboard</TabsTrigger>
          <TabsTrigger value="matrix"><ShieldCheck className="w-4 h-4 mr-2" />Matriz de Cumplimiento</TabsTrigger>
          <TabsTrigger value="evidences"><ClipboardList className="w-4 h-4 mr-2" />Gestión de Evidencias</TabsTrigger>
          <TabsTrigger value="report"><FileText className="w-4 h-4 mr-2" />Informe Completo</TabsTrigger>
        </TabsList>
        
        <TabsContent value="dashboard" className="mt-6">
          <EnsDashboard 
            stats={stats} 
            loading={loading}
            onSeed={seedEnsRequirements}
            hasRequirements={hasEnsCertification && requirements.length > 0}
            isReadOnly={isReadOnly}
            normativeName="ENS"
          />
        </TabsContent>

        <TabsContent value="matrix" className="mt-6">
            <Tabs value={activeMatrixTab} onValueChange={setActiveMatrixTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="Bajo"><ShieldQuestion className="w-4 h-4 mr-2" />Nivel Bajo</TabsTrigger>
                    <TabsTrigger value="Medio"><ShieldEllipsis className="w-4 h-4 mr-2" />Nivel Medio</TabsTrigger>
                    <TabsTrigger value="Alto"><CheckSquare className="w-4 h-4 mr-2" />Nivel Alto</TabsTrigger>
                </TabsList>
                <TabsContent value="Bajo" className="mt-4">
                    <EnsRequirementsLevelTab 
                        level="Bajo"
                        requirements={requirements}
                        evidences={evidences}
                        ensHook={requirementsHookForTable}
                        getEvidenceFileUrl={getEvidenceFileUrl}
                        isReadOnly={isReadOnly}
                    />
                </TabsContent>
                <TabsContent value="Medio" className="mt-4">
                     <EnsRequirementsLevelTab 
                        level="Medio"
                        requirements={requirements}
                        evidences={evidences}
                        ensHook={requirementsHookForTable}
                        getEvidenceFileUrl={getEvidenceFileUrl}
                        isReadOnly={isReadOnly}
                    />
                </TabsContent>
                <TabsContent value="Alto" className="mt-4">
                     <EnsRequirementsLevelTab 
                        level="Alto"
                        requirements={requirements}
                        evidences={evidences}
                        ensHook={requirementsHookForTable}
                        getEvidenceFileUrl={getEvidenceFileUrl}
                        isReadOnly={isReadOnly}
                    />
                </TabsContent>
            </Tabs>
        </TabsContent>

        <TabsContent value="evidences" className="mt-6">
          <EnsEvidencesTab
            evidenciasHook={evidenciasHook}
            requirements={requirements}
            certifications={certifications.filter(c => c.name === 'Esquema Nacional de Seguridad')}
            isReadOnly={isReadOnly}
            showToast={showToast}
          />
        </TabsContent>

        <TabsContent value="report" className="mt-6">
          <FullReportTab
            requirements={requirements}
            normativeName="Esquema Nacional de Seguridad"
            clientName={currentClientName}
          />
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default EnsPage;