import React from 'react';
import { motion } from 'framer-motion';
import { Shield, BarChart2, FolderArchive, FileText as ReportIcon, Loader2, AlertOctagon } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import IsoDashboard from '@/components/iso27001/IsoDashboard';
import EnsEvidencesTab from '@/components/ens/EnsEvidencesTab';
import RequirementsTable from '@/components/requisitos/RequirementsTable';
import { Button } from '@/components/ui/button';
import { PlusCircle, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import EnsRequirementForm from '@/components/ens/EnsRequirementForm';
import FullReportTab from '@/components/common/FullReportTab';

const RequirementsTab = ({ requirements, evidences, doraHook, isReadOnly }) => {
    const [isFormOpen, setFormOpen] = React.useState(false);
    const [editingRequirement, setEditingRequirement] = React.useState(null);
    const [toDelete, setToDelete] = React.useState(null);
    const [filters, setFilters] = React.useState({ searchTerm: '', status: 'all', category: 'all' });

    const { addRequirement, updateRequirement, deleteRequirement, getEvidenceFileUrl, linkEvidenceToRequirement, unlinkEvidenceFromRequirement } = doraHook;

    const filteredRequirements = React.useMemo(() => {
        let result = requirements;
        if (filters.searchTerm) {
            const term = filters.searchTerm.toLowerCase();
            result = result.filter(r => (r.titulo && r.titulo.toLowerCase().includes(term)) || (r.codigo && r.codigo.toLowerCase().includes(term)));
        }
        if (filters.status !== 'all') {
            result = result.filter(r => r.estado_cumplimiento === filters.status);
        }
        if (filters.category !== 'all') {
            result = result.filter(r => r.tipo_requisito === filters.category);
        }
        return result;
    }, [requirements, filters]);

    const handleSubmit = async (formData) => {
        if (editingRequirement) {
            await updateRequirement(editingRequirement.id, formData);
        } else {
            await addRequirement(formData);
        }
        setFormOpen(false);
        setEditingRequirement(null);
    };

    const openForm = (req = null) => { setEditingRequirement(req); setFormOpen(true); };
    const handleDelete = async () => { if (toDelete) { await deleteRequirement(toDelete.id); setToDelete(null); } };

    const categories = [...new Set(requirements.map(r => r.tipo_requisito))];

    return (
        <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-800">Requisitos DORA</h2>
                <div className="flex items-center gap-2">
                    <div className="relative"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /><Input placeholder="Buscar..." className="pl-9" value={filters.searchTerm} onChange={e => setFilters(f => ({ ...f, searchTerm: e.target.value }))} /></div>
                    <Select value={filters.category} onValueChange={v => setFilters(f => ({ ...f, category: v }))}><SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todos los pilares</SelectItem>{categories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}</SelectContent></Select>
                    <Select value={filters.status} onValueChange={v => setFilters(f => ({ ...f, status: v }))}><SelectTrigger className="w-[150px]"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todos</SelectItem><SelectItem value="Cumplido">Cumplido</SelectItem><SelectItem value="Parcial">Parcial</SelectItem><SelectItem value="No cumplido">No cumplido</SelectItem><SelectItem value="No aplica">No aplica</SelectItem></SelectContent></Select>
                    <Button onClick={() => openForm()} disabled={isReadOnly}><PlusCircle className="mr-2 h-4 w-4" /> Nuevo</Button>
                </div>
            </div>
            <RequirementsTable requirements={filteredRequirements} evidences={evidences} isReadOnly={isReadOnly} onEdit={openForm} onDelete={setToDelete} getEvidenceFileUrl={getEvidenceFileUrl} requirementsHook={{ linkEvidenceToRequirement, unlinkEvidenceFromRequirement }} />
            <Dialog open={isFormOpen} onOpenChange={setFormOpen}><DialogContent className="sm:max-w-2xl"><DialogHeader><DialogTitle>{editingRequirement ? 'Editar' : 'Nuevo'} Requisito DORA</DialogTitle></DialogHeader><EnsRequirementForm onSubmit={handleSubmit} onCancel={() => setFormOpen(false)} existingRequirement={editingRequirement} level={editingRequirement?.tipo_requisito || 'DORA-Riesgo'} isReadOnly={isReadOnly} isIso={true} /></DialogContent></Dialog>
            <AlertDialog open={!!toDelete} onOpenChange={() => setToDelete(null)}><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>¿Confirmas la eliminación?</AlertDialogTitle></AlertDialogHeader><AlertDialogDescription>Esta acción es permanente.</AlertDialogDescription><AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
        </div>
    );
};

const DORAPage = ({ doraHook, selectedClientId, isReadOnly, clientsHook }) => {
    const { clients } = clientsHook;
    const { requirements, evidences, loading, stats, certification, seedDORAMethod, showToast } = doraHook;

    if (!selectedClientId) {
        return <div className="flex flex-col items-center justify-center h-full text-center bg-white/50 p-8 rounded-lg shadow"><AlertOctagon className="w-16 h-16 mx-auto mb-4 text-gray-400" /><h2 className="text-2xl font-semibold text-gray-700">DORA</h2><p className="mt-2 text-gray-500">Por favor, selecciona un cliente para empezar.</p></div>;
    }

    if (loading) {
        return <div className="flex items-center justify-center h-full"><Loader2 className="w-12 h-12 animate-spin text-blue-500" /></div>;
    }

    const selectedClient = clients.find(c => c.id === selectedClientId);

    return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <Tabs defaultValue="dashboard" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="dashboard"><BarChart2 className="w-4 h-4 mr-2" />Dashboard</TabsTrigger>
                    <TabsTrigger value="controls"><Shield className="w-4 h-4 mr-2" />Requisitos</TabsTrigger>
                    <TabsTrigger value="evidences"><FolderArchive className="w-4 h-4 mr-2" />Evidencias</TabsTrigger>
                    <TabsTrigger value="reports"><ReportIcon className="w-4 h-4 mr-2" />Informes</TabsTrigger>
                </TabsList>
                <TabsContent value="dashboard" className="mt-4">
                    <IsoDashboard 
                        stats={stats} 
                        loading={loading}
                        onSeed={seedDORAMethod}
                        hasRequirements={requirements.length > 0}
                        isReadOnly={isReadOnly}
                        normativeName="DORA"
                    />
                </TabsContent>
                <TabsContent value="controls" className="mt-4">
                    <RequirementsTab requirements={requirements} evidences={evidences} doraHook={doraHook} isReadOnly={isReadOnly} />
                </TabsContent>
                <TabsContent value="evidences" className="mt-4">
                    <EnsEvidencesTab 
                        evidenciasHook={doraHook} 
                        requirements={requirements} 
                        certifications={certification ? [certification] : []}
                        isReadOnly={isReadOnly}
                        showToast={showToast}
                    />
                </TabsContent>
                <TabsContent value="reports" className="mt-4">
                    <FullReportTab 
                        requirements={requirements}
                        normativeName="DORA"
                        clientName={selectedClient?.name || 'Cliente no seleccionado'}
                    />
                </TabsContent>
            </Tabs>
        </motion.div>
    );
};

export default DORAPage;