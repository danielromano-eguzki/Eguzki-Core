import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ShieldAlert, FileText, AlertTriangle, Activity, ShieldQuestion, PlusCircle, Settings, Cloud, File as FileIcon, Plug } from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog.jsx";
import GenericTable from '@/components/it/GenericTable';
import GenericForm from '@/components/it/GenericForm';
import IntegrationsPage from '@/pages/IntegrationsPage';
import BusinessContinuityPage from '@/pages/BusinessContinuityPage.jsx';
import IncidentManagementPage from '@/pages/IncidentManagementPage.jsx';

const otherItSections = {
  vulnerabilities: { title: 'Vulnerabilidades y Parcheos', icon: ShieldQuestion, columns: [{ accessorKey: 'vulnerability_name', header: 'Vulnerabilidad' }, { accessorKey: 'affected_asset', header: 'Activo Afectado' }, { accessorKey: 'detection_date', header: 'Detección' }, { accessorKey: 'severity', header: 'Severidad' }, { accessorKey: 'status', header: 'Estado' }], formFields: [{ name: 'vulnerability_name', label: 'Nombre / ID Vulnerabilidad', type: 'text', required: true }, { name: 'affected_asset', label: 'Activo Afectado', type: 'text' }, { name: 'detection_date', label: 'Fecha de Detección', type: 'date' }, { name: 'severity', label: 'Severidad', type: 'select', options: ['Baja', 'Media', 'Alta', 'Crítica'] }, { name: 'status', label: 'Estado', type: 'select', options: ['Pendiente', 'En Proceso', 'Parcheado', 'Riesgo Aceptado'] }, { name: 'patching_date', label: 'Fecha de Parcheo', type: 'date' }, { name: 'responsible', label: 'Responsable', type: 'text' }, { name: 'observations', label: 'Observaciones', type: 'textarea' }] },
  monitoring_docs: { title: 'Documentación de Monitorización', icon: FileText, columns: [{ accessorKey: 'title', header: 'Título' }, { accessorKey: 'document_type', header: 'Tipo' }, { accessorKey: 'review_date', header: 'Revisión' }, { accessorKey: 'file_name', header: 'Archivo' }], formFields: [{ name: 'title', label: 'Título del Documento', type: 'text', required: true }, { name: 'description', label: 'Descripción', type: 'textarea' }, { name: 'document_type', label: 'Tipo de Documento', type: 'text', placeholder: 'Ej: Guía, Procedimiento, Informe' }, { name: 'review_date', label: 'Fecha de Revisión', type: 'date' }, { name: 'file', label: 'Adjuntar Documento', type: 'file' }] },
};

const GenericItSection = ({ sectionKey, title, ...props }) => {
  const sectionConfig = otherItSections[sectionKey];
  return (
    <div className="p-4 bg-white/70 backdrop-blur-md rounded-xl shadow-md border border-gray-200/50">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800">{title}</h2>
        <Button onClick={() => props.handleOpenForm(sectionKey)} disabled={props.isReadOnly}>
          <PlusCircle className="mr-2 h-4 w-4" /> Añadir Registro
        </Button>
      </div>
      <GenericTable
        data={props.itHook[sectionKey]}
        columns={sectionConfig.columns}
        loading={props.itHook.loading}
        onEdit={(item) => props.handleOpenForm(sectionKey, item)}
        onDelete={(item) => props.handleDeleteItem(sectionKey, item)}
        isReadOnly={props.isReadOnly}
      />
    </div>
  );
};

const IntegrationsSubPage = ({ integrationFilters, ...props }) => {
  return (
    <div className="p-4 bg-white/70 backdrop-blur-md rounded-xl shadow-md border border-gray-200/50">
      <IntegrationsPage {...props} integrationFilters={integrationFilters} />
    </div>
  );
};

const MonitoringPage = (props) => {
  return (
    <Tabs defaultValue="integrations" className="w-full">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="integrations"><Plug className="w-4 h-4 mr-2"/>Integraciones</TabsTrigger>
        <TabsTrigger value="documentation"><FileIcon className="w-4 h-4 mr-2"/>Documentación</TabsTrigger>
      </TabsList>
      <TabsContent value="integrations" className="mt-6">
        <IntegrationsSubPage {...props} integrationFilters={['wazuh', 'kibana', 'elasticsearch']} />
      </TabsContent>
      <TabsContent value="documentation" className="mt-6">
        <GenericItSection sectionKey="monitoring_docs" title="Documentación de Monitorización" {...props} />
      </TabsContent>
    </Tabs>
  );
};

const IncidentsAndVulnerabilitiesPage = (props) => {
  return (
    <div className="space-y-8">
      <IncidentManagementPage {...props} />
      <GenericItSection sectionKey="vulnerabilities" title="Gestión de Vulnerabilidades y Parcheos" {...props} />
    </div>
  );
};

const ContinuityAndIncidentsPage = (props) => {
  const [isFormOpen, setFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [currentSectionKey, setCurrentSectionKey] = useState(null);

  const handleOpenForm = (sectionKey, item = null) => {
    setCurrentSectionKey(sectionKey);
    setEditingItem(item);
    setFormOpen(true);
  };
  
  const handleCloseForm = () => {
    setCurrentSectionKey(null);
    setEditingItem(null);
    setFormOpen(false);
  };

  const handleSubmit = async (formData) => {
    const file = formData.file;
    delete formData.file;

    if (editingItem) {
      await props.itHook.updateItem(currentSectionKey, editingItem.id, formData, file);
    } else {
      await props.itHook.addItem(currentSectionKey, formData, file);
    }
    handleCloseForm();
  };

  const handleDeleteItem = (sectionKey, item) => {
    setCurrentSectionKey(sectionKey);
    setItemToDelete(item);
  };

  const confirmDelete = async () => {
    if(itemToDelete) {
      await props.itHook.deleteItem(currentSectionKey, itemToDelete.id);
      setItemToDelete(null);
    }
  };

  const getSectionConfig = () => {
    return otherItSections[currentSectionKey];
  };

  const sectionConfig = getSectionConfig();

  return (
    <>
      <Helmet>
        <title>Continuidad de Negocio - Eguzki Core</title>
        <meta name="description" content="Gestión de Continuidad de Negocio, Respuesta a Incidentes y Monitorización." />
      </Helmet>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <div className="mb-6 flex items-center space-x-3">
          <ShieldAlert className="w-8 h-8 text-gradient-green" />
          <h1 className="text-3xl font-bold text-gray-800">
            Continuidad de Negocio
          </h1>
        </div>

        <Tabs defaultValue="continuity" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="continuity">
              <FileText className="w-4 h-4 mr-2" />
              Continuidad y Backups
            </TabsTrigger>
            <TabsTrigger value="incidents">
              <ShieldQuestion className="w-4 h-4 mr-2" />
              Incidentes y Vulnerabilidades
            </TabsTrigger>
            <TabsTrigger value="monitoring">
              <Activity className="w-4 h-4 mr-2" />
              Monitorización
            </TabsTrigger>
          </TabsList>

          <TabsContent value="continuity" className="mt-6">
            <BusinessContinuityPage {...props} />
          </TabsContent>
          <TabsContent value="incidents" className="mt-6">
            <IncidentsAndVulnerabilitiesPage {...props} handleOpenForm={handleOpenForm} handleDeleteItem={handleDeleteItem} />
          </TabsContent>
          <TabsContent value="monitoring" className="mt-6">
            <MonitoringPage {...props} handleOpenForm={handleOpenForm} handleDeleteItem={handleDeleteItem} />
          </TabsContent>
        </Tabs>

        <Dialog open={isFormOpen} onOpenChange={setFormOpen}>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingItem ? 'Editar' : 'Añadir'} {sectionConfig?.title}</DialogTitle>
              <DialogDescription>
                Completa la información para {editingItem ? 'actualizar el' : 'añadir un nuevo'} registro.
              </DialogDescription>
            </DialogHeader>
            <GenericForm
              fields={sectionConfig?.formFields || []}
              onSubmit={handleSubmit}
              onCancel={handleCloseForm}
              initialData={editingItem}
            />
          </DialogContent>
        </Dialog>
        
        <AlertDialog open={!!itemToDelete} onOpenChange={() => setItemToDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Confirmas la eliminación?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción es permanente y eliminará el registro.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </motion.div>
    </>
  );
};

export default ContinuityAndIncidentsPage;