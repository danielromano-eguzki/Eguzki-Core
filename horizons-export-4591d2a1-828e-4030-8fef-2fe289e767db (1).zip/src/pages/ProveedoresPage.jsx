import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog.jsx";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog.jsx";
import ProveedorForm from '@/components/proveedores/ProveedorForm.jsx';
import ProveedoresTable from '@/components/proveedores/ProveedoresTable.jsx';
import ExportMenu from '@/components/common/ExportMenu.jsx';

const supplierHeaders = [
  { label: 'Nombre', key: 'name' },
  { label: 'Servicios', key: 'services' },
  { label: 'Fecha Contrato', key: 'agreement_date' },
  { label: 'Criticidad', key: 'criticality_level' }
];

const ProveedoresPage = ({ 
  showToast, 
  suppliersHook,
  selectedClientId,
  isReadOnly,
}) => {
  const { suppliers, addSupplier, updateSupplier, deleteSupplier, loading: loadingSuppliers, getFileUrl } = suppliersHook;
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  const [supplierToDelete, setSupplierToDelete] = useState(null);

  const handleFormSubmit = async (formData, contractFile, questionnaireFile) => {
    if (editingSupplier) {
      await updateSupplier(editingSupplier.id, formData, contractFile, questionnaireFile);
    } else {
      await addSupplier(formData, contractFile, questionnaireFile);
    }
    setIsFormModalOpen(false);
    setEditingSupplier(null);
  };

  const openFormForNew = () => {
    if (!selectedClientId) {
      showToast("Acción Requerida", "Por favor, selecciona un cliente primero para poder añadir un proveedor.", "destructive");
      return;
    }
    setEditingSupplier(null);
    setIsFormModalOpen(true);
  };

  const openFormForEdit = (supplier) => {
    setEditingSupplier(supplier);
    setIsFormModalOpen(true);
  };
  
  const openDeleteDialog = (supplier) => {
    setSupplierToDelete(supplier);
  };

  const confirmDelete = async () => {
    if (supplierToDelete) {
      await deleteSupplier(supplierToDelete.id);
      setSupplierToDelete(null);
    }
  };

  const handleDownloadFile = async (filePath, desiredName) => {
    const url = await getFileUrl(filePath);
    if (url) {
        try {
            const response = await fetch(url);
            const blob = await response.blob();
            const link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            link.download = desiredName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(link.href);
        } catch (error) {
            showToast("Error de Descarga", "No se pudo descargar el archivo.", "destructive");
            console.error("Download error:", error);
        }
    }
  };
  
  const currentSuppliers = suppliers || [];

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center">
          Gestión de Proveedores
        </h2>
        <div className="flex items-center space-x-2">
          <ExportMenu 
            data={currentSuppliers} 
            headers={supplierHeaders} 
            filenamePrefix="inventario_proveedores" 
            reportTitle="Inventario de Proveedores"
            disabled={loadingSuppliers}
          />
          <Button onClick={openFormForNew} disabled={isReadOnly}>
            <PlusCircle className="mr-2 h-4 w-4" /> Nuevo Proveedor
          </Button>
        </div>
      </div>

      {loadingSuppliers && (
        <div className="flex justify-center items-center h-64">
          <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-12 h-12 border-4 border-green-500 border-t-transparent rounded-full"></motion.div>
        </div>
      )}

      {!loadingSuppliers && currentSuppliers.length === 0 && (
        <div className="text-center py-16 text-gray-500 bg-white/50 p-8 rounded-lg shadow">
          <p className="text-xl">No hay proveedores registrados.</p>
          <p>Puedes añadir uno nuevo usando el botón de "Nuevo Proveedor".</p>
        </div>
      )}

      {!loadingSuppliers && currentSuppliers.length > 0 && (
        <ProveedoresTable
          suppliers={currentSuppliers}
          onEdit={openFormForEdit}
          onDelete={openDeleteDialog}
          onDownloadFile={handleDownloadFile}
          loading={loadingSuppliers}
          isReadOnly={isReadOnly}
        />
      )}

      <Dialog open={isFormModalOpen} onOpenChange={(isOpen) => { if (!isOpen) setEditingSupplier(null); setIsFormModalOpen(isOpen); }}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader><DialogTitle>{editingSupplier ? 'Editar' : 'Nuevo'} Proveedor</DialogTitle></DialogHeader>
          <ProveedorForm onSubmit={handleFormSubmit} onCancel={() => setIsFormModalOpen(false)} existingSupplier={editingSupplier} isReadOnly={isReadOnly} />
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={!!supplierToDelete} onOpenChange={() => setSupplierToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Estás seguro?</AlertDialogTitle></AlertDialogHeader>
          <AlertDialogDescription>Esta acción no se puede deshacer. Esto eliminará permanentemente al proveedor y sus documentos asociados.</AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Sí, eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );
};

export default ProveedoresPage;