import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { PlusCircle, FileText, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog.jsx";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog.jsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import NormativeDocumentForm from '@/components/cuerpo_normativo/NormativeDocumentForm.jsx';
import NormativeDocumentsTable from '@/components/cuerpo_normativo/NormativeDocumentsTable.jsx';
import ExportMenu from '@/components/common/ExportMenu.jsx';
import TemplateAdoptionModal from '@/components/cuerpo_normativo/TemplateAdoptionModal.jsx';

import { supabase } from '@/lib/customSupabaseClient.js';

const documentHeaders = [
  { label: 'ID Documento', key: 'doc_id' },
  { label: 'Descripción', key: 'description' },
  { label: 'Tipo', key: 'type' },
  { label: 'Fuente', key: 'source_type' },
  { label: 'Departamento Responsable', key: 'responsible_department' },
  { label: 'Fecha Aprobación', key: 'approval_date' },
  { label: 'Resumen', key: 'summary' },
  { label: 'Fecha Creación', key: 'created_at' }
];

const CuerpoNormativoPage = ({
  normativeDocumentsHook,
  showToast,
  isReadOnly,
  selectedClientId,
  userId,
}) => {
  const { documents, addDocument, updateDocument, deleteDocument, loading, getFileUrl, refetchDocuments } = normativeDocumentsHook;
  
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [editingDocument, setEditingDocument] = useState(null);
  const [documentToDelete, setDocumentToDelete] = useState(null);
  const [allCertifications, setAllCertifications] = useState([]);

  useEffect(() => {
    const fetchAllCertificationsAndRequirements = async () => {
      if (!userId || !selectedClientId) return;
      const { data: certs, error } = await supabase
        .from('certificaciones')
        .select(`
          id,
          name,
          requirements:requisitos_certificacion (
            id,
            codigo,
            titulo
          )
        `)
        .eq('client_id', selectedClientId);
      
      if (error) {
        console.error("Error fetching certifications for form", error);
      } else {
        setAllCertifications(certs || []);
      }
    };
    fetchAllCertificationsAndRequirements();
  }, [userId, selectedClientId]);

  const handleFormSubmit = async (formData, attachmentFile, linkedReqs) => {
    if (editingDocument) {
      await updateDocument(editingDocument.id, formData, attachmentFile, linkedReqs);
    } else {
      await addDocument(formData, attachmentFile, linkedReqs);
    }
    setIsFormModalOpen(false);
    setEditingDocument(null);
  };

  const openFormForNew = () => {
    if (!selectedClientId) {
      showToast("Acción Requerida", "Por favor, selecciona un cliente primero para poder añadir un documento.", "destructive");
      return;
    }
    setEditingDocument(null);
    setIsFormModalOpen(true);
  };

  const openFormForEdit = (doc) => {
    setEditingDocument(doc);
    setIsFormModalOpen(true);
  };

  const openDeleteDialog = (doc) => {
    setDocumentToDelete(doc);
  };

  const confirmDelete = async () => {
    if (documentToDelete) {
      await deleteDocument(documentToDelete.id);
      setDocumentToDelete(null);
    }
  };
  
  const handleDownloadFile = async (filePath, desiredName) => {
    const url = await getFileUrl(filePath);
    if (url) {
      try {
        const response = await fetch(url);
        const blob = await response.blob();
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = desiredName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(link.href);
      } catch (error) {
        showToast("Error de Descarga", "No se pudo descargar el archivo.", "destructive");
        console.error("Download error:", error);
      }
    }
  };

  const handleAdoptTemplate = async (template) => {
    if (!selectedClientId) {
      showToast("Acción Requerida", "Por favor, selecciona un cliente primero para poder adoptar una plantilla.", "destructive");
      return;
    }
    
    const newDocumentData = {
      doc_id: `DOC-${template.title.substring(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`,
      description: template.title,
      type: template.document_type,
      summary: template.description,
      responsible_department: '',
      approval_date: null,
    };

    let newFile = null;
    if (template.file_path) {
      const { data: urlData, error: urlError } = await supabase.storage.from('document_templates').createSignedUrl(template.file_path, 3600);
      if (urlError) {
        console.error("Error getting template file URL:", urlError);
        showToast("Error", "No se pudo obtener la URL del archivo de la plantilla.", "destructive");
        return;
      }
      
      try {
        const response = await fetch(urlData.signedUrl);
        const blob = await response.blob();
        newFile = new File([blob], template.file_name, { type: blob.type });
      } catch (error) {
        console.error("Error fetching template file:", error);
        showToast("Error", "No se pudo obtener el archivo de la plantilla.", "destructive");
        return;
      }
    }

    await addDocument(newDocumentData, newFile, []);
    showToast('Plantilla Adoptada', `El documento "${template.title}" ha sido añadido a tu documentación interna.`, 'success');
    setIsTemplateModalOpen(false);
    refetchDocuments();
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center">
          Cuerpo Normativo
        </h2>
        <div className="flex items-center space-x-2">
          <ExportMenu 
            data={documents} 
            headers={documentHeaders} 
            filenamePrefix="cuerpo_normativo" 
            reportTitle="Inventario de Cuerpo Normativo"
            disabled={loading}
          />
          <Button onClick={() => setIsTemplateModalOpen(true)} disabled={isReadOnly} variant="outline">
            <Copy className="mr-2 h-4 w-4" /> Adoptar desde Plantilla
          </Button>
          <Button onClick={openFormForNew} disabled={isReadOnly}>
            <PlusCircle className="mr-2 h-4 w-4" /> Nuevo Documento
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="interna" className="w-full">
        <TabsList className="grid w-full grid-cols-1">
          <TabsTrigger value="interna">
            <FileText className="mr-2 h-4 w-4" />
            Documentación Interna ({documents.length})
          </TabsTrigger>
        </TabsList>
        <TabsContent value="interna" className="mt-4">
          <NormativeDocumentsTable 
              title=""
              documents={documents}
              onEdit={openFormForEdit}
              onDelete={openDeleteDialog}
              onDownloadFile={handleDownloadFile}
              isReadOnly={isReadOnly}
              loading={loading}
          />
        </TabsContent>
      </Tabs>

      <Dialog open={isFormModalOpen} onOpenChange={(isOpen) => { if (!isOpen) setEditingDocument(null); setIsFormModalOpen(isOpen); }}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader><DialogTitle>{editingDocument ? 'Editar' : 'Nuevo'} Documento Normativo</DialogTitle></DialogHeader>
          <NormativeDocumentForm 
            onSubmit={handleFormSubmit} 
            onCancel={() => setIsFormModalOpen(false)} 
            existingDocument={editingDocument}
            certifications={allCertifications}
            isReadOnly={isReadOnly}
          />
        </DialogContent>
      </Dialog>

      <TemplateAdoptionModal
        isOpen={isTemplateModalOpen}
        onClose={() => setIsTemplateModalOpen(false)}
        onAdopt={handleAdoptTemplate}
        userId={userId}
        showToast={showToast}
        isReadOnly={isReadOnly}
      />
      
      <AlertDialog open={!!documentToDelete} onOpenChange={() => setDocumentToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Estás seguro?</AlertDialogTitle></AlertDialogHeader>
          <AlertDialogDescription>Esta acción no se puede deshacer. Esto eliminará permanentemente el documento y su archivo asociado.</AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Sí, eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </motion.div>
  );
};

export default CuerpoNormativoPage;