import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { PlusCircle, Edit, Trash2, Search, Eye } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { motion } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import IncidenteForm from '@/components/incidentes/IncidenteForm';
import IncidentDetails from '@/components/incidentes/IncidentDetails';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";


const IncidentManagementPage = ({ incidentesHook, isReadOnly }) => {
  const { incidents, addIncident, updateIncident, deleteIncident, loading } = incidentesHook;
  const [isFormOpen, setFormOpen] = useState(false);
  const [isDetailsOpen, setDetailsOpen] = useState(false);
  const [selectedIncident, setSelectedIncident] = useState(null);
  const [filters, setFilters] = useState({ searchTerm: '', status: 'all', severity: 'all' });

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const filteredIncidents = useMemo(() => {
    return (incidents || []).filter(inc => {
      const searchTermMatch = filters.searchTerm
        ? inc.name.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
          (inc.description && inc.description.toLowerCase().includes(filters.searchTerm.toLowerCase()))
        : true;
      const statusMatch = filters.status !== 'all' ? inc.status === filters.status : true;
      const severityMatch = filters.severity !== 'all' ? inc.severity === filters.severity : true;
      return searchTermMatch && statusMatch && severityMatch;
    });
  }, [incidents, filters]);

  const handleOpenForm = (incident = null) => {
    setSelectedIncident(incident);
    setFormOpen(true);
  };
  
  const handleCloseForm = () => {
    setFormOpen(false);
    setSelectedIncident(null);
  };

  const handleOpenDetails = (incident) => {
    setSelectedIncident(incident);
    setDetailsOpen(true);
  };

  const handleCloseDetails = () => {
    setDetailsOpen(false);
    setSelectedIncident(null);
  };
  
  const handleFormSubmit = async (formData, attachmentFile) => {
    if (selectedIncident) {
      await updateIncident(selectedIncident.id, formData, attachmentFile);
    } else {
      await addIncident(formData, attachmentFile);
    }
    handleCloseForm();
  };

  const handleDelete = async (id) => {
    await deleteIncident(id);
  };

  const getSeverityBadge = (severity) => {
    switch(severity) {
      case 'Crítico': return 'destructive';
      case 'Alto': return 'secondary';
      case 'Medio': return 'outline';
      case 'Bajo': return 'default';
      default: return 'default';
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>Inventario de Incidentes</CardTitle>
              <CardDescription>Registro y seguimiento de todos los incidentes de seguridad.</CardDescription>
            </div>
            <Button onClick={() => handleOpenForm(null)} disabled={isReadOnly}>
              <PlusCircle className="mr-2 h-4 w-4" /> Nuevo Incidente
            </Button>
          </div>
          <div className="flex items-center gap-2 pt-4">
            <div className="relative flex-grow">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <Input placeholder="Buscar por nombre o descripción..." className="pl-9" value={filters.searchTerm} onChange={e => handleFilterChange('searchTerm', e.target.value)} />
            </div>
            <Select value={filters.status} onValueChange={v => handleFilterChange('status', v)}>
              <SelectTrigger className="w-[180px]"><SelectValue placeholder="Estado" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los Estados</SelectItem>
                <SelectItem value="Nuevo">Nuevo</SelectItem>
                <SelectItem value="Investigando">Investigando</SelectItem>
                <SelectItem value="Contenido">Contenido</SelectItem>
                <SelectItem value="Erradicado">Erradicado</SelectItem>
                <SelectItem value="Recuperado">Recuperado</SelectItem>
                <SelectItem value="Cerrado">Cerrado</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filters.severity} onValueChange={v => handleFilterChange('severity', v)}>
              <SelectTrigger className="w-[180px]"><SelectValue placeholder="Severidad" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las Severidades</SelectItem>
                <SelectItem value="Bajo">Bajo</SelectItem>
                <SelectItem value="Medio">Medio</SelectItem>
                <SelectItem value="Alto">Alto</SelectItem>
                <SelectItem value="Crítico">Crítico</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nombre</TableHead>
                  <TableHead>Fecha del Incidente</TableHead>
                  <TableHead>Severidad</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading && <TableRow><TableCell colSpan={5} className="text-center">Cargando...</TableCell></TableRow>}
                {!loading && filteredIncidents.length === 0 && (
                  <TableRow><TableCell colSpan={5} className="text-center">No se encontraron incidentes.</TableCell></TableRow>
                )}
                {!loading && filteredIncidents.map((inc) => (
                  <TableRow key={inc.id}>
                    <TableCell className="font-medium">{inc.name}</TableCell>
                    <TableCell>{new Date(inc.incident_date).toLocaleString()}</TableCell>
                    <TableCell><Badge variant={getSeverityBadge(inc.severity)}>{inc.severity}</Badge></TableCell>
                    <TableCell><Badge variant="outline">{inc.status}</Badge></TableCell>
                    <TableCell>
                      <div className="flex space-x-1">
                        <Button variant="ghost" size="icon" onClick={() => handleOpenDetails(inc)}><Eye className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => handleOpenForm(inc)} disabled={isReadOnly}><Edit className="h-4 w-4" /></Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" disabled={isReadOnly}><Trash2 className="h-4 w-4 text-red-500" /></Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>¿Confirmas la eliminación?</AlertDialogTitle>
                              <AlertDialogDescription>Esta acción no se puede deshacer.</AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDelete(inc.id)} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      
      <IncidenteForm
        open={isFormOpen}
        onOpenChange={setFormOpen}
        onSubmit={handleFormSubmit}
        incidente={selectedIncident}
      />

      <Dialog open={isDetailsOpen} onOpenChange={handleCloseDetails}>
        <DialogContent className="sm:max-w-3xl md:max-w-4xl lg:max-w-5xl max-h-[90vh]">
          {selectedIncident && <IncidentDetails incident={selectedIncident} incidentesHook={incidentesHook} />}
        </DialogContent>
      </Dialog>
    </motion.div>
  );
};

export default IncidentManagementPage;