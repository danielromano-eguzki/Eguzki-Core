import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { PlusCircle, FileText, ListChecks, ServerCrash, Archive, RefreshCw, CheckCircle, XCircle, Edit, Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter as DialogFooterComponent } from '@/components/ui/dialog';
import { motion } from 'framer-motion';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import BiaSection from '@/components/business_continuity/BiaSection';
import CriticalProcessesSection from '@/components/business_continuity/CriticalProcessesSection';
import ContinuitySystemsSection from '@/components/business_continuity/ContinuitySystemsSection';
import CriticalAssetsBcSection from '@/components/business_continuity/CriticalAssetsBcSection';
import BackupTestForm from '@/components/incidentes/BackupTestForm';
import BackupInventoryForm from '@/components/incidentes/BackupInventoryForm';

import BiaForm from '@/components/business_continuity/BiaForm';
import CriticalProcessForm from '@/components/business_continuity/CriticalProcessForm';
import ContinuitySystemForm from '@/components/business_continuity/ContinuitySystemForm';
import CriticalAssetBcForm from '@/components/business_continuity/CriticalAssetBcForm';

const BusinessContinuityPage = ({ businessContinuityHook, showToast }) => {
  const { 
    bias, addBia, updateBia, deleteBia,
    criticalProcesses, addCriticalProcess, updateCriticalProcess, deleteCriticalProcess,
    continuitySystems, addContinuitySystem, updateContinuitySystem, deleteContinuitySystem, getContinuityDocumentUrl,
    criticalAssetsBc, addCriticalAssetBc, updateCriticalAssetBc, deleteCriticalAssetBc,
    backupInventory, addBackupInventoryItem, updateBackupInventoryItem, deleteBackupInventoryItem,
    backupTests, addBackupTest,
    loading, refetchAll
  } = businessContinuityHook;

  const [currentModal, setCurrentModal] = useState(null); 
  const [editingItem, setEditingItem] = useState(null);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [activeSection, setActiveSection] = useState(null);

  const openModal = (type, item = null) => {
    setCurrentModal(type);
    setEditingItem(item);
    setActiveSection(null); 
  };

  const closeModal = () => {
    setCurrentModal(null);
    setEditingItem(null);
  };
  
  const openSectionModal = (sectionType) => {
    setActiveSection(sectionType);
  };

  const closeSectionModal = () => {
    setActiveSection(null);
  };

  const openDeleteConfirm = (item, type) => {
    setItemToDelete({ ...item, type });
  };

  const closeDeleteConfirm = () => {
    setItemToDelete(null);
  };

  const handleDelete = async () => {
    if (!itemToDelete) return;
    const { id, type, document_path } = itemToDelete;
    switch (type) {
      case 'bia': await deleteBia(id); break;
      case 'critical_process': await deleteCriticalProcess(id); break;
      case 'continuity_system': await deleteContinuitySystem(id, document_path); break;
      case 'critical_asset_bc': await deleteCriticalAssetBc(id); break;
      case 'backup_inventory': await deleteBackupInventoryItem(id); break;
      default: break;
    }
    closeDeleteConfirm();
    refetchAll(); 
  };
  
  const sections = [
    { id: 'bia', title: 'Análisis de Impacto (BIA)', icon: FileText, description: 'Identifica procesos de negocio y el impacto que tendría su interrupción.', component: BiaSection, data: bias, formComponent: BiaForm, addFn: addBia, updateFn: updateBia },
    { id: 'critical_processes', title: 'Procesos Críticos', icon: ListChecks, description: 'Lista los procesos esenciales para la operación, derivados del BIA.', component: CriticalProcessesSection, data: criticalProcesses, formComponent: CriticalProcessForm, addFn: addCriticalProcess, updateFn: updateCriticalProcess, dependencies: { bias } },
    { id: 'continuity_systems', title: 'Políticas y DRPs', icon: ServerCrash, description: 'Define políticas, planes y sistemas para asegurar la continuidad (DRP, BCP).', component: ContinuitySystemsSection, data: continuitySystems, formComponent: ContinuitySystemForm, addFn: addContinuitySystem, updateFn: updateContinuitySystem, actions: { getContinuityDocumentUrl } },
    { id: 'critical_assets_bc', title: 'Activos Críticos para Continuidad', icon: Archive, description: 'Inventario de activos de información y tecnológicos vitales para la continuidad.', component: CriticalAssetsBcSection, data: criticalAssetsBc, formComponent: CriticalAssetBcForm, addFn: addCriticalAssetBc, updateFn: updateCriticalAssetBc },
  ];
  
  const handleInventorySubmit = async (formData) => {
    if (editingItem && currentModal === 'backup_inventory') {
      await updateBackupInventoryItem(editingItem.id, formData);
    } else {
      await addBackupInventoryItem(formData);
    }
    closeModal();
  };

  const handleTestSubmit = async (formData) => {
    await addBackupTest(formData);
    closeModal();
  };


  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <div className="mb-6 flex justify-between items-center">
        <div>
            <h2 className="text-2xl font-bold text-gradient-green">Panel de Continuidad de Negocio</h2>
             <p className="text-gray-600">
                Organice su estrategia de continuidad de negocio gestionando los elementos clave.
            </p>
        </div>
         <Button onClick={refetchAll} variant="outline" className="text-emerald-600 border-emerald-500 hover:bg-emerald-50">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refrescar Datos
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {sections.map((section) => (
          <motion.div key={section.id} whileHover={{ y: -5 }} className="hover-lift">
            <Card className="h-full flex flex-col">
              <CardHeader>
                <div className="flex items-center space-x-3 mb-2">
                  <section.icon className="w-8 h-8 text-emerald-600" />
                  <CardTitle className="text-xl text-gray-700">{section.title}</CardTitle>
                </div>
                <CardDescription className="text-sm text-gray-500 min-h-[40px]">{section.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow" />
              <CardFooter>
                <Button 
                  onClick={() => openSectionModal(section.id)} 
                  className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white"
                >
                  Gestionar {section.title}
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
      
      <div className="mt-8 space-y-8">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Inventario de Sistemas con Backup</CardTitle>
                <CardDescription>Detalle de la configuración de copias de seguridad por sistema.</CardDescription>
              </div>
              <Button onClick={() => openModal('backup_inventory')}><PlusCircle className="w-4 h-4 mr-2" /> Añadir Sistema</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sistema</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Frecuencia</TableHead>
                    <TableHead>Ubicación</TableHead>
                    <TableHead>Responsable</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading && <TableRow><TableCell colSpan={6} className="text-center">Cargando...</TableCell></TableRow>}
                  {!loading && backupInventory.length === 0 && (
                    <TableRow><TableCell colSpan={6} className="text-center">No hay sistemas en el inventario.</TableCell></TableRow>
                  )}
                  {!loading && backupInventory.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.system_name}</TableCell>
                      <TableCell><Badge variant="outline">{item.backup_type}</Badge></TableCell>
                      <TableCell>{item.frequency}</TableCell>
                      <TableCell>{item.storage_location}</TableCell>
                      <TableCell>{item.responsible_person}</TableCell>
                      <TableCell>
                        <div className="flex space-x-1">
                          <Button variant="ghost" size="icon" onClick={() => openModal('backup_inventory', item)}><Edit className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon" onClick={() => openDeleteConfirm(item, 'backup_inventory')}><Trash2 className="h-4 w-4 text-red-500" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Pruebas de Backups</CardTitle>
                <CardDescription>Registro histórico de las pruebas de restauración de copias de seguridad.</CardDescription>
              </div>
              <Button onClick={() => openModal('backup_test')}><PlusCircle className="w-4 h-4 mr-2" /> Registrar Prueba</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Sistema/Dato Restaurado</TableHead>
                    <TableHead>Resultado</TableHead>
                    <TableHead>Realizado Por</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading && <TableRow><TableCell colSpan={4} className="text-center">Cargando...</TableCell></TableRow>}
                  {!loading && backupTests.length === 0 && (
                    <TableRow><TableCell colSpan={4} className="text-center">No hay pruebas registradas.</TableCell></TableRow>
                  )}
                  {!loading && backupTests.map((test) => (
                    <TableRow key={test.id}>
                      <TableCell>{new Date(test.test_date).toLocaleDateString()}</TableCell>
                      <TableCell>{test.system_restored}</TableCell>
                      <TableCell>
                        <span className={`flex items-center ${test.result === 'Exitoso' ? 'text-green-600' : test.result === 'Fallido' ? 'text-red-600' : 'text-yellow-600'}`}>
                          {test.result === 'Exitoso' ? <CheckCircle className="w-4 h-4 mr-2" /> : <XCircle className="w-4 h-4 mr-2" />}
                          {test.result}
                        </span>
                      </TableCell>
                      <TableCell>{test.tested_by}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      <Dialog open={!!activeSection} onOpenChange={(open) => !open && closeSectionModal()}>
        <DialogContent className="sm:max-w-3xl md:max-w-4xl lg:max-w-5xl max-h-[90vh] flex flex-col">
          {activeSection && (() => {
            const sectionConfig = sections.find(s => s.id === activeSection);
            if (!sectionConfig) return null;
            const SectionComponent = sectionConfig.component;
            return (
              <>
                <DialogHeader>
                  <DialogTitle className="text-2xl text-gradient-green">{sectionConfig.title}</DialogTitle>
                  <DialogDescription>{sectionConfig.description}</DialogDescription>
                </DialogHeader>
                <div className="flex-grow overflow-y-auto p-1">
                  <SectionComponent
                    data={sectionConfig.data}
                    loading={loading}
                    onAdd={() => openModal(sectionConfig.id)}
                    onEdit={(item) => openModal(sectionConfig.id, item)}
                    onDelete={(item) => openDeleteConfirm(item, sectionConfig.id)}
                    actions={sectionConfig.actions}
                    dependencies={sectionConfig.dependencies}
                    showToast={showToast}
                  />
                </div>
                <DialogFooterComponent>
                  <Button variant="outline" onClick={closeSectionModal}>Cerrar</Button>
                </DialogFooterComponent>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>

      <Dialog open={!!currentModal} onOpenChange={(open) => !open && closeModal()}>
        <DialogContent className="sm:max-w-lg">
          {currentModal && (() => {
            const sectionConfig = sections.find(s => s.id === currentModal);
            if (currentModal === 'backup_inventory') {
              return <>
                <DialogHeader><DialogTitle>{editingItem ? 'Editar' : 'Añadir'} Sistema al Inventario</DialogTitle></DialogHeader>
                <BackupInventoryForm item={editingItem} onSubmit={handleInventorySubmit} onCancel={closeModal} />
              </>
            }
            if (currentModal === 'backup_test') {
              return <>
                <DialogHeader><DialogTitle>Registrar Prueba de Backup</DialogTitle></DialogHeader>
                <BackupTestForm onSubmit={handleTestSubmit} onCancel={closeModal} />
              </>
            }
            if (!sectionConfig) return null;
            const FormComponent = sectionConfig.formComponent;
            return (
              <>
                <DialogHeader>
                  <DialogTitle>
                    {editingItem ? 'Editar' : 'Añadir'} {sectionConfig.title.slice(0,-1)} 
                  </DialogTitle>
                </DialogHeader>
                <FormComponent 
                  item={editingItem} 
                  onSubmit={async (data, file) => { 
                    if(editingItem) {
                      await sectionConfig.updateFn(editingItem.id, data, file);
                    } else {
                      await sectionConfig.addFn(data, file);
                    }
                    closeModal(); 
                    await refetchAll();
                    if (!activeSection) {
                        openSectionModal(sectionConfig.id);
                    }
                  }} 
                  onCancel={closeModal}
                  bias={bias}
                />
              </>
            );
          })()}
        </DialogContent>
      </Dialog>

      <Dialog open={!!itemToDelete} onOpenChange={(open) => !open && closeDeleteConfirm()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar Eliminación</DialogTitle>
            <DialogDescription>
              ¿Está seguro de que desea eliminar este elemento? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooterComponent>
            <Button variant="outline" onClick={closeDeleteConfirm}>Cancelar</Button>
            <Button variant="destructive" onClick={handleDelete}>Eliminar</Button>
          </DialogFooterComponent>
        </DialogContent>
      </Dialog>

    </motion.div>
  );
};

export default BusinessContinuityPage;