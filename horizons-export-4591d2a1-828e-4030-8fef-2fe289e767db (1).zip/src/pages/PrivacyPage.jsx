import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';
import { ShieldCheck, ClipboardList, ShieldAlert, UserCheck, FileText, FileSignature, Globe, Gavel, ListChecks, FileText as ReportIcon } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import PolicySection from '@/components/privacy/PolicySection';
import RopaSection from '@/components/privacy/RopaSection';
import PiaSection from '@/components/privacy/PiaSection';
import DsrSection from '@/components/privacy/DsrSection';
import BreachSection from '@/components/privacy/BreachSection';
import ContractSection from '@/components/privacy/ContractSection';
import InternationalTransferSection from '@/components/privacy/InternationalTransferSection';
import GdprRequirementsChecklist from '@/components/privacy/GdprRequirementsChecklist';
import FullReportTab from '@/components/common/FullReportTab';

const PrivacyPage = ({ showToast, selectedClientId, isReadOnly, privacyHook, userId, supabase, clients }) => {
  const [gdprRequirements, setGdprRequirements] = useState([]);
  
  if (!selectedClientId) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center bg-white/50 p-8 rounded-lg shadow">
        <ShieldCheck className="w-16 h-16 mx-auto mb-4 text-gray-400" />
        <h2 className="text-2xl font-semibold text-gray-700">Gestión de Privacidad (GDPR)</h2>
        <p className="mt-2 text-gray-500">Por favor, selecciona un cliente para gestionar sus registros de privacidad.</p>
      </div>
    );
  }

  const selectedClient = clients.find(c => c.id === selectedClientId);

  return (
    <>
      <Helmet>
        <title>Gestión de Privacidad (GDPR) - Eguzki Core</title>
        <meta name="description" content="Gestiona el cumplimiento del GDPR, incluyendo ROPA, PIAs, DSRs y brechas de seguridad." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-6"
      >
        <Card className="bg-transparent border-none shadow-none">
          <CardHeader className="p-0">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full text-white shadow-lg">
                <ShieldCheck className="w-8 h-8" />
              </div>
              <div>
                <CardTitle className="text-3xl font-bold text-gray-900">Gestión de Privacidad (GDPR)</CardTitle>
                <CardDescription className="text-lg text-gray-600">
                  Centraliza la documentación y gestión del cumplimiento del Reglamento General de Protección de Datos.
                </CardDescription>
              </div>
            </div>
          </CardHeader>
        </Card>

        <Tabs defaultValue="policies" className="w-full">
          <TabsList className="grid w-full grid-cols-9 bg-white/60 backdrop-blur-lg rounded-xl p-2 h-auto">
            <TabsTrigger value="policies" className="flex-col h-full py-2">
              <Gavel className="w-5 h-5 mb-1" />
              <span className="text-xs sm:text-sm">Políticas</span>
            </TabsTrigger>
            <TabsTrigger value="ropa" className="flex-col h-full py-2">
              <FileText className="w-5 h-5 mb-1" />
              <span className="text-xs sm:text-sm">ROPA</span>
            </TabsTrigger>
            <TabsTrigger value="pia" className="flex-col h-full py-2">
              <ClipboardList className="w-5 h-5 mb-1" />
              <span className="text-xs sm:text-sm">PIAs</span>
            </TabsTrigger>
            <TabsTrigger value="dsr" className="flex-col h-full py-2">
              <UserCheck className="w-5 h-5 mb-1" />
              <span className="text-xs sm:text-sm">DSRs</span>
            </TabsTrigger>
            <TabsTrigger value="breaches" className="flex-col h-full py-2">
              <ShieldAlert className="w-5 h-5 mb-1" />
              <span className="text-xs sm:text-sm">Brechas</span>
            </TabsTrigger>
            <TabsTrigger value="contracts" className="flex-col h-full py-2">
              <FileSignature className="w-5 h-5 mb-1" />
              <span className="text-xs sm:text-sm">Contratos</span>
            </TabsTrigger>
            <TabsTrigger value="transfers" className="flex-col h-full py-2">
              <Globe className="w-5 h-5 mb-1" />
              <span className="text-xs sm:text-sm">Transf. Int.</span>
            </TabsTrigger>
            <TabsTrigger value="requirements" className="flex-col h-full py-2">
              <ListChecks className="w-5 h-5 mb-1" />
              <span className="text-xs sm:text-sm">Requisitos</span>
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex-col h-full py-2">
              <ReportIcon className="w-5 h-5 mb-1" />
              <span className="text-xs sm:text-sm">Informes</span>
            </TabsTrigger>
          </TabsList>
          <TabsContent value="policies">
            <PolicySection
              policies={privacyHook.policies}
              savePolicy={privacyHook.savePolicy}
              loading={privacyHook.loading}
              isReadOnly={isReadOnly}
            />
          </TabsContent>
          <TabsContent value="ropa">
             <RopaSection
                ropa={privacyHook.ropa}
                addRopa={privacyHook.addRopa}
                updateRopa={privacyHook.updateRopa}
                deleteRopa={privacyHook.deleteRopa}
                loading={privacyHook.loading}
                isReadOnly={isReadOnly}
                userId={userId}
                selectedClientId={selectedClientId}
                supabase={supabase}
              />
          </TabsContent>
          <TabsContent value="pia">
            <PiaSection
              pia={privacyHook.pia}
              addPia={privacyHook.addPia}
              updatePia={privacyHook.updatePia}
              deletePia={privacyHook.deletePia}
              loading={privacyHook.loading}
              isReadOnly={isReadOnly}
            />
          </TabsContent>
          <TabsContent value="dsr">
            <DsrSection
              dsr={privacyHook.dsr}
              addDsr={privacyHook.addDsr}
              updateDsr={privacyHook.updateDsr}
              deleteDsr={privacyHook.deleteDsr}
              loading={privacyHook.loading}
              isReadOnly={isReadOnly}
            />
          </TabsContent>
          <TabsContent value="breaches">
            <BreachSection
              breaches={privacyHook.breaches}
              addBreach={privacyHook.addBreach}
              updateBreach={privacyHook.updateBreach}
              deleteBreach={privacyHook.deleteBreach}
              loading={privacyHook.loading}
              isReadOnly={isReadOnly}
            />
          </TabsContent>
          <TabsContent value="contracts">
            <ContractSection
              contracts={privacyHook.contracts}
              addContract={privacyHook.addContract}
              updateContract={privacyHook.updateContract}
              deleteContract={privacyHook.deleteContract}
              loading={privacyHook.loading}
              isReadOnly={isReadOnly}
              supabase={supabase}
            />
          </TabsContent>
          <TabsContent value="transfers">
            <InternationalTransferSection
              transfers={privacyHook.internationalTransfers}
              addTransfer={privacyHook.addInternationalTransfer}
              updateTransfer={privacyHook.updateInternationalTransfer}
              deleteTransfer={privacyHook.deleteInternationalTransfer}
              loading={privacyHook.loading}
              isReadOnly={isReadOnly}
            />
          </TabsContent>
          <TabsContent value="requirements">
            <GdprRequirementsChecklist onRequirementsChange={setGdprRequirements} />
          </TabsContent>
          <TabsContent value="reports">
            <FullReportTab 
              requirements={gdprRequirements}
              normativeName="Reglamento General de Protección de Datos (GDPR)"
              clientName={selectedClient?.name || 'Cliente no seleccionado'}
            />
          </TabsContent>
        </Tabs>
      </motion.div>
    </>
  );
};

export default PrivacyPage;