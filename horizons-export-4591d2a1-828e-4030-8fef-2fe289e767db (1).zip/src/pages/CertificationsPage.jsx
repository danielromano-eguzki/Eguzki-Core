import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';
import { Award, Wifi, Server, Shield, AlertTriangle, ShieldCheck, Anchor, FileLock } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CRAPage from '@/pages/CRAPage';
import SOC2Page from '@/pages/SOC2Page';
import DORAPage from '@/pages/DORAPage';
import NIS2Page from '@/pages/NIS2Page';
import PrivacyPage from '@/pages/PrivacyPage';
import EnsPage from '@/pages/EnsPage';
import Iso27001Page from '@/pages/Iso27001Page';

const CertificationsPage = (props) => {
  return (
    <>
      <Helmet>
        <title>Certificaciones - Eguzki Core</title>
        <meta name="description" content="Gestiona certificaciones como CRA, SOC 2, DORA, NIS2, GDPR, ENS e ISO 27001." />
      </Helmet>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold text-gray-800 mb-6 flex items-center">
          <Award className="w-8 h-8 mr-3 text-gradient-green" />
          Certificaciones
        </h1>
        <Tabs defaultValue="privacy" className="w-full">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="privacy"><ShieldCheck className="w-4 h-4 mr-2"/>Privacidad (GDPR)</TabsTrigger>
            <TabsTrigger value="ens"><Anchor className="w-4 h-4 mr-2"/>ENS</TabsTrigger>
            <TabsTrigger value="iso27001"><FileLock className="w-4 h-4 mr-2"/>ISO 27001</TabsTrigger>
            <TabsTrigger value="cra"><Wifi className="w-4 h-4 mr-2"/>CRA</TabsTrigger>
            <TabsTrigger value="soc2"><Server className="w-4 h-4 mr-2"/>SOC 2</TabsTrigger>
            <TabsTrigger value="dora"><Shield className="w-4 h-4 mr-2"/>DORA</TabsTrigger>
            <TabsTrigger value="nis2"><AlertTriangle className="w-4 h-4 mr-2"/>NIS 2</TabsTrigger>
          </TabsList>
          <TabsContent value="privacy" className="mt-6">
            <PrivacyPage {...props} />
          </TabsContent>
          <TabsContent value="ens" className="mt-6">
            <EnsPage {...props} />
          </TabsContent>
          <TabsContent value="iso27001" className="mt-6">
            <Iso27001Page {...props} />
          </TabsContent>
          <TabsContent value="cra" className="mt-6">
            <CRAPage {...props} />
          </TabsContent>
          <TabsContent value="soc2" className="mt-6">
            <SOC2Page {...props} />
          </TabsContent>
          <TabsContent value="dora" className="mt-6">
            <DORAPage {...props} />
          </TabsContent>
          <TabsContent value="nis2" className="mt-6">
            <NIS2Page {...props} />
          </TabsContent>
        </Tabs>
      </motion.div>
    </>
  );
};

export default CertificationsPage;