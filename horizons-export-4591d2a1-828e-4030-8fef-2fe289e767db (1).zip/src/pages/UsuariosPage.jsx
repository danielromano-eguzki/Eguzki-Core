import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase } from 'lucide-react';

const UsuariosPage = ({ showToast, session, clients, addClient, updateClient, deleteClient, loadingClients, refetchClients, selectedClientId, setSelectedClientIdInApp }) => {
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h2 className="text-3xl font-bold text-gray-900 flex items-center">
          <Briefcase className="w-8 h-8 mr-3 text-gradient" />
          Página de Clientes (Anteriormente Usuarios)
        </h2>
      </div>
      <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg">
        <p className="text-lg text-gray-700">
          Esta página ha sido renombrada a "Mis Clientes" y su funcionalidad se ha movido a <code className="bg-gray-200 px-1 rounded">src/pages/ClientsPage.jsx</code>.
        </p>
        <p className="mt-4 text-gray-600">
          Ahora cada consultor (usuario de esta aplicación) puede gestionar sus propios clientes finales.
          Los datos como Activos, Riesgos, Normativas, etc., se segregan por el cliente seleccionado globalmente en la cabecera.
        </p>
         <p className="mt-2 text-gray-600">
          El email <code className="bg-gray-200 px-1 rounded">daniel.romano@eguzkiciberseguridad.com</code> ya no tiene un rol especial en esta página, ya que la gestión es por consultor y sus clientes asignados.
        </p>
      </div>
    </motion.div>
  );
};

export default UsuariosPage;