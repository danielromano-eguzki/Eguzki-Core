import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.jsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog.jsx";
import { ClipboardList, Archive } from 'lucide-react';
import FindingForm from '@/components/findings/FindingForm.jsx';
import FindingDetailsModal from '@/components/findings/FindingDetailsModal.jsx';
import FindingsHeader from '@/components/findings/FindingsHeader.jsx';
import FindingsStats from '@/components/findings/FindingsStats.jsx';
import FindingsToolbar from '@/components/findings/FindingsToolbar.jsx';
import FindingCard from '@/components/findings/FindingCard.jsx';
import FindingsTable from '@/components/findings/FindingsTable.jsx';
import ExportMenu from '@/components/common/ExportMenu.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const findingHeaders = [
  { label: 'ID', key: 'id' },
  { label: 'ID Personalizado', key: 'finding_id_custom' },
  { label: 'Tipo', key: 'type' },
  { label: 'Descripción', key: 'description' },
  { label: 'Requisito Afectado', key: 'requirement_text' },
  { label: 'Fuente', key: 'source' },
  { label: 'Estado', key: 'status' },
  { label: 'Prioridad', key: 'priority' },
  { label: 'Solución Propuesta', key: 'proposed_solution' },
  { label: 'Responsable', key: 'responsible' },
  { label: 'Fecha Límite', key: 'due_date' },
  { label: 'Fecha Creación', key: 'created_at' },
];

const FindingsPage = ({ 
  findingsHook,
  auditoriaInternaHook,
  certificationHook,
  evidenciasHook,
  session, 
  selectedClientId,
  showToast,
  isReadOnly
}) => {
  const { findings, addFinding, updateFinding, deleteFinding, loading: loadingFindings } = findingsHook;
  const { requirements } = certificationHook;
  const { auditPrograms } = auditoriaInternaHook;
  const { evidences, addEvidence, getEvidenceFileUrl } = evidenciasHook;

  const [searchTerm, setSearchTerm] = useState('');
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingFinding, setEditingFinding] = useState(null);
  const [findingToDelete, setFindingToDelete] = useState(null);
  const [findingToArchive, setFindingToArchive] = useState(null);
  const [detailsModalFinding, setDetailsModalFinding] = useState(null);
  const [viewMode, setViewMode] = useState('cards');
  const [activeTab, setActiveTab] = useState('active');

  const filteredFindings = useMemo(() => {
    const sourceFindings = activeTab === 'active' 
      ? (findings || []).filter(f => f.source_type !== 'historical')
      : (findings || []).filter(f => f.source_type === 'historical');

    return sourceFindings.filter(finding => 
      (finding.description && finding.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (finding.finding_id_custom && finding.finding_id_custom.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (finding.type && finding.type.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (finding.source && finding.source.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (finding.requirement_text && finding.requirement_text.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [findings, searchTerm, activeTab]);

  const handleFormSubmit = async (findingData, evidenceFile) => {
    let evidenceId = findingData.evidence_id;
    
    if (evidenceFile) {
        const evidenceFormData = {
            nombre: `Evidencia para hallazgo ${findingData.finding_id_custom || 'nuevo'}`,
            tipo: 'Evidencia de Hallazgo',
            fecha: new Date().toISOString().split('T')[0],
            responsable: findingData.responsible || session.user.email,
            comentarios: `Fichero adjunto para el hallazgo: ${findingData.description.substring(0, 50)}...`
        };
        const newEvidence = await addEvidence(evidenceFormData, evidenceFile, []);
        if (newEvidence) {
            evidenceId = newEvidence.id;
        }
    }

    const dataToSubmit = { ...findingData, client_id: selectedClientId, evidence_id: evidenceId };
    
    if (editingFinding) {
      await updateFinding(editingFinding.id, dataToSubmit);
    } else {
      const sourceType = activeTab === 'history' ? 'historical' : 'active';
      await addFinding({ ...dataToSubmit, source_type: sourceType });
    }
    setIsFormModalOpen(false);
    setEditingFinding(null);
  };
  
  const openFormForNew = () => {
    if (!selectedClientId) {
      showToast("Acción Requerida", "Por favor, selecciona un cliente primero para poder añadir un hallazgo.", "destructive");
      return;
    }
    setEditingFinding(null);
    setIsFormModalOpen(true);
  };
  
  const openFormForEdit = (finding) => {
    setEditingFinding(finding);
    setIsFormModalOpen(true);
  };
  
  const openDeleteModal = (finding) => setFindingToDelete(finding);
  const openArchiveModal = (finding) => setFindingToArchive(finding);

  const confirmDelete = async () => {
    if (findingToDelete) {
      await deleteFinding(findingToDelete.id);
      setFindingToDelete(null);
    }
  };

  const confirmArchive = async () => {
    if (findingToArchive) {
      await updateFinding(findingToArchive.id, { source_type: 'historical' });
      showToast("Hallazgo Archivado", "El hallazgo ha sido movido al registro histórico.", "default");
      setFindingToArchive(null);
    }
  };

  if (!selectedClientId) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center bg-white/50 p-8 rounded-lg shadow">
          <ClipboardList className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <h2 className="text-2xl font-semibold text-gray-700">Gestión de Hallazgos</h2>
          <p className="mt-2 text-gray-500">Por favor, selecciona un cliente en la cabecera para ver o gestionar sus hallazgos.</p>
        </div>
      );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <FindingsHeader onNewFindingClick={openFormForNew} />
      <FindingsStats findings={findings} />
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="flex justify-between items-center mb-4">
          <TabsList>
            <TabsTrigger value="active">Hallazgos Activos</TabsTrigger>
            <TabsTrigger value="history">Registro Histórico</TabsTrigger>
          </TabsList>
          <ExportMenu 
            data={filteredFindings} 
            headers={findingHeaders} 
            filenamePrefix={`informe_hallazgos_${activeTab}`}
            reportTitle={`Informe de Hallazgos (${activeTab === 'active' ? 'Activos' : 'Históricos'})`}
            disabled={loadingFindings}
          />
        </div>
        <FindingsToolbar
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          onFilterClick={() => showToast("Funcionalidad 'Filtros Avanzados'", "Próximamente podrás filtrar por tipo, estado, prioridad, etc.")}
        />

        <TabsContent value="active">
          {renderContent()}
        </TabsContent>
        <TabsContent value="history">
          {renderContent()}
        </TabsContent>
      </Tabs>

      <Dialog open={isFormModalOpen} onOpenChange={(isOpen) => { if (!isOpen) setEditingFinding(null); setIsFormModalOpen(isOpen); }}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader><DialogTitle>{editingFinding ? 'Editar' : 'Nuevo'} Hallazgo</DialogTitle></DialogHeader>
          <FindingForm 
            onSubmit={handleFormSubmit} 
            onCancel={() => setIsFormModalOpen(false)} 
            existingFinding={editingFinding}
            session={session}
            isReadOnly={isReadOnly}
            isHistorical={activeTab === 'history'}
          />
        </DialogContent>
      </Dialog>

      <FindingDetailsModal 
        finding={detailsModalFinding} 
        isOpen={!!detailsModalFinding} 
        onOpenChange={() => setDetailsModalFinding(null)}
        session={session}
        getEvidenceUrl={getEvidenceFileUrl}
      />

      <AlertDialog open={!!findingToDelete} onOpenChange={() => setFindingToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>Esta acción no se puede deshacer. Esto eliminará permanentemente el hallazgo.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Sí, eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!findingToArchive} onOpenChange={() => setFindingToArchive(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Archivar Hallazgo?</AlertDialogTitle>
            <AlertDialogDescription>Esta acción moverá el hallazgo al registro histórico. Podrás seguir viéndolo en la pestaña "Registro Histórico".</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmArchive}>Sí, archivar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );

  function renderContent() {
    if (loadingFindings) {
      return (
        <div className="flex justify-center items-center h-40">
          <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-12 h-12 border-4 border-green-500 border-t-transparent rounded-full"></motion.div>
        </div>
      );
    }
    
    if (filteredFindings.length === 0) {
      return (
        <div className="text-center py-10 text-gray-500 bg-white/50 p-8 rounded-lg shadow">
          <ClipboardList className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <p className="text-xl mb-2">No se han encontrado hallazgos.</p>
          <p>Puedes añadir uno nuevo usando el botón de "Nuevo Hallazgo".</p>
        </div>
      );
    }

    if (viewMode === 'cards') {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredFindings.map((finding, index) => (
            <FindingCard
              key={finding.id}
              finding={finding}
              index={index}
              onEdit={openFormForEdit}
              onDelete={openDeleteModal}
              onArchive={activeTab === 'active' ? openArchiveModal : null}
              onShowDetails={setDetailsModalFinding}
              isReadOnly={isReadOnly}
            />
          ))}
        </div>
      );
    }

    if (viewMode === 'table') {
      return (
        <FindingsTable
          findings={filteredFindings}
          onEdit={openFormForEdit}
          onDelete={openDeleteModal}
          onArchive={activeTab === 'active' ? openArchiveModal : null}
          onShowDetails={setDetailsModalFinding}
          isReadOnly={isReadOnly}
        />
      );
    }
    return null;
  }
};

export default FindingsPage;