import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import Joyride, { STATUS } from 'react-joyride';
import { 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  TrendingUp, 
  Target, 
  Upload, 
  Eye, 
  Brain, 
  ChevronRight,
  Briefcase
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import KeySecurityIndicators from '@/components/dashboard/KeySecurityIndicators.jsx';

const DashboardPage = ({ 
  showToast, 
  setActiveTab, 
  selectedClientId, 
  handleClientChange,
  clients,
  clientsHook,
  ensHook, 
  iso27001Hook,
  riesgosHook,
  incidentesHook,
  trainingsHook,
  assetsHook
}) => {
  const [runTour, setRunTour] = useState(false);
  const client = clients.find(c => c.id === selectedClientId);

  const tourSteps = [
    {
      target: '#welcome-banner',
      content: '¡Bienvenido a Eguzki Core! Este es tu centro de mando para la gestión de cumplimiento.',
      disableBeacon: true,
    },
    {
      target: '#stats-cards',
      content: 'Aquí tienes un resumen rápido del estado de tus controles de seguridad. Haz clic para ir a la sección correspondiente.',
    },
    {
      target: '#kpi-indicators',
      content: 'Estos son tus Indicadores Clave de Seguridad (KPIs/KRIs) para una visión general del rendimiento. Haz clic en uno para ir a la sección correspondiente.',
    },
    {
      target: '#frameworks-progress',
      content: 'Monitoriza el progreso de cumplimiento para cada normativa o framework que estés gestionando. Haz clic para ir a la sección correspondiente.',
    },
    {
      target: '#recent-activity',
      content: 'Mantente al día con las últimas actividades realizadas en la plataforma.',
    },
     {
      target: '.sidebar-nav',
      content: 'Usa esta barra lateral para navegar a las diferentes secciones como Clientes, Activos, Riesgos y más.',
    },
  ];

  const handleJoyrideCallback = (data) => {
    const { status } = data;
    if ([STATUS.FINISHED, STATUS.SKIPPED].includes(status)) {
      setRunTour(false);
    }
  };

  const allRequirements = useMemo(() => [
    ...(ensHook?.requirements || []),
    ...(iso27001Hook?.requirements || []),
  ], [ensHook?.requirements, iso27001Hook?.requirements]);

  const stats = useMemo(() => {
    const total = allRequirements.length;
    if (total === 0) return [
      { id: 'stats-completed', label: 'Controles Completados', value: 0, change: '0%', icon: CheckCircle, color: 'text-primary', navigateTo: 'ens' },
      { id: 'stats-review', label: 'Parcial', value: 0, change: '0%', icon: Clock, color: 'text-yellow-500', navigateTo: 'ens' },
      { id: 'stats-pending', label: 'No Cumplido', value: 0, change: '0%', icon: AlertTriangle, color: 'text-red-500', navigateTo: 'ens' },
      { id: 'stats-progress', label: 'Progreso Total', value: '0%', change: '0%', icon: TrendingUp, color: 'text-blue-500', navigateTo: 'ens' }
    ];

    const completed = allRequirements.filter(r => r.estado_cumplimiento === 'Cumplido').length;
    const partial = allRequirements.filter(r => r.estado_cumplimiento === 'Parcial').length;
    const notCompliant = allRequirements.filter(r => r.estado_cumplimiento === 'No cumplido').length;
    const progress = total > 0 ? Math.round(((completed + partial * 0.5) / total) * 100) : 0;

    return [
      { id: 'stats-completed', label: 'Controles Completados', value: completed, change: `${Math.round((completed / total) * 100)}%`, icon: CheckCircle, color: 'text-primary', navigateTo: 'ens' },
      { id: 'stats-review', label: 'Parcial', value: partial, change: `${Math.round((partial / total) * 100)}%`, icon: Clock, color: 'text-yellow-500', navigateTo: 'ens' },
      { id: 'stats-pending', label: 'No Cumplido', value: notCompliant, change: `${Math.round((notCompliant / total) * 100)}%`, icon: AlertTriangle, color: 'text-red-500', navigateTo: 'ens' },
      { id: 'stats-progress', label: 'Progreso Total', value: `${progress}%`, change: '', icon: TrendingUp, color: 'text-blue-500', navigateTo: 'ens' }
    ];
  }, [allRequirements]);

  const frameworks = useMemo(() => {
    const frameworksData = [];
    if (ensHook?.requirements?.length > 0) {
      const total = ensHook.requirements.length;
      const completed = ensHook.requirements.filter(r => r.estado_cumplimiento === 'Cumplido').length;
      const partial = ensHook.requirements.filter(r => r.estado_cumplimiento === 'Parcial').length;
      frameworksData.push({
        name: 'ENS',
        progress: total > 0 ? Math.round(((completed + partial * 0.5) / total) * 100) : 0,
        controls: total,
        color: 'bg-primary',
        navigateTo: 'ens'
      });
    }
    if (iso27001Hook?.requirements?.length > 0) {
      const total = iso27001Hook.requirements.length;
      const completed = iso27001Hook.requirements.filter(r => r.estado_cumplimiento === 'Cumplido').length;
      const partial = iso27001Hook.requirements.filter(r => r.estado_cumplimiento === 'Parcial').length;
      frameworksData.push({
        name: 'ISO 27001',
        progress: total > 0 ? Math.round(((completed + partial * 0.5) / total) * 100) : 0,
        controls: total,
        color: 'bg-blue-500',
        navigateTo: 'iso27001'
      });
    }
    return frameworksData;
  }, [ensHook, iso27001Hook]);
  
  const recentActivities = [
    { action: 'Evidencia subida', item: 'Política de Seguridad v2.1', time: 'Hace 2 horas', type: 'upload', navigateTo: 'evidencias' },
    { action: 'Control completado', item: 'A.8.1.1 - Inventario de activos', time: 'Hace 4 horas', type: 'complete', navigateTo: 'normativas' },
    { action: 'Revisión pendiente', item: 'Procedimiento de backup', time: 'Hace 1 día', type: 'review', navigateTo: 'auditoria_interna' },
    { action: 'IA sugiere mejora', item: 'Control A.12.6.1', time: 'Hace 2 días', type: 'ai', navigateTo: 'asistente' }
  ];

  const handleCardClick = (navigateTo) => {
    if (navigateTo && setActiveTab) {
      setActiveTab(navigateTo);
    } else if (navigateTo) {
      showToast("Navegación no disponible", "Intenta de nuevo o contacta soporte.");
    }
  };


  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <Joyride
        run={runTour}
        steps={tourSteps}
        continuous
        showProgress
        showSkipButton
        callback={handleJoyrideCallback}
        styles={{
          options: {
            arrowColor: '#ffffff',
            backgroundColor: '#ffffff',
            primaryColor: '#243430',
            textColor: '#333333',
            zIndex: 1000,
          },
          buttonClose: {
             display: 'none',
          },
        }}
        locale={{
          back: 'Atrás',
          close: 'Cerrar',
          last: 'Finalizar',
          next: 'Siguiente',
          skip: 'Saltar',
        }}
      />
      <div id="welcome-banner" className="bg-gradient-to-r from-primary to-[#3c514c] rounded-2xl p-8 text-white relative overflow-hidden">
        <div className="relative z-10">
          <h2 className="text-3xl font-bold mb-2">Bienvenido a Eguzki Core</h2>
          <p className="text-green-100 mb-1">Tu sistema de gestión integral de cumplimiento normativo está listo.</p>
          <p className="text-green-200 mb-6 text-sm">
            {client ? `Actualmente viendo el dashboard para: ${client.name}` : 'Selecciona un cliente para ver sus datos.'}
          </p>
          <Button 
            onClick={() => setRunTour(true)}
            className="bg-white text-primary hover:bg-gray-100"
          >
            Comenzar Tour Guiado
            <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32 animate-pulse-slow"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full -ml-24 -mb-24 animate-float"></div>
      </div>

      {selectedClientId ? (
        <>
          <div id="stats-cards" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.id}
                id={stat.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 hover-lift cursor-pointer transition-all hover:shadow-lg"
                onClick={() => handleCardClick(stat.navigateTo)}
              >
                <div className="flex items-center justify-between mb-4">
                  <stat.icon className={`w-8 h-8 ${stat.color}`} />
                  <span className="text-sm font-medium text-primary">{stat.change}</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</h3>
                <p className="text-gray-600 text-sm">{stat.label}</p>
              </motion.div>
            ))}
          </div>
          
          <div id="kpi-indicators">
            <KeySecurityIndicators 
              setActiveTab={setActiveTab}
              selectedClientId={selectedClientId}
              handleClientChange={handleClientChange}
              clients={clients}
              ensHook={ensHook}
              iso27001Hook={iso27001Hook}
              riesgosHook={riesgosHook}
              incidentesHook={incidentesHook}
              trainingsHook={trainingsHook}
              assetsHook={assetsHook}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <motion.div 
              id="frameworks-progress"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20"
            >
              <h3 className="text-xl font-bold mb-6 flex items-center">
                <Target className="w-6 h-6 mr-2 text-blue-600" />
                Progreso por Normativa
              </h3>
              <div className="space-y-4">
                {frameworks.length > 0 ? frameworks.map((framework, index) => (
                  <motion.div 
                    key={framework.name}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="space-y-2 p-3 rounded-lg hover:bg-white/50 transition-colors cursor-pointer"
                    onClick={() => handleCardClick(framework.navigateTo)}
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-medium">{framework.name}</span>
                      <span className="text-sm text-gray-600">{framework.progress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${framework.progress}%` }}
                        transition={{ delay: index * 0.2, duration: 1 }}
                        className={`h-2 rounded-full ${framework.color}`}
                      ></motion.div>
                    </div>
                    <p className="text-xs text-gray-500">{framework.controls} controles</p>
                  </motion.div>
                )) : <p className="text-gray-500 text-sm">No hay datos de normativas para este cliente.</p>}
              </div>
            </motion.div>

            <motion.div 
              id="recent-activity"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20"
            >
              <h3 className="text-xl font-bold mb-6 flex items-center">
                <Clock className="w-6 h-6 mr-2 text-purple-600" />
                Actividad Reciente
              </h3>
              <div className="space-y-4">
                {recentActivities.map((activity, index) => (
                  <motion.div 
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-start space-x-3 p-3 rounded-lg hover:bg-white/50 transition-colors cursor-pointer"
                    onClick={() => handleCardClick(activity.navigateTo)}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      activity.type === 'upload' ? 'bg-blue-100 text-blue-600' :
                      activity.type === 'complete' ? 'bg-green-100 text-primary' :
                      activity.type === 'review' ? 'bg-yellow-100 text-yellow-600' :
                      'bg-purple-100 text-purple-600'
                    }`}>
                      {activity.type === 'upload' && <Upload className="w-4 h-4" />}
                      {activity.type === 'complete' && <CheckCircle className="w-4 h-4" />}
                      {activity.type === 'review' && <Eye className="w-4 h-4" />}
                      {activity.type === 'ai' && <Brain className="w-4 h-4" />}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{activity.action}</p>
                      <p className="text-gray-600 text-xs">{activity.item}</p>
                      <p className="text-gray-400 text-xs">{activity.time}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </>
      ) : (
        <div className="flex flex-col items-center justify-center h-96 text-center bg-white/50 p-8 rounded-lg shadow">
          <Briefcase className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <h2 className="text-2xl font-semibold text-gray-700">Selecciona un Cliente</h2>
          <p className="mt-2 text-gray-500">Por favor, selecciona un cliente en el menú superior para ver su dashboard y KPIs.</p>
          <Button onClick={() => setActiveTab('clients')} className="mt-6">
            Ir a Clientes
          </Button>
        </div>
      )}
    </motion.div>
  );
};

export default DashboardPage;