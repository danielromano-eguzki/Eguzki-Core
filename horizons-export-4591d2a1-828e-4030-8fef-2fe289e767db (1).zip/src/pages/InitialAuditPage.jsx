import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ClipboardCheck, AlertTriangle, HelpCircle, ListChecks, Percent, Edit, Trash2, PlusCircle, Save, RotateCcw } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { format, parseISO } from 'date-fns';

const responseOptions = [
  { value: 'Aplicado', label: 'Aplicado' },
  { value: 'No Aplicado', label: 'No Aplicado' },
  { value: 'No Definido', label: 'No Definido' },
  { value: 'No Aplicable', label: 'No Aplicable' },
];

const priorityOptions = [
  { value: 'Alta', label: 'Alta' },
  { value: 'Media', label: 'Media' },
  { value: 'Baja', label: 'Baja' },
];

const statusOptions = [
  { value: 'Pendiente', label: 'Pendiente' },
  { value: 'En Progreso', label: 'En Progreso' },
  { value: 'Completado', label: 'Completado' },
];

const ActionItemFormModal = ({ isOpen, onClose, onSubmit, initialData, questionText, showToast }) => {
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('Media');
  const [status, setStatus] = useState('Pendiente');
  const [dueDate, setDueDate] = useState('');
  const [responsible, setResponsible] = useState('');

  useEffect(() => {
    if (initialData) {
      setDescription(initialData.action_item_description || '');
      setPriority(initialData.action_item_priority || 'Media');
      setStatus(initialData.action_item_status || 'Pendiente');
      setDueDate(initialData.action_item_due_date ? format(parseISO(initialData.action_item_due_date), 'yyyy-MM-dd') : '');
      setResponsible(initialData.action_item_responsible || '');
    } else {
      setDescription('');
      setPriority('Media');
      setStatus('Pendiente');
      setDueDate('');
      setResponsible('');
    }
  }, [initialData, isOpen]);

  const handleSubmit = () => {
    if (!description.trim()) {
      showToast('Descripción Requerida', 'La descripción de la acción a tomar es obligatoria.', 'destructive');
      return;
    }
    onSubmit({
      action_item_description: description,
      action_item_priority: priority,
      action_item_status: status,
      action_item_due_date: dueDate || null,
      action_item_responsible: responsible,
    });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[525px] bg-white/90 backdrop-blur-lg">
        <DialogHeader>
          <DialogTitle>Detalles de la Acción para: {questionText}</DialogTitle>
          <DialogDescription>
            Define los detalles para la acción correctiva o de mejora.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="action-description" className="text-right col-span-1">Acción</Label>
            <Textarea id="action-description" value={description} onChange={(e) => setDescription(e.target.value)} className="col-span-3" placeholder="Describe la acción a realizar..." />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="action-priority" className="text-right col-span-1">Prioridad</Label>
            <Select value={priority} onValueChange={setPriority}>
              <SelectTrigger id="action-priority" className="col-span-3"><SelectValue /></SelectTrigger>
              <SelectContent>{priorityOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="action-status" className="text-right col-span-1">Estado</Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger id="action-status" className="col-span-3"><SelectValue /></SelectTrigger>
              <SelectContent>{statusOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="action-due-date" className="text-right col-span-1">F. Límite</Label>
            <Input id="action-due-date" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="col-span-3" />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="action-responsible" className="text-right col-span-1">Responsable</Label>
            <Input id="action-responsible" value={responsible} onChange={(e) => setResponsible(e.target.value)} className="col-span-3" placeholder="Ej: Equipo de TI" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleSubmit}><Save className="w-4 h-4 mr-2" /> Guardar Acción</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};


const InitialAuditPage = ({ userId, selectedClientId, showToast, supabase, clients, initialAuditHook }) => {
  const {
    questions,
    responses,
    actionItems,
    complianceIndex,
    loadingQuestions,
    loadingResponses,
    savingResponse,
    saveResponse,
    refetchInitialAudit,
  } = initialAuditHook;

  const [isActionModalOpen, setIsActionModalOpen] = useState(false);
  const [currentQuestionForModal, setCurrentQuestionForModal] = useState(null);

  const groupedQuestions = useMemo(() => {
    return questions.reduce((acc, q) => {
      if (!acc[q.category]) acc[q.category] = [];
      acc[q.category].push(q);
      return acc;
    }, {});
  }, [questions]);

  const handleResponseChange = async (questionId, value) => {
    const currentResponse = responses[questionId];
    let actionDetails = {
      action_item_description: currentResponse?.action_item_description || null,
      action_item_priority: currentResponse?.action_item_priority || null,
      action_item_status: currentResponse?.action_item_status || null,
      action_item_due_date: currentResponse?.action_item_due_date || null,
      action_item_responsible: currentResponse?.action_item_responsible || null,
    };

    if (value === 'No Aplicado' || value === 'No Definido') {
      const question = questions.find(q => q.id === questionId);
      setCurrentQuestionForModal({ ...question, ...actionDetails });
      setIsActionModalOpen(true);
    } else {
      await saveResponse(questionId, value, { ...actionDetails, action_item_description: null }); // Limpiar acción si no es No Aplicado/Definido
    }
  };
  
  const handleSaveActionItem = async (actionData) => {
    if (currentQuestionForModal) {
      const responseValue = responses[currentQuestionForModal.id]?.response || (actionData.action_item_description ? 'No Definido' : 'No Aplicable');
      await saveResponse(currentQuestionForModal.id, responseValue, actionData);
    }
    setIsActionModalOpen(false);
    setCurrentQuestionForModal(null);
  };

  const openActionModalForExisting = (actionItem) => {
    const question = questions.find(q => q.id === actionItem.question_id);
    if (question) {
      setCurrentQuestionForModal({
        ...question,
        action_item_description: actionItem.description,
        action_item_priority: actionItem.priority,
        action_item_status: actionItem.status,
        action_item_due_date: actionItem.due_date,
        action_item_responsible: actionItem.responsible,
      });
      setIsActionModalOpen(true);
    }
  };

  const handleDeleteActionItem = async (questionId) => {
     if (window.confirm('¿Estás seguro de que quieres eliminar esta acción y marcar el ítem como "No Aplicable"?')) {
      await saveResponse(questionId, 'No Aplicable', {
        action_item_description: null,
        action_item_priority: null,
        action_item_status: null,
        action_item_due_date: null,
        action_item_responsible: null,
      });
    }
  };


  if (!selectedClientId && clients && clients.length > 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center bg-white/60 backdrop-blur-lg rounded-xl shadow-lg p-10">
        <AlertTriangle className="w-16 h-16 text-amber-500 mb-6" />
        <h2 className="text-2xl font-semibold text-gray-700 mb-2">Selecciona un Cliente</h2>
        <p className="text-gray-500 max-w-md">Por favor, elige un cliente para ver o completar su auditoría inicial.</p>
      </div>
    );
  }
  
  if (clients && clients.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center bg-white/60 backdrop-blur-lg rounded-xl shadow-lg p-10">
        <HelpCircle className="w-16 h-16 text-sky-500 mb-6" />
        <h2 className="text-2xl font-semibold text-gray-700 mb-2">No hay Clientes</h2>
        <p className="text-gray-500 max-w-md">Añade un cliente en "Mis Clientes" para poder realizar una auditoría inicial.</p>
      </div>
    );
  }

  const isLoading = loadingQuestions || loadingResponses || savingResponse;

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-800 flex items-center">
          <ClipboardCheck className="w-8 h-8 mr-3 text-gradient-green" />
          Auditoría Inicial Checklist
        </h1>
        <Button onClick={refetchInitialAudit} variant="outline" disabled={isLoading}>
          <RotateCcw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          {isLoading ? 'Actualizando...' : 'Refrescar'}
        </Button>
      </div>

      <Card className="bg-white/70 backdrop-blur-md">
        <CardHeader>
          <CardTitle className="flex items-center"><Percent className="w-6 h-6 mr-2 text-blue-600" />Índice de Cumplimiento</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-5xl font-bold text-blue-700 text-center py-4">
            {complianceIndex.toFixed(1)}%
          </div>
          <div className="w-full bg-gray-200 rounded-full h-4">
            <motion.div 
              className="bg-gradient-to-r from-sky-500 to-indigo-600 h-4 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${complianceIndex}%` }}
              transition={{ duration: 0.8, ease: "easeInOut" }}
            />
          </div>
        </CardContent>
      </Card>

      {Object.entries(groupedQuestions).map(([category, qs]) => (
        <Card key={category} className="bg-white/70 backdrop-blur-md">
          <CardHeader>
            <CardTitle>{category}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {qs.map((q) => (
              <div key={q.id} className="p-3 border rounded-lg bg-white/50 hover:shadow-md transition-shadow">
                <Label htmlFor={`q-${q.id}`} className="font-medium text-gray-700 block mb-2">{q.question_text}</Label>
                <div className="flex items-center space-x-3">
                  <Select 
                    value={responses[q.id]?.response || ''} 
                    onValueChange={(value) => handleResponseChange(q.id, value)}
                    disabled={savingResponse}
                  >
                    <SelectTrigger id={`q-${q.id}`} className="flex-grow bg-white">
                      <SelectValue placeholder="Selecciona una respuesta..." />
                    </SelectTrigger>
                    <SelectContent>
                      {responseOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  {(responses[q.id]?.response === 'No Aplicado' || responses[q.id]?.response === 'No Definido') && (
                    <Button variant="outline" size="sm" onClick={() => openActionModalForExisting({ question_id: q.id, ...responses[q.id] })}>
                      <Edit className="w-4 h-4 mr-1" /> {responses[q.id]?.action_item_description ? 'Editar Acción' : 'Añadir Acción'}
                    </Button>
                  )}
                </div>
                {responses[q.id]?.action_item_description && (responses[q.id]?.response === 'No Aplicado' || responses[q.id]?.response === 'No Definido') && (
                  <div className="mt-2 p-2 text-xs bg-amber-50 border border-amber-200 rounded">
                    <strong>Acción:</strong> {responses[q.id].action_item_description} 
                    {responses[q.id].action_item_priority && ` (P: ${responses[q.id].action_item_priority})`}
                    {responses[q.id].action_item_status && ` (E: ${responses[q.id].action_item_status})`}
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      ))}

      <Card className="bg-white/70 backdrop-blur-md">
        <CardHeader>
          <CardTitle className="flex items-center"><ListChecks className="w-6 h-6 mr-2 text-red-600" />Inventario de Acciones a Realizar</CardTitle>
        </CardHeader>
        <CardContent>
          {actionItems.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-4">No hay acciones pendientes o definidas.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50/50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Categoría</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ítem del Checklist</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acción a Realizar</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prioridad</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">F. Límite</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Responsable</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Editar/Elim.</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {actionItems.map(item => (
                    <motion.tr key={item.id} initial={{opacity:0}} animate={{opacity:1}}>
                      <td className="px-4 py-3 text-sm text-gray-600">{item.category}</td>
                      <td className="px-4 py-3 text-sm text-gray-600 max-w-xs truncate" title={item.question_text}>{item.question_text}</td>
                      <td className="px-4 py-3 text-sm text-gray-800 font-medium max-w-xs truncate" title={item.description}>{item.description}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm">
                        <span className={`font-semibold ${item.priority === 'Alta' ? 'text-red-600' : item.priority === 'Media' ? 'text-yellow-600' : 'text-green-600'}`}>{item.priority || '-'}</span>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600">{item.status || '-'}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600">{item.due_date ? format(parseISO(item.due_date), 'dd/MM/yyyy') : '-'}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600">{item.responsible || '-'}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-blue-600 hover:text-blue-800" onClick={() => openActionModalForExisting(item)}><Edit size={14}/></Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-red-600 hover:text-red-800" onClick={() => handleDeleteActionItem(item.question_id)}><Trash2 size={14}/></Button>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {currentQuestionForModal && (
        <ActionItemFormModal
          isOpen={isActionModalOpen}
          onClose={() => { setIsActionModalOpen(false); setCurrentQuestionForModal(null); }}
          onSubmit={handleSaveActionItem}
          initialData={currentQuestionForModal}
          questionText={currentQuestionForModal.question_text}
          showToast={showToast}
        />
      )}

      {(loadingQuestions || loadingResponses) && (
        <div className="fixed inset-0 bg-white/50 backdrop-blur-sm flex items-center justify-center z-50">
            <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full"></motion.div>
        </div>
      )}
    </motion.div>
  );
};

export default InitialAuditPage;