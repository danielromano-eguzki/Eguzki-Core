import React, { useState, useMemo, useEffect } from 'react';
import { Search, Link2, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/customSupabaseClient';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';

const EvidenceLinkerRow = ({ item, allRequirements, allCertifications, onLink, onUnlink, isReadOnly }) => {
  const [selectedReq, setSelectedReq] = useState('');

  const linkedReqs = item.linked_requirements || [];
  const availableReqs = allRequirements.filter(r => !linkedReqs.some(lr => lr.requirement_id === r.id));

  const getCertName = (certId) => {
    return allCertifications.find(c => c.id === certId)?.name || 'N/A';
  };

  const getReqDetails = (reqId) => {
    return allRequirements.find(r => r.id === reqId);
  };

  return (
    <TableRow>
      <TableCell>{item.name}</TableCell>
      <TableCell className="font-medium">
        <Badge variant="secondary">{item.type}</Badge>
      </TableCell>
      <TableCell>
        <div className="flex flex-col gap-2">
          {linkedReqs.map(link => {
            const req = getReqDetails(link.requirement_id);
            if (!req) return null;
            return (
              <div key={req.id} className="flex items-center justify-between text-xs p-1 rounded bg-gray-100 border">
                <span>{getCertName(req.certificacion_id)} - {req.codigo}</span>
                {!isReadOnly && (
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => onUnlink(item, req.id)}>
                    <X className="h-3 w-3 text-red-500" />
                  </Button>
                )}
              </div>
            );
          })}
          {!isReadOnly && (
            <div className="flex items-center gap-2 mt-1">
              <Select onValueChange={setSelectedReq} value={selectedReq}>
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue placeholder="Vincular requisito..." />
                </SelectTrigger>
                <SelectContent>
                  {availableReqs.map(req => (
                    <SelectItem key={req.id} value={req.id}>
                      {getCertName(req.certificacion_id)} - {req.codigo} - {req.titulo}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button size="sm" className="h-8" onClick={() => { onLink(item, selectedReq); setSelectedReq(''); }} disabled={!selectedReq}>
                Vincular
              </Button>
            </div>
          )}
        </div>
      </TableCell>
    </TableRow>
  );
};

const EvidencesPage = ({
  normativeDocumentsHook,
  isReadOnly,
  userId,
  selectedClientId,
  showToast
}) => {
  const { documents, loading: loadingNormativeDocs, refetchDocuments } = normativeDocumentsHook;

  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [allCertifications, setAllCertifications] = useState([]);
  const [allRequirements, setAllRequirements] = useState([]);
  const [loadingRequirements, setLoadingRequirements] = useState(false);

  const fetchRequirementsAndLinks = async () => {
    if (!userId || !selectedClientId) return;
    setLoadingRequirements(true);

    const certPromise = supabase.from('certificaciones').select('id, name').eq('client_id', selectedClientId);
    const reqPromise = supabase.from('requisitos_certificacion').select('id, codigo, titulo, certificacion_id').eq('client_id', selectedClientId);
    
    const [{ data: certs, error: certsError }, { data: reqs, error: reqsError }] = await Promise.all([certPromise, reqPromise]);

    if (certsError) showToast("Error", "No se pudieron cargar las certificaciones.", "destructive");
    else setAllCertifications(certs || []);

    if (reqsError) showToast("Error", "No se pudieron cargar los requisitos.", "destructive");
    else setAllRequirements(reqs || []);

    setLoadingRequirements(false);
  };

  useEffect(() => {
    fetchRequirementsAndLinks();
  }, [userId, selectedClientId]);

  const handleLink = async (item, requirementId) => {
    if (!requirementId) return;
    
    const { error } = await supabase.from('normative_document_requirement_link').insert({
      user_id: userId,
      client_id: selectedClientId,
      document_id: item.id,
      requirement_id: requirementId
    });

    if (error) {
      showToast("Error", "No se pudo crear la vinculación.", "destructive");
    } else {
      showToast("Éxito", "Vinculación creada.", "default");
      refetchDocuments();
    }
  };

  const handleUnlink = async (item, requirementId) => {
    const { error } = await supabase.from('normative_document_requirement_link')
      .delete()
      .match({ document_id: item.id, requirement_id: requirementId });

    if (error) {
      showToast("Error", "No se pudo eliminar la vinculación.", "destructive");
    } else {
      showToast("Éxito", "Vinculación eliminada.", "default");
      refetchDocuments();
    }
  };

  const documentTypes = useMemo(() => {
    if (!documents) return [];
    const types = new Set(documents
        .filter(d => d.source_type === 'internal' || d.source_type === 'generated')
        .map(d => d.type));
    return ['all', ...Array.from(types)];
  }, [documents]);

  const documentItems = useMemo(() => {
    let items = (documents || [])
      .filter(d => d.source_type === 'internal' || d.source_type === 'generated')
      .map(d => ({
        id: d.id,
        type: d.type,
        name: d.description,
        linked_requirements: d.linked_requirements || []
      }));

    if (typeFilter !== 'all') {
      items = items.filter(item => item.type === typeFilter);
    }

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      items = items.filter(item => item.name.toLowerCase().includes(term) || item.type.toLowerCase().includes(term));
    }
    
    return items;
  }, [documents, searchTerm, typeFilter]);

  const isLoading = loadingNormativeDocs || loadingRequirements;

  return (
    <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-gray-800">Vincular Evidencias a Requisitos</h2>
        <div className="flex items-center gap-2">
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtrar por tipo" />
            </SelectTrigger>
            <SelectContent>
              {documentTypes.map(type => (
                <SelectItem key={type} value={type}>
                  {type === 'all' ? 'Todos los tipos' : type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <Input placeholder="Buscar documentos..." className="pl-9" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
          </div>
        </div>
      </div>
      <p className="text-sm text-gray-600 mb-4">
        Esta sección centraliza todos los documentos del Cuerpo Normativo para que puedas vincularlos fácilmente a los requisitos de tus certificaciones.
      </p>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-12 h-12 border-4 border-green-500 border-t-transparent rounded-full"></motion.div>
        </div>
      ) : (
        <div className="rounded-lg border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nombre / Descripción</TableHead>
                <TableHead className="w-[250px]">Tipo de Documento</TableHead>
                <TableHead>Requisito Normativo Relacionado</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {documentItems.length > 0 ? (
                documentItems.map(item => (
                  <EvidenceLinkerRow
                    key={`${item.type}-${item.id}`}
                    item={item}
                    allRequirements={allRequirements}
                    allCertifications={allCertifications}
                    onLink={handleLink}
                    onUnlink={handleUnlink}
                    isReadOnly={isReadOnly}
                  />
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={3} className="h-24 text-center">
                    No se encontraron documentos. Añade algunos desde la pestaña 'Cuerpo Normativo'.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};

export default EvidencesPage;