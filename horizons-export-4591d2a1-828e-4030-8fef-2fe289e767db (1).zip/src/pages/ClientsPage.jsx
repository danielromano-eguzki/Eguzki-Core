import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserCheck, UserX } from 'lucide-react';
import ClientsHeader from '@/components/clients/ClientsHeader.jsx';
import ClientsToolbar from '@/components/clients/ClientsToolbar.jsx';
import ClientList from '@/components/clients/ClientList.jsx';
import ManageClientDialog from '@/components/clients/ManageClientDialog.jsx';
import DeleteClientDialog from '@/components/clients/DeleteClientDialog.jsx';
import DocumentViewerDialog from '@/components/clients/DocumentViewerDialog.jsx';

const ClientsPage = ({ showToast, isReadOnly, handleClientChange: onClientSelect, clientsHook }) => {
  const {
    clients,
    addClient,
    updateClient,
    deleteClient,
    updateClientStatus,
    loading: loadingClients,
    getClientFileUrl,
  } = clientsHook;

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState(null);
  const [clientToDelete, setClientToDelete] = useState(null);
  const [clientWithDocs, setClientWithDocs] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('activos');

  const handleFormSubmit = async (formData) => {
    if (isReadOnly) {
      showToast("Modo de solo lectura", "Tu rol de auditor no permite realizar modificaciones.", "destructive");
      return;
    }
    if (editingClient) {
      await updateClient(editingClient.id, formData);
    } else {
      await addClient(formData);
    }
    setIsModalOpen(false);
    setEditingClient(null);
  };

  const handleDownload = async (filePath) => {
    const url = await getClientFileUrl(filePath);
    if (url) {
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', '');
      link.setAttribute('target', '_blank');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const openAddNewModal = () => {
    if (isReadOnly) return;
    setEditingClient(null);
    setIsModalOpen(true);
  };

  const openEditModal = (client) => {
    if (isReadOnly) return;
    setEditingClient(client);
    setIsModalOpen(true);
  };

  const openDeleteAlert = (client) => {
    if (isReadOnly) return;
    setClientToDelete(client);
  };

  const confirmDelete = async () => {
    if (isReadOnly) return;

    if (clientToDelete) {
      const success = await deleteClient(clientToDelete.id);
      if (success) {
        const remainingClients = clients.filter(c => c.id !== clientToDelete.id);
        if (remainingClients.length > 0) {
          onClientSelect(remainingClients[0].id);
        } else {
          onClientSelect('');
        }
      }
    }
    setClientToDelete(null);
  };

  const filteredClients = useMemo(() => {
    if (!clients) return { activos: [], inactivos: [] };
    
    const filtered = clients.filter(client =>
      client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (client.description && client.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (client.contact_name && client.contact_name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (client.certification_goal && client.certification_goal.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    return {
      activos: filtered.filter(c => c.status === 'Activo'),
      inactivos: filtered.filter(c => c.status === 'Inactivo'),
    };

  }, [clients, searchTerm]);

  if (loadingClients) {
    return (
      <div className="flex justify-center items-center h-64">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-12 h-12 border-4 border-green-500 border-t-transparent rounded-full"></motion.div>
      </div>
    );
  }

  const handleStatusChange = (client, newStatus) => {
    if (isReadOnly) {
      showToast("Modo de solo lectura", "Tu rol de auditor no permite realizar modificaciones.", "destructive");
      return;
    }
    updateClientStatus(client.id, newStatus);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      <ClientsHeader onAddNew={openAddNewModal} isReadOnly={isReadOnly} />

      <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg">
        <ClientsToolbar searchTerm={searchTerm} onSearchChange={setSearchTerm} />
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="activos">
              <UserCheck className="mr-2 h-4 w-4" />
              Activos ({filteredClients.activos.length})
            </TabsTrigger>
            <TabsTrigger value="inactivos">
              <UserX className="mr-2 h-4 w-4" />
              Inactivos ({filteredClients.inactivos.length})
            </TabsTrigger>
          </TabsList>
          <TabsContent value="activos">
            <ClientList
              clients={filteredClients.activos}
              loading={loadingClients}
              onEdit={openEditModal}
              onDelete={openDeleteAlert}
              onShowDocs={setClientWithDocs}
              onStatusChange={handleStatusChange}
              isReadOnly={isReadOnly}
            />
          </TabsContent>
          <TabsContent value="inactivos">
            <ClientList
              clients={filteredClients.inactivos}
              loading={loadingClients}
              onEdit={openEditModal}
              onDelete={openDeleteAlert}
              onShowDocs={setClientWithDocs}
              onStatusChange={handleStatusChange}
              isReadOnly={isReadOnly}
            />
          </TabsContent>
        </Tabs>
      </div>

      <ManageClientDialog
        open={isModalOpen}
        onOpenChange={(isOpen) => { if (!isOpen) { setIsModalOpen(false); setEditingClient(null); } else { setIsModalOpen(true); } }}
        client={editingClient}
        onSubmit={handleFormSubmit}
        onCancel={() => { setIsModalOpen(false); setEditingClient(null); }}
        isReadOnly={isReadOnly}
        getClientFileUrl={getClientFileUrl}
      />

      <DeleteClientDialog
        client={clientToDelete}
        onConfirm={confirmDelete}
        onCancel={() => setClientToDelete(null)}
      />

      <DocumentViewerDialog
        client={clientWithDocs}
        onDownload={handleDownload}
        onClose={() => setClientWithDocs(null)}
      />
    </motion.div>
  );
};

export default ClientsPage;