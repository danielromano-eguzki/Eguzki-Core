import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Shield, PlusCircle, Edit, Trash, Filter, Search, FileText, FolderArchive, Download, UploadCloud, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import RequirementForm from '@/components/requisitos/RequirementForm';
import RequirementsTable from '@/components/requisitos/RequirementsTable';
import EvidenceForm from '@/components/evidencias/EvidenceForm';
import EvidencesInventoryTable from '@/components/evidencias/EvidencesInventoryTable';
import ExportMenu from '@/components/common/ExportMenu';

const requirementHeaders = [
  { label: 'Certificación', key: 'certificacion_name' },
  { label: 'Código', key: 'codigo' },
  { label: 'Título', key: 'titulo' },
  { label: 'Estado', key: 'estado_cumplimiento' },
  { label: 'Criticidad', key: 'criticidad' },
  { label: 'Tipo', key: 'tipo_requisito' },
];

const evidenceHeaders = [
  { label: 'ID', key: 'id' },
  { label: 'Nombre', key: 'nombre' },
  { label: 'Tipo', key: 'tipo' },
  { label: 'Departamento', key: 'departamento' },
  { label: 'Responsable', key: 'responsable' },
  { label: 'Fecha', key: 'fecha' },
  { label: 'Última Modificación', key: 'updated_at' },
];

const CertificationPage = ({
  showToast,
  certificationHook,
  certificationName,
  selectedClientId,
  isReadOnly,
}) => {
  const { 
    certification,
    requirements, addRequirement, updateRequirement, deleteRequirement,
    evidences, addEvidence, updateEvidence, deleteEvidence, getEvidenceFileUrl,
    loading, loadCertificationData, calculateHash,
    linkEvidenceToRequirement, unlinkEvidenceFromRequirement
  } = certificationHook;

  useEffect(() => {
    if (certificationName && selectedClientId) {
      loadCertificationData(certificationName);
    }
  }, [certificationName, selectedClientId, loadCertificationData]);

  const [mainTab, setMainTab] = useState('requirements');
  
  const [isReqFormOpen, setReqFormOpen] = useState(false);
  const [isEvidenceFormOpen, setEvidenceFormOpen] = useState(false);
  
  const [editingRequirement, setEditingRequirement] = useState(null);
  const [editingEvidence, setEditingEvidence] = useState(null);

  const [toDelete, setToDelete] = useState({ type: null, item: null });

  const [filters, setFilters] = useState({
    searchTerm: '',
    status: 'all',
    criticality: '',
    evidenceSearch: '',
  });

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const filteredRequirements = useMemo(() => {
    let result = requirements.map(r => ({
        ...r,
        certificacion_name: certification?.name || 'N/A'
      }));

    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      result = result.filter(r => 
        r.titulo.toLowerCase().includes(term) ||
        r.codigo?.toLowerCase().includes(term) ||
        r.descripcion?.toLowerCase().includes(term)
      );
    }
    if (filters.status && filters.status !== 'all') {
      result = result.filter(r => r.estado_cumplimiento === filters.status);
    }
    if (filters.criticality && filters.criticality !== 'all') {
      result = result.filter(r => r.criticidad === filters.criticality);
    }
    return result;
  }, [requirements, certification, filters]);

  const filteredEvidences = useMemo(() => {
    if (!filters.evidenceSearch) return evidences;
    const term = filters.evidenceSearch.toLowerCase();
    return evidences.filter(ev => 
      ev.nombre.toLowerCase().includes(term) ||
      ev.departamento?.toLowerCase().includes(term) ||
      ev.responsable?.toLowerCase().includes(term)
    );
  }, [evidences, filters.evidenceSearch]);

  const handleReqSubmit = async (formData, evidenceId, evidenceFile) => {
    if (editingRequirement) {
      await updateRequirement(editingRequirement.id, formData, evidenceId, evidenceFile);
    } else {
      await addRequirement(formData, evidenceId, evidenceFile);
    }
    setReqFormOpen(false);
    setEditingRequirement(null);
  };
  
  const handleEvidenceSubmit = async (formData, file, linkedReqs) => {
    if (editingEvidence) {
      await updateEvidence(editingEvidence.id, formData, file, linkedReqs);
    } else {
      await addEvidence(formData, file, linkedReqs);
    }
    setEvidenceFormOpen(false);
    setEditingEvidence(null);
  };

  const openReqForm = (req = null) => { setEditingRequirement(req); setReqFormOpen(true); };
  const openEvidenceForm = (ev = null) => { 
    setEditingEvidence(ev); 
    setEvidenceFormOpen(true);
    if(isReqFormOpen) setReqFormOpen(false);
  };

  const handleDelete = async () => {
    if (!toDelete.item) return;
    switch(toDelete.type) {
      case 'requirement': await deleteRequirement(toDelete.item.id); break;
      case 'evidence': await deleteEvidence(toDelete.item.id); break;
      default: break;
    }
    setToDelete({ type: null, item: null });
  };

  const handleDownloadEvidence = async (evidence) => {
    if (!evidence.file_path) return;
    const url = await getEvidenceFileUrl(evidence.file_path);
    if (url) {
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', evidence.file_name || 'download');
      document.body.appendChild(link);
      link.click();
      link.parentNode.removeChild(link);
    } else {
      showToast("Error", "No se pudo obtener la URL del archivo.", "destructive");
    }
  };

  const handleVerifyHash = (evidence) => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.onchange = async (e) => {
      const file = e.target.files[0];
      if (file) {
        showToast("Verificando...", "Calculando hash del fichero seleccionado.", "default");
        const newHash = await calculateHash(file);
        if (newHash === evidence.hash) {
          showToast("Verificación Exitosa", "El hash del fichero coincide con el almacenado. La integridad está confirmada.", "success");
        } else {
          showToast("Verificación Fallida", `El hash del fichero NO coincide. Original: ${evidence.hash.substring(0,10)}... Nuevo: ${newHash.substring(0,10)}...`, "destructive");
        }
      }
    };
    fileInput.click();
  };

  if (!selectedClientId) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center bg-white/50 p-8 rounded-lg shadow">
        <Shield className="w-16 h-16 mx-auto mb-4 text-gray-400" />
        <h2 className="text-2xl font-semibold text-gray-700">{certificationName}</h2>
        <p className="mt-2 text-gray-500">Por favor, selecciona un cliente para empezar.</p>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-800 flex items-center">
          <Shield className="w-8 h-8 mr-3 text-gradient-green" />
          {certificationName}
        </h1>
      </div>

      <Tabs value={mainTab} onValueChange={setMainTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="requirements"><FileText className="w-4 h-4 mr-2" />Gestión de Requisitos</TabsTrigger>
          <TabsTrigger value="evidences"><FolderArchive className="w-4 h-4 mr-2" />Inventario de Evidencias</TabsTrigger>
        </TabsList>
        
        <TabsContent value="requirements" className="mt-4">
            <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-800">Requisitos de {certificationName}</h2>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <Input placeholder="Buscar requisitos..." className="pl-9" value={filters.searchTerm} onChange={e => handleFilterChange('searchTerm', e.target.value)} />
                  </div>
                  <Select value={filters.status} onValueChange={v => handleFilterChange('status', v)}>
                    <SelectTrigger className="w-[150px]"><SelectValue placeholder="Estado" /></SelectTrigger>
                    <SelectContent><SelectItem value="all">Todos</SelectItem><SelectItem value="Cumplido">Cumplido</SelectItem><SelectItem value="Parcial">Parcial</SelectItem><SelectItem value="No cumplido">No cumplido</SelectItem><SelectItem value="No aplica">No aplica</SelectItem></SelectContent>
                  </Select>
                  <Button onClick={() => openReqForm()} disabled={isReadOnly}><PlusCircle className="mr-2 h-4 w-4" /> Nuevo</Button>
                </div>
              </div>
              {loading ? <p>Cargando...</p> : (
                <RequirementsTable
                  requirements={filteredRequirements}
                  evidences={evidences}
                  isReadOnly={isReadOnly}
                  onEdit={openReqForm}
                  onDelete={req => setToDelete({ type: 'requirement', item: req })}
                  getEvidenceFileUrl={getEvidenceFileUrl}
                  requirementsHook={{ linkEvidenceToRequirement, unlinkEvidenceFromRequirement }}
                />
              )}
            </div>
        </TabsContent>

        <TabsContent value="evidences" className="mt-4">
          <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-800">Inventario Central de Evidencias</h2>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input placeholder="Buscar evidencias..." className="pl-9" value={filters.evidenceSearch} onChange={e => handleFilterChange('evidenceSearch', e.target.value)} />
                </div>
                <ExportMenu data={filteredEvidences} headers={evidenceHeaders} filenamePrefix="evidencias" reportTitle="Inventario de Evidencias" disabled={loading} />
                <Button onClick={() => openEvidenceForm()} disabled={isReadOnly}><PlusCircle className="mr-2 h-4 w-4" /> Nueva Evidencia</Button>
              </div>
            </div>
            {loading ? <p>Cargando...</p> : (
              <EvidencesInventoryTable
                evidences={filteredEvidences}
                onEdit={openEvidenceForm}
                onDelete={ev => setToDelete({ type: 'evidence', item: ev })}
                onDownload={handleDownloadEvidence}
                onUpload={openEvidenceForm}
                onVerifyHash={handleVerifyHash}
                isReadOnly={isReadOnly}
              />
            )}
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={isReqFormOpen} onOpenChange={(isOpen) => { if(!isOpen) { setEditingRequirement(null); } setReqFormOpen(isOpen); }}>
        <DialogContent className="sm:max-w-3xl"><DialogHeader><DialogTitle>{editingRequirement ? 'Editar' : 'Nuevo'} Requisito</DialogTitle></DialogHeader>
          <RequirementForm 
            onSubmit={handleReqSubmit} 
            onCancel={() => setReqFormOpen(false)} 
            existingRequirement={editingRequirement} 
            certifications={certification ? [certification] : []}
            evidences={evidences}
            onOpenEvidenceForm={openEvidenceForm}
            isReadOnly={isReadOnly} 
           />
        </DialogContent>
      </Dialog>
      
      <Dialog open={isEvidenceFormOpen} onOpenChange={(isOpen) => { if(!isOpen) { setEditingEvidence(null); if(!isReqFormOpen && editingRequirement) { setReqFormOpen(true); }} setEvidenceFormOpen(isOpen); }}>
        <DialogContent className="sm:max-w-2xl"><DialogHeader><DialogTitle>{editingEvidence ? 'Editar' : 'Nueva'} Evidencia</DialogTitle></DialogHeader>
          <EvidenceForm 
            onSubmit={handleEvidenceSubmit} 
            onCancel={() => setEvidenceFormOpen(false)} 
            existingEvidence={editingEvidence} 
            isReadOnly={isReadOnly}
            requirements={requirements}
            certifications={certification ? [certification] : []}
            calculateHash={calculateHash}
          />
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!toDelete.item} onOpenChange={() => setToDelete({ type: null, item: null })}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Confirmas la eliminación?</AlertDialogTitle></AlertDialogHeader>
          <AlertDialogDescription>Esta acción es permanente y no se podrá deshacer.</AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );
};

export default CertificationPage;