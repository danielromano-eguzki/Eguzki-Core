import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Brain, Zap, Send, Sparkles } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const AsistentePage = ({ showToast, supabase, session, selectedClientId }) => {
  const [isConsultaModalOpen, setIsConsultaModalOpen] = useState(false);
  const [consultaText, setConsultaText] = useState('');
  const [iaMessage, setIaMessage] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const recomendaciones = [
    { 
      id: 'rec1',
      title: 'Control A.8.1.1 - Inventario de activos', 
      suggestion: 'Se recomienda actualizar el inventario con los nuevos equipos adquiridos en Q1. Considera añadir campos como "Fecha de Última Revisión" y "Criticidad".',
      priority: 'Alta',
      framework: 'ISO 27001'
    },
    { 
      id: 'rec2',
      title: 'Control A.12.6.1 - Gestión de vulnerabilidades', 
      suggestion: 'Implementar un proceso formal de gestión de parches de seguridad, incluyendo escaneos regulares y plazos de remediación definidos.',
      priority: 'Media',
      framework: 'ISO 27001'
    },
    { 
      id: 'rec3',
      title: 'Art. 32 GDPR - Seguridad del tratamiento', 
      suggestion: 'Documentar las medidas técnicas y organizativas implementadas para la protección de datos personales y realizar una DPIA para nuevos tratamientos.',
      priority: 'Alta',
      framework: 'GDPR'
    }
  ];

  const handleIniciarConsulta = () => {
    setConsultaText('');
    setIaMessage('');
    setIsConsultaModalOpen(true);
  };

  const handleEnviarConsulta = async () => {
    if (!consultaText.trim()) {
      showToast("Consulta vacía", "Por favor, escribe tu consulta para la IA.", "destructive");
      return;
    }
    setIsProcessing(true);
    setIaMessage('');

    try {
      // Asegúrate que el nombre 'openai-connector' es EXACTO al de tu Edge Function en Supabase.
      const { data, error: invokeError } = await supabase.functions.invoke('openai-connector', {
        body: JSON.stringify({ query: consultaText, clientId: selectedClientId })
      });

      if (invokeError) {
        console.error("Error al invocar Edge Function:", invokeError);
        let detailedErrorMessage = "Error al contactar el asistente. ";
        
        // Intenta obtener más detalles del error de invocación
        if (invokeError.message) {
          detailedErrorMessage += invokeError.message;
        }
        
        // A menudo, el error "Failed to send a request" viene con un contexto.
        // El objeto 'invokeError' podría tener una propiedad 'context' o similar
        // que a su vez podría contener la respuesta real del servidor (si la hubo).
        // Esto es un intento genérico de acceder a más detalles.
        if (invokeError.context && typeof invokeError.context.json === 'function') {
            try {
                const errorContextJson = await invokeError.context.json();
                detailedErrorMessage += ` Detalles: ${JSON.stringify(errorContextJson)}`;
            } catch (e) {
                detailedErrorMessage += ` (No se pudo parsear contexto del error: ${invokeError.context.statusText || 'Status desconocido'})`;
            }
        } else if (invokeError.context && invokeError.context.message) {
             detailedErrorMessage += ` Detalles del contexto: ${invokeError.context.message}`;
        } else if (typeof invokeError === 'object' && invokeError !== null) {
            detailedErrorMessage += ` (Detalles técnicos: ${JSON.stringify(invokeError)})`;
        }


        setIaMessage(`Error: ${detailedErrorMessage}`);
        showToast("Error de Invocación", detailedErrorMessage, "destructive");
        return;
      }
      
      // Si la invocación fue exitosa (no hubo invokeError), revisamos 'data'.
      // Una Edge Function bien diseñada podría devolver un error en su propia respuesta.
      if (data && data.error) { 
        console.error("Error devuelto por la Edge Function:", data.error);
        setIaMessage(`Error del asistente: ${data.error}`);
        showToast("Error del Asistente", `El asistente devolvió un error: ${data.error}`, "destructive");
      } else if (data && data.reply) {
        setIaMessage(data.reply);
      } else {
        // Si 'data' no tiene 'error' ni 'reply', es una respuesta inesperada.
        console.warn("Respuesta no esperada de la Edge Function:", data);
        const responsePreview = JSON.stringify(data)?.substring(0, 100) || "Respuesta vacía o no JSON";
        setIaMessage(`Respuesta inesperada del asistente: ${responsePreview}... Revisa los logs de la función.`);
        showToast("Respuesta Inesperada", `Se recibió una respuesta no válida del asistente: ${responsePreview}`, "warning");
      }

    } catch (err) {
      // Este catch es para errores de programación en este bloque try, o errores muy inesperados.
      console.error("Error crítico en handleEnviarConsulta:", err);
      let displayErrorMessage = "Ocurrió un problema inesperado al procesar tu consulta.";
      if (err.message) {
        displayErrorMessage = err.message;
      }
      setIaMessage(`Error crítico: ${displayErrorMessage}. Intenta de nuevo más tarde o revisa la consola.`);
      showToast("Error Crítico", displayErrorMessage, "destructive");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      <div className="text-center p-6 bg-gradient-to-b from-indigo-50 via-purple-50 to-pink-50 rounded-xl shadow-inner">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 120, delay: 0.2 }}
          className="inline-block p-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full shadow-lg mb-4"
        >
          <Brain className="w-12 h-12 text-white" />
        </motion.div>
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600 mb-3">
          Asistente de Cumplimiento IA
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Tu copiloto inteligente para navegar el complejo mundo del cumplimiento normativo. Haz preguntas, obtén sugerencias y automatiza tareas.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <motion.div 
          whileHover={{ scale: 1.03 }}
          className="bg-gradient-to-br from-purple-600 to-indigo-700 rounded-xl p-8 text-white shadow-xl hover:shadow-2xl transition-shadow duration-300"
        >
          <div className="flex items-center mb-4">
            <Sparkles className="w-10 h-10 mr-3 animate-pulse-slow" />
            <h3 className="text-2xl font-semibold">Iniciar Consulta con IA</h3>
          </div>
          <p className="text-purple-100 mb-6">
            ¿Tienes dudas sobre un control específico? ¿Necesitas ayuda para redactar una política? Pregúntale a nuestra IA.
          </p>
          <Dialog open={isConsultaModalOpen} onOpenChange={(isOpen) => { setIsConsultaModalOpen(isOpen); if(!isOpen) {setIaMessage(''); setConsultaText('');} }}>
            <DialogTrigger asChild>
              <Button onClick={handleIniciarConsulta} variant="outline" className="bg-white/20 text-white border-white/30 hover:bg-white/30 w-full">
                <Send className="w-5 h-5 mr-2" /> Iniciar Consulta
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg bg-white/90 backdrop-blur-md">
              <DialogHeader>
                <DialogTitle className="text-2xl font-semibold text-gray-800 flex items-center">
                  <Brain className="w-6 h-6 mr-2 text-purple-500" /> Consulta a Eguzki Brain IA
                </DialogTitle>
                <DialogDescription className="text-gray-600">
                  Escribe tu pregunta o el tema sobre el que necesitas asistencia. La IA intentará ayudarte con la información disponible.
                  {selectedClientId && <span className="block text-xs mt-1 text-purple-700">Contexto del cliente actual: {selectedClientId.substring(0,8)}...</span>}
                </DialogDescription>
              </DialogHeader>
              <div className="py-4 space-y-4">
                <div>
                  <Label htmlFor="consulta-text" className="text-gray-700">Tu consulta:</Label>
                  <Textarea
                    id="consulta-text"
                    value={consultaText}
                    onChange={(e) => setConsultaText(e.target.value)}
                    placeholder="Ej: ¿Cuáles son los requisitos clave para el control A.5.1 de ISO 27001?"
                    className="min-h-[100px] bg-white"
                    disabled={isProcessing}
                  />
                </div>
                {iaMessage && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`p-4 border rounded-md text-sm ${iaMessage.toLowerCase().startsWith('error') ? 'bg-red-50 border-red-200 text-red-800' : 'bg-purple-50 border-purple-200 text-purple-800'}`}
                  >
                    <pre className="whitespace-pre-wrap break-all font-sans">{iaMessage}</pre>
                  </motion.div>
                )}
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsConsultaModalOpen(false)} disabled={isProcessing}>
                  Cerrar
                </Button>
                <Button onClick={handleEnviarConsulta} className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white" disabled={isProcessing}>
                  {isProcessing ? (
                    <><motion.div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" /> Procesando...</>
                  ) : (
                    <><Send className="w-4 h-4 mr-2" /> Enviar Consulta</>
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </motion.div>

        <motion.div 
           whileHover={{ scale: 1.03 }}
           className="bg-gradient-to-br from-sky-500 to-teal-600 rounded-xl p-8 text-white shadow-xl hover:shadow-2xl transition-shadow duration-300"
        >
          <div className="flex items-center mb-4">
            <Zap className="w-10 h-10 mr-3 animate-pulse-slow" />
            <h3 className="text-2xl font-semibold">Sugerencias Inteligentes</h3>
          </div>
          <p className="text-sky-100 mb-6">
            Permite que la IA analice tu estado actual y te ofrezca recomendaciones personalizadas para mejorar tu cumplimiento.
          </p>
          <Button 
            onClick={() => showToast("Próximamente: Ver Sugerencias", "Esta función analizará tus datos para ofrecerte recomendaciones personalizadas.")} 
            variant="outline" 
            className="bg-white/20 text-white border-white/30 hover:bg-white/30 w-full"
          >
            <Zap className="w-5 h-5 mr-2" /> Ver Sugerencias
          </Button>
        </motion.div>
      </div>

      <div className="bg-white/80 backdrop-blur-xl rounded-2xl p-6 md:p-8 border border-white/30 shadow-lg">
        <h3 className="text-2xl font-bold mb-6 flex items-center text-gray-800">
          <Sparkles className="w-7 h-7 mr-3 text-purple-600" />
          Recomendaciones Destacadas
        </h3>
        {recomendaciones.length > 0 ? (
          <div className="space-y-5">
            {recomendaciones.map((rec, index) => (
              <motion.div 
                key={rec.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.15, type: "spring", stiffness: 100 }}
                className="p-5 bg-white rounded-xl border border-gray-200 shadow-md hover:shadow-lg transition-shadow duration-300"
              >
                <div className="flex flex-col sm:flex-row justify-between items-start mb-2">
                  <h4 className="font-semibold text-lg text-purple-700 mb-1 sm:mb-0">{rec.title}</h4>
                  <div className="flex space-x-2 flex-shrink-0">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      rec.priority === 'Alta' ? 'bg-red-100 text-red-700 border border-red-200' : 'bg-yellow-100 text-yellow-700 border border-yellow-200'
                    }`}>
                      Prioridad: {rec.priority}
                    </span>
                    <span className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-xs font-semibold border border-indigo-200">
                      {rec.framework}
                    </span>
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-4">{rec.suggestion}</p>
                <Button 
                  size="sm" 
                  variant="default"
                  className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
                  onClick={() => showToast("Implementar Sugerencia", `Acción para '${rec.title}' no implementada.`)}
                >
                  Ver Detalles y Acciones
                </Button>
              </motion.div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500 text-center py-4">No hay recomendaciones recientes. ¡Sigue trabajando en tu cumplimiento!</p>
        )}
      </div>
    </motion.div>
  );
};

export default AsistentePage;