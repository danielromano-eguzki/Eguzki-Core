import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';
import { Award, Wifi, Server, Shield, AlertTriangle } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CRAPage from '@/pages/CRAPage';
import SOC2Page from '@/pages/SOC2Page';
import DORAPage from '@/pages/DORAPage';
import NIS2Page from '@/pages/NIS2Page';

const OtherCertificationsPage = (props) => {
  return (
    <>
      <Helmet>
        <title>Otras Certificaciones - Eguzki Core</title>
        <meta name="description" content="Gestiona certificaciones como CRA, SOC 2, DORA y NIS2." />
      </Helmet>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold text-gray-800 mb-6 flex items-center">
          <Award className="w-8 h-8 mr-3 text-gradient-green" />
          Otras Certificaciones
        </h1>
        <Tabs defaultValue="cra" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="cra"><Wifi className="w-4 h-4 mr-2"/>CRA</TabsTrigger>
            <TabsTrigger value="soc2"><Server className="w-4 h-4 mr-2"/>SOC 2</TabsTrigger>
            <TabsTrigger value="dora"><Shield className="w-4 h-4 mr-2"/>DORA</TabsTrigger>
            <TabsTrigger value="nis2"><AlertTriangle className="w-4 h-4 mr-2"/>NIS 2</TabsTrigger>
          </TabsList>
          <TabsContent value="cra" className="mt-6">
            <CRAPage {...props} />
          </TabsContent>
          <TabsContent value="soc2" className="mt-6">
            <SOC2Page {...props} />
          </TabsContent>
          <TabsContent value="dora" className="mt-6">
            <DORAPage {...props} />
          </TabsContent>
          <TabsContent value="nis2" className="mt-6">
            <NIS2Page {...props} />
          </TabsContent>
        </Tabs>
      </motion.div>
    </>
  );
};

export default OtherCertificationsPage;