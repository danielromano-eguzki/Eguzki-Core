import React, { useState, useMemo, useEffect } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import {
      Dialog,
      DialogContent,
      DialogDescription,
      DialogHeader,
      DialogTitle,
      DialogTrigger,
    } from "@/components/ui/dialog";
    import {
      AlertDialog,
      AlertDialogAction,
      AlertDialogCancel,
      AlertDialogContent,
      AlertDialogDescription,
      AlertDialogFooter,
      AlertDialogHeader,
      AlertDialogTitle,
    } from "@/components/ui/alert-dialog";
    import {
      Archive, PlusCircle, Search, Upload
    } from 'lucide-react';
    import AssetForm from '@/components/assets/AssetForm.jsx';
    import AssetStatsCards from '@/components/assets/AssetStatsCards.jsx';
    import { AssetTable, AssetTableFilters } from '@/components/assets/AssetTable.jsx';
    import ExportMenu from '@/components/common/ExportMenu.jsx';
    import AssetImporter from '@/components/assets/AssetImporter.jsx';
    
    const assetHeaders = [
      { label: 'ID', key: 'id' },
      { label: 'Nombre', key: 'name' },
      { label: 'Tipo', key: 'type' },
      { label: 'Ubicación', key: 'location' },
      { label: 'Propietario', key: 'owner' },
      { label: 'Valor', key: 'value' },
      { label: 'Última Auditoría', key: 'last_audit' },
      { label: 'BYOD', key: 'byod' },
      { label: 'Riesgos Vinculados', key: 'risk_count'}
    ];
    
    const AssetsPage = ({ showToast, assetsHook, selectedClientId, isReadOnly, setActiveTab }) => {
      const { assets, addAsset, addMultipleAssets, updateAsset, deleteAsset, loading: loadingAssets } = assetsHook;
      const [isModalOpen, setIsModalOpen] = useState(false);
      const [isImporterOpen, setIsImporterOpen] = useState(false);
      const [editingAsset, setEditingAsset] = useState(null);
      const [assetToDelete, setAssetToDelete] = useState(null);
      const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);
      const [searchTerm, setSearchTerm] = useState('');
      const [filters, setFilters] = useState({ type: '', value: '', owner: '' });
      const [sortConfig, setSortConfig] = useState({ key: 'name', direction: 'ascending' });
    
      useEffect(() => {
        clearFilters();
      }, [selectedClientId]);
    
      const uniqueOwners = useMemo(() => [...new Set(assets.map(asset => asset.owner).filter(Boolean))], [assets]);
    
      const handleFormSubmit = (assetData) => {
        if (isReadOnly) {
          showToast("Modo de solo lectura", "Tu rol de auditor no permite realizar modificaciones.", "destructive");
          return;
        }
        if (editingAsset) {
          updateAsset(editingAsset.id, assetData);
        } else {
          addAsset(assetData);
        }
        setIsModalOpen(false);
        setEditingAsset(null);
      };
    
      const handleImportSubmit = async (importedAssets) => {
        if (isReadOnly) {
          showToast("Modo de solo lectura", "Tu rol de auditor no permite realizar modificaciones.", "destructive");
          return;
        }
        const { success, count } = await addMultipleAssets(importedAssets);
        if (success) {
          setIsImporterOpen(false);
        }
      };
    
      const openEditModal = (asset) => {
        if (isReadOnly) return;
        setEditingAsset(asset);
        setIsModalOpen(true);
      };
    
      const openDeleteAlert = (asset) => {
        if (isReadOnly) return;
        setAssetToDelete(asset);
        setIsDeleteAlertOpen(true);
      };
    
      const confirmDelete = () => {
        if (isReadOnly) {
          showToast("Modo de solo lectura", "Tu rol de auditor no permite realizar modificaciones.", "destructive");
          return;
        }
        if (assetToDelete) {
          deleteAsset(assetToDelete.id);
        }
        setIsDeleteAlertOpen(false);
        setAssetToDelete(null);
      };
    
      const handleFilterChange = (column, value) => {
        setFilters(prev => ({ ...prev, [column]: value }));
      };
    
      const requestSort = (key) => {
        let direction = 'ascending';
        if (sortConfig.key === key && sortConfig.direction === 'ascending') {
          direction = 'descending';
        }
        setSortConfig({ key, direction });
      };
    
      const clearFilters = () => {
        setSearchTerm('');
        setFilters({ type: '', value: '', owner: '' });
        setSortConfig({ key: 'name', direction: 'ascending' });
      };
    
      const sortedAndFilteredAssets = useMemo(() => {
        let processedAssets = assets.map(asset => ({
          ...asset,
          risk_count: asset.asset_risk_link?.length || 0
        }));
    
        if (searchTerm) {
          processedAssets = processedAssets.filter(asset =>
            Object.values(asset).some(val =>
              String(val).toLowerCase().includes(searchTerm.toLowerCase())
            )
          );
        }
        Object.keys(filters).forEach(key => {
          if (filters[key]) {
            processedAssets = processedAssets.filter(asset =>
              String(asset[key]).toLowerCase() === String(filters[key]).toLowerCase()
            );
          }
        });
        if (sortConfig.key) {
          processedAssets.sort((a, b) => {
            const valA = a[sortConfig.key];
            const valB = b[sortConfig.key];

            if (typeof valA === 'boolean' && typeof valB === 'boolean') {
              if (valA === valB) return 0;
              if (sortConfig.direction === 'ascending') {
                return valA ? -1 : 1;
              }
              return valA ? 1 : -1;
            }

            const strA = String(valA || '').toLowerCase();
            const strB = String(valB || '').toLowerCase();
            
            if (strA < strB) return sortConfig.direction === 'ascending' ? -1 : 1;
            if (strA > strB) return sortConfig.direction === 'ascending' ? 1 : -1;
            return 0;
          });
        }
        return processedAssets;
      }, [assets, searchTerm, filters, sortConfig]);
    
      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <AssetStatsCards assets={assets} />
    
          <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="flex flex-col sm:flex-row justify-between items-center mb-4 gap-4">
              <h3 className="text-xl font-bold text-gray-800">Inventario de Activos</h3>
              <div className="flex items-center space-x-2">
                <div className="relative w-full sm:w-auto">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input
                    type="text"
                    placeholder="Buscar en activos..."
                    className="pl-10 pr-4 py-2 w-full sm:w-64 bg-white/80"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <ExportMenu 
                  data={sortedAndFilteredAssets} 
                  headers={assetHeaders} 
                  filenamePrefix="inventario_activos" 
                  reportTitle="Inventario de Activos"
                  disabled={loadingAssets}
                />
                <Dialog open={isImporterOpen} onOpenChange={setIsImporterOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" disabled={isReadOnly}>
                      <Upload className="w-4 h-4 mr-2" />
                      Importar Activos
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-4xl bg-white/90 backdrop-blur-lg">
                    <DialogHeader>
                      <DialogTitle>Importar Activos desde CSV/XLSX</DialogTitle>
                      <DialogDescription>
                        Sube un fichero, mapea las columnas y añade múltiples activos de una sola vez.
                      </DialogDescription>
                    </DialogHeader>
                    <AssetImporter onSubmit={handleImportSubmit} onCancel={() => setIsImporterOpen(false)} />
                  </DialogContent>
                </Dialog>
                <Dialog open={isModalOpen} onOpenChange={(isOpen) => { setIsModalOpen(isOpen); if (!isOpen) setEditingAsset(null); }}>
                  <DialogTrigger asChild>
                    <Button onClick={() => { setEditingAsset(null); setIsModalOpen(true); }} disabled={isReadOnly}>
                      <PlusCircle className="w-4 h-4 mr-2" />
                      Añadir Activo
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[525px] bg-white/90 backdrop-blur-lg">
                    <DialogHeader>
                      <DialogTitle>{editingAsset ? 'Editar Activo' : 'Añadir Nuevo Activo'}</DialogTitle>
                      <DialogDescription>
                        {editingAsset ? 'Modifica la información del activo.' : 'Completa la información del nuevo activo.'}
                      </DialogDescription>
                    </DialogHeader>
                    <AssetForm onSubmit={handleFormSubmit} onCancel={() => { setIsModalOpen(false); setEditingAsset(null); }} existingAsset={editingAsset} isAuditorMode={isReadOnly} />
                  </DialogContent>
                </Dialog>
              </div>
            </div>
    
            <AssetTableFilters
              filters={filters}
              handleFilterChange={handleFilterChange}
              uniqueOwners={uniqueOwners}
              clearFilters={clearFilters}
            />
    
            <AssetTable
              assets={sortedAndFilteredAssets}
              sortConfig={sortConfig}
              requestSort={requestSort}
              onEdit={openEditModal}
              onDelete={openDeleteAlert}
              setActiveTab={setActiveTab}
              isAuditorMode={isReadOnly}
            />
             {loadingAssets && (
              <div className="flex justify-center items-center py-10">
                  <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-8 h-8 border-4 border-gray-300 border-t-transparent rounded-full"></motion.div>
              </div>
            )}
          </div>
          <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
                <AlertDialogDescription>
                  Esta acción no se puede deshacer. Esto eliminará permanentemente el activo "{assetToDelete?.name}" y cualquier riesgo vinculado.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setAssetToDelete(null)}>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </motion.div>
      );
    };
    
    export default AssetsPage;