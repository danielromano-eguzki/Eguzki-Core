import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';
import {
  Monitor, HardDrive, KeyRound, Users, GitMerge, FileText, Router, Layers, UserPlus, PlusCircle, ShieldAlert, ShieldQuestion, GraduationCap, Database, LayoutDashboard, Settings, Cloud, Activity, File, Plug, Upload, PlayCircle, FileCheck2, Download
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog.jsx";
import GenericTable from '@/components/it/GenericTable';
import GenericForm from '@/components/it/GenericForm';
import { cn } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ItDashboard from '@/components/it/ItDashboard';
import IntegrationsPage from '@/pages/IntegrationsPage';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';

const itSections = {
  software: { title: 'Inventario de Software', icon: Monitor, columns: [{ accessorKey: 'software_name', header: 'Nombre' }, { accessorKey: 'type', header: 'Tipo' }, { accessorKey: 'vendor_license', header: 'Licencia' }, { accessorKey: 'version', header: 'Versión' }, { accessorKey: 'install_date', header: 'Instalación' }, { accessorKey: 'associated_os', header: 'Sistema Operativo Asociado' }, { accessorKey: 'department', header: 'Departamento' }, { accessorKey: 'responsible_user', header: 'Usuario Responsable' }, { accessorKey: 'associated_risk', header: 'Riesgo Asociado' }, { accessorKey: 'grc_approval', header: 'Aprobado GRC' }], formFields: [{ name: 'software_name', label: 'Nombre del Software', type: 'text', required: true }, { name: 'type', label: 'Tipo', type: 'text' }, { name: 'vendor_license', label: 'Proveedor / Licencia', type: 'text' }, { name: 'version', label: 'Versión', type: 'text' }, { name: 'install_date', label: 'Fecha de Instalación', type: 'date' }, { name: 'associated_os', label: 'Sistema Operativo Asociado', type: 'text' }, { name: 'department', label: 'Departamento', type: 'text' }, { name: 'responsible_user', label: 'Usuario Responsable', type: 'text' }, { name: 'associated_risk', label: 'Riesgo Asociado', type: 'text' }, { name: 'grc_approval', label: 'Aprobación GRC', type: 'checkbox' }, { name: 'observations', label: 'Observaciones', type: 'textarea' }] },
  hardware: { title: 'Inventario de Equipos', icon: HardDrive, columns: [{ accessorKey: 'asset_tag', header: 'Etiqueta' }, { accessorKey: 'type', header: 'Tipo' }, { accessorKey: 'brand_model', header: 'Marca/Modelo' }, { accessorKey: 'assigned_user', header: 'Usuario' }, { accessorKey: 'status', header: 'Estado' }], formFields: [{ name: 'asset_tag', label: 'ID / Etiqueta', type: 'text' }, { name: 'type', label: 'Tipo (PC, portátil, móvil…)', type: 'text' }, { name: 'brand_model', label: 'Marca / Modelo', type: 'text' }, { name: 'serial_number', label: 'Nº de Serie', type: 'text' }, { name: 'location', label: 'Ubicación', type: 'text' }, { name: 'assigned_user', label: 'Usuario Asignado', type: 'text' }, { name: 'department', label: 'Departamento', type: 'text' }, { name: 'operating_system', label: 'Sistema Operativo', type: 'text' }, { name: 'acquisition_date', label: 'Fecha de Adquisición', type: 'date' }, { name: 'status', label: 'Estado (activo/baja)', type: 'text' }, { name: 'last_review', label: 'Última Revisión', type: 'date' }, { name: 'observations', label: 'Observaciones', type: 'textarea' }] },
  access: { title: 'Permisos y Accesos', icon: KeyRound, columns: [{ accessorKey: 'user_identity', header: 'Usuario' }, { accessorKey: 'system_app', header: 'Sistema/App' }, { accessorKey: 'access_level', header: 'Nivel' }, { accessorKey: 'grant_date', header: 'Concesión' }, { accessorKey: 'review_date', header: 'Revisión' }], formFields: [{ name: 'user_identity', label: 'Usuario', type: 'text' }, { name: 'department', label: 'Departamento', type: 'text' }, { name: 'role_position', label: 'Rol / Cargo', type: 'text' }, { name: 'system_app', label: 'Sistema / App', type: 'text' }, { name: 'access_level', label: 'Nivel de Acceso', type: 'text' }, { name: 'grant_date', label: 'Fecha de Concesión', type: 'date' }, { name: 'review_date', label: 'Fecha de Revisión', type: 'date' }, { name: 'authorized_by', label: 'Autorizado por', type: 'text' }, { name: 'evidence', label: 'Evidencia', type: 'text' }, { name: 'observations', label: 'Observaciones', type: 'textarea' }] },
  users: { title: 'Gestión de Usuarios', icon: Users, columns: [{ accessorKey: 'full_name', header: 'Nombre Completo' }, { accessorKey: 'corporate_email', header: 'Email' }, { accessorKey: 'department', header: 'Departamento' }, { accessorKey: 'position', header: 'Cargo' }, { accessorKey: 'status', header: 'Estado' }], formFields: [{ name: 'user_identity', label: 'ID / Usuario', type: 'text' }, { name: 'full_name', label: 'Nombre Completo', type: 'text' }, { name: 'corporate_email', label: 'Correo Corporativo', type: 'email' }, { name: 'department', label: 'Departamento', type: 'text' }, { name: 'position', label: 'Cargo', type: 'text' }, { name: 'start_date', label: 'Fecha de Alta', type: 'date' }, { name: 'end_date', label: 'Fecha de Baja', type: 'date' }, { name: 'responsible', label: 'Responsable', type: 'text' }, { name: 'assigned_systems', label: 'Sistemas Asignados', type: 'text' }, { name: 'status', label: 'Estado', type: 'text' }, { name: 'observations', label: 'Observaciones', type: 'textarea' }] },
  changes: { title: 'Control de Cambios', icon: GitMerge, columns: [{ accessorKey: 'description', header: 'Descripción' }, { accessorKey: 'affected_system', header: 'Sistema Afectado' }, { accessorKey: 'request_date', header: 'Fecha Solicitud' }, { accessorKey: 'status', header: 'Estado' }], formFields: [{ name: 'request_date', label: 'Fecha Solicitud', type: 'date' }, { name: 'requester', label: 'Solicitante', type: 'text' }, { name: 'description', label: 'Descripción', type: 'textarea' }, { name: 'affected_system', label: 'Sistema Afectado', type: 'text' }, { name: 'risk', label: 'Riesgo', type: 'text' }, { name: 'approver', label: 'Aprobador', type: 'text' }, { name: 'execution_date', label: 'Fecha de Ejecución', type: 'date' }, { name: 'status', label: 'Estado', type: 'text' }, { name: 'evidence', label: 'Evidencias', type: 'text' }, { name: 'observations', label: 'Observaciones', type: 'textarea' }] },
  guides: { title: 'Guías y Procedimientos', icon: FileText, columns: [{ accessorKey: 'title', header: 'Título' }, { accessorKey: 'type', header: 'Tipo' }, { accessorKey: 'technical_area', header: 'Área Técnica' }, { accessorKey: 'last_review', header: 'Última Revisión' }], formFields: [{ name: 'title', label: 'Título', type: 'text', required: true }, { name: 'type', label: 'Tipo (configuración, política…)', type: 'text' }, { name: 'technical_area', label: 'Área Técnica', type: 'text' }, { name: 'responsible', label: 'Responsable', type: 'text' }, { name: 'creation_date', label: 'Fecha Creación', type: 'date' }, { name: 'last_review', label: 'Última Revisión', type: 'date' }, { name: 'document_link', label: 'Enlace Documento', type: 'text' }, { name: 'status', label: 'Estado (borrador, aprobado…)', type: 'text' }, { name: 'observations', label: 'Observaciones', type: 'textarea' }] },
  connections: { title: 'Conexiones Críticas', icon: Router, columns: [{ accessorKey: 'origin_destination', header: 'Origen - Destino' }, { accessorKey: 'associated_service', header: 'Servicio' }, { accessorKey: 'encryption', header: 'Cifrado' }, { accessorKey: 'risk', header: 'Riesgo' }], formFields: [{ name: 'connection_type', label: 'Tipo de Conexión', type: 'text' }, { name: 'origin_destination', label: 'Origen – Destino', type: 'text' }, { name: 'associated_service', label: 'Servicio Asociado', type: 'text' }, { name: 'transmitted_data', label: 'Datos Transmitidos', type: 'text' }, { name: 'provider', label: 'Proveedor (si aplica)', type: 'text' }, { name: 'encryption', label: 'Cifrado', type: 'checkbox' }, { name: 'start_date', label: 'Fecha Alta', type: 'date' }, { name: 'technical_responsible', label: 'Responsable Técnico', type: 'text' }, { name: 'risk', label: 'Riesgo', type: 'text' }, { name: 'observations', label: 'Observaciones', type: 'textarea' }] },
  apps: { title: 'Apps y Proveedores', icon: Layers, columns: [{ accessorKey: 'application', header: 'Aplicación' }, { accessorKey: 'provider', header: 'Proveedor' }, { accessorKey: 'type', header: 'Tipo' }, { accessorKey: 'criticality', header: 'Criticidad' }, { accessorKey: 'grc_evaluation', header: 'Evaluación GRC' }], formFields: [{ name: 'application', label: 'Aplicación', type: 'text', required: true }, { name: 'provider', label: 'Proveedor', type: 'text' }, { name: 'type', label: 'Tipo (on-premise, SaaS…)', type: 'text' }, { name: 'function', label: 'Función (CRM, ERP…)', type: 'text' }, { name: 'user_department', label: 'Departamento Usuario', type: 'text' }, { name: 'criticality', label: 'Criticidad', type: 'text' }, { name: 'sla', label: 'SLA (Sí/No)', type: 'checkbox' }, { name: 'internal_responsible', label: 'Responsable Interno', type: 'text' }, { name: 'grc_evaluation', label: 'Evaluación GRC (Sí/No)', type: 'checkbox' }, { name: 'review_date', label: 'Fecha Revisión', type: 'date' }, { name: 'observations', label: 'Observaciones', type: 'textarea' }] },
  onboarding: { title: 'On/Offboarding', icon: UserPlus, columns: [{ accessorKey: 'employee_name', header: 'Empleado' }, { accessorKey: 'process_type', header: 'Proceso' }, { accessorKey: 'date', header: 'Fecha' }, { accessorKey: 'checklist_completed', header: 'Checklist OK' }, { accessorKey: 'status', header: 'Estado' }], formFields: [{ name: 'employee_name', label: 'Nombre Empleado', type: 'text' }, { name: 'process_type', label: 'Tipo de Proceso', type: 'select', options: ['Onboarding', 'Offboarding'] }, { name: 'date', label: 'Fecha Incorporación / Salida', type: 'date' }, { name: 'process_responsible', label: 'Responsable del Proceso', type: 'text' }, { name: 'access_granted_revoked', label: 'Accesos Concedidos / Revocados', type: 'textarea' }, { name: 'equipment_handled', label: 'Equipos Entregados / Recogidos', type: 'textarea' }, { name: 'training_imparted', label: 'Formación Impartida', type: 'textarea' }, { name: 'checklist_completed', label: 'Checklist Completado', type: 'checkbox' }, { name: 'validation_date', label: 'Fecha Validación', type: 'date' }, { name: 'status', label: 'Estado (en curso / completado)', type: 'text' }, { name: 'observations', label: 'Observaciones', type: 'textarea' }] },
};

const otherItSections = {
  hardening: { title: 'Plantillas de Configuración', icon: Settings, columns: [{ accessorKey: 'asset_name', header: 'Activo' }, { accessorKey: 'hardening_type', header: 'Tipo' }, { accessorKey: 'last_review_date', header: 'Última Revisión' }, { accessorKey: 'status', header: 'Estado' }, { accessorKey: 'file_name', header: 'Archivo Adjunto' }], formFields: [{ name: 'asset_name', label: 'Nombre del Activo', type: 'text', required: true }, { name: 'hardening_type', label: 'Tipo de Hardening', type: 'text' }, { name: 'description', label: 'Descripción', type: 'textarea' }, { name: 'baseline_link', label: 'Enlace a Baseline', type: 'text' }, { name: 'last_review_date', label: 'Fecha Última Revisión', type: 'date' }, { name: 'status', label: 'Estado', type: 'select', options: ['Conforme', 'No Conforme', 'En Proceso'] }, { name: 'responsible', label: 'Responsable', type: 'text' }, { name: 'file', label: 'Adjuntar Fichero', type: 'file' }, { name: 'observations', label: 'Observaciones', type: 'textarea' }] },
  cloud: { title: 'Servicios Cloud', icon: Cloud, integrationFilters: ['aws', 'azure'] },
};

const predefinedHardeningTemplates = [
  {
    title: 'Guía de Hardening para Windows Server 2022',
    description: 'Checklist y guía de configuración basada en las mejores prácticas de seguridad para Windows Server 2022.',
    type: 'Guía (PDF)',
  },
  {
    title: 'Script de Hardening para Ubuntu 22.04 LTS',
    description: 'Script de Bash para automatizar la aplicación de configuraciones de seguridad en servidores Ubuntu 22.04.',
    type: 'Script (Bash)',
  },
  {
    title: 'CIS Benchmark para Microsoft 365',
    description: 'Guía de configuración para asegurar el tenant de Microsoft 365 según el benchmark de CIS.',
    type: 'Benchmark (PDF)',
  },
  {
    title: 'Plantilla de GPO para Hardening de Endpoints Windows',
    description: 'Plantilla de Política de Grupo (GPO) para aplicar configuraciones de seguridad en estaciones de trabajo Windows 10/11.',
    type: 'Plantilla GPO',
  },
];

const ItInventories = (props) => {
  const [activeTab, setActiveTab] = useState('software');
  
  const sectionConfig = itSections[activeTab];

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="flex space-x-6">
        <aside className="w-1/4">
          <nav className="space-y-1">
            {Object.entries(itSections).map(([key, { title, icon: Icon }]) => (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                className={cn(
                  'w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-all text-sm font-medium',
                  activeTab === key
                    ? 'bg-primary text-primary-foreground shadow-md'
                    : 'text-gray-600 hover:bg-gray-100'
                )}
              >
                <Icon className="w-5 h-5" />
                <span>{title}</span>
              </button>
            ))}
          </nav>
        </aside>

        <main className="w-3/4">
          <div className="p-4 bg-white/70 backdrop-blur-md rounded-xl shadow-md border border-gray-200/50">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold text-gray-800">{sectionConfig.title}</h2>
              <Button onClick={() => props.handleOpenForm(activeTab)} disabled={props.isReadOnly}>
                <PlusCircle className="mr-2 h-4 w-4" /> Añadir Registro
              </Button>
            </div>
            <GenericTable
              data={props.itHook[activeTab]}
              columns={sectionConfig.columns}
              loading={props.itHook.loading}
              onEdit={(item) => props.handleOpenForm(activeTab, item)}
              onDelete={(item) => props.handleDeleteItem(activeTab, item)}
              isReadOnly={props.isReadOnly}
            />
          </div>
        </main>
      </div>
    </motion.div>
  );
};

const HardeningTemplatesSection = ({ sectionKey, ...props }) => {
  const sectionConfig = otherItSections[sectionKey];
  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Plantillas Predefinidas</CardTitle>
          <CardDescription>Utiliza estas plantillas como punto de partida para tus políticas de hardening.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {predefinedHardeningTemplates.map((template, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg bg-slate-50/50">
                <div>
                  <h4 className="font-semibold text-gray-800">{template.title}</h4>
                  <p className="text-sm text-muted-foreground">{template.description}</p>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-medium text-gray-500 bg-gray-200 px-2 py-1 rounded-full">{template.type}</span>
                  <Button variant="outline" size="sm" onClick={() => props.showToast()}>
                    <Download className="mr-2 h-4 w-4" /> Descargar
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Mis Plantillas de Configuración</CardTitle>
              <CardDescription>Sube y gestiona tus propias plantillas de hardening.</CardDescription>
            </div>
            <Button onClick={() => props.handleOpenForm(sectionKey)} disabled={props.isReadOnly}>
              <PlusCircle className="mr-2 h-4 w-4" /> Añadir Plantilla
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <GenericTable
            data={props.itHook[sectionKey]}
            columns={sectionConfig.columns}
            loading={props.itHook.loading}
            onEdit={(item) => props.handleOpenForm(sectionKey, item)}
            onDelete={(item) => props.handleDeleteItem(sectionKey, item)}
            isReadOnly={props.isReadOnly}
          />
        </CardContent>
      </Card>
    </div>
  );
};

const BestPracticeAssessmentModule = ({ showToast }) => {
  const [configFile, setConfigFile] = useState(null);

  const handleFileChange = (event) => {
    if (event.target.files && event.target.files.length > 0) {
      setConfigFile(event.target.files[0]);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Módulo de Evaluación de "Best Practices"</CardTitle>
        <CardDescription>
          Sube un fichero de configuración (ej. AWS Config export, GPO report) para evaluarlo contra una línea base de seguridad.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid w-full max-w-sm items-center gap-1.5">
          <label htmlFor="config-file" className="text-sm font-medium">Fichero de Configuración</label>
          <Input id="config-file" type="file" onChange={handleFileChange} />
        </div>
        {configFile && <p className="text-sm text-muted-foreground">Archivo seleccionado: {configFile.name}</p>}
        <Button onClick={() => showToast()} disabled={!configFile}>
          <FileCheck2 className="mr-2 h-4 w-4" /> Evaluar Configuración
        </Button>
      </CardContent>
    </Card>
  );
};

const AutomaticHardeningScripts = ({ showToast }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Scripts Automáticos de Hardening</CardTitle>
        <CardDescription>
          Ejecuta scripts predefinidos para aplicar configuraciones de seguridad en tus sistemas.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <h4 className="font-semibold">Hardening de Servidor Windows</h4>
              <p className="text-sm text-muted-foreground">Aplica las guías de CIS para Windows Server 2022.</p>
            </div>
            <Button variant="outline" onClick={() => showToast()}>
              <PlayCircle className="mr-2 h-4 w-4" /> Ejecutar
            </Button>
          </div>
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <h4 className="font-semibold">Hardening de Servidor Linux (Ubuntu)</h4>
              <p className="text-sm text-muted-foreground">Aplica configuraciones de seguridad recomendadas para Ubuntu 22.04.</p>
            </div>
            <Button variant="outline" onClick={() => showToast()}>
              <PlayCircle className="mr-2 h-4 w-4" /> Ejecutar
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const HardeningPage = (props) => {
  return (
    <Tabs defaultValue="templates" className="w-full">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="scripts"><PlayCircle className="w-4 h-4 mr-2"/>Scripts Automáticos</TabsTrigger>
        <TabsTrigger value="templates"><FileText className="w-4 h-4 mr-2"/>Plantillas de Configuración</TabsTrigger>
        <TabsTrigger value="assessment"><FileCheck2 className="w-4 h-4 mr-2"/>Evaluación de "Best Practices"</TabsTrigger>
      </TabsList>
      <TabsContent value="scripts" className="mt-6">
        <AutomaticHardeningScripts {...props} />
      </TabsContent>
      <TabsContent value="templates" className="mt-6">
        <HardeningTemplatesSection sectionKey="hardening" {...props} />
      </TabsContent>
      <TabsContent value="assessment" className="mt-6">
        <BestPracticeAssessmentModule {...props} />
      </TabsContent>
    </Tabs>
  );
};

const IntegrationsSubPage = ({ integrationFilters, ...props }) => {
  return (
    <div className="p-4 bg-white/70 backdrop-blur-md rounded-xl shadow-md border border-gray-200/50">
      <IntegrationsPage {...props} integrationFilters={integrationFilters} />
    </div>
  );
};

const ItPage = (props) => {
  const [isFormOpen, setFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [currentSectionKey, setCurrentSectionKey] = useState('software');

  const handleOpenForm = (sectionKey, item = null) => {
    setCurrentSectionKey(sectionKey);
    setEditingItem(item);
    setFormOpen(true);
  };
  
  const handleCloseForm = () => {
    setEditingItem(null);
    setFormOpen(false);
  };

  const handleSubmit = async (formData) => {
    const file = formData.file;
    delete formData.file;

    if (editingItem) {
      await props.itHook.updateItem(currentSectionKey, editingItem.id, formData, file);
    } else {
      await props.itHook.addItem(currentSectionKey, formData, file);
    }
    handleCloseForm();
  };

  const handleDeleteItem = (sectionKey, item) => {
    setCurrentSectionKey(sectionKey);
    setItemToDelete(item);
  };

  const confirmDelete = async () => {
    if(itemToDelete) {
      await props.itHook.deleteItem(currentSectionKey, itemToDelete.id);
      setItemToDelete(null);
    }
  };

  const getSectionConfig = () => {
    return itSections[currentSectionKey] || otherItSections[currentSectionKey];
  };

  const sectionConfig = getSectionConfig();

  return (
    <>
      <Helmet>
        <title>Gestión de IT - Eguzki Core</title>
        <meta name="description" content="Gestiona inventarios, hardening y servicios cloud." />
      </Helmet>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold text-gray-800 mb-6">Centro de Mando de IT</h1>
        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="dashboard"><LayoutDashboard className="w-4 h-4 mr-2"/>Dashboard</TabsTrigger>
            <TabsTrigger value="inventories"><Database className="w-4 h-4 mr-2"/>Inventarios</TabsTrigger>
            <TabsTrigger value="cloud"><Cloud className="w-4 h-4 mr-2"/>Cloud</TabsTrigger>
            <TabsTrigger value="hardening"><Settings className="w-4 h-4 mr-2"/>Hardening</TabsTrigger>
          </TabsList>
          <TabsContent value="dashboard" className="mt-6">
            <ItDashboard {...props} />
          </TabsContent>
          <TabsContent value="inventories" className="mt-6">
            <ItInventories {...props} handleOpenForm={handleOpenForm} handleDeleteItem={handleDeleteItem} />
          </TabsContent>
          <TabsContent value="cloud" className="mt-6">
            <IntegrationsSubPage {...props} integrationFilters={otherItSections.cloud.integrationFilters} />
          </TabsContent>
          <TabsContent value="hardening" className="mt-6">
            <HardeningPage {...props} handleOpenForm={handleOpenForm} handleDeleteItem={handleDeleteItem} />
          </TabsContent>
        </Tabs>

        <Dialog open={isFormOpen} onOpenChange={setFormOpen}>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingItem ? 'Editar' : 'Añadir'} {sectionConfig?.title}</DialogTitle>
              <DialogDescription>
                Completa la información para {editingItem ? 'actualizar el' : 'añadir un nuevo'} registro.
              </DialogDescription>
            </DialogHeader>
            {sectionConfig?.formFields && (
              <GenericForm
                fields={sectionConfig.formFields}
                onSubmit={handleSubmit}
                onCancel={handleCloseForm}
                initialData={editingItem}
              />
            )}
          </DialogContent>
        </Dialog>
        
        <AlertDialog open={!!itemToDelete} onOpenChange={() => setItemToDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Confirmas la eliminación?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción es permanente y eliminará el registro.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </motion.div>
    </>
  );
};

export default ItPage;