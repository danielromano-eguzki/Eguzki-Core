import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plug, Settings, ExternalLink, Info, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { useIntegrations } from '@/hooks/useIntegrations'; 

const staticIntegrationsList = [
  {
    id: 'jira',
    name: 'Jira',
    description: 'Sincroniza tareas, hallazgos e incidentes con tus proyectos de Jira.',
    logoPlaceholder: '🧩',
    category: 'Gestión de Proyectos',
    docsLink: '#',
    fields: [
      { name: 'instanceUrl', label: 'URL de Instancia Jira', type: 'text', placeholder: 'https://tu-dominio.atlassian.net' },
      { name: 'email', label: 'Email de Usuario Jira', type: 'email', placeholder: 'usuario@ejemplo.com' },
      { name: 'apiToken', label: 'API Token', type: 'password', placeholder: 'Tu API Token de Jira' },
    ]
  },
  {
    id: 'confluence',
    name: 'Confluence',
    description: 'Vincula documentación de Confluence a controles, riesgos y políticas.',
    logoPlaceholder: '📚',
    category: 'Documentación',
    docsLink: '#',
    fields: [
      { name: 'instanceUrl', label: 'URL de Instancia Confluence', type: 'text', placeholder: 'https://tu-dominio.atlassian.net' },
      { name: 'email', label: 'Email de Usuario Confluence', type: 'email', placeholder: 'usuario@ejemplo.com' },
      { name: 'apiToken', label: 'API Token', type: 'password', placeholder: 'Tu API Token de Confluence' },
    ]
  },
  {
    id: 'clickup',
    name: 'ClickUp',
    description: 'Gestiona tareas de cumplimiento y acciones correctivas directamente en ClickUp.',
    logoPlaceholder: '🎯',
    category: 'Gestión de Proyectos',
    docsLink: '#',
    fields: [
      { name: 'apiToken', label: 'API Token de ClickUp', type: 'password', placeholder: 'pk_xxxxxxxxxxxx' },
      { name: 'teamId', label: 'ID del Equipo (Opcional)', type: 'text', placeholder: 'ID del equipo/espacio a usar' },
    ]
  },
  {
    id: 'googledrive',
    name: 'Google Drive',
    description: 'Conecta y gestiona evidencias y documentos almacenados en Google Drive.',
    logoPlaceholder: '☁️',
    category: 'Almacenamiento',
    docsLink: '#',
    authType: 'oauth', 
    fields: [] 
  },
   {
    name: 'Gmail',
    id: 'gmail',
    description: 'Integra notificaciones y alertas de cumplimiento con tu cuenta de Gmail.',
    logoPlaceholder: '📧',
    category: 'Comunicación',
    docsLink: '#',
    authType: 'oauth',
    fields: []
  },
  {
    name: 'Tresorit',
    id: 'tresorit',
    description: 'Utiliza Tresorit para el almacenamiento seguro de evidencias y documentos sensibles.',
    logoPlaceholder: '🔒',
    category: 'Almacenamiento Seguro',
    docsLink: '#',
    fields: [
      { name: 'apiKey', label: 'API Key de Tresorit', type: 'password', placeholder: 'Tu API Key' },
    ]
  },
  {
    name: 'Slack',
    id: 'slack',
    description: 'Recibe notificaciones importantes y actualizaciones de cumplimiento en tus canales de Slack.',
    logoPlaceholder: '💬',
    category: 'Comunicación',
    docsLink: '#',
    authType: 'oauth',
    fields: [
       { name: 'webhookUrl', label: 'Webhook URL (Opcional para envíos simples)', type: 'text', placeholder: 'URL del Webhook de Slack' },
    ]
  },
  {
    name: 'Microsoft Teams',
    id: 'msteams',
    description: 'Colabora y recibe alertas de cumplimiento directamente en Microsoft Teams.',
    logoPlaceholder: '👥',
    category: 'Comunicación',
    docsLink: '#',
    fields: [
      { name: 'webhookUrl', label: 'Webhook URL', type: 'text', placeholder: 'URL del Webhook de Teams' },
    ]
  },
  {
    id: 'kibana',
    name: 'Kibana',
    description: 'Visualiza logs y métricas desde Elasticsearch para análisis de seguridad y operativos.',
    logoPlaceholder: '📊',
    category: 'Monitorización y Logs',
    docsLink: '#',
    fields: [
      { name: 'kibanaUrl', label: 'URL de Kibana', type: 'text', placeholder: 'https://tu-kibana.ejemplo.com' },
      { name: 'elasticsearchUrl', label: 'URL de Elasticsearch', type: 'text', placeholder: 'https://tu-elasticsearch.ejemplo.com' },
      { name: 'apiKey', label: 'API Key (Opcional)', type: 'password', placeholder: 'Tu API Key si es necesaria' },
    ]
  },
  {
    id: 'wazuh',
    name: 'Wazuh',
    description: 'Integra alertas de seguridad, detección de intrusiones y análisis de logs desde Wazuh.',
    logoPlaceholder: '🛡️',
    category: 'Seguridad SIEM/XDR',
    docsLink: '#',
    fields: [
      { name: 'wazuhApiUrl', label: 'URL de la API de Wazuh', type: 'text', placeholder: 'https://tu-wazuh-manager:55000' },
      { name: 'apiUser', label: 'Usuario API de Wazuh', type: 'text', placeholder: 'usuario_api' },
      { name: 'apiPassword', label: 'Contraseña API de Wazuh', type: 'password', placeholder: 'Tu contraseña API' },
    ]
  },
  {
    id: 'grafana',
    name: 'Grafana',
    description: 'Conecta con Grafana para visualizar dashboards de métricas y logs relevantes.',
    logoPlaceholder: '📈',
    category: 'Monitorización y Dashboards',
    docsLink: '#',
    fields: [
      { name: 'grafanaUrl', label: 'URL de Grafana', type: 'text', placeholder: 'https://tu-grafana.ejemplo.com' },
      { name: 'apiKey', label: 'API Key de Grafana (Viewer/Editor)', type: 'password', placeholder: 'Tu API Key de Grafana' },
    ]
  },
  {
    id: 'prometheus',
    name: 'Prometheus',
    description: 'Recopila métricas de sistemas y aplicaciones desde tu instancia de Prometheus.',
    logoPlaceholder: '🔥',
    category: 'Monitorización y Alertas',
    docsLink: '#',
    fields: [
      { name: 'prometheusUrl', label: 'URL de Prometheus', type: 'text', placeholder: 'http://localhost:9090' },
    ]
  },
  {
    id: 'datadog',
    name: 'Datadog',
    description: 'Centraliza métricas, trazas y logs de Datadog para una visión completa.',
    logoPlaceholder: '🐶',
    category: 'Monitorización y Analítica Cloud',
    docsLink: '#',
    fields: [
      { name: 'apiKey', label: 'Datadog API Key', type: 'password', placeholder: 'Tu API Key de Datadog' },
      { name: 'appKey', label: 'Datadog Application Key', type: 'password', placeholder: 'Tu Application Key de Datadog' },
      { name: 'site', label: 'Datadog Site', type: 'text', placeholder: 'ej: datadoghq.com (US1), datadoghq.eu (EU1)' },
    ]
  },
  {
    id: 'azure',
    name: 'Microsoft Azure',
    description: 'Conecta con Azure para monitorizar recursos, seguridad y costes.',
    logoPlaceholder: '🌐',
    category: 'Cloud',
    docsLink: '#',
    authType: 'oauth',
    fields: [
      { name: 'tenantId', label: 'ID de Inquilino (Tenant ID)', type: 'text', placeholder: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx' },
      { name: 'clientId', label: 'ID de Cliente (Client ID)', type: 'text', placeholder: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx' },
      { name: 'clientSecret', label: 'Secreto de Cliente (Client Secret)', type: 'password', placeholder: 'Tu secreto de cliente' },
      { name: 'subscriptionId', label: 'ID de Suscripción', type: 'text', placeholder: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx' },
    ]
  },
  {
    id: 'aws',
    name: 'Amazon Web Services',
    description: 'Integra AWS para una gestión centralizada de la seguridad y el cumplimiento.',
    logoPlaceholder: '📦',
    category: 'Cloud',
    docsLink: '#',
    fields: [
      { name: 'accessKeyId', label: 'Access Key ID', type: 'text', placeholder: 'AKIAIOSFODNN7EXAMPLE' },
      { name: 'secretAccessKey', label: 'Secret Access Key', type: 'password', placeholder: 'Tu clave de acceso secreta' },
      { name: 'region', label: 'Región por defecto', type: 'text', placeholder: 'us-east-1' },
    ]
  },
  {
    id: 'elasticsearch',
    name: 'Elasticsearch',
    description: 'Conecta directamente con Elasticsearch para búsquedas y análisis de datos.',
    logoPlaceholder: '🔍',
    category: 'Monitorización y Logs',
    docsLink: '#',
    fields: [
      { name: 'elasticsearchUrl', label: 'URL de Elasticsearch', type: 'text', placeholder: 'https://tu-elasticsearch.ejemplo.com' },
      { name: 'apiKey', label: 'API Key (Opcional)', type: 'password', placeholder: 'Tu API Key si es necesaria' },
    ]
  }
];

const IntegrationStatusIcon = ({ status }) => {
  if (status === 'Conectado') return <CheckCircle className="h-5 w-5 text-emerald-500" />;
  if (status === 'Error') return <XCircle className="h-5 w-5 text-red-500" />;
  if (status === 'Requiere acción') return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
  return <Plug className="h-5 w-5 text-gray-400" />;
};


const IntegrationsPage = ({ showToast, userId, selectedClientId, integrationFilters }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedIntegration, setSelectedIntegration] = useState(null);
  const [formData, setFormData] = useState({});
  
  const { 
    integrations: userIntegrations, 
    loading: loadingIntegrations, 
    upsertIntegrationConfig,
    getIntegrationStatus,
    getIntegrationConfig
  } = useIntegrations(userId, selectedClientId, showToast);

  const handleOpenModal = (integration) => {
    setSelectedIntegration(integration);
    const currentConfig = getIntegrationConfig(integration.name);
    setFormData(currentConfig?.config_details || {});
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedIntegration(null);
    setFormData({});
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmitConfig = async () => {
    if (!selectedIntegration) return;

    const success = await upsertIntegrationConfig(
      selectedIntegration.name, 
      formData, 
      true, 
      'Conectado' 
    ); 

    if (success) {
      showToast(
        `Configuración para ${selectedIntegration.name} guardada`,
        "La integración debería estar activa. Refresca si no ves los cambios.",
        "success"
      );
      handleCloseModal();
    } else {
      showToast(
        `Error al guardar ${selectedIntegration.name}`,
        "No se pudo guardar la configuración. Intenta de nuevo.",
        "destructive"
      );
    }
  };
  
  const handleDisconnect = async (integrationName) => {
     await upsertIntegrationConfig(integrationName, {}, false, 'Desconectado');
     showToast(`${integrationName} desconectado`, "La integración ha sido desactivada.", "default");
  };

  const filteredIntegrations = integrationFilters 
    ? staticIntegrationsList.filter(int => integrationFilters.includes(int.id))
    : staticIntegrationsList;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="p-4 md:p-6"
    >
      {!integrationFilters && (
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gradient-green mb-2">Integraciones</h1>
          <p className="text-gray-600">
            Conecte Eguzki Core con sus herramientas favoritas para automatizar flujos de trabajo y centralizar su información de cumplimiento.
          </p>
        </div>
      )}

      {loadingIntegrations && <p>Cargando configuraciones de integración...</p>}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredIntegrations.map((integration, index) => {
          const userIntegrationConfig = getIntegrationConfig(integration.name);
          const status = userIntegrationConfig?.status || 'No configurado';
          const isActive = userIntegrationConfig?.is_active || false;

          return (
            <motion.div
              key={integration.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
            >
              <Card className="h-full flex flex-col overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white/80 backdrop-blur-md border border-gray-200/50 rounded-xl">
                <CardHeader className="p-4">
                  <div className="flex items-center space-x-4 mb-3">
                    <div className="w-16 h-16 rounded-lg overflow-hidden flex items-center justify-center bg-gray-100 text-4xl">
                      <span role="img" aria-label={`${integration.name} logo`}>{integration.logoPlaceholder}</span>
                    </div>
                    <div>
                      <CardTitle className="text-xl font-semibold text-gray-800">{integration.name}</CardTitle>
                      <CardDescription className="text-xs text-emerald-600 font-medium">{integration.category}</CardDescription>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 min-h-[60px]">{integration.description}</p>
                </CardHeader>
                <CardContent className="p-4 flex-grow">
                  <div className="flex items-center space-x-2 text-sm">
                    <IntegrationStatusIcon status={status} />
                    <span>{status}</span>
                  </div>
                </CardContent>
                <CardFooter className="p-4 bg-gray-50/50 border-t border-gray-200/50 flex flex-col items-stretch space-y-2">
                  {isActive ? (
                     <Button 
                        onClick={() => handleDisconnect(integration.name)}
                        variant="outline"
                        className="w-full"
                      >
                        <XCircle className="mr-2 h-4 w-4" />
                        Desconectar
                      </Button>
                  ) : (
                    <Button 
                      onClick={() => handleOpenModal(integration)}
                      className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white"
                    >
                      <Plug className="mr-2 h-4 w-4" />
                      Configurar
                    </Button>
                  )}
                  <a 
                    href={integration.docsLink} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-xs text-gray-500 hover:text-emerald-700 hover:underline flex items-center justify-center pt-1"
                    onClick={(e) => {
                      if (integration.docsLink === '#') {
                        e.preventDefault();
                        showToast("🚧 Documentación no disponible", "La documentación para esta integración estará lista pronto.");
                      }
                    }}
                  >
                    <Info className="mr-1 h-3 w-3" /> Documentación
                  </a>
                </CardFooter>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {selectedIntegration && (
        <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>Configurar {selectedIntegration.name}</DialogTitle>
              <DialogDescription>
                Introduce los detalles para conectar con {selectedIntegration.name}. 
                Consulta la <a href={selectedIntegration.docsLink === '#' ? undefined : selectedIntegration.docsLink} target="_blank" rel="noopener noreferrer" className="underline text-emerald-600 hover:text-emerald-700" onClick={(e)=>{if(selectedIntegration.docsLink === '#'){e.preventDefault(); showToast("Documentación no disponible") }}}>documentación</a> para más ayuda.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-4">
              {selectedIntegration.authType === 'oauth' ? (
                <div className="text-center p-4 bg-blue-50 border border-blue-200 rounded-md">
                  <p className="text-sm text-blue-700">Esta integración utiliza OAuth 2.0.</p>
                  <Button className="mt-4" onClick={() => showToast("Flujo OAuth no implementado")}>
                    Conectar con {selectedIntegration.name}
                  </Button>
                  <p className="text-xs text-gray-500 mt-2">Serás redirigido a {selectedIntegration.name} para autorizar la conexión.</p>
                </div>
              ) : selectedIntegration.fields && selectedIntegration.fields.length > 0 ? (
                selectedIntegration.fields.map(field => (
                  <div key={field.name} className="space-y-1">
                    <Label htmlFor={field.name}>{field.label}</Label>
                    <Input 
                      id={field.name} 
                      name={field.name} 
                      type={field.type} 
                      placeholder={field.placeholder} 
                      value={formData[field.name] || ''}
                      onChange={handleInputChange} 
                    />
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-600">Esta integración no requiere configuración adicional por ahora o usa un método de conexión diferente.</p>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={handleCloseModal}>Cancelar</Button>
              {selectedIntegration.authType !== 'oauth' && selectedIntegration.fields && selectedIntegration.fields.length > 0 && (
                <Button onClick={handleSubmitConfig}>Guardar Configuración</Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

    </motion.div>
  );
};

export default IntegrationsPage;