import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode.react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, ShieldCheck, Key, CheckCircle } from 'lucide-react';

const MfaSetupPage = ({ auth, showToast, supabase }) => {
  const [qrCode, setQrCode] = useState('');
  const [factorId, setFactorId] = useState('');
  const [verifyCode, setVerifyCode] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingQr, setIsLoadingQr] = useState(true);

  useEffect(() => {
    const enrollNewFactor = async () => {
      setIsLoadingQr(true);
      const { data, error } = await supabase.auth.mfa.enroll({ factorType: 'totp' });
      if (error) {
        showToast('Error', `No se pudo iniciar la configuración de 2FA: ${error.message}`, 'destructive');
      } else {
        setFactorId(data.id);
        setQrCode(data.totp.uri);
      }
      setIsLoadingQr(false);
    };
    enrollNewFactor();
  }, [supabase, showToast]);

  const handleVerifyAndEnable = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const { data: challengeData, error: challengeError } = await supabase.auth.mfa.challenge({ factorId });
    if (challengeError) {
        showToast('Error de Verificación', `No se pudo crear el desafío: ${challengeError.message}`, 'destructive');
        setIsSubmitting(false);
        return;
    }

    const { error: verifyError } = await supabase.auth.mfa.verify({
      factorId,
      challengeId: challengeData.id,
      code: verifyCode,
    });

    if (verifyError) {
      showToast('Error de Verificación', 'El código es incorrecto. Inténtalo de nuevo.', 'destructive');
      setVerifyCode('');
    } else {
      showToast('¡Éxito!', 'La autenticación de dos factores ha sido habilitada.', 'default');
      auth.finishMfaSetup();
    }
    setIsSubmitting(false);
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1A2D27] via-[#10211C] to-black p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-lg bg-black/20 backdrop-blur-lg rounded-xl shadow-2xl p-8 border border-emerald-500/30 text-white"
      >
        <div className="flex flex-col items-center mb-8">
          <ShieldCheck className="w-16 h-16 text-emerald-400 mb-4" />
          <h1 className="text-3xl font-bold text-center">Asegura tu Cuenta</h1>
          <p className="text-emerald-200 text-center mt-2">Configura la autenticación de dos factores (2FA) para una capa extra de seguridad.</p>
        </div>
        
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold text-emerald-100">Paso 1: Escanea el Código QR</h3>
            <p className="text-sm text-emerald-300 mt-1 mb-4">Usa una aplicación de autenticación (como Google Authenticator, Authy, etc.) para escanear este código.</p>
            <div className="p-4 bg-white rounded-lg inline-block mx-auto flex items-center justify-center h-[180px] w-[180px]">
              {isLoadingQr ? <Loader2 className="w-8 h-8 text-gray-700 animate-spin" /> : <QRCode value={qrCode} size={160} />}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-emerald-100 mt-6">Paso 2: Verifica el Código</h3>
            <p className="text-sm text-emerald-300 mt-1 mb-4">Ingresa el código de 6 dígitos que aparece en tu aplicación para completar la configuración.</p>
            <form onSubmit={handleVerifyAndEnable} className="space-y-4">
                <div>
                    <Label htmlFor="verify-code" className="text-emerald-100">Código de Verificación</Label>
                    <div className="relative">
                        <Key className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-emerald-300" />
                        <Input 
                            id="verify-code" 
                            value={verifyCode} 
                            onChange={(e) => setVerifyCode(e.target.value)} 
                            maxLength="6" 
                            placeholder="123456" 
                            disabled={isSubmitting || isLoadingQr}
                            className="pl-10 bg-white/10 text-white placeholder-emerald-300/70 border-emerald-700/50 focus:border-emerald-500 focus:ring-emerald-500"
                        />
                    </div>
                </div>
                <Button type="submit" className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white py-3 font-semibold" disabled={isSubmitting || isLoadingQr || verifyCode.length < 6}>
                    {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="w-5 h-5 mr-2" />}
                    {isSubmitting ? 'Verificando...' : 'Verificar y Habilitar'}
                </Button>
            </form>
          </div>
           <Button variant="outline" onClick={auth.handleLogout} className="w-full border-red-500/50 text-red-300 hover:bg-red-500/20 hover:text-red-200">
             Cerrar sesión y configurar más tarde
           </Button>
        </div>

      </motion.div>
    </div>
  );
};

export default MfaSetupPage;