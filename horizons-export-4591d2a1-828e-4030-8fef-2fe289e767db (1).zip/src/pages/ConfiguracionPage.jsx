import React from 'react';
import { motion } from 'framer-motion';
import { Settings, Shield, UserCog } from 'lucide-react';
import MfaSetup from '@/components/auth/MfaSetup.jsx';
import BackupManager from '@/components/configuracion/BackupManager.jsx';
import LogViewer from '@/components/configuracion/LogViewer.jsx';
import PasswordChangeForm from '@/components/configuracion/PasswordChangeForm.jsx';

const ConfiguracionPage = ({ showToast, auth, supabase, logs, loadingLogs }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      className="space-y-8"
    >
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-800 flex items-center">
          <Settings className="w-8 h-8 mr-3 text-gradient-green" />
          Configuración General
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div className="space-y-10">
          <section>
            <h2 className="text-2xl font-semibold text-gray-700 mb-4 border-b pb-2 flex items-center">
              <UserCog className="w-6 h-6 mr-2 text-gray-600" />
              Gestión de Usuario
            </h2>
            <PasswordChangeForm showToast={showToast} />
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-gray-700 mb-4 border-b pb-2 flex items-center">
              <Shield className="w-6 h-6 mr-2 text-gray-600" />
              Seguridad de la Cuenta
            </h2>
            <MfaSetup showToast={showToast} supabase={supabase} />
          </section>
        </div>
        
        <div className="space-y-10">
          <BackupManager showToast={showToast} supabase={supabase} />
          <LogViewer logs={logs} loading={loadingLogs} />
        </div>
      </div>
    </motion.div>
  );
};

export default ConfiguracionPage;