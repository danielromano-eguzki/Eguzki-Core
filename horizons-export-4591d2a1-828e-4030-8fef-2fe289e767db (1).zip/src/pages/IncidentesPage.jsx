import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, PlusCircle, Search, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import IncidenteForm from '@/components/incidentes/IncidenteForm';
import { useIncidentes } from '@/hooks/useIncidentes';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

export const IncidentesPage = ({ showToast, selectedClientId, userId, isReadOnly }) => {
  const { incidentes, addIncidente, updateIncidente, deleteIncidente, loading } = useIncidentes(userId, selectedClientId, showToast);
  const [isFormOpen, setFormOpen] = useState(false);
  const [editingIncidente, setEditingIncidente] = useState(null);
  const [toDelete, setToDelete] = useState(null);
  const [filters, setFilters] = useState({ searchTerm: '', status: 'all' });

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const filteredIncidentes = useMemo(() => {
    return incidentes.filter(incidente => {
      const searchTermMatch = filters.searchTerm ? 
        incidente.name.toLowerCase().includes(filters.searchTerm.toLowerCase()) || 
        incidente.description.toLowerCase().includes(filters.searchTerm.toLowerCase()) : true;
      const statusMatch = filters.status !== 'all' ? incidente.status === filters.status : true;
      return searchTermMatch && statusMatch;
    });
  }, [incidentes, filters]);

  const handleFormSubmit = async (formData) => {
    if (editingIncidente) {
      await updateIncidente(editingIncidente.id, formData);
    } else {
      await addIncidente(formData);
    }
    setFormOpen(false);
    setEditingIncidente(null);
  };

  const openForm = (incidente = null) => {
    setEditingIncidente(incidente);
    setFormOpen(true);
  };

  const handleDelete = async () => {
    if (!toDelete) return;
    await deleteIncidente(toDelete.id);
    setToDelete(null);
  };

  if (!selectedClientId) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center bg-white/50 p-8 rounded-lg shadow">
        <AlertTriangle className="w-16 h-16 mx-auto mb-4 text-gray-400" />
        <h2 className="text-2xl font-semibold text-gray-700">Gestión de Incidentes</h2>
        <p className="mt-2 text-gray-500">Por favor, selecciona un cliente para empezar a gestionar incidentes.</p>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-800 flex items-center">
          <AlertTriangle className="w-8 h-8 mr-3 text-gradient-green" />
          Gestión de Incidentes
        </h1>
        <Button onClick={() => openForm()} disabled={isReadOnly}><PlusCircle className="mr-2 h-4 w-4" /> Nuevo Incidente</Button>
      </div>

      <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">Inventario de Incidentes</h2>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <Input placeholder="Buscar incidentes..." className="pl-9" value={filters.searchTerm} onChange={e => handleFilterChange('searchTerm', e.target.value)} />
            </div>
            <Select value={filters.status} onValueChange={v => handleFilterChange('status', v)}>
              <SelectTrigger className="w-[180px]"><SelectValue placeholder="Filtrar por estado" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los estados</SelectItem>
                <SelectItem value="Abierto">Abierto</SelectItem>
                <SelectItem value="En progreso">En progreso</SelectItem>
                <SelectItem value="Resuelto">Resuelto</SelectItem>
                <SelectItem value="Cerrado">Cerrado</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        {loading ? <p>Cargando incidentes...</p> : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredIncidentes.map(incidente => (
              <Card key={incidente.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle>{incidente.name}</CardTitle>
                  <CardDescription>Estado: {incidente.status}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">{incidente.description}</p>
                  <div className="mt-4 flex justify-end gap-2">
                    <Button variant="outline" onClick={() => openForm(incidente)} disabled={isReadOnly}>Editar</Button>
                    <Button variant="destructive" onClick={() => setToDelete(incidente)} disabled={isReadOnly}>Eliminar</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <Dialog open={isFormOpen} onOpenChange={(isOpen) => { if(!isOpen) { setEditingIncidente(null); } setFormOpen(isOpen); }}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingIncidente ? 'Editar' : 'Nuevo'} Incidente</DialogTitle>
          </DialogHeader>
          <IncidenteForm onSubmit={handleFormSubmit} onCancel={() => setFormOpen(false)} existingIncidente={editingIncidente} />
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!toDelete} onOpenChange={() => setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Confirmas la eliminación?</AlertDialogTitle>
            <AlertDialogDescription>Esta acción es permanente y no se podrá deshacer.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );
};