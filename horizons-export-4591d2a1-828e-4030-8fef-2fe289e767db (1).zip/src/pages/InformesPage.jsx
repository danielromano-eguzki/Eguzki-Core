import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { FileText, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import ReportView from '@/components/informes/ReportView';

const InformesPage = ({ user, selectedClientId, clientsHook, showToast, findingsHook, incidentesHook, evidenciasHook, auditoriaInternaHook, certificationHook, assetsHook, riesgosHook }) => {
  const [selectedReport, setSelectedReport] = useState(null);
  const { clients } = clientsHook;
  const client = clients.find(c => c.id === selectedClientId);

  const reports = [
    { id: 'monthly', title: 'Informe de Actualizaciones Mensuales', description: 'Comunica avances, cambios y estado de hitos del mes.', icon: '📜' },
    { id: 'final_project', title: 'Informe Final de Proyecto', description: 'Presenta cierre, logros y evidencias del proyecto.', icon: '🏁' },
    { id: 'internal_audit', title: 'Informe de Auditoría Interna', description: 'Evalúa cumplimiento normativo y madurez del SGSI o ENS.', icon: '🔍' },
    { id: 'gap_analysis', title: 'Informe de Gap Análisis', description: 'Compara la situación actual con los requisitos normativos.', icon: '📊' },
    { id: 'implementation_design', title: 'Informe de Diseño de Implementación', description: 'Planifica cómo se implementarán controles y medidas.', icon: '💡' },
    { id: 'findings_action_plans', title: 'Hallazgos y Planes de Acción', description: 'Documenta hallazgos de auditoría o revisión y define acciones.', icon: '📋' },
    { id: 'risk_report', title: 'Informe de Riesgos', description: 'Identifica, evalúa y prioriza riesgos de seguridad.', icon: '⚠️' },
  ];

  const handleGenerateReport = (reportId) => {
    if (!selectedClientId) {
      showToast("Selecciona un cliente", "Debes seleccionar un cliente para poder generar un informe.", "destructive");
      return;
    }
    setSelectedReport(reportId);
  };

  if (selectedReport) {
    const reportDetails = reports.find(r => r.id === selectedReport);
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-6"
      >
        <Helmet>
          <title>Eguzki Core - {reportDetails.title}</title>
          <meta name="description" content={`Generar ${reportDetails.title} para el cliente ${client?.name}`} />
        </Helmet>
        <Button onClick={() => setSelectedReport(null)} variant="outline" className="mb-4">
          <ChevronLeft className="w-4 h-4 mr-2" /> Volver a la selección de informes
        </Button>
        <ReportView
          reportType={selectedReport}
          reportTitle={reportDetails.title}
          client={client}
          user={user}
          showToast={showToast}
          findings={findingsHook.findings}
          incidents={incidentesHook.incidents}
          evidences={evidenciasHook.evidences}
          auditoriaInternaHook={auditoriaInternaHook}
          certifications={certificationHook.certifications}
          requirements={certificationHook.requirements}
          risks={riesgosHook.riesgos}
          actionPlans={riesgosHook.actionPlans}
          assets={assetsHook.assets}
        />
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <Helmet>
        <title>Eguzki Core - Informes</title>
        <meta name="description" content="Genera informes automatizados para tus clientes." />
      </Helmet>
      <h1 className="text-3xl font-bold text-gray-800 flex items-center">
        <FileText className="w-8 h-8 mr-3 text-gradient-green" />
        Generación de Informes
      </h1>
      
      {!selectedClientId ? (
        <div className="flex flex-col items-center justify-center h-64 text-center bg-white/50 p-8 rounded-lg shadow">
          <FileText className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <h2 className="text-2xl font-semibold text-gray-700">Selecciona un Cliente</h2>
          <p className="mt-2 text-gray-500">Por favor, selecciona un cliente en el menú superior para empezar a generar informes.</p>
        </div>
      ) : (
        <>
          <p className="text-gray-600">
            Selecciona el tipo de informe que deseas generar para <strong>{client?.name || 'tu cliente'}</strong>. Cada informe se adapta a las necesidades específicas de comunicación y análisis.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reports.map(report => (
              <Card key={report.id} className="bg-white/70 backdrop-blur-lg border border-white/20 shadow-md transition-all hover:shadow-lg hover:border-emerald-200">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-xl font-bold text-gray-800">{report.title}</CardTitle>
                  <span className="text-3xl">{report.icon}</span>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600 mb-4">{report.description}</CardDescription>
                  <Button onClick={() => handleGenerateReport(report.id)} className="w-full bg-gradient-to-r from-emerald-500 to-green-600 text-white hover:from-emerald-600 hover:to-green-700">
                    Generar Informe
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}
    </motion.div>
  );
};

export default InformesPage;