import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Lock, Key, CheckCircle, ShieldCheck, Loader2 } from 'lucide-react';
import QRCode from 'qrcode.react';

const PasswordResetForm = ({ onPasswordSet }) => {
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        await onPasswordSet(password, confirmPassword);
        setIsSubmitting(false);
    };

    return (
        <motion.div
            key="password"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 50 }}
            className="space-y-6"
        >
            <div className="text-center">
                <Lock className="mx-auto h-12 w-12 text-emerald-400" />
                <h2 className="mt-4 text-3xl font-extrabold text-white">Establece tu contraseña</h2>
                <p className="mt-2 text-sm text-emerald-200">Crea una contraseña segura para proteger tu cuenta.</p>
            </div>
            <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                    <Label className="text-emerald-100" htmlFor="password">Nueva Contraseña</Label>
                    <Input id="password" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Mínimo 8 caracteres" required />
                </div>
                <div>
                    <Label className="text-emerald-100" htmlFor="confirm-password">Confirmar Contraseña</Label>
                    <Input id="confirm-password" type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder="Repite la contraseña" required />
                </div>
                <Button type="submit" className="w-full" disabled={isSubmitting || password.length < 8 || password !== confirmPassword}>
                    {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="mr-2 h-4 w-4" />}
                    Guardar y Continuar
                </Button>
            </form>
        </motion.div>
    );
};

const MfaSetupForm = ({ onMfaSet }) => {
    const { qrCode, factorId, verifyCode, setVerifyCode, isSubmitting, isLoadingQr, handleVerifyAndEnable } = onMfaSet();

    const handleSubmit = async (e) => {
        e.preventDefault();
        await handleVerifyAndEnable();
    };

    return (
        <motion.div
            key="mfa"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 50 }}
            className="space-y-6"
        >
            <div className="text-center">
                <ShieldCheck className="mx-auto h-12 w-12 text-emerald-400" />
                <h2 className="mt-4 text-3xl font-extrabold text-white">Configura 2FA</h2>
                <p className="mt-2 text-sm text-emerald-200">Escanea el código QR con tu app de autenticación.</p>
            </div>
            <div className="flex justify-center p-4 bg-white rounded-lg">
                {isLoadingQr ? <Loader2 className="h-32 w-32 animate-spin text-gray-700" /> : <QRCode value={qrCode || ''} size={128} />}
            </div>
            <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                    <Label className="text-emerald-100" htmlFor="mfa-code">Código de Verificación</Label>
                    <Input id="mfa-code" type="text" value={verifyCode} onChange={e => setVerifyCode(e.target.value)} placeholder="Código de 6 dígitos" required maxLength="6" />
                </div>
                <Button type="submit" className="w-full" disabled={isSubmitting || verifyCode.length < 6}>
                    {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
                    Habilitar 2FA y Acceder
                </Button>
            </form>
        </motion.div>
    );
};


const WelcomePage = ({ auth, showToast, supabase }) => {
    const [step, setStep] = useState('password'); // 'password' or 'mfa'
    const [mfaData, setMfaData] = useState({ qrCode: '', factorId: '', isLoadingQr: true });
    const [verifyCode, setVerifyCode] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handlePasswordSet = async (password, confirmPassword) => {
        if (password !== confirmPassword) {
            showToast("Error", "Las contraseñas no coinciden.", "destructive");
            return;
        }
        if (password.length < 8) {
            showToast("Error", "La contraseña debe tener al menos 8 caracteres.", "destructive");
            return;
        }

        const { error } = await auth.updateUserPassword(password);
        if (!error) {
            showToast("Éxito", "Contraseña actualizada. Ahora configura 2FA.", "default");
            enrollNewFactor();
            setStep('mfa');
        }
    };
    
    const enrollNewFactor = async () => {
        setMfaData({ ...mfaData, isLoadingQr: true });
        const { data, error } = await supabase.auth.mfa.enroll({ factorType: 'totp' });
        if (error) {
            showToast('Error', `No se pudo iniciar la configuración de 2FA: ${error.message}`, 'destructive');
        } else {
            setMfaData({ qrCode: data.totp.uri, factorId: data.id, isLoadingQr: false });
        }
    };

    const handleVerifyAndEnable = async () => {
        setIsSubmitting(true);
        const { data: challengeData, error: challengeError } = await supabase.auth.mfa.challenge({ factorId: mfaData.factorId });
        if (challengeError) {
            showToast('Error de Verificación', `No se pudo crear el desafío: ${challengeError.message}`, 'destructive');
            setIsSubmitting(false);
            return;
        }

        const { error: verifyError } = await supabase.auth.mfa.verify({
          factorId: mfaData.factorId,
          challengeId: challengeData.id,
          code: verifyCode,
        });

        if (verifyError) {
            showToast('Error de Verificación', 'El código es incorrecto. Inténtalo de nuevo.', 'destructive');
        } else {
            showToast('¡Bienvenido!', 'Tu cuenta ha sido configurada correctamente.', 'default');
            auth.handlePasswordUpdateAndMfaSetup();
        }
        setIsSubmitting(false);
    };

    const mfaProps = () => ({
        ...mfaData,
        verifyCode,
        setVerifyCode,
        isSubmitting,
        handleVerifyAndEnable,
    });

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1A2D27] via-[#10211C] to-black p-4">
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-full max-w-md p-8 space-y-8 bg-black/20 backdrop-blur-lg rounded-xl shadow-2xl border border-emerald-500/30"
            >
                <AnimatePresence mode="wait">
                    {step === 'password' && <PasswordResetForm onPasswordSet={handlePasswordSet} />}
                    {step === 'mfa' && <MfaSetupForm onMfaSet={mfaProps} />}
                </AnimatePresence>
            </motion.div>
        </div>
    );
};

export default WelcomePage;