import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { AlertOctagon, PlusCircle, ListFilter, Search, Target, LayoutDashboard, ClipboardList, ShieldCheck, FileText } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import RiesgoForm from '@/components/riesgos/RiesgoForm.jsx';
import RiesgosEstadisticas from '@/components/riesgos/RiesgosEstadisticas.jsx';
import RiesgosGraficos from '@/components/riesgos/RiesgosGraficos.jsx';
import RiesgosTable from '@/components/riesgos/RiesgosTable.jsx';
import ExportMenu from '@/components/common/ExportMenu.jsx';
import RiskMap from '@/components/riesgos/RiskMap.jsx';
import MageritExplanation from '@/components/riesgos/MageritExplanation.jsx';
import ActionPlansInventory from '@/components/riesgos/ActionPlansInventory';
import RiskTemplatesTab from '@/components/riesgos/RiskTemplatesTab';
import { useRiskTemplates } from '@/hooks/useRiskTemplates';

const mageritNivelRiesgo = ["Muy Bajo", "Bajo", "Medio", "Alto", "Muy Alto", "Crítico"];
const mageritTratamiento = ["Aceptar", "Evitar", "Mitigar", "Transferir"];
const mageritEstado = ["Pendiente", "Evaluado", "En Progreso", "Implementado", "Rechazado"];

const riesgoHeaders = [
  { label: 'ID', key: 'id' },
  { label: 'Nombre Riesgo', key: 'name' },
  { label: 'Activos Afectados', key: 'asset_names' },
  { label: 'Amenaza', key: 'threat' },
  { label: 'Tipología Amenaza', key: 'threat_typology' },
  { label: 'Probabilidad', key: 'probability' },
  { label: 'Impacto', key: 'impact' },
  { label: 'Nivel Riesgo', key: 'level' },
  { label: 'Tratamiento', key: 'treatment' },
  { label: 'Responsable Tratamiento', key: 'treatment_owner' },
  { label: 'Fecha Resolución', key: 'resolution_date' },
  { label: 'Estado', key: 'status' }
];

const RiesgosPage = ({ 
  showToast, 
  assetsHook,
  riesgosHook,
  selectedClientId, 
  isReadOnly,
  userId
}) => {
  const { assets, loading: loadingAssets } = assetsHook;
  const {
    riesgos, actionPlans, riskSettings, loading: loadingRiesgos,
    addRiesgo, updateRiesgo, deleteRiesgo,
    addActionPlan, updateActionPlan, deleteActionPlan,
    updateRiskThreshold, addMultipleRiesgos
  } = riesgosHook;

  const riskTemplatesHook = useRiskTemplates(userId, showToast);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRiesgo, setEditingRiesgo] = useState(null);
  const [riesgoToDelete, setRiesgoToDelete] = useState(null);
  const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({ level: '', treatment: '', status: '', asset_id: '' });
  const [sortConfig, setSortConfig] = useState({ key: 'name', direction: 'ascending' });
  const [localThreshold, setLocalThreshold] = useState(riskSettings?.risk_threshold || 15);

  useEffect(() => {
    if (riskSettings) {
      setLocalThreshold(riskSettings.risk_threshold);
    }
  }, [riskSettings]);

  useEffect(() => {
    clearFilters();
  }, [selectedClientId]);

  const handleFormSubmit = (riesgoData) => {
     if (isReadOnly) {
      showToast("Modo de solo lectura", "Tu rol de auditor no permite realizar modificaciones.", "destructive");
      return;
    }
    if (editingRiesgo) {
      updateRiesgo(editingRiesgo.id, riesgoData);
    } else {
      addRiesgo(riesgoData);
    }
    setIsModalOpen(false);
    setEditingRiesgo(null);
  };

  const openEditModal = (riesgo) => {
    if (isReadOnly) return;
    setEditingRiesgo(riesgo);
    setIsModalOpen(true);
  };

  const openDeleteAlert = (riesgo) => {
    if (isReadOnly) return;
    setRiesgoToDelete(riesgo);
    setIsDeleteAlertOpen(true);
  };

  const confirmDelete = () => {
    if (isReadOnly) {
      showToast("Modo de solo lectura", "Tu rol de auditor no permite realizar modificaciones.", "destructive");
      return;
    }
    if (riesgoToDelete) {
      deleteRiesgo(riesgoToDelete.id);
    }
    setIsDeleteAlertOpen(false);
    setRiesgoToDelete(null);
  };

  const handleFilterChange = (column, value) => {
    setFilters(prev => ({ ...prev, [column]: value }));
  };

  const requestSort = (key) => {
    let direction = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const clearFilters = () => {
    setSearchTerm('');
    setFilters({ level: '', treatment: '', status: '', asset_id: '' });
    setSortConfig({ key: 'name', direction: 'ascending' });
  };

  const handleThresholdChange = (value) => {
    setLocalThreshold(value[0]);
  };

  const handleThresholdCommit = (value) => {
    if (!isReadOnly) {
      updateRiskThreshold(value[0]);
    }
  };

  const sortedAndFilteredRiesgos = useMemo(() => {
    let filteredRiesgos = [...(riesgos || [])];
    if (searchTerm) {
      filteredRiesgos = filteredRiesgos.filter(riesgo =>
        Object.values(riesgo).some(val =>
          String(val).toLowerCase().includes(searchTerm.toLowerCase())
        ) || (riesgo.asset_risk_link?.some(link => assets.find(a => a.id === link.asset_id)?.name.toLowerCase().includes(searchTerm.toLowerCase())))
      );
    }
    if (filters.level) filteredRiesgos = filteredRiesgos.filter(r => r.level === filters.level);
    if (filters.treatment) filteredRiesgos = filteredRiesgos.filter(r => r.treatment === filters.treatment);
    if (filters.status) filteredRiesgos = filteredRiesgos.filter(r => r.status === filters.status);
    if (filters.asset_id) filteredRiesgos = filteredRiesgos.filter(r => r.asset_risk_link?.some(l => l.asset_id === filters.asset_id));
    
    if (sortConfig.key) {
      filteredRiesgos.sort((a, b) => {
        let valA = a[sortConfig.key] || '';
        let valB = b[sortConfig.key] || '';
        
        if (valA < valB) return sortConfig.direction === 'ascending' ? -1 : 1;
        if (valA > valB) return sortConfig.direction === 'ascending' ? 1 : -1;
        return 0;
      });
    }

    return filteredRiesgos.map(riesgo => ({
      ...riesgo,
      asset_names: riesgo.asset_risk_link?.map(link => assets?.find(a => a.id === link.asset_id)?.name || 'N/A').join(', ') || 'N/A'
    }));
  }, [riesgos, searchTerm, filters, sortConfig, assets]);

  if (!selectedClientId) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center bg-white/50 p-8 rounded-lg shadow">
        <AlertOctagon className="w-16 h-16 mx-auto mb-4 text-gray-400" />
        <h2 className="text-2xl font-semibold text-gray-700">Gestión de Riesgos</h2>
        <p className="mt-2 text-gray-500">Por favor, selecciona un cliente para gestionar sus riesgos.</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-800 flex items-center">
          <AlertOctagon className="w-8 h-8 mr-3 text-gradient-green" />
          Gestión de Riesgos
        </h1>
      </div>

      <Tabs defaultValue="dashboard" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="dashboard"><LayoutDashboard className="w-4 h-4 mr-2" />Dashboard</TabsTrigger>
          <TabsTrigger value="analysis"><ClipboardList className="w-4 h-4 mr-2" />Análisis de Riesgos</TabsTrigger>
          <TabsTrigger value="action_plans"><ShieldCheck className="w-4 h-4 mr-2" />Planes de Acción</TabsTrigger>
        </TabsList>
        
        <TabsContent value="dashboard" className="mt-6 space-y-6">
          <RiesgosEstadisticas riesgos={riesgos || []} />
          <RiesgosGraficos riesgos={riesgos || []} />
          <MageritExplanation />
          <RiskMap riesgos={riesgos || []} />
        </TabsContent>

        <TabsContent value="analysis" className="mt-6 space-y-6">
          <Tabs defaultValue="matrix" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="matrix"><ClipboardList className="w-4 h-4 mr-2" />Matriz de Riesgos</TabsTrigger>
              <TabsTrigger value="templates"><FileText className="w-4 h-4 mr-2" />Plantillas</TabsTrigger>
            </TabsList>
            <TabsContent value="matrix" className="mt-6">
              <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20">
                <div className="flex flex-col sm:flex-row justify-between items-center mb-4 gap-4">
                  <h3 className="text-xl font-bold text-gray-800">Matriz de Riesgos</h3>
                  <div className="flex items-center space-x-2">
                    <div className="relative w-full sm:w-auto">
                      <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                      <Input
                        type="text"
                        placeholder="Buscar en riesgos..."
                        className="pl-10 pr-4 py-2 w-full sm:w-64 bg-white/80"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <ExportMenu 
                      data={sortedAndFilteredRiesgos} 
                      headers={riesgoHeaders} 
                      filenamePrefix="matriz_riesgos" 
                      reportTitle="Matriz de Riesgos"
                      disabled={loadingRiesgos}
                    />
                    <Dialog open={isModalOpen} onOpenChange={(isOpen) => { setIsModalOpen(isOpen); if (!isOpen) setEditingRiesgo(null); }}>
                      <DialogTrigger asChild>
                        <Button onClick={() => { setEditingRiesgo(null); setIsModalOpen(true); }} disabled={isReadOnly}>
                          <PlusCircle className="w-4 h-4 mr-2" />
                          Añadir Riesgo
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-2xl bg-white/90 backdrop-blur-lg">
                        <DialogHeader>
                          <DialogTitle>{editingRiesgo ? 'Editar Riesgo' : 'Añadir Nuevo Riesgo'}</DialogTitle>
                          <DialogDescription>
                            {editingRiesgo ? 'Modifica la información del riesgo.' : 'Completa la información para un nuevo riesgo.'}
                          </DialogDescription>
                        </DialogHeader>
                        <RiesgoForm onSubmit={handleFormSubmit} onCancel={() => { setIsModalOpen(false); setEditingRiesgo(null); }} existingRiesgo={editingRiesgo} assets={assets || []} />
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 mb-4 p-4 bg-gray-50/50 rounded-lg">
                  <div>
                    <Label htmlFor="filter-level" className="text-sm font-medium text-gray-700">Nivel de Riesgo</Label>
                    <Select onValueChange={(value) => handleFilterChange('level', value === 'all' ? '' : value)} value={filters.level || 'all'}>
                      <SelectTrigger id="filter-level" className="bg-white"><SelectValue placeholder="Todos" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos los Niveles</SelectItem>
                        {mageritNivelRiesgo.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="filter-treatment" className="text-sm font-medium text-gray-700">Tratamiento</Label>
                    <Select onValueChange={(value) => handleFilterChange('treatment', value === 'all' ? '' : value)} value={filters.treatment || 'all'}>
                      <SelectTrigger id="filter-treatment" className="bg-white"><SelectValue placeholder="Todos" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos los Tratamientos</SelectItem>
                        {mageritTratamiento.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="filter-status" className="text-sm font-medium text-gray-700">Estado</Label>
                    <Select onValueChange={(value) => handleFilterChange('status', value === 'all' ? '' : value)} value={filters.status || 'all'}>
                      <SelectTrigger id="filter-status" className="bg-white"><SelectValue placeholder="Todos" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos los Estados</SelectItem>
                        {mageritEstado.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="filter-asset" className="text-sm font-medium text-gray-700">Activo Afectado</Label>
                    <Select onValueChange={(value) => handleFilterChange('asset_id', value === 'all' ? '' : value)} value={filters.asset_id || 'all'}>
                      <SelectTrigger id="filter-asset" className="bg-white"><SelectValue placeholder="Todos" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos los Activos</SelectItem>
                        {(assets || []).map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700 block mb-2 opacity-0">Reset</Label>
                    <Button variant="outline" onClick={clearFilters} className="w-full bg-white"><ListFilter className="w-4 h-4 mr-2" />Limpiar Filtros</Button>
                  </div>
                </div>

                <RiesgosTable
                  riesgos={sortedAndFilteredRiesgos}
                  assets={assets || []}
                  sortConfig={sortConfig}
                  requestSort={requestSort}
                  onEdit={openEditModal}
                  onDelete={openDeleteAlert}
                  isAuditorMode={isReadOnly}
                />
                {loadingRiesgos && (
                  <div className="flex justify-center items-center py-10">
                      <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-8 h-8 border-4 border-gray-300 border-t-transparent rounded-full"></motion.div>
                  </div>
                )}
              </div>
            </TabsContent>
            <TabsContent value="templates" className="mt-6">
              <RiskTemplatesTab 
                templatesHook={riskTemplatesHook}
                onImportExample={addMultipleRiesgos}
                isReadOnly={isReadOnly}
                showToast={showToast}
              />
            </TabsContent>
          </Tabs>

          <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-md">
            <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center">
              <Target className="w-6 h-6 mr-3 text-gradient-green" />
              Umbral de Riesgo para Plan de Acción
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              Define el valor de riesgo (Probabilidad x Impacto) a partir del cual es obligatorio crear un plan de acción.
            </p>
            <div className="flex items-center gap-4">
              <Slider
                min={1}
                max={25}
                step={1}
                value={[localThreshold]}
                onValueChange={handleThresholdChange}
                onValueCommit={handleThresholdCommit}
                disabled={isReadOnly}
                className="flex-1"
              />
              <div className="font-bold text-lg text-gray-800 bg-white px-4 py-2 rounded-lg border w-20 text-center">
                {localThreshold}
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="action_plans" className="mt-6">
          <ActionPlansInventory 
            risks={riesgos || []}
            actionPlans={actionPlans || []}
            addActionPlan={addActionPlan}
            updateActionPlan={updateActionPlan}
            deleteActionPlan={deleteActionPlan}
            riskThreshold={localThreshold}
            isReadOnly={isReadOnly}
          />
        </TabsContent>
      </Tabs>

      <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. Esto eliminará permanentemente el riesgo "{riesgoToDelete?.name}" y todos sus planes de acción asociados.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setRiesgoToDelete(null)}>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );
};

export default RiesgosPage;