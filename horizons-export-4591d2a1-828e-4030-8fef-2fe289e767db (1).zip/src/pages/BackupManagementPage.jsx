import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { PlusCircle, CheckCircle, XCircle, Edit, Trash2 } from 'lucide-react';
import { motion } from 'framer-motion';
import BackupTestForm from '@/components/incidentes/BackupTestForm';
import BackupInventoryForm from '@/components/incidentes/BackupInventoryForm';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';

const BackupManagementPage = ({ businessContinuityHook, showToast }) => {
  const { 
    backupInventory, addBackupInventoryItem, updateBackupInventoryItem, deleteBackupInventoryItem,
    backupTests, addBackupTest,
    loading, refetchAll 
  } = businessContinuityHook;

  const [isInventoryFormOpen, setIsInventoryFormOpen] = useState(false);
  const [isTestFormOpen, setIsTestFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);

  useEffect(() => {
    refetchAll();
  }, []);

  const handleInventorySubmit = async (formData) => {
    if (editingItem) {
      await updateBackupInventoryItem(editingItem.id, formData);
    } else {
      await addBackupInventoryItem(formData);
    }
    setIsInventoryFormOpen(false);
    setEditingItem(null);
  };

  const handleTestSubmit = async (formData) => {
    await addBackupTest(formData);
    setIsTestFormOpen(false);
  };

  const handleEditInventory = (item) => {
    setEditingItem(item);
    setIsInventoryFormOpen(true);
  };

  const handleDeleteInventory = async (id) => {
    await deleteBackupInventoryItem(id);
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="space-y-6">
      <Tabs defaultValue="inventory" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="inventory">Inventario de Backups</TabsTrigger>
          <TabsTrigger value="tests">Pruebas de Restauración</TabsTrigger>
        </TabsList>
        
        <TabsContent value="inventory" className="mt-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Inventario de Sistemas con Backup</CardTitle>
                  <CardDescription>Detalle de la configuración de copias de seguridad por sistema.</CardDescription>
                </div>
                <Dialog open={isInventoryFormOpen} onOpenChange={(isOpen) => { setIsInventoryFormOpen(isOpen); if (!isOpen) setEditingItem(null); }}>
                  <DialogTrigger asChild>
                    <Button><PlusCircle className="w-4 h-4 mr-2" /> Añadir Sistema</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>{editingItem ? 'Editar' : 'Añadir'} Sistema al Inventario de Backups</DialogTitle>
                    </DialogHeader>
                    <BackupInventoryForm onSubmit={handleInventorySubmit} onCancel={() => { setIsInventoryFormOpen(false); setEditingItem(null); }} item={editingItem} />
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Sistema</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Frecuencia</TableHead>
                      <TableHead>Ubicación</TableHead>
                      <TableHead>Responsable</TableHead>
                      <TableHead>Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading && <TableRow><TableCell colSpan={6} className="text-center">Cargando...</TableCell></TableRow>}
                    {!loading && backupInventory.length === 0 && (
                      <TableRow><TableCell colSpan={6} className="text-center">No hay sistemas en el inventario.</TableCell></TableRow>
                    )}
                    {!loading && backupInventory.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.system_name}</TableCell>
                        <TableCell><Badge variant="outline">{item.backup_type}</Badge></TableCell>
                        <TableCell>{item.frequency}</TableCell>
                        <TableCell>{item.storage_location}</TableCell>
                        <TableCell>{item.responsible_person}</TableCell>
                        <TableCell>
                          <div className="flex space-x-1">
                            <Button variant="ghost" size="icon" onClick={() => handleEditInventory(item)}><Edit className="h-4 w-4" /></Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDeleteInventory(item.id)}><Trash2 className="h-4 w-4 text-red-500" /></Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tests" className="mt-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Pruebas de Backups</CardTitle>
                  <CardDescription>Registro histórico de las pruebas de restauración de copias de seguridad.</CardDescription>
                </div>
                <Dialog open={isTestFormOpen} onOpenChange={setIsTestFormOpen}>
                  <DialogTrigger asChild>
                    <Button><PlusCircle className="w-4 h-4 mr-2" /> Registrar Prueba</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Registrar Nueva Prueba de Backup</DialogTitle>
                    </DialogHeader>
                    <BackupTestForm onSubmit={handleTestSubmit} onCancel={() => setIsTestFormOpen(false)} />
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Sistema/Dato Restaurado</TableHead>
                      <TableHead>Resultado</TableHead>
                      <TableHead>Realizado Por</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading && <TableRow><TableCell colSpan={4} className="text-center">Cargando...</TableCell></TableRow>}
                    {!loading && backupTests.length === 0 && (
                      <TableRow><TableCell colSpan={4} className="text-center">No hay pruebas registradas.</TableCell></TableRow>
                    )}
                    {!loading && backupTests.map((test) => (
                      <TableRow key={test.id}>
                        <TableCell>{new Date(test.test_date).toLocaleDateString()}</TableCell>
                        <TableCell>{test.system_restored}</TableCell>
                        <TableCell>
                          <span className={`flex items-center ${test.result === 'Exitoso' ? 'text-green-600' : test.result === 'Fallido' ? 'text-red-600' : 'text-yellow-600'}`}>
                            {test.result === 'Exitoso' ? <CheckCircle className="w-4 h-4 mr-2" /> : <XCircle className="w-4 h-4 mr-2" />}
                            {test.result}
                          </span>
                        </TableCell>
                        <TableCell>{test.tested_by}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default BackupManagementPage;