import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { LogIn, Mail, Key } from 'lucide-react';
import MfaChallengeForm from '@/components/auth/MfaChallengeForm';

const LoginForm = ({
  onLogin,
  isVerifying,
  showToast
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const handleSubmit = e => {
    e.preventDefault();
    if (!email || !password) {
      showToast("Campos incompletos", "Por favor, introduce tu email y contraseña.", "destructive");
      return;
    }
    onLogin(email, password);
  };
  return <motion.div initial={{
    opacity: 0
  }} animate={{
    opacity: 1
  }} exit={{
    opacity: 0
  }} className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <Label htmlFor="email" className="text-emerald-100">Email</Label>
          <div className="relative">
            <Mail className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-emerald-300" />
            <Input id="email" name="email" type="email" placeholder="tu@email.com" className="pl-10 bg-white/10 text-white placeholder-emerald-300/70 border-emerald-700/50 focus:border-emerald-500 focus:ring-emerald-500" required disabled={isVerifying} value={email} onChange={e => setEmail(e.target.value)} />
          </div>
        </div>
        <div>
          <Label htmlFor="password" className="text-emerald-100">Contraseña</Label>
          <div className="relative">
            <Key className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-emerald-300" />
            <Input id="password" name="password" type="password" placeholder="••••••••" className="pl-10 bg-white/10 text-white placeholder-emerald-300/70 border-emerald-700/50 focus:border-emerald-500 focus:ring-emerald-500" required disabled={isVerifying} value={password} onChange={e => setPassword(e.target.value)} />
          </div>
        </div>
        <Button type="submit" className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white py-3 font-semibold" disabled={isVerifying}>
          {isVerifying ? <motion.div animate={{
          rotate: 360
        }} transition={{
          duration: 1,
          repeat: Infinity,
          ease: "linear"
        }} className="w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2"></motion.div> : <LogIn className="w-5 h-5 mr-2" />}
          {isVerifying ? 'Iniciando sesión...' : 'Iniciar Sesión'}
        </Button>
      </form>
    </motion.div>;
};

const LoginPage = ({
  auth,
  showToast
}) => {
  return <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1A2D27] via-[#10211C] to-black p-4">
      <motion.div initial={{
      opacity: 0,
      scale: 0.9
    }} animate={{
      opacity: 1,
      scale: 1
    }} transition={{
      duration: 0.5
    }} className="w-full max-w-md bg-black/20 backdrop-blur-lg rounded-xl shadow-2xl p-8 border border-emerald-500/30">
        <div className="flex flex-col items-center mb-8">
          <div className="w-24 h-auto mb-4">
            <img src="https://storage.googleapis.com/hostinger-horizons-assets-prod/4591d2a1-828e-4030-8fef-2fe289e767db/fbb6eeab9659944dfb76a5c3181c10f8.png" alt="Logo Eguzki Core" className="w-full h-full object-contain" />
          </div>
          <h1 className="text-3xl font-bold text-white text-center">Eguzki Core</h1>
          <p className="text-emerald-200 text-center">Plataforma de Gestión 360º para el Cumplimiento Normativo</p>
        </div>
        
        <AnimatePresence mode="wait">
          {auth.authStep === 'login' && <LoginForm key="login-form" onLogin={auth.handleLogin} isVerifying={auth.isVerifying} showToast={showToast} />}
          {auth.authStep === 'mfa_required' && <MfaChallengeForm key="mfa-form" onVerify={auth.handleMfaLogin} isVerifying={auth.isVerifying} />}
        </AnimatePresence>

      </motion.div>
    </div>;
};
export default LoginPage;