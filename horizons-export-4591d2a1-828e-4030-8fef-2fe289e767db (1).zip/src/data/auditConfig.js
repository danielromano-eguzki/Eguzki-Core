import { BookOpen, CalendarDays, Users, CheckSquare, FileText, ClipboardCheck } from 'lucide-react';

export const initialAuditSectionsConfig = [
  { 
    key: 'planning', 
    title: 'Planning de Auditoría', 
    icon: BookOpen, 
    description: 'Define el alcance, objetivos y criterios de la auditoría interna.', 
    defaultItems: [
      { title: 'Documento de Plan de Auditoría', item_type: 'document', description: 'Sube el plan detallado de la auditoría.' }
    ], 
    originalToastMessage: "Accede a la plantilla para el Planning de Auditoría." 
  },
  { 
    key: 'calendar', 
    title: 'Definición de Calendario', 
    icon: CalendarDays, 
    description: 'Establece las fechas clave y agenda para las actividades de auditoría.', 
    defaultItems: [
      { title: 'Calendario de Auditoría', item_type: 'document', description: 'Adjunta el calendario con hitos y reuniones.'}, 
      { title: 'Hito: Reunión de Inicio', item_type: 'task', description: 'Fecha de la reunión inicial.'}
    ], 
    originalToastMessage: "Utiliza la plantilla para definir el Calendario de tu auditoría." 
  },
  { 
    key: 'team_meetings', 
    title: 'Template para Reuniones con Equipo', 
    icon: Users, 
    description: 'Utiliza plantillas para guiar las entrevistas y reuniones.', 
    defaultItems: [
      { title: 'Plantilla de Entrevista', item_type: 'template_download', description: 'Descarga la plantilla para entrevistas.', template_key: 'interview_template' }
    ], 
    originalToastMessage: "Descarga el Template para Reuniones con el Equipo." 
  },
  { 
    key: 'requirements', 
    title: 'Requisitos Necesarios', 
    icon: CheckSquare, 
    description: 'Lista y verifica los documentos y accesos requeridos.', 
    defaultItems: [
      { title: 'Lista de Documentación Requerida', item_type: 'task', description: 'Verificar la recepción de todos los documentos.'}
    ], 
    originalToastMessage: "Consulta el listado de Requisitos Necesarios para la auditoría." 
  },
  { 
    key: 'evidence_gathering', 
    title: 'Reunión de Evidencias', 
    icon: ClipboardCheck, 
    description: 'Centraliza y organiza las evidencias recolectadas.', 
    defaultItems: [
      { title: 'Carpeta de Evidencias', item_type: 'link', description: 'Enlace a la carpeta compartida de evidencias (si aplica).', link_url: '#' }
    ], 
    originalToastMessage: "Organiza la Reunión de Evidencias con esta guía." 
  },
  { 
    key: 'final_report', 
    title: 'Template para Reporte Final', 
    icon: FileText, 
    description: 'Genera el informe final de auditoría con hallazgos y recomendaciones.', 
    defaultItems: [
      { title: 'Plantilla de Reporte Final', item_type: 'template_download', description: 'Descarga la plantilla para el informe final.', template_key: 'final_report_template'}, 
      { title: 'Reporte Final de Auditoría', item_type: 'document', description: 'Sube el reporte final firmado.'}
    ], 
    originalToastMessage: "Usa la plantilla para el Reporte Final de Auditoría." 
  },
];