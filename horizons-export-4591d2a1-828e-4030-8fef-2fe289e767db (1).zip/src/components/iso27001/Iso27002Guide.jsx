import React from 'react';
import { motion } from 'framer-motion';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const controlsData = [
    {
        category: "Controles Organizacionales (Cláusula 5)",
        controls: [
            { id: "A.5.1", title: "Políticas para la seguridad de la información", description: "Se debe definir, aprobar por la dirección, publicar y comunicar a los empleados y partes externas pertinentes, un conjunto de políticas para la seguridad de la información." },
            { id: "A.5.7", title: "Inteligencia de amenazas", description: "Se debe recopilar y analizar información relacionada con amenazas a la seguridad de la información para producir inteligencia sobre amenazas." },
            { id: "A.5.23", title: "Seguridad de la información para el uso de servicios en la nube", description: "Se deben especificar y gestionar los procesos para la adquisición, uso, gestión y salida de servicios en la nube de acuerdo con los requisitos de seguridad de la información de la organización." },
            { id: "A.5.30", title: "Preparación de las TIC para la continuidad del negocio", description: "La preparación de las TIC se debe planificar, implementar, mantener y probar en función de los objetivos de continuidad del negocio y los requisitos de continuidad de las TIC." },
        ]
    },
    {
        category: "Controles de Personas (Cláusula 6)",
        controls: [
            { id: "A.6.3", title: "Concienciación, educación y formación en seguridad de la información", description: "El personal de la organización y las partes interesadas pertinentes deben recibir una concienciación, educación y formación adecuadas en seguridad de la información y actualizaciones periódicas de las políticas y procedimientos de la organización, según sea relevante para su función laboral." },
            { id: "A.6.7", title: "Trabajo remoto", description: "Se deben implementar medidas de seguridad cuando el personal trabaja de forma remota para proteger la información a la que se accede, procesa o almacena fuera de las instalaciones de la organización." }
        ]
    },
    {
        category: "Controles Físicos (Cláusula 7)",
        controls: [
            { id: "A.7.4", title: "Monitorización de la seguridad física", description: "Las instalaciones deben ser monitorizadas continuamente para detectar accesos físicos no autorizados." },
            { id: "A.7.7", title: "Escritorio y pantalla limpios", description: "Se deben definir y hacer cumplir reglas de escritorio limpio para los papeles y los medios de almacenamiento extraíbles y reglas de pantalla limpia para los equipos de procesamiento de información." },
            { id: "A.7.10", title: "Medios de almacenamiento", description: "Los medios de almacenamiento deben gestionarse a lo largo de su ciclo de vida de adquisición, uso, transporte y eliminación, de acuerdo con el esquema de clasificación y los requisitos de manejo de la organización." },
        ]
    },
    {
        category: "Controles Tecnológicos (Cláusula 8)",
        controls: [
            { id: "A.8.1", title: "Dispositivos de punto final del usuario", description: "Se debe proteger la información almacenada en los dispositivos de punto final del usuario." },
            { id: "A.8.9", title: "Gestión de la configuración", description: "Se deben establecer, documentar, implementar, monitorear y revisar las configuraciones, incluidas las de seguridad, de hardware, software, servicios y redes." },
            { id: "A.8.12", title: "Prevención de la fuga de datos", description: "Se deben aplicar medidas de prevención de fuga de datos a los sistemas, redes y cualquier otro dispositivo que procese, almacene o transmita información sensible." },
            { id: "A.8.16", title: "Actividades de monitorización", description: "Las redes, los sistemas y las aplicaciones deben ser monitorizados para detectar comportamientos anómalos y tomar las medidas adecuadas para evaluar posibles incidentes de seguridad de la información." },
            { id: "A.8.23", title: "Filtrado web", description: "El acceso a sitios web externos debe gestionarse para reducir la exposición a contenido malicioso." },
            { id: "A.8.28", title: "Codificación segura", description: "Se deben aplicar principios de codificación segura al desarrollo de software." }
        ]
    }
];

const Iso27002Guide = () => {
    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <Card className="bg-white/70 backdrop-blur-lg border-white/20 shadow-lg">
                <CardHeader>
                    <CardTitle className="text-xl font-bold text-gray-800">Guía de Controles ISO/IEC 27002:2022</CardTitle>
                    <p className="text-sm text-gray-600">
                        Una referencia rápida a los controles de seguridad de la información. Esta guía proporciona la descripción de los controles del Anexo A de la ISO 27001.
                    </p>
                </CardHeader>
                <CardContent>
                    <Accordion type="single" collapsible className="w-full">
                        {controlsData.map((category, index) => (
                            <div key={index} className="mb-4">
                                <h3 className="text-lg font-semibold text-gray-700 mb-2">{category.category}</h3>
                                {category.controls.map(control => (
                                    <AccordionItem key={control.id} value={control.id} className="bg-white/50 rounded-lg mb-2 border">
                                        <AccordionTrigger className="px-4 py-3 hover:no-underline">
                                            <div className="flex items-center gap-4">
                                                <Badge variant="secondary">{control.id}</Badge>
                                                <span className="font-medium text-left">{control.title}</span>
                                            </div>
                                        </AccordionTrigger>
                                        <AccordionContent className="px-4 pb-4">
                                            <p className="text-gray-600">{control.description}</p>
                                        </AccordionContent>
                                    </AccordionItem>
                                ))}
                            </div>
                        ))}
                    </Accordion>
                </CardContent>
            </Card>
        </motion.div>
    );
};

export default Iso27002Guide;