import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, FilePlus, FileText, Trash2, Edit, UploadCloud } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { motion } from 'framer-motion';

const exampleRisks = [
  { name: 'Ataque de Phishing exitoso', threat: 'Engaño a empleado para revelar credenciales.', threat_typology: 'Phishing', probability: 'Media (3)', impact: 'Alto (4)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Infección por Ransomware', threat: 'Cifrado de archivos críticos por malware.', threat_typology: 'Malware', probability: 'Baja (2)', impact: 'Muy Alto (5)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Fuga de datos por empleado', threat: 'Exfiltración de datos sensibles por un empleado interno.', threat_typology: 'Amenaza interna', probability: 'Baja (2)', impact: 'Alto (4)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Ataque de Denegación de Servicio (DoS)', threat: 'Inundación de servidores web con tráfico malicioso.', threat_typology: 'Denegación de servicio (DoS)', probability: 'Media (3)', impact: 'Medio (3)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Pérdida de dispositivo móvil corporativo', threat: 'Robo o pérdida de un portátil o smartphone con datos de la empresa.', threat_typology: 'Robo físico', probability: 'Media (3)', impact: 'Medio (3)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Vulnerabilidad sin parchear en software crítico', threat: 'Explotación de una vulnerabilidad conocida en un sistema operativo o aplicación.', threat_typology: 'Acceso no autorizado', probability: 'Alta (4)', impact: 'Alto (4)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Error humano en configuración de la nube', threat: 'Configuración incorrecta de un bucket S3, dejándolo públicamente accesible.', threat_typology: 'Error humano', probability: 'Media (3)', impact: 'Alto (4)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Fallo de hardware en servidor principal', threat: 'Caída de un servidor crítico por fallo de disco duro o fuente de alimentación.', threat_typology: 'Fallo de sistema', probability: 'Baja (2)', impact: 'Alto (4)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Desastre natural (incendio/inundación)', threat: 'Destrucción física del centro de datos principal.', threat_typology: 'Desastre natural', probability: 'Muy Baja (1)', impact: 'Muy Alto (5)', treatment: 'Transferir', status: 'Pendiente' },
  { name: 'Acceso no autorizado a instalaciones', threat: 'Intrusión física en las oficinas.', threat_typology: 'Robo físico', probability: 'Baja (2)', impact: 'Bajo (2)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Ingeniería social (pretexting)', threat: 'Obtención de información sensible a través de una llamada telefónica fraudulenta.', threat_typology: 'Phishing', probability: 'Media (3)', impact: 'Medio (3)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Contraseñas débiles o reutilizadas', threat: 'Adivinación o cracking de contraseñas de usuario.', threat_typology: 'Acceso no autorizado', probability: 'Alta (44)', impact: 'Medio (3)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Falta de segregación de redes', threat: 'Un atacante pivota desde una red menos segura (invitados) a la red corporativa.', threat_typology: 'Acceso no autorizado', probability: 'Media (3)', impact: 'Alto (4)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Ausencia de copias de seguridad', threat: 'Imposibilidad de recuperar datos tras un incidente.', threat_typology: 'Fallo de sistema', probability: 'Baja (2)', impact: 'Muy Alto (5)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Shadow IT', threat: 'Uso de aplicaciones no autorizadas por los empleados, sin supervisión de TI.', threat_typology: 'Error humano', probability: 'Media (3)', impact: 'Medio (3)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Ataque a la cadena de suministro', threat: 'Un proveedor de software comprometido distribuye una actualización maliciosa.', threat_typology: 'Malware', probability: 'Baja (2)', impact: 'Muy Alto (5)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Falta de monitorización y logging', threat: 'Incapacidad para detectar o investigar un incidente de seguridad a tiempo.', threat_typology: 'Fallo de sistema', probability: 'Media (3)', impact: 'Alto (4)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Gestión de parches ineficaz', threat: 'Sistemas críticos permanecen vulnerables mucho después de que se publiquen los parches.', threat_typology: 'Acceso no autorizado', probability: 'Alta (4)', impact: 'Alto (4)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Políticas de seguridad obsoletas', threat: 'Las políticas no reflejan las tecnologías o amenazas actuales.', threat_typology: 'Error humano', probability: 'Media (3)', impact: 'Bajo (2)', treatment: 'Mitigar', status: 'Pendiente' },
  { name: 'Falta de formación en ciberseguridad', threat: 'Los empleados no reconocen amenazas comunes y cometen errores.', threat_typology: 'Error humano', probability: 'Alta (4)', impact: 'Medio (3)', treatment: 'Mitigar', status: 'Pendiente' },
];

const TemplateForm = ({ onSubmit, onCancel, existingTemplate, isReadOnly }) => {
  const [title, setTitle] = useState(existingTemplate?.title || '');
  const [description, setDescription] = useState(existingTemplate?.description || '');
  const [file, setFile] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isReadOnly) return;
    onSubmit({ title, description }, file);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="template-title">Título</Label>
        <Input id="template-title" value={title} onChange={(e) => setTitle(e.target.value)} required disabled={isReadOnly} />
      </div>
      <div>
        <Label htmlFor="template-description">Descripción</Label>
        <Textarea id="template-description" value={description} onChange={(e) => setDescription(e.target.value)} disabled={isReadOnly} />
      </div>
      <div>
        <Label htmlFor="template-file">Archivo (Opcional)</Label>
        <Input id="template-file" type="file" onChange={(e) => setFile(e.target.files[0])} disabled={isReadOnly} />
      </div>
      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        {!isReadOnly && <Button type="submit">{existingTemplate ? 'Actualizar' : 'Guardar'}</Button>}
      </div>
    </form>
  );
};

const RiskTemplatesTab = ({ templatesHook, onImportExample, isReadOnly, showToast }) => {
  const { templates, loading, addTemplate, updateTemplate, deleteTemplate, getFileUrl } = templatesHook;
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [templateToDelete, setTemplateToDelete] = useState(null);

  const handleImport = () => {
    if (isReadOnly) {
      showToast("Modo de solo lectura", "No se pueden importar riesgos.", "destructive");
      return;
    }
    onImportExample(exampleRisks);
  };

  const handleNewTemplate = () => {
    if (isReadOnly) return;
    setEditingTemplate(null);
    setIsFormOpen(true);
  };

  const handleEditTemplate = (template) => {
    if (isReadOnly) return;
    setEditingTemplate(template);
    setIsFormOpen(true);
  };

  const handleDeleteTemplate = (template) => {
    if (isReadOnly) return;
    setTemplateToDelete(template);
  };

  const confirmDeleteTemplate = async () => {
    if (templateToDelete) {
      await deleteTemplate(templateToDelete.id);
      setTemplateToDelete(null);
    }
  };

  const handleFormSubmit = async (formData, file) => {
    if (editingTemplate) {
      await updateTemplate(editingTemplate.id, formData, file);
    } else {
      await addTemplate(formData, file);
    }
    setIsFormOpen(false);
    setEditingTemplate(null);
  };

  const handleDownload = async (filePath) => {
    const url = await getFileUrl(filePath);
    if (url) {
      window.open(url, '_blank');
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-white/70 backdrop-blur-lg border border-white/20 shadow-md">
        <CardHeader>
          <CardTitle>Matriz de Riesgo de Ejemplo</CardTitle>
          <CardDescription>Importa una matriz de riesgo predefinida con 20 riesgos comunes de ciberseguridad para empezar rápidamente.</CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={handleImport} disabled={isReadOnly}>
            <Download className="mr-2 h-4 w-4" /> Importar Ejemplo
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-white/70 backdrop-blur-lg border border-white/20 shadow-md">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Plantillas de Riesgos Personalizadas</CardTitle>
              <CardDescription>Sube y gestiona tus propias plantillas de análisis de riesgos para reutilizarlas.</CardDescription>
            </div>
            <Button onClick={handleNewTemplate} disabled={isReadOnly}>
              <FilePlus className="mr-2 h-4 w-4" /> Nueva Plantilla
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center py-10">
              <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-8 h-8 border-4 border-gray-300 border-t-transparent rounded-full"></motion.div>
            </div>
          ) : templates.length > 0 ? (
            <div className="space-y-3">
              {templates.map(template => (
                <div key={template.id} className="flex items-center justify-between p-3 bg-gray-50/50 rounded-lg border">
                  <div className="flex items-center gap-3">
                    <FileText className="w-5 h-5 text-gray-600" />
                    <div>
                      <p className="font-semibold">{template.title}</p>
                      <p className="text-sm text-gray-500">{template.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {template.file_path && (
                      <Button variant="ghost" size="icon" onClick={() => handleDownload(template.file_path)}>
                        <Download className="w-4 h-4" />
                      </Button>
                    )}
                    {!isReadOnly && (
                      <>
                        <Button variant="ghost" size="icon" onClick={() => handleEditTemplate(template)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteTemplate(template)}>
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-10 border-2 border-dashed rounded-lg">
              <UploadCloud className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-semibold text-gray-900">No hay plantillas</h3>
              <p className="mt-1 text-sm text-gray-500">Empieza subiendo tu primera plantilla de riesgo.</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isFormOpen} onOpenChange={(isOpen) => { if (!isOpen) setEditingTemplate(null); setIsFormOpen(isOpen); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingTemplate ? 'Editar' : 'Nueva'} Plantilla de Riesgo</DialogTitle>
          </DialogHeader>
          <TemplateForm
            onSubmit={handleFormSubmit}
            onCancel={() => setIsFormOpen(false)}
            existingTemplate={editingTemplate}
            isReadOnly={isReadOnly}
          />
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!templateToDelete} onOpenChange={() => setTemplateToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Estás seguro?</AlertDialogTitle></AlertDialogHeader>
          <AlertDialogDescription>Esta acción no se puede deshacer. Esto eliminará permanentemente la plantilla.</AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteTemplate} className="bg-red-600 hover:bg-red-700">Sí, eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default RiskTemplatesTab;