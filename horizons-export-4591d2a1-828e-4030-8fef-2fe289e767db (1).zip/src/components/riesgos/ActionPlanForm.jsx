import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { DialogFooter } from '@/components/ui/dialog';

const actionPlanStatus = ["Pendiente", "En Progreso", "Completado", "Cancelado"];
const effectivenessLevels = ["Muy Efectiva", "Efectiva", "Poco Efectiva", "Inefectiva"];
const residualRiskLevels = ["Muy Bajo", "Bajo", "Medio", "Alto", "Muy Alto", "Crítico"];

const ActionPlanForm = ({ onSubmit, onCancel, existingPlan }) => {
  const [description, setDescription] = useState(existingPlan?.description || '');
  const [responsible, setResponsible] = useState(existingPlan?.responsible || '');
  const [dueDate, setDueDate] = useState(existingPlan?.due_date || '');
  const [status, setStatus] = useState(existingPlan?.status || 'Pendiente');
  const [effectiveness, setEffectiveness] = useState(existingPlan?.effectiveness || '');
  const [estimatedResidualRisk, setEstimatedResidualRisk] = useState(existingPlan?.estimated_residual_risk || '');

  const handleSubmit = (e) => {
    e.preventDefault();
    const planData = {
      description,
      responsible,
      due_date: dueDate,
      status,
      effectiveness,
      estimated_residual_risk: estimatedResidualRisk,
    };
    onSubmit(planData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto p-1 pr-4">
      <div>
        <Label htmlFor="plan-description">Descripción de la Medida / Plan de Acción</Label>
        <Textarea id="plan-description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Ej: Implementar cifrado en la base de datos" required />
      </div>
      <div>
        <Label htmlFor="plan-responsible">Responsable</Label>
        <Input id="plan-responsible" value={responsible} onChange={(e) => setResponsible(e.target.value)} placeholder="Ej: Equipo de TI" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="plan-due-date">Fecha de Vencimiento</Label>
          <Input id="plan-due-date" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
        </div>
        <div>
          <Label htmlFor="plan-status">Estado</Label>
          <Select onValueChange={setStatus} value={status} required>
            <SelectTrigger id="plan-status"><SelectValue placeholder="Seleccionar estado" /></SelectTrigger>
            <SelectContent>
              {actionPlanStatus.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="plan-effectiveness">Efectividad</Label>
          <Select onValueChange={setEffectiveness} value={effectiveness}>
            <SelectTrigger id="plan-effectiveness"><SelectValue placeholder="Evaluar efectividad" /></SelectTrigger>
            <SelectContent>
              {effectivenessLevels.map(level => <SelectItem key={level} value={level}>{level}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="plan-residual-risk">Riesgo Residual Estimado</Label>
          <Select onValueChange={setEstimatedResidualRisk} value={estimatedResidualRisk}>
            <SelectTrigger id="plan-residual-risk"><SelectValue placeholder="Estimar riesgo residual" /></SelectTrigger>
            <SelectContent>
              {residualRiskLevels.map(level => <SelectItem key={level} value={level}>{level}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
      <DialogFooter className="pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{existingPlan ? 'Actualizar Plan' : 'Añadir Plan'}</Button>
      </DialogFooter>
    </form>
  );
};

export default ActionPlanForm;