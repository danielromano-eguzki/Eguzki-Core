import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ArrowUpDown, Edit3, Trash2 } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const getRiskLevelColor = (level) => {
  if (level === 'Crítico' || level === 'Muy Alto') return 'bg-red-100 text-red-700';
  if (level === 'Alto') return 'bg-orange-100 text-orange-700';
  if (level === 'Medio') return 'bg-yellow-100 text-yellow-700';
  return 'bg-green-100 text-primary';
};

const getStatusColor = (status) => {
  if (status === 'Implementado') return 'bg-green-100 text-primary';
  if (status === 'En Progreso') return 'bg-blue-100 text-blue-700';
  if (status === 'Rechazado') return 'bg-red-100 text-red-700';
  return 'bg-gray-100 text-gray-700';
};

const RiesgosTable = ({ riesgos, assets, sortConfig, requestSort, onEdit, onDelete, isAuditorMode }) => {
  const getAssetNames = (links) => {
    if (!links || links.length === 0) return 'N/A';
    return links.map(link => assets.find(a => a.id === link.asset_id)?.name || 'Desconocido').join(', ');
  };

  const renderSortArrow = (key) => {
    if (sortConfig.key !== key) return <ArrowUpDown className="w-4 h-4 ml-2 opacity-30" />;
    return sortConfig.direction === 'ascending' ? '▲' : '▼';
  };

  return (
    <div className="overflow-x-auto">
      <Table className="min-w-full">
        <TableHeader>
          <TableRow>
            <TableHead onClick={() => requestSort('name')} className="cursor-pointer">
              <div className="flex items-center">Nombre Riesgo {renderSortArrow('name')}</div>
            </TableHead>
            <TableHead>Activos Afectados</TableHead>
            <TableHead>Tipología Amenaza</TableHead>
            <TableHead>Responsable</TableHead>
            <TableHead onClick={() => requestSort('level')} className="cursor-pointer">
              <div className="flex items-center">Nivel Riesgo {renderSortArrow('level')}</div>
            </TableHead>
            <TableHead>Tratamiento</TableHead>
            <TableHead>Estado</TableHead>
            <TableHead>Fecha Resolución</TableHead>
            <TableHead>Acciones</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TooltipProvider>
            {riesgos.map((riesgo) => (
              <TableRow key={riesgo.id}>
                <TableCell className="font-medium">
                  <div className="font-bold">{riesgo.name}</div>
                </TableCell>
                <TableCell>
                  <Tooltip>
                    <TooltipTrigger>
                      <span className="truncate block max-w-xs">{getAssetNames(riesgo.asset_risk_link)}</span>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{getAssetNames(riesgo.asset_risk_link)}</p>
                    </TooltipContent>
                  </Tooltip>
                </TableCell>
                <TableCell>{riesgo.threat_typology}</TableCell>
                <TableCell>{riesgo.treatment_owner}</TableCell>
                <TableCell>
                  <Badge className={`${getRiskLevelColor(riesgo.level)}`}>{riesgo.level}</Badge>
                </TableCell>
                <TableCell>{riesgo.treatment}</TableCell>
                <TableCell>
                  <Badge className={`${getStatusColor(riesgo.status)}`}>{riesgo.status}</Badge>
                </TableCell>
                <TableCell>{riesgo.resolution_date ? new Date(riesgo.resolution_date).toLocaleDateString() : 'N/A'}</TableCell>
                <TableCell>
                  {!isAuditorMode && (
                    <div className="flex items-center">
                      <Button variant="ghost" size="icon" onClick={() => onEdit(riesgo)}><Edit3 className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => onDelete(riesgo)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                    </div>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TooltipProvider>
        </TableBody>
      </Table>
    </div>
  );
};

export default RiesgosTable;