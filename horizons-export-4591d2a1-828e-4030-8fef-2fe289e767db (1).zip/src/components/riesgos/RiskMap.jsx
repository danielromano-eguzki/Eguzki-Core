import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Map } from 'lucide-react';

const probabilityLabels = ["Muy Baja (1)", "Baja (2)", "Media (3)", "Alta (4)", "Muy Alta (5)"];
const impactLabels = ["Muy Alto (5)", "Alto (4)", "Medio (3)", "Bajo (2)", "Muy Bajo (1)"];

const mageritNivelRiesgoMap = [
  ["Muy Bajo", "Muy Bajo", "Bajo", "Medio", "Alto"],
  ["Muy Bajo", "Bajo", "Medio", "Alto", "Muy Alto"],
  ["Bajo", "Medio", "Alto", "Muy Alto", "Crítico"],
  ["Medio", "Alto", "Muy Alto", "Crítico", "Crítico"],
  ["Alto", "Muy Alto", "Crítico", "Crítico", "Crítico"],
];

const getNivelColor = (nivel) => {
  const colors = {
    'Crítico': 'bg-red-600/80',
    'Muy Alto': 'bg-orange-600/80',
    'Alto': 'bg-orange-500/80',
    'Medio': 'bg-yellow-400/80',
    'Bajo': 'bg-green-400/80',
    'Muy Bajo': 'bg-emerald-500/80',
  };
  return colors[nivel] || 'bg-gray-400/80';
};

const parseValue = (str) => {
  if (!str) return null;
  const match = str.match(/\((\d+)\)/);
  return match ? parseInt(match[1], 10) : null;
};

const RiskMap = ({ riesgos }) => {
  const riskCounts = useMemo(() => {
    const counts = Array(5).fill(null).map(() => Array(5).fill(0));
    riesgos.forEach(riesgo => {
      const prob = parseValue(riesgo.probability);
      const imp = parseValue(riesgo.impact);
      if (prob !== null && imp !== null && prob >= 1 && prob <= 5 && imp >= 1 && imp <= 5) {
        counts[imp - 1][prob - 1]++;
      }
    });
    return counts;
  }, [riesgos]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className="mb-6"
    >
      <Card className="bg-white/70 backdrop-blur-lg border border-white/20 shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-gray-800">
            <Map className="w-6 h-6 text-gradient-green" />
            Mapa de Riesgos (Probabilidad vs. Impacto)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex">
            <div className="flex flex-col justify-around items-center pr-4 w-24">
              <div className="transform -rotate-90 whitespace-nowrap font-semibold text-gray-600">Impacto</div>
            </div>
            <div className="flex-1">
              <div className="grid grid-cols-5 gap-1">
                {impactLabels.map((impactLabel, rowIndex) => (
                  <React.Fragment key={impactLabel}>
                    {probabilityLabels.map((probLabel, colIndex) => {
                      const impactValue = 5 - rowIndex;
                      const probValue = colIndex + 1;
                      const riskLevel = mageritNivelRiesgoMap[impactValue - 1][probValue - 1];
                      const count = riskCounts[impactValue - 1][probValue - 1];
                      return (
                        <div
                          key={`${rowIndex}-${colIndex}`}
                          className={`relative aspect-square flex flex-col items-center justify-center rounded-lg text-white p-2 transition-transform hover:scale-105 ${getNivelColor(riskLevel)}`}
                          title={`Probabilidad: ${probLabel}\nImpacto: ${impactLabel}\nNivel: ${riskLevel}`}
                        >
                          <span className="text-2xl font-bold">{count}</span>
                          <span className="text-xs opacity-80">{riskLevel}</span>
                        </div>
                      );
                    })}
                  </React.Fragment>
                ))}
              </div>
              <div className="flex justify-center mt-4">
                <div className="font-semibold text-gray-600">Probabilidad</div>
              </div>
            </div>
          </div>
          <div className="flex justify-center mt-4 space-x-4 text-xs">
            {Object.entries({
              'Muy Bajo': 'bg-emerald-500', 'Bajo': 'bg-green-400', 'Medio': 'bg-yellow-400',
              'Alto': 'bg-orange-500', 'Muy Alto': 'bg-orange-600', 'Crítico': 'bg-red-600'
            }).map(([level, color]) => (
              <div key={level} className="flex items-center">
                <span className={`w-3 h-3 rounded-full mr-1.5 ${color}`}></span>
                <span>{level}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default RiskMap;