import React, { useMemo } from 'react';
import { Bar, Pie } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement } from 'chart.js';
import { BarChart2, PieChart } from 'lucide-react';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

const mageritNivelRiesgo = ["Muy Bajo", "Bajo", "Medio", "Alto", "Muy Alto", "Crítico"];
const mageritTratamiento = ["Aceptar", "Evitar", "Mitigar", "Transferir"];

const getNivelColor = (nivel, type = 'hex') => {
  const colors = {
    'Crítico': { hex: '#EF4444' }, 'Muy Alto': { hex: '#EA580C' }, 'Alto': { hex: '#F97316' },
    'Medio': { hex: '#FACC15' }, 'Bajo': { hex: '#4ADE80' }, 'Muy Bajo': { hex: '#243430' }
  };
  return colors[nivel]?.[type] || '#6B7280';
};

const RiesgosGraficos = ({ riesgos }) => {
  const nivelesData = useMemo(() => {
    const counts = mageritNivelRiesgo.reduce((acc, nivel) => ({ ...acc, [nivel]: riesgos.filter(r => r.level === nivel).length }), {});
    return {
      labels: mageritNivelRiesgo,
      datasets: [{
        label: 'Número de Riesgos',
        data: mageritNivelRiesgo.map(nivel => counts[nivel]),
        backgroundColor: mageritNivelRiesgo.map(nivel => getNivelColor(nivel)),
        borderColor: mageritNivelRiesgo.map(nivel => getNivelColor(nivel)),
        borderWidth: 1
      }]
    };
  }, [riesgos]);

  const tratamientosData = useMemo(() => {
    const counts = mageritTratamiento.reduce((acc, t) => ({ ...acc, [t]: riesgos.filter(r => r.treatment === t).length }), {});
    return {
      labels: mageritTratamiento,
      datasets: [{
        label: 'Distribución por Tratamiento',
        data: mageritTratamiento.map(t => counts[t]),
        backgroundColor: ['#3B82F6', '#10B981', '#F59E0B', '#8B5CF6'],
        borderColor: ['#FFFFFF'],
        borderWidth: 2
      }]
    };
  }, [riesgos]);

  const chartOptions = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { position: 'top', labels: { color: '#374151' } }, title: { display: true, text: 'Distribución de Riesgos por Nivel', color: '#1F2937', font: { size: 16 } } },
    scales: { y: { ticks: { color: '#4B5563' } }, x: { ticks: { color: '#4B5563' } } }
  };

  const pieChartOptions = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { position: 'top', labels: { color: '#374151' } }, title: { display: true, text: 'Distribución de Riesgos por Tratamiento', color: '#1F2937', font: { size: 16 } } }
  };

  if (!riesgos || riesgos.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <PieChart className="w-12 h-12 mx-auto mb-2 text-gray-400" />
        No hay datos de riesgos disponibles para mostrar gráficos.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
      <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-md">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center"><BarChart2 className="mr-2 text-blue-600" />Riesgos por Nivel</h3>
        <div style={{ height: '300px' }}><Bar data={nivelesData} options={chartOptions} /></div>
      </div>
      <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-md">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center"><PieChart className="mr-2 text-purple-600" />Riesgos por Tratamiento</h3>
        <div style={{ height: '300px' }}><Pie data={tratamientosData} options={pieChartOptions} /></div>
      </div>
    </div>
  );
};

export default RiesgosGraficos;