import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { DialogFooter } from '@/components/ui/dialog';
import { X } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

const mageritProbabilidad = ["Muy Baja (1)", "Baja (2)", "Media (3)", "Alta (4)", "Muy Alta (5)"];
const mageritImpacto = ["Muy Bajo (1)", "Bajo (2)", "Medio (3)", "Alto (4)", "Muy Alto (5)"];
const mageritTratamiento = ["Aceptar", "Evitar", "Mitigar", "Transferir"];
const mageritEstado = ["Pendiente", "Evaluado", "En Progreso", "Implementado", "Rechazado"];
const mageritNivelRiesgoMap = [
  ["Muy Bajo", "Muy Bajo", "Bajo", "Medio", "Alto"],
  ["Muy Bajo", "Bajo", "Medio", "Alto", "Muy Alto"],
  ["Bajo", "Medio", "Alto", "Muy Alto", "Crítico"],
  ["Medio", "Alto", "Muy Alto", "Crítico", "Crítico"],
  ["Alto", "Muy Alto", "Crítico", "Crítico", "Crítico"],
];
const dimensions = ["Integridad", "Confidencialidad", "Disponibilidad", "Autenticidad", "Trazabilidad"];
const threatTypologies = [
  "Acceso no autorizado",
  "Malware",
  "Phishing",
  "Denegación de servicio (DoS)",
  "Error humano",
  "Fallo de sistema",
  "Desastre natural",
  "Robo físico",
  "Amenaza interna",
  "Otro"
];

const RiesgoForm = ({ onSubmit, onCancel, existingRiesgo, assets }) => {
  const [name, setName] = useState('');
  const [assetIds, setAssetIds] = useState([]);
  const [threat, setThreat] = useState('');
  const [affectedDimensions, setAffectedDimensions] = useState([]);
  const [probability, setProbability] = useState('');
  const [impact, setImpact] = useState('');
  const [level, setLevel] = useState('');
  const [treatment, setTreatment] = useState('');
  const [status, setStatus] = useState('Pendiente');
  const [threatTypology, setThreatTypology] = useState('');
  const [treatmentOwner, setTreatmentOwner] = useState('');
  const [resolutionDate, setResolutionDate] = useState('');

  useEffect(() => {
    if (existingRiesgo) {
      setName(existingRiesgo.name || '');
      setAssetIds(existingRiesgo.asset_risk_link?.map(l => l.asset_id) || []);
      setThreat(existingRiesgo.threat || '');
      setAffectedDimensions(existingRiesgo.affected_dimensions || []);
      setProbability(existingRiesgo.probability || '');
      setImpact(existingRiesgo.impact || '');
      setLevel(existingRiesgo.level || '');
      setTreatment(existingRiesgo.treatment || '');
      setStatus(existingRiesgo.status || 'Pendiente');
      setThreatTypology(existingRiesgo.threat_typology || '');
      setTreatmentOwner(existingRiesgo.treatment_owner || '');
      setResolutionDate(existingRiesgo.resolution_date || '');
    } else {
      setName('');
      setAssetIds([]);
      setThreat('');
      setAffectedDimensions([]);
      setProbability('');
      setImpact('');
      setLevel('');
      setTreatment('');
      setStatus('Pendiente');
      setThreatTypology('');
      setTreatmentOwner('');
      setResolutionDate('');
    }
  }, [existingRiesgo]);

  useEffect(() => {
    if (probability && impact) {
      const probIndex = parseInt(probability.split(' ')[1].replace('(', '').replace(')', ''), 10) - 1;
      const impactIndex = parseInt(impact.split(' ')[1].replace('(', '').replace(')', ''), 10) - 1;
      if (probIndex >= 0 && impactIndex >= 0) {
        setLevel(mageritNivelRiesgoMap[impactIndex][probIndex]);
      }
    } else {
        setLevel('');
    }
  }, [probability, impact]);

  const handleDimensionChange = (dimension) => {
    setAffectedDimensions(prev =>
      prev.includes(dimension)
        ? prev.filter(d => d !== dimension)
        : [...prev, dimension]
    );
  };
  
  const handleAssetChange = (assetId) => {
    setAssetIds(prev =>
      prev.includes(assetId)
        ? prev.filter(id => id !== assetId)
        : [...prev, assetId]
    );
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const riesgoData = {
      name, asset_ids: assetIds, threat, affected_dimensions: affectedDimensions, probability,
      impact, level, treatment, status, threat_typology: threatTypology,
      treatment_owner: treatmentOwner, resolution_date: resolutionDate || null,
    };
    onSubmit(riesgoData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto p-1 pr-4">
      <div>
        <Label htmlFor="riesgo-name">Nombre del Riesgo</Label>
        <Input id="riesgo-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej: Fuga de datos en servidor" required />
      </div>
      <div>
        <Label>Activos Afectados</Label>
        <div className="p-2 border rounded-md">
          <ScrollArea className="h-32">
            <div className="space-y-2">
              {assets.map(asset => (
                <div key={asset.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={`asset-${asset.id}`}
                    checked={assetIds.includes(asset.id)}
                    onCheckedChange={() => handleAssetChange(asset.id)}
                  />
                  <Label htmlFor={`asset-${asset.id}`} className="font-normal">{asset.name}</Label>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      </div>
      <div>
        <Label htmlFor="riesgo-threat">Amenaza</Label>
        <Textarea id="riesgo-threat" value={threat} onChange={(e) => setThreat(e.target.value)} placeholder="Describe la amenaza potencial"/>
      </div>
       <div>
        <Label htmlFor="threat-typology">Tipología de Amenaza</Label>
        <Select onValueChange={setThreatTypology} value={threatTypology}>
          <SelectTrigger id="threat-typology">
            <SelectValue placeholder="Seleccionar tipología" />
          </SelectTrigger>
          <SelectContent>
            {threatTypologies.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label>Dimensión Afectada</Label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 p-2 border rounded-md">
          {dimensions.map(dim => (
            <div key={dim} className="flex items-center space-x-2">
              <Checkbox
                id={`dim-${dim}`}
                checked={affectedDimensions.includes(dim)}
                onCheckedChange={() => handleDimensionChange(dim)}
              />
              <Label htmlFor={`dim-${dim}`} className="font-normal">{dim}</Label>
            </div>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="riesgo-probability">Probabilidad</Label>
          <Select onValueChange={setProbability} value={probability} required>
            <SelectTrigger id="riesgo-probability"><SelectValue placeholder="Seleccionar probabilidad"/></SelectTrigger>
            <SelectContent>
                {mageritProbabilidad.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="riesgo-impact">Impacto</Label>
          <Select onValueChange={setImpact} value={impact} required>
            <SelectTrigger id="riesgo-impact"><SelectValue placeholder="Seleccionar impacto"/></SelectTrigger>
            <SelectContent>
                {mageritImpacto.map(i => <SelectItem key={i} value={i}>{i}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label htmlFor="riesgo-level">Nivel de Riesgo (Calculado)</Label>
        <Input id="riesgo-level" value={level} readOnly className="bg-gray-100" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="riesgo-treatment">Tratamiento</Label>
          <Select onValueChange={setTreatment} value={treatment} required>
            <SelectTrigger id="riesgo-treatment"><SelectValue placeholder="Seleccionar tratamiento"/></SelectTrigger>
            <SelectContent>
                {mageritTratamiento.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="riesgo-status">Estado</Label>
          <Select onValueChange={setStatus} value={status} required>
            <SelectTrigger id="riesgo-status"><SelectValue placeholder="Seleccionar estado"/></SelectTrigger>
            <SelectContent>
                {mageritEstado.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="treatment-owner">Responsable del Tratamiento</Label>
          <Input id="treatment-owner" value={treatmentOwner} onChange={(e) => setTreatmentOwner(e.target.value)} placeholder="Ej: Departamento de TI" />
        </div>
        <div>
          <Label htmlFor="resolution-date">Fecha de Resolución</Label>
          <Input id="resolution-date" type="date" value={resolutionDate} onChange={(e) => setResolutionDate(e.target.value)} />
        </div>
      </div>
      <DialogFooter className="pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{existingRiesgo ? 'Actualizar Riesgo' : 'Añadir Riesgo'}</Button>
      </DialogFooter>
    </form>
  );
};

export default RiesgoForm;