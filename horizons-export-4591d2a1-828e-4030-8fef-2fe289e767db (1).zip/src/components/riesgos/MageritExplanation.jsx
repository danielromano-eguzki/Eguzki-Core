import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, TrendingUp } from 'lucide-react';

const probabilityLevels = [
  { level: 1, name: 'Muy Baja', description: 'El suceso podría ocurrir sólo en circunstancias excepcionales; una vez cada 5 años o más.' },
  { level: 2, name: 'Baja', description: 'El suceso podría ocurrir en algún momento; una vez al año.' },
  { level: 3, name: 'Media', description: 'El suceso debería ocurrir en algún momento; varias veces al año.' },
  { level: 4, name: 'Alta', description: 'Es muy probable que el suceso ocurra en la mayoría de las circunstancias; una vez al mes.' },
  { level: 5, name: 'Muy Alta', description: 'El suceso se espera que ocurra en la mayoría de las circunstancias; varias veces al mes.' },
];

const impactLevels = [
  { level: 1, name: 'Muy Bajo', description: 'Impacto insignificante en la operativa, reputación o finanzas. Pérdidas menores a 1.000€.' },
  { level: 2, name: 'Bajo', description: 'Impacto menor, fácilmente absorbible. Pérdidas entre 1.000€ y 10.000€.' },
  { level: 3, name: 'Medio', description: 'Impacto notable que requiere acción. Pérdidas entre 10.000€ y 50.000€.' },
  { level: 4, name: 'Alto', description: 'Impacto grave que amenaza los objetivos. Pérdidas entre 50.000€ y 200.000€.' },
  { level: 5, name: 'Muy Alto', description: 'Impacto catastrófico que amenaza la supervivencia de la organización. Pérdidas superiores a 200.000€.' },
];

const MageritExplanation = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6"
    >
      <Card className="bg-white/70 backdrop-blur-lg border border-white/20 shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-gray-800">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            Evaluación de Probabilidad (Magerit v3)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {probabilityLevels.map(p => (
            <div key={p.level} className="p-3 rounded-lg bg-gray-50/50 border border-gray-200/50">
              <div className="flex items-center justify-between">
                <p className="font-semibold text-gray-700">{p.name}</p>
                <Badge variant="secondary">Nivel {p.level}</Badge>
              </div>
              <p className="text-sm text-gray-600 mt-1">{p.description}</p>
            </div>
          ))}
        </CardContent>
      </Card>
      <Card className="bg-white/70 backdrop-blur-lg border border-white/20 shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-gray-800">
            <ArrowRight className="w-6 h-6 text-red-600" />
            Evaluación de Impacto (Magerit v3)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {impactLevels.map(i => (
            <div key={i.level} className="p-3 rounded-lg bg-gray-50/50 border border-gray-200/50">
              <div className="flex items-center justify-between">
                <p className="font-semibold text-gray-700">{i.name}</p>
                <Badge variant="secondary">Nivel {i.level}</Badge>
              </div>
              <p className="text-sm text-gray-600 mt-1">{i.description}</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default MageritExplanation;