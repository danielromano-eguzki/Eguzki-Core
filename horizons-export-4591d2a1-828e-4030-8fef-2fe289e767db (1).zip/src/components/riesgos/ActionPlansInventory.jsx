import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Edit3, Trash2, PlusCircle, ShieldCheck } from 'lucide-react';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from "@/components/ui/alert-dialog";
import ActionPlanForm from './ActionPlanForm';

const getStatusColor = (status) => {
  if (status === 'Completado') return 'bg-green-100 text-green-700';
  if (status === 'En Progreso') return 'bg-blue-100 text-blue-700';
  if (status === 'Cancelado') return 'bg-red-100 text-red-700';
  return 'bg-gray-100 text-gray-700';
};

const ActionPlansInventory = ({ risks, actionPlans, addActionPlan, updateActionPlan, deleteActionPlan, riskThreshold, isReadOnly }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [planToDelete, setPlanToDelete] = useState(null);
  const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);
  const [currentRiskId, setCurrentRiskId] = useState(null);

  const parseValue = (str) => {
    if (!str) return 0;
    const match = str.match(/\((\d+)\)/);
    return match ? parseInt(match[1], 10) : 0;
  };

  const calculateRiskValue = (risk) => {
    const prob = parseValue(risk.probability);
    const imp = parseValue(risk.impact);
    return prob * imp;
  };

  const risksRequiringPlan = risks.filter(risk => calculateRiskValue(risk) > riskThreshold);

  const handleAddNew = (riskId) => {
    if (isReadOnly) return;
    setCurrentRiskId(riskId);
    setEditingPlan(null);
    setIsModalOpen(true);
  };

  const handleEdit = (plan) => {
    if (isReadOnly) return;
    setCurrentRiskId(plan.risk_id);
    setEditingPlan(plan);
    setIsModalOpen(true);
  };

  const handleDelete = (plan) => {
    if (isReadOnly) return;
    setPlanToDelete(plan);
    setIsDeleteAlertOpen(true);
  };

  const confirmDelete = () => {
    if (planToDelete) {
      deleteActionPlan(planToDelete.id);
    }
    setIsDeleteAlertOpen(false);
    setPlanToDelete(null);
  };

  const handleFormSubmit = (planData) => {
    if (editingPlan) {
      updateActionPlan(editingPlan.id, planData);
    } else {
      addActionPlan({ ...planData, risk_id: currentRiskId });
    }
    setIsModalOpen(false);
    setEditingPlan(null);
    setCurrentRiskId(null);
  };

  return (
    <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-md">
      <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
        Inventario de Medidas y Planes de Acción
      </h3>
      <p className="text-sm text-gray-600 mb-4">
        A continuación se muestran los riesgos que superan el umbral de <span className="font-bold">{riskThreshold}</span> y requieren un plan de acción.
      </p>

      <div className="space-y-6">
        {risksRequiringPlan.length > 0 ? (
          risksRequiringPlan.map(risk => (
            <div key={risk.id} className="p-4 border rounded-lg bg-gray-50/50">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-semibold text-gray-800">{risk.name}</h4>
                  <p className="text-sm text-gray-500">Nivel de Riesgo: {risk.level} (Valor: {calculateRiskValue(risk)})</p>
                </div>
                {!isReadOnly && (
                  <Button size="sm" onClick={() => handleAddNew(risk.id)}>
                    <PlusCircle className="w-4 h-4 mr-2" /> Añadir Plan
                  </Button>
                )}
              </div>
              <div className="mt-4 overflow-x-auto">
                {actionPlans.filter(p => p.risk_id === risk.id).length > 0 ? (
                  <table className="w-full text-sm min-w-[800px]">
                    <thead className="text-left text-gray-500">
                      <tr>
                        <th className="p-2 w-1/3">Descripción</th>
                        <th className="p-2">Responsable</th>
                        <th className="p-2">Vencimiento</th>
                        <th className="p-2">Estado</th>
                        <th className="p-2">Efectividad</th>
                        <th className="p-2">Riesgo Residual</th>
                        <th className="p-2">Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {actionPlans.filter(p => p.risk_id === risk.id).map(plan => (
                        <tr key={plan.id} className="border-t">
                          <td className="p-2">{plan.description}</td>
                          <td className="p-2">{plan.responsible}</td>
                          <td className="p-2">{plan.due_date}</td>
                          <td className="p-2">
                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(plan.status)}`}>
                              {plan.status}
                            </span>
                          </td>
                          <td className="p-2">{plan.effectiveness || 'N/A'}</td>
                          <td className="p-2">{plan.estimated_residual_risk || 'N/A'}</td>
                          <td className="p-2">
                            {!isReadOnly && (
                              <div className="flex items-center">
                                <Button variant="ghost" size="icon" onClick={() => handleEdit(plan)}><Edit3 className="w-4 h-4" /></Button>
                                <Button variant="ghost" size="icon" onClick={() => handleDelete(plan)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                              </div>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <p className="text-center text-sm text-gray-500 py-4">No hay planes de acción definidos para este riesgo.</p>
                )}
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-gray-500 py-6">No hay riesgos que superen el umbral definido.</p>
        )}
      </div>

      <Dialog open={isModalOpen} onOpenChange={(isOpen) => { if (!isOpen) { setEditingPlan(null); setCurrentRiskId(null); } setIsModalOpen(isOpen); }}>
        <DialogContent className="sm:max-w-lg bg-white/90 backdrop-blur-lg">
          <DialogHeader>
            <DialogTitle>{editingPlan ? 'Editar Plan de Acción' : 'Añadir Nuevo Plan de Acción'}</DialogTitle>
            <DialogDescription>
              {editingPlan ? 'Modifica la información del plan.' : 'Completa la información para el nuevo plan de acción.'}
            </DialogDescription>
          </DialogHeader>
          <ActionPlanForm onSubmit={handleFormSubmit} onCancel={() => setIsModalOpen(false)} existingPlan={editingPlan} />
        </DialogContent>
      </Dialog>

      <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. Esto eliminará permanentemente el plan de acción.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setPlanToDelete(null)}>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ActionPlansInventory;