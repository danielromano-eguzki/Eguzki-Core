import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle } from 'lucide-react';

const AddonCard = ({ addon, onPurchase }) => {
  return (
    <motion.div
      whileHover={{ y: -5, boxShadow: '0 10px 20px rgba(0,0,0,0.1)' }}
      className="h-full"
    >
      <Card className="flex flex-col h-full bg-white/80 backdrop-blur-md border border-gray-200/50 rounded-xl overflow-hidden">
        <CardHeader className="p-6">
          <div className="flex items-center space-x-4 mb-4">
            <div className="p-3 bg-gray-100 rounded-lg">
              {addon.icon}
            </div>
            <div>
              <CardTitle className="text-xl font-bold text-gray-800">{addon.title}</CardTitle>
              <CardDescription className="text-sm font-medium text-emerald-600">{addon.category}</CardDescription>
            </div>
          </div>
          <p className="text-gray-600 text-sm min-h-[60px]">{addon.description}</p>
        </CardHeader>
        <CardContent className="p-6 flex-grow">
          <ul className="space-y-2 text-sm text-gray-700">
            {addon.features.map((feature, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="w-4 h-4 mr-2 mt-0.5 text-green-500 flex-shrink-0" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </CardContent>
        <CardFooter className="p-6 bg-gray-50/50 border-t border-gray-200/50 flex items-center justify-between">
          <p className="text-2xl font-bold text-gray-800">{addon.price}</p>
          <Button onClick={onPurchase} className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white">
            Adquirir
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default AddonCard;