import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Edit3, Trash2, Download, ArrowUpDown, ChevronDown, ChevronUp, Filter as FilterIcon } from 'lucide-react';

const SortableHeader = ({ columnKey, title, sortConfig, requestSort }) => (
  <th scope="col" className="px-4 py-3 cursor-pointer hover:bg-gray-200/70" onClick={() => requestSort(columnKey)}>
    <div className="flex items-center justify-between">
      {title}
      {sortConfig.key === columnKey ? (
        sortConfig.direction === 'ascending' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
      ) : <ArrowUpDown className="w-4 h-4 opacity-30" />}
    </div>
  </th>
);

const EvidencesTable = ({ evidences, categories, controls, sortConfig, requestSort, onEdit, onDelete, onDownloadFile }) => (
  <div className="overflow-x-auto">
    <table className="w-full text-sm text-left text-gray-700">
      <thead className="text-xs text-gray-700 uppercase bg-gray-100/50">
        <tr>
          <SortableHeader columnKey="name" title="Nombre Evidencia" sortConfig={sortConfig} requestSort={requestSort} />
          <SortableHeader columnKey="category_id" title="Categoría" sortConfig={sortConfig} requestSort={requestSort} />
          <SortableHeader columnKey="control_id" title="Control" sortConfig={sortConfig} requestSort={requestSort} />
          <SortableHeader columnKey="type" title="Tipo" sortConfig={sortConfig} requestSort={requestSort} />
          <SortableHeader columnKey="date" title="Fecha" sortConfig={sortConfig} requestSort={requestSort} />
          <SortableHeader columnKey="owner" title="Propietario" sortConfig={sortConfig} requestSort={requestSort} />
          <th scope="col" className="px-4 py-3">Archivo</th>
          <th scope="col" className="px-4 py-3">Acciones</th>
        </tr>
      </thead>
      <tbody>
        {evidences.map((evidence, index) => (
          <motion.tr
            key={evidence.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-white/80 border-b border-gray-200/80 hover:bg-gray-50/70"
          >
            <td className="px-4 py-3 font-medium text-gray-900">{evidence.name}</td>
            <td className="px-4 py-3">{categories.find(cat => cat.id === evidence.category_id)?.name || 'N/A'}</td>
            <td className="px-4 py-3">{controls.find(ctrl => ctrl.id === evidence.control_id)?.control_id_ext || 'N/A'}</td>
            <td className="px-4 py-3">{evidence.type}</td>
            <td className="px-4 py-3">{evidence.date}</td>
            <td className="px-4 py-3">{evidence.owner}</td>
            <td className="px-4 py-3">
              {evidence.file_path ? (
                <Button variant="outline" size="sm" onClick={() => onDownloadFile(evidence.file_path, evidence.file_name)}>
                  <Download className="w-4 h-4 mr-2" /> {evidence.file_name?.substring(0, 15) || 'Descargar'}...
                </Button>
              ) : (
                <span className="text-xs text-gray-400">No adjunto</span>
              )}
            </td>
            <td className="px-4 py-3">
              <Button variant="ghost" size="icon" onClick={() => onEdit(evidence)}><Edit3 className="w-4 h-4" /></Button>
              <Button variant="ghost" size="icon" onClick={() => onDelete(evidence)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
            </td>
          </motion.tr>
        ))}
        {evidences.length === 0 && (
          <tr>
            <td colSpan="8" className="text-center py-10 text-gray-500">
              <FilterIcon className="w-12 h-12 mx-auto mb-2 text-gray-400" />
              No se encontraron evidencias con los filtros actuales.
            </td>
          </tr>
        )}
      </tbody>
    </table>
  </div>
);

export default EvidencesTable;