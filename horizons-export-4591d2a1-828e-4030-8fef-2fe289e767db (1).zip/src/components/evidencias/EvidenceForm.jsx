import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { DialogFooter } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from '@/components/ui/badge';

const EvidenceForm = ({ onSubmit, onCancel, existingEvidence, isReadOnly, requirements, certifications, calculateHash }) => {
  const [formData, setFormData] = useState({
    evidence_id_custom: '',
    nombre: '',
    tipo: '',
    departamento: '',
    responsable: '',
    fecha: new Date().toISOString().split('T')[0],
    comentarios: '',
    hash: '',
  });
  const [file, setFile] = useState(null);
  const [linkedReqs, setLinkedReqs] = useState([]);
  const [isCalculatingHash, setIsCalculatingHash] = useState(false);

  useEffect(() => {
    if (existingEvidence) {
      setFormData({
        evidence_id_custom: existingEvidence.evidence_id_custom || '',
        nombre: existingEvidence.nombre || '',
        tipo: existingEvidence.tipo || '',
        departamento: existingEvidence.departamento || '',
        responsable: existingEvidence.responsable || '',
        fecha: existingEvidence.fecha ? new Date(existingEvidence.fecha).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
        comentarios: existingEvidence.comentarios || '',
        hash: existingEvidence.hash || '',
      });
      const initialLinked = existingEvidence.linked_requirements?.map(lr => lr.requisitos_certificacion?.id).filter(Boolean) || [];
      setLinkedReqs(initialLinked);
    }
  }, [existingEvidence]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = async (e) => {
    const selectedFile = e.target.files[0] || null;
    setFile(selectedFile);
    if (selectedFile) {
      setIsCalculatingHash(true);
      const hash = await calculateHash(selectedFile);
      setFormData(prev => ({ ...prev, hash: hash }));
      setIsCalculatingHash(false);
    } else {
      setFormData(prev => ({ ...prev, hash: existingEvidence?.hash || '' }));
    }
  };

  const handleReqLinkChange = (reqId) => {
    setLinkedReqs(prev => 
      prev.includes(reqId) ? prev.filter(id => id !== reqId) : [...prev, reqId]
    );
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isReadOnly || isCalculatingHash) return;
    const { hash, ...dataToSubmit } = formData;
    onSubmit(dataToSubmit, file, linkedReqs);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto p-1">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="evidence_id_custom">ID de Evidencia</Label>
          <Input id="evidence_id_custom" name="evidence_id_custom" value={formData.evidence_id_custom} onChange={handleChange} placeholder="Ej: EVID-001" disabled={isReadOnly} required />
        </div>
        <div>
          <Label htmlFor="nombre">Nombre de la Evidencia</Label>
          <Input id="nombre" name="nombre" value={formData.nombre} onChange={handleChange} placeholder="Nombre descriptivo" disabled={isReadOnly} required />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="tipo">Tipo</Label>
          <Input id="tipo" name="tipo" value={formData.tipo} onChange={handleChange} placeholder="Ej: Documento, Captura, Log" disabled={isReadOnly} />
        </div>
        <div>
          <Label htmlFor="departamento">Departamento</Label>
          <Input id="departamento" name="departamento" value={formData.departamento} onChange={handleChange} placeholder="Ej: IT, RRHH" disabled={isReadOnly} />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="responsable">Responsable</Label>
          <Input id="responsable" name="responsable" value={formData.responsable} onChange={handleChange} placeholder="Nombre del responsable" disabled={isReadOnly} />
        </div>
        <div>
          <Label htmlFor="fecha">Fecha</Label>
          <Input id="fecha" name="fecha" type="date" value={formData.fecha} onChange={handleChange} disabled={isReadOnly} />
        </div>
      </div>
      <div>
        <Label htmlFor="file">Adjuntar Fichero</Label>
        <Input id="file" type="file" onChange={handleFileChange} className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20" disabled={isReadOnly} />
        {existingEvidence?.file_path && !file && <p className="text-xs text-gray-500 mt-1">Fichero actual: {existingEvidence.file_name}</p>}
      </div>
      {(formData.hash || isCalculatingHash) && (
        <div>
          <Label htmlFor="hash">Hash (SHA-256)</Label>
          <Input 
            id="hash" 
            name="hash" 
            value={isCalculatingHash ? "Calculando hash..." : formData.hash} 
            readOnly 
            disabled 
            className="bg-gray-100 cursor-not-allowed" 
          />
        </div>
      )}
      <div>
        <Label htmlFor="comentarios">Comentarios</Label>
        <Textarea id="comentarios" name="comentarios" value={formData.comentarios} onChange={handleChange} placeholder="Añade cualquier comentario relevante" disabled={isReadOnly} />
      </div>
      
      <div>
        <Label>Requisitos Aplicables</Label>
        <div className="border rounded-md">
          <ScrollArea className="h-48 p-2">
            <Accordion type="multiple" className="w-full">
              {certifications.map(cert => {
                const certReqs = requirements.filter(req => req.certificacion_id === cert.id);
                if (certReqs.length === 0) return null;
                const selectedCount = certReqs.filter(r => linkedReqs.includes(r.id)).length;
                
                return (
                  <AccordionItem value={cert.id} key={cert.id}>
                    <AccordionTrigger>
                      <div className="flex justify-between w-full pr-4 items-center">
                        <span>{cert.name}</span>
                        {selectedCount > 0 && <Badge variant="secondary">{selectedCount}</Badge>}
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2 p-2">
                      {certReqs.map(req => (
                        <div key={req.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={`req-${req.id}`}
                            checked={linkedReqs.includes(req.id)}
                            onCheckedChange={() => handleReqLinkChange(req.id)}
                            disabled={isReadOnly}
                          />
                          <label htmlFor={`req-${req.id}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                            {req.codigo} - {req.titulo}
                          </label>
                        </div>
                      ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
          </ScrollArea>
        </div>
      </div>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        {!isReadOnly && <Button type="submit" disabled={isCalculatingHash}>{existingEvidence ? 'Actualizar Evidencia' : 'Añadir Evidencia'}</Button>}
      </DialogFooter>
    </form>
  );
};

export default EvidenceForm;