import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Edit, Trash, Download, UploadCloud, RefreshCw } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const EvidencesInventoryTable = ({ evidences, onEdit, onDelete, onDownload, onUpload, onVerifyHash, isReadOnly }) => {
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      return format(new Date(dateString), 'dd/MM/yyyy HH:mm');
    } catch (error) {
      return 'Fecha inválida';
    }
  };

  const getLinkedRequirementsInfo = (evidence) => {
    if (!evidence.linked_requirements || evidence.linked_requirements.length === 0) {
      return <span className="text-gray-400">Sin vincular</span>;
    }
    
    const requirements = evidence.linked_requirements.map(link => link.requisitos_certificacion).filter(Boolean);
    
    if (requirements.length === 0) {
      return <span className="text-gray-400">Sin vincular</span>;
    }

    const firstReq = requirements[0];
    const certName = firstReq.certificacion?.name || 'N/A';
    const reqCode = firstReq.codigo || 'Req';
    const displayText = `${certName} / ${reqCode}`;
    
    const remainingCount = requirements.length - 1;

    return (
      <div className="flex items-center gap-2">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Badge variant="secondary" className="truncate cursor-default">{displayText}</Badge>
            </TooltipTrigger>
            <TooltipContent>
              <p>Requisitos vinculados:</p>
              <ul className="list-disc pl-4">
                {requirements.slice(0, 5).map(r => (
                  <li key={r.id}>{r.codigo} - {r.titulo}</li>
                ))}
                {requirements.length > 5 && <li>...y {requirements.length - 5} más.</li>}
              </ul>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        {remainingCount > 0 && (
          <Badge variant="outline" className="shrink-0">+{remainingCount}</Badge>
        )}
      </div>
    );
  };

  return (
    <div className="rounded-lg border overflow-hidden bg-white/50">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-12"></TableHead>
            <TableHead>ID</TableHead>
            <TableHead>Nombre</TableHead>
            <TableHead className="hidden lg:table-cell">Aplicable en</TableHead>
            <TableHead className="hidden md:table-cell">Responsable</TableHead>
            <TableHead>Última Subida</TableHead>
            <TableHead className="text-right">Acciones</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {evidences && evidences.length > 0 ? (
            evidences.map((evidence) => (
              <TableRow key={evidence.id} className="hover:bg-slate-50/50">
                <TableCell>
                  {evidence.hash && (
                     <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                           <Button variant="ghost" size="icon" onClick={() => onVerifyHash(evidence)} className="h-8 w-8" title="Verificar integridad del fichero">
                            <RefreshCw className="h-4 w-4 text-blue-600" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Verificar integridad</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  )}
                </TableCell>
                <TableCell className="font-medium">{evidence.evidence_id_custom || evidence.id.substring(0, 8)}</TableCell>
                <TableCell className="max-w-xs truncate" title={evidence.nombre}>{evidence.nombre}</TableCell>
                <TableCell className="hidden lg:table-cell">{getLinkedRequirementsInfo(evidence)}</TableCell>
                <TableCell className="hidden md:table-cell">{evidence.responsable || 'N/A'}</TableCell>
                <TableCell>{formatDate(evidence.updated_at)}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end items-center gap-1">
                    {evidence.file_path ? (
                      <TooltipProvider><Tooltip><TooltipTrigger asChild>
                        <Button variant="outline" size="icon" onClick={() => onDownload(evidence)} className="h-8 w-8">
                          <Download className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger><TooltipContent><p>Descargar</p></TooltipContent></Tooltip></TooltipProvider>
                    ) : (
                       <TooltipProvider><Tooltip><TooltipTrigger asChild>
                        <Button variant="outline" size="icon" onClick={() => onUpload(evidence)} className="h-8 w-8" disabled={isReadOnly}>
                          <UploadCloud className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger><TooltipContent><p>Subir Fichero</p></TooltipContent></Tooltip></TooltipProvider>
                    )}
                    <TooltipProvider><Tooltip><TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" onClick={() => onEdit(evidence)} className="h-8 w-8" disabled={isReadOnly}>
                        <Edit className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger><TooltipContent><p>Editar</p></TooltipContent></Tooltip></TooltipProvider>
                     <TooltipProvider><Tooltip><TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" onClick={() => onDelete(evidence)} className="h-8 w-8 hover:bg-red-100" disabled={isReadOnly}>
                        <Trash className="h-4 w-4 text-red-500" />
                      </Button>
                    </TooltipTrigger><TooltipContent><p>Eliminar</p></TooltipContent></Tooltip></TooltipProvider>
                  </div>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={7} className="h-24 text-center">
                No se han encontrado evidencias.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export default EvidencesInventoryTable;