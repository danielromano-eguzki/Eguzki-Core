import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { DialogFooter } from '@/components/ui/dialog';

const CategoryForm = ({ onSubmit, onCancel, existingCategory }) => {
  const [name, setName] = useState(existingCategory?.name || '');
  const [description, setDescription] = useState(existingCategory?.description || '');

  const handleSubmit = (e) => {
    e.preventDefault();
    const categoryData = { name, description };
    if (existingCategory?.id) {
      categoryData.id = existingCategory.id;
    }
    onSubmit(categoryData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="category-name">Nombre de la Categoría</Label>
        <Input id="category-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej: Políticas y Procedimientos" required />
      </div>
      <div>
        <Label htmlFor="category-description">Descripción</Label>
        <Input id="category-description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Breve descripción de la categoría" />
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{existingCategory ? 'Actualizar Categoría' : 'Añadir Categoría'}</Button>
      </DialogFooter>
    </form>
  );
};

export default CategoryForm;