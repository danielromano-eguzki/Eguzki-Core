import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Eye } from 'lucide-react';
import { useMode } from '@/contexts/ModeContext';

const AuditorModeBanner = () => {
  const { isAuditorMode } = useMode();

  return (
    <AnimatePresence>
      {isAuditorMode && (
        <motion.div
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -100, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 200, damping: 25 }}
          className="fixed top-16 left-0 right-0 bg-gradient-to-r from-amber-500 to-orange-500 text-white text-center py-2 px-4 shadow-lg z-50 flex items-center justify-center"
        >
          <Eye className="w-5 h-5 mr-3 animate-pulse" />
          <span className="font-semibold">Modo Auditor Activado (Solo Lectura)</span>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AuditorModeBanner;