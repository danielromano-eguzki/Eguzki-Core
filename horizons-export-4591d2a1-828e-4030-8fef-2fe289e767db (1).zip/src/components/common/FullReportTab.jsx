import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Download, FileText, Loader2, BarChart2, Edit, Save } from 'lucide-react';
import { exportFullReportToPdf } from '@/lib/exportUtils.js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';

const COLORS = {
  'Cumplido': '#243430',
  'Parcial': '#f59e0b',
  'No cumplido': '#ef4444',
  'No aplica': '#a1a1aa',
  'Sin estado': '#64748b',
};

const FullReportTab = ({ requirements, normativeName, clientName }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(true);
  const [reportData, setReportData] = useState({
    reportDate: new Date().toISOString().split('T')[0],
    auditTeam: '',
    auditDuration: '',
    scopeAndObjectives: '',
    improvementPoints: '',
    conclusions: '',
  });
  const chartRef = useRef(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setReportData(prev => ({ ...prev, [name]: value }));
  };

  const processDataForReport = () => {
    return requirements.map(req => ({
      codigo: req.codigo || req.id,
      titulo: req.titulo || req.text,
      estado_cumplimiento: req.estado_cumplimiento || (req.checked ? 'Cumplido' : 'No cumplido'),
      observaciones: req.observaciones || '',
      evidencias_vinculadas: (req.linked_evidences || [])
        .map(ev => ev.nombre || ev.id)
        .join(', ') || 'N/A',
    }));
  };

  const statusCounts = requirements.reduce((acc, req) => {
    const status = req.estado_cumplimiento || (req.checked ? 'Cumplido' : 'No cumplido');
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {});

  const chartData = Object.entries(statusCounts).map(([name, value]) => ({ name, value }));

  const handleExport = async () => {
    setIsLoading(true);
    const inventoryData = processDataForReport();
    const filename = `Informe_Auditoria_${normativeName.replace(/\s/g, '_')}_${clientName.replace(/\s/g, '_')}`;
    
    await exportFullReportToPdf({
      reportMetadata: reportData,
      inventoryData,
      normativeName,
      clientName,
      chartElement: chartRef.current,
      filename
    });

    setIsLoading(false);
  };

  const getStatusBadgeColor = (status) => {
    const colors = {
      'Cumplido': 'bg-green-100 text-green-800',
      'Parcial': 'bg-yellow-100 text-yellow-800',
      'No cumplido': 'bg-red-100 text-red-800',
      'No aplica': 'bg-gray-100 text-gray-800',
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg space-y-8">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Informe de Auditoría Interna</h2>
          <p className="text-gray-600">Genera un informe de cumplimiento detallado para <span className="font-semibold">{normativeName}</span>.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={() => setIsEditing(!isEditing)} variant="outline">
            {isEditing ? <Save className="mr-2 h-4 w-4" /> : <Edit className="mr-2 h-4 w-4" />}
            {isEditing ? 'Guardar Datos' : 'Editar Datos'}
          </Button>
          <Button onClick={handleExport} disabled={isLoading}>
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
            Exportar PDF
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader><CardTitle>1. Datos de la Auditoría</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="reportDate">Fecha del Informe</Label>
            <Input id="reportDate" name="reportDate" type="date" value={reportData.reportDate} onChange={handleInputChange} disabled={!isEditing} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="auditTeam">Equipo Auditor</Label>
            <Input id="auditTeam" name="auditTeam" value={reportData.auditTeam} onChange={handleInputChange} placeholder="Nombres del equipo" disabled={!isEditing} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="auditDuration">Tiempo de la Auditoría</Label>
            <Input id="auditDuration" name="auditDuration" value={reportData.auditDuration} onChange={handleInputChange} placeholder="Ej: 3 días, 20 horas" disabled={!isEditing} />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="scopeAndObjectives">Alcance y Objetivos</Label>
            <Textarea id="scopeAndObjectives" name="scopeAndObjectives" value={reportData.scopeAndObjectives} onChange={handleInputChange} placeholder="Describe el alcance y los objetivos de la auditoría" disabled={!isEditing} rows={4} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="flex items-center"><BarChart2 className="mr-2 h-5 w-5" /> 2. Resumen de Cumplimiento</CardTitle></CardHeader>
        <CardContent ref={chartRef}>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={chartData} cx="50%" cy="50%" labelLine={false} outerRadius={120} fill="#8884d8" dataKey="value" label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}>
                  {chartData.map((entry, index) => (<Cell key={`cell-${index}`} fill={COLORS[entry.name]} />))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>3. Inventario de Cumplimiento</CardTitle></CardHeader>
        <CardContent>
          <div className="rounded-lg border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Código</TableHead>
                  <TableHead>Requisito</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Evidencias Vinculadas</TableHead>
                  <TableHead>Observaciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {processDataForReport().map((item, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{item.codigo}</TableCell>
                    <TableCell>{item.titulo}</TableCell>
                    <TableCell><Badge className={getStatusBadgeColor(item.estado_cumplimiento)}>{item.estado_cumplimiento}</Badge></TableCell>
                    <TableCell className="max-w-xs truncate">{item.evidencias_vinculadas}</TableCell>
                    <TableCell className="max-w-xs truncate">{item.observaciones}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>4. Puntos de Mejora y Hallazgos</CardTitle></CardHeader>
        <CardContent>
          <Textarea id="improvementPoints" name="improvementPoints" value={reportData.improvementPoints} onChange={handleInputChange} placeholder="Detalla los hallazgos, no conformidades y oportunidades de mejora identificadas." disabled={!isEditing} rows={6} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>5. Conclusiones Finales</CardTitle></CardHeader>
        <CardContent>
          <Textarea id="conclusions" name="conclusions" value={reportData.conclusions} onChange={handleInputChange} placeholder="Resume las conclusiones generales de la auditoría y el estado de madurez del sistema." disabled={!isEditing} rows={6} />
        </CardContent>
      </Card>
    </div>
  );
};

export default FullReportTab;