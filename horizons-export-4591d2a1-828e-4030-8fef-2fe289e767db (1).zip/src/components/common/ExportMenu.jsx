import React from 'react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Download, FileText, FileSpreadsheet, FileType } from 'lucide-react';
import { exportToCsv, exportToXlsx, exportToPdf } from '@/lib/exportUtils';

const ExportMenu = ({ data, headers, filenamePrefix, reportTitle, disabled }) => {
  if (!data || data.length === 0) {
    return (
       <Button variant="outline" disabled>
          <Download className="mr-2 h-4 w-4" />
          Exportar
        </Button>
    );
  }

  const handleExport = (format) => {
    const date = new Date().toISOString().slice(0, 10);
    const filename = `${filenamePrefix}_${date}`;
    
    switch (format) {
      case 'csv':
        exportToCsv(data, headers, filename);
        break;
      case 'xlsx':
        exportToXlsx(data, headers, filename);
        break;
      case 'pdf':
        exportToPdf(data, headers, filename, reportTitle);
        break;
      default:
        break;
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" disabled={disabled}>
          <Download className="mr-2 h-4 w-4" />
          Exportar
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent>
        <DropdownMenuItem onClick={() => handleExport('csv')}>
          <FileText className="mr-2 h-4 w-4" />
          <span>Exportar a CSV</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleExport('xlsx')}>
          <FileSpreadsheet className="mr-2 h-4 w-4" />
          <span>Exportar a XLSX</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleExport('pdf')}>
          <FileType className="mr-2 h-4 w-4" />
          <span>Exportar a PDF</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default ExportMenu;