import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Download, FileText, Loader2, BarChart2 } from 'lucide-react';
import { exportToPdfWithChart, exportToXlsx, exportToCsv } from '@/lib/exportUtils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

const COLORS = {
  'Cumplido': '#22c55e',
  'Parcial': '#f59e0b',
  'No cumplido': '#ef4444',
  'No aplica': '#a1a1aa',
  'Sin estado': '#64748b',
};

const ReportsTab = ({ requirements, normativeName, clientName }) => {
  const [isLoading, setIsLoading] = useState(false);
  const chartRef = useRef(null);

  const processDataForReport = () => {
    return requirements.map(req => ({
      codigo: req.codigo || req.id,
      titulo: req.titulo || req.text,
      estado_cumplimiento: req.estado_cumplimiento || (req.checked ? 'Cumplido' : 'No cumplido'),
      evidencias_vinculadas: (req.linked_evidences || [])
        .map(ev => ev.nombre || ev.id)
        .join(', ') || 'N/A',
    }));
  };

  const statusCounts = requirements.reduce((acc, req) => {
    const status = req.estado_cumplimiento || (req.checked ? 'Cumplido' : 'No cumplido');
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {});

  const chartData = Object.entries(statusCounts).map(([name, value]) => ({ name, value }));
  const totalRequirements = requirements.length;
  const fulfilledCount = statusCounts['Cumplido'] || 0;
  const compliancePercentage = totalRequirements > 0 ? Math.round((fulfilledCount / totalRequirements) * 100) : 0;

  const handleExport = async (format) => {
    setIsLoading(true);
    const reportData = processDataForReport();
    const headers = [
      { label: 'Código', key: 'codigo' },
      { label: 'Requisito', key: 'titulo' },
      { label: 'Estado', key: 'estado_cumplimiento' },
      { label: 'Evidencias', key: 'evidencias_vinculadas' },
    ];
    const filename = `Informe_${normativeName.replace(/\s/g, '_')}_${clientName.replace(/\s/g, '_')}`;

    if (format === 'pdf') {
      await exportToPdfWithChart(reportData, headers, filename, `Informe de Cumplimiento: ${normativeName}`, clientName, chartRef.current);
    } else if (format === 'xlsx') {
      exportToXlsx(reportData, headers, filename);
    } else if (format === 'csv') {
      exportToCsv(reportData, headers, filename);
    }
    setIsLoading(false);
  };

  return (
    <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Generador de Informes de Cumplimiento</h2>
          <p className="text-gray-600">Exporta el estado actual de los requisitos y evidencias para <span className="font-semibold">{normativeName}</span>.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={() => handleExport('pdf')} disabled={isLoading}>
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
            PDF
          </Button>
          <Button onClick={() => handleExport('xlsx')} variant="outline" disabled={isLoading}>
            <FileText className="mr-2 h-4 w-4" />
            XLSX
          </Button>
          <Button onClick={() => handleExport('csv')} variant="outline" disabled={isLoading}>
            <FileText className="mr-2 h-4 w-4" />
            CSV
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center"><BarChart2 className="mr-2 h-5 w-5" /> Resumen de Cumplimiento</CardTitle>
          </CardHeader>
          <CardContent ref={chartRef}>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={120}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[entry.name]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        <div className="space-y-4">
            <Card>
                <CardHeader><CardTitle>Total Requisitos</CardTitle></CardHeader>
                <CardContent><p className="text-3xl font-bold">{totalRequirements}</p></CardContent>
            </Card>
             <Card>
                <CardHeader><CardTitle>Nivel de Cumplimiento</CardTitle></CardHeader>
                <CardContent><p className="text-3xl font-bold text-green-600">{compliancePercentage}%</p></CardContent>
            </Card>
        </div>
      </div>

    </div>
  );
};

export default ReportsTab;