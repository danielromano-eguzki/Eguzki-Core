import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Monitor, HardDrive, Users, GitMerge, AlertTriangle, Activity } from 'lucide-react';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { format, subDays } from 'date-fns';
import { es } from 'date-fns/locale';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const StatCard = ({ icon: Icon, title, value, color }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
  >
    <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white/80 backdrop-blur-md border border-gray-200/50 rounded-xl overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
        <Icon className={`h-5 w-5 ${color}`} />
      </CardHeader>
      <CardContent>
        <div className={`text-3xl font-bold ${color}`}>{value}</div>
      </CardContent>
    </Card>
  </motion.div>
);

const ItDashboard = ({ itHook, incidentesHook }) => {
  const { software, hardware, users, changes, loading: itLoading } = itHook;
  const { incidents, loading: incidentsLoading } = incidentesHook;

  const summaryStats = useMemo(() => [
    { title: 'Aplicaciones Inventariadas', value: software?.length || 0, icon: Monitor, color: 'text-blue-500' },
    { title: 'Equipos Inventariados', value: hardware?.length || 0, icon: HardDrive, color: 'text-primary' },
    { title: 'Usuarios Gestionados', value: users?.length || 0, icon: Users, color: 'text-purple-500' },
    { title: 'Cambios Registrados', value: changes?.length || 0, icon: GitMerge, color: 'text-orange-500' },
    { title: 'Incidentes Abiertos', value: (incidents || []).filter(i => i.status !== 'Cerrado').length, icon: AlertTriangle, color: 'text-red-500' },
  ], [software, hardware, users, changes, incidents]);

  const incidentTrendData = useMemo(() => {
    const last7Days = Array.from({ length: 7 }, (_, i) => subDays(new Date(), i)).reverse();
    const labels = last7Days.map(day => format(day, 'EEE', { locale: es }));
    const data = last7Days.map(day => 
      (incidents || []).filter(inc => format(new Date(inc.incident_date), 'yyyy-MM-dd') === format(day, 'yyyy-MM-dd')).length
    );

    return {
      labels,
      datasets: [
        {
          label: 'Incidentes en los últimos 7 días',
          data,
          backgroundColor: 'rgba(239, 68, 68, 0.6)',
          borderColor: 'rgba(239, 68, 68, 1)',
          borderWidth: 1,
        },
      ],
    };
  }, [incidents]);

  const recentChanges = useMemo(() => {
    const oneWeekAgo = subDays(new Date(), 7);
    return (changes || [])
      .filter(c => new Date(c.request_date) >= oneWeekAgo)
      .sort((a, b) => new Date(b.request_date) - new Date(a.request_date))
      .slice(0, 5);
  }, [changes]);

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: { display: false },
      title: { display: true, text: 'Tendencia de Incidentes (Últimos 7 Días)', font: { size: 16 } },
    },
    scales: {
      y: { beginAtZero: true, ticks: { stepSize: 1 } },
    },
  };

  const loading = itLoading || incidentsLoading;

  if (loading) {
    return <div className="text-center p-8">Cargando dashboard de IT...</div>;
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-8"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        {summaryStats.map((stat, index) => (
          <StatCard key={index} {...stat} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-3 bg-white/70 backdrop-blur-lg p-6 rounded-xl shadow-md border border-gray-200/50"
        >
          <Bar options={chartOptions} data={incidentTrendData} />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2 bg-white/70 backdrop-blur-lg p-6 rounded-xl shadow-md border border-gray-200/50"
        >
          <h3 className="text-lg font-bold mb-4 flex items-center"><Activity className="mr-2" />Cambios Recientes (Última Semana)</h3>
          {recentChanges.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fecha</TableHead>
                  <TableHead>Descripción</TableHead>
                  <TableHead>Estado</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentChanges.map(change => (
                  <TableRow key={change.id}>
                    <TableCell>{format(new Date(change.request_date), 'dd/MM/yy')}</TableCell>
                    <TableCell className="truncate max-w-xs">{change.description}</TableCell>
                    <TableCell>{change.status}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-center text-gray-500 mt-8">No hay cambios registrados en la última semana.</p>
          )}
        </motion.div>
      </div>
    </motion.div>
  );
};

export default ItDashboard;