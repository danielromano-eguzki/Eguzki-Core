import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const GenericForm = ({ fields, onSubmit, onCancel, initialData }) => {
  const [formData, setFormData] = useState({});
  const [file, setFile] = useState(null);

  useEffect(() => {
    const defaultState = {};
    fields.forEach(field => {
      if (initialData && initialData[field.name] !== undefined) {
        defaultState[field.name] = initialData[field.name];
      } else {
        defaultState[field.name] = field.type === 'checkbox' ? false : '';
      }
    });
    setFormData(defaultState);
    setFile(null);
  }, [fields, initialData]);

  const handleChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const submissionData = { ...formData };
    if (file) {
      submissionData.file = file;
    }
    onSubmit(submissionData);
  };

  const renderField = (field) => {
    switch (field.type) {
      case 'textarea':
        return <Textarea id={field.name} value={formData[field.name] || ''} onChange={(e) => handleChange(field.name, e.target.value)} />;
      case 'checkbox':
        return (
            <div className="flex items-center space-x-2">
                <Checkbox id={field.name} checked={!!formData[field.name]} onCheckedChange={(checked) => handleChange(field.name, checked)} />
                <label htmlFor={field.name} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                   {field.label}
                </label>
            </div>
        );
      case 'select':
        return (
          <Select value={formData[field.name] || ''} onValueChange={(value) => handleChange(field.name, value)}>
            <SelectTrigger><SelectValue placeholder={`Seleccionar ${field.label}...`} /></SelectTrigger>
            <SelectContent>
              {field.options.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
            </SelectContent>
          </Select>
        );
      case 'file':
        return (
          <div>
            <Input id={field.name} type="file" onChange={handleFileChange} />
            {initialData && initialData.file_name && !file && (
              <p className="text-sm text-gray-500 mt-2">Archivo actual: {initialData.file_name}</p>
            )}
            {file && (
              <p className="text-sm text-gray-500 mt-2">Nuevo archivo: {file.name}</p>
            )}
          </div>
        );
      default:
        return <Input id={field.name} type={field.type} value={formData[field.name] || ''} onChange={(e) => handleChange(field.name, e.target.value)} required={field.required} />;
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto p-2">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {fields.map(field => (
          <div key={field.name} className={field.type === 'textarea' ? 'md:col-span-2' : ''}>
             {field.type !== 'checkbox' && <Label htmlFor={field.name}>{field.label}</Label>}
             {renderField(field)}
          </div>
        ))}
      </div>
      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">Guardar</Button>
      </div>
    </form>
  );
};

export default GenericForm;