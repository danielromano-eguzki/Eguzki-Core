import React from 'react';
import { motion } from 'framer-motion';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Edit, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const GenericTable = ({ data, columns, loading, onEdit, onDelete, isReadOnly }) => {
  
  const formatCell = (item, column) => {
    const value = item[column.accessorKey];
    if (typeof value === 'boolean') {
      return value ? <Badge variant="default" className="bg-green-500">Sí</Badge> : <Badge variant="secondary">No</Badge>;
    }
    return value || 'N/A';
  };
  
  if (loading) {
    return <p className="text-center p-8">Cargando datos...</p>;
  }

  if (!data || data.length === 0) {
    return <p className="text-center text-gray-500 p-8">No hay registros para mostrar.</p>;
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            {columns.map(col => <TableHead key={col.accessorKey}>{col.header}</TableHead>)}
            {!isReadOnly && <TableHead className="text-right">Acciones</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map(item => (
            <motion.tr 
              key={item.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
            >
              {columns.map(col => <TableCell key={col.accessorKey}>{formatCell(item, col)}</TableCell>)}
              {!isReadOnly && (
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" onClick={() => onEdit(item)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => onDelete(item)}>
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </Button>
                </TableCell>
              )}
            </motion.tr>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default GenericTable;