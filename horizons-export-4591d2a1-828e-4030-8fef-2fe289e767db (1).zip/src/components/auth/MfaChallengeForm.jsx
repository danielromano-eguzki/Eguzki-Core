import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ShieldCheck } from 'lucide-react';

const MfaChallengeForm = ({ onVerify, isVerifying }) => {
  const [code, setCode] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (code) {
      onVerify(code);
      setCode('');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="text-center">
        <h2 className="text-2xl font-semibold text-white">Verificación de dos factores</h2>
        <p className="text-emerald-200 mt-1">Ingresa el código de tu aplicación de autenticación.</p>
      </div>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <Label htmlFor="mfa-code" className="text-emerald-100">Código de 6 dígitos</Label>
          <Input
            id="mfa-code"
            type="text"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="pl-4 text-center tracking-[0.5em] bg-white/10 text-white placeholder-emerald-300/70 border-emerald-700/50 focus:border-emerald-500 focus:ring-emerald-500"
            maxLength="6"
            placeholder="••••••"
            autoComplete="one-time-code"
            required
            disabled={isVerifying}
          />
        </div>
        <Button type="submit" className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white py-3 font-semibold" disabled={isVerifying || code.length < 6}>
          {isVerifying ? (
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2"
            ></motion.div>
          ) : <ShieldCheck className="w-5 h-5 mr-2" />}
          {isVerifying ? 'Verificando...' : 'Verificar e Ingresar'}
        </Button>
      </form>
    </motion.div>
  );
};

export default MfaChallengeForm;