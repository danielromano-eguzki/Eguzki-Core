import React, { useState, useEffect, useCallback } from 'react';
import QRCode from 'qrcode.react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Shield, ShieldCheck, ShieldOff, Loader2, AlertTriangle } from 'lucide-react';

const MfaSetup = ({ showToast, supabase }) => {
  const [factors, setFactors] = useState([]);
  const [isEnrolling, setIsEnrolling] = useState(false);
  const [isUnenrolling, setIsUnenrolling] = useState(false);
  const [qrCode, setQrCode] = useState('');
  const [factorId, setFactorId] = useState('');
  const [verifyCode, setVerifyCode] = useState('');
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const mfaEnabled = factors.some(f => f.status === 'verified');

  const checkMfaStatus = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.auth.mfa.listFactors();
    if (error) {
      showToast('Error', 'No se pudo verificar el estado de 2FA.', 'destructive');
    } else if (data) {
      setFactors(data.totp);
    }
    setLoading(false);
  }, [supabase, showToast]);

  useEffect(() => {
    checkMfaStatus();
  }, [checkMfaStatus]);

  const handleEnroll = async () => {
    setIsSubmitting(true);
    const { data, error } = await supabase.auth.mfa.enroll({ factorType: 'totp' });
    if (error) {
      showToast('Error', `No se pudo iniciar el proceso de 2FA: ${error.message}`, 'destructive');
    } else {
      setFactorId(data.id);
      setQrCode(data.totp.uri);
      setIsEnrolling(true);
    }
    setIsSubmitting(false);
  };
  
  const handleForceUnenroll = async () => {
    setIsSubmitting(true);
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
        showToast('Error', 'No se pudo obtener el usuario. Por favor, inicie sesión de nuevo.', 'destructive');
        setIsSubmitting(false);
        return;
    }

    try {
        const { error } = await supabase.functions.invoke('force-unenroll-mfa', {
            body: { userId: user.id },
        });

        if (error) {
            throw error;
        }

        showToast('¡Éxito!', 'Todos los factores 2FA han sido desvinculados. Ahora puede configurar uno nuevo.', 'default');
        setFactors([]);
        setIsUnenrolling(false);
    } catch (error) {
        console.error('Error forcing unenrollment:', error);
        showToast('Error', 'No se pudieron desvincular los factores. Contacta a soporte.', 'destructive');
    } finally {
        setIsSubmitting(false);
    }
  };


  const handleVerifyAndEnable = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const { data: challengeData, error: challengeError } = await supabase.auth.mfa.challenge({ factorId });
    if (challengeError) {
        showToast('Error de Verificación', `No se pudo crear el desafío: ${challengeError.message}`, 'destructive');
        setIsSubmitting(false);
        return;
    }

    const { error: verifyError } = await supabase.auth.mfa.verify({
      factorId,
      challengeId: challengeData.id,
      code: verifyCode,
    });

    if (verifyError) {
      showToast('Error de Verificación', 'El código es incorrecto. Inténtalo de nuevo.', 'destructive');
      setVerifyCode('');
    } else {
      showToast('¡Éxito!', 'La autenticación de dos factores ha sido habilitada.', 'default');
      await checkMfaStatus();
      setIsEnrolling(false);
      setVerifyCode('');
      setQrCode('');
    }
    setIsSubmitting(false);
  };

  const handleUnenroll = async () => {
    setIsSubmitting(true);
    const verifiedFactor = factors.find(f => f.status === 'verified');
    if (!verifiedFactor) {
      showToast('Error', 'No se encontró un factor 2FA para deshabilitar.', 'destructive');
      setIsSubmitting(false);
      return;
    }

    const { error } = await supabase.auth.mfa.unenroll({ factorId: verifiedFactor.id });
    if (error) {
      showToast('Error', `No se pudo deshabilitar 2FA: ${error.message}`, 'destructive');
    } else {
      showToast('2FA Deshabilitado', 'La autenticación de dos factores ha sido desactivada.', 'default');
      setFactors(factors.filter(f => f.id !== verifiedFactor.id));
    }
    setIsSubmitting(false);
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-40">
        <Loader2 className="w-8 h-8 text-gray-400 animate-spin" />
      </div>
    );
  }

  if (isEnrolling) {
    return (
      <div className="p-6 bg-white/60 backdrop-blur-lg rounded-xl shadow-md">
        <h3 className="text-lg font-semibold text-gray-800">Paso 1: Escanea el Código QR</h3>
        <p className="text-sm text-gray-600 mt-1 mb-4">Usa tu aplicación de autenticación (como Google Authenticator, Authy, etc.) para escanear este código.</p>
        <div className="p-4 bg-white rounded-lg inline-block">
          {qrCode && <QRCode value={qrCode} size={160} />}
        </div>
        <h3 className="text-lg font-semibold text-gray-800 mt-6">Paso 2: Verifica el Código</h3>
        <p className="text-sm text-gray-600 mt-1 mb-4">Ingresa el código de 6 dígitos que aparece en tu aplicación para completar la configuración.</p>
        <form onSubmit={handleVerifyAndEnable} className="flex items-end gap-4">
          <div className="flex-grow">
            <Label htmlFor="verify-code">Código de Verificación</Label>
            <Input id="verify-code" value={verifyCode} onChange={(e) => setVerifyCode(e.target.value)} maxLength="6" placeholder="123456" disabled={isSubmitting} />
          </div>
          <Button type="submit" disabled={isSubmitting || verifyCode.length < 6}>
            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isSubmitting ? 'Verificando...' : 'Verificar y Habilitar'}
          </Button>
          <Button variant="outline" onClick={() => setIsEnrolling(false)} disabled={isSubmitting}>Cancelar</Button>
        </form>
      </div>
    );
  }

  return (
    <div className="p-6 bg-white/60 backdrop-blur-lg rounded-xl shadow-md">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 flex items-center">
            {mfaEnabled ? <ShieldCheck className="w-5 h-5 mr-2 text-green-600"/> : <Shield className="w-5 h-5 mr-2 text-gray-500" />}
            Autenticación de Dos Factores (2FA)
          </h3>
          <p className={`text-sm ${mfaEnabled ? 'text-green-700' : 'text-gray-600'}`}>
            {mfaEnabled ? 'Estado: Habilitado' : 'Estado: Deshabilitado'}
          </p>
        </div>
        {mfaEnabled ? (
          <Button variant="destructive" onClick={handleUnenroll} disabled={isSubmitting}>
            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            <ShieldOff className="w-4 h-4 mr-2" />
            {isSubmitting ? 'Deshabilitando...' : 'Deshabilitar 2FA'}
          </Button>
        ) : (
          <Button onClick={handleEnroll} disabled={isSubmitting}>
            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            <ShieldCheck className="w-4 h-4 mr-2" />
            {isSubmitting ? 'Iniciando...' : 'Habilitar 2FA'}
          </Button>
        )}
      </div>
      {factors.length > 0 && !mfaEnabled && (
        <div className="!mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
           <h4 className="font-semibold text-amber-800 flex items-center"><AlertTriangle className="w-5 h-5 mr-2" />¿Problemas para habilitar 2FA?</h4>
           <p className="text-sm text-amber-700 mt-1">Detectamos factores 2FA previos que no están verificados. Si perdiste el acceso, puedes forzar la desvinculación para empezar de nuevo. Se cerrará tu sesión en todos los dispositivos.</p>
           <Button variant="ghost" className="text-amber-800 hover:bg-amber-100 mt-2 h-auto p-1" onClick={handleForceUnenroll} disabled={isSubmitting}>
             {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
             Forzar desvinculación de todos los factores
           </Button>
        </div>
      )}
    </div>
  );
};

export default MfaSetup;