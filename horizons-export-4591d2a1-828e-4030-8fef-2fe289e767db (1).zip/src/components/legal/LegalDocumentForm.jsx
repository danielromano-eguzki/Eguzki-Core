import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DialogFooter } from '@/components/ui/dialog';

const documentTypes = ['Contrato', 'Acuerdo de Confidencialidad (NDA)', 'Aviso Legal', 'Política de Privacidad', 'Términos y Condiciones', 'Otro'];
const statuses = ['Vigente', 'En Revisión', 'Expirado', 'Archivado'];

const LegalDocumentForm = ({ onSubmit, onCancel, existingDocument, isReadOnly }) => {
  const [formData, setFormData] = useState({
    name: '',
    type: 'Contrato',
    description: '',
    review_date: '',
    status: 'Vigente',
  });
  const [attachmentFile, setAttachmentFile] = useState(null);

  useEffect(() => {
    if (existingDocument) {
      setFormData({
        name: existingDocument.name || '',
        type: existingDocument.type || 'Contrato',
        description: existingDocument.description || '',
        review_date: existingDocument.review_date ? existingDocument.review_date.split('T')[0] : '',
        status: existingDocument.status || 'Vigente',
      });
    }
  }, [existingDocument]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setAttachmentFile(e.target.files[0]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if(isReadOnly) return;
    onSubmit(formData, attachmentFile);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto p-1 pr-4">
      <div>
        <Label htmlFor="name">Nombre del Documento</Label>
        <Input id="name" name="name" value={formData.name} onChange={handleChange} placeholder="Ej: Contrato de Servicios con Acme Corp" required disabled={isReadOnly} />
      </div>
      <div>
        <Label htmlFor="type">Tipo de Documento</Label>
        <Select onValueChange={(value) => handleSelectChange('type', value)} value={formData.type} disabled={isReadOnly}>
          <SelectTrigger id="type"><SelectValue placeholder="Seleccionar tipo" /></SelectTrigger>
          <SelectContent>
            {documentTypes.map(type => (
              <SelectItem key={type} value={type}>{type}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label htmlFor="description">Descripción</Label>
        <Textarea id="description" name="description" value={formData.description} onChange={handleChange} placeholder="Breve descripción del contenido o propósito del documento." disabled={isReadOnly} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="review_date">Próxima Fecha de Revisión</Label>
          <Input id="review_date" name="review_date" type="date" value={formData.review_date} onChange={handleChange} disabled={isReadOnly} />
        </div>
        <div>
          <Label htmlFor="status">Estado</Label>
          <Select onValueChange={(value) => handleSelectChange('status', value)} value={formData.status} disabled={isReadOnly}>
            <SelectTrigger id="status"><SelectValue placeholder="Seleccionar estado" /></SelectTrigger>
            <SelectContent>
              {statuses.map(status => (
                <SelectItem key={status} value={status}>{status}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label htmlFor="attachmentFile">Archivo Adjunto</Label>
        <Input id="attachmentFile" type="file" onChange={handleFileChange} disabled={isReadOnly} />
        {existingDocument?.file_name && !attachmentFile && <p className="text-sm text-gray-500 mt-1">Archivo actual: {existingDocument.file_name}</p>}
      </div>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        {!isReadOnly && <Button type="submit">{existingDocument ? 'Actualizar Documento' : 'Añadir Documento'}</Button>}
      </DialogFooter>
    </form>
  );
};

export default LegalDocumentForm;