import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Edit, Trash2, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const LegalDocumentsTable = ({ documents, onEdit, onDelete, onDownloadFile, isReadOnly, loading }) => {
  const [downloading, setDownloading] = useState(null);

  const handleDownload = async (doc) => {
    setDownloading(doc.id);
    await onDownloadFile(doc.file_path, doc.file_name);
    setDownloading(null);
  };

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case 'Vigente': return 'success';
      case 'En Revisión': return 'warning';
      case 'Expirado': return 'destructive';
      default: return 'outline';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-12 h-12 border-4 border-green-500 border-t-transparent rounded-full"></motion.div>
      </div>
    );
  }

  return (
    <div className="bg-white/60 backdrop-blur-lg rounded-xl shadow-md p-6 border border-gray-200/50">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nombre</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead>Próxima Revisión</TableHead>
              <TableHead>Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {documents && documents.map((doc, index) => (
              <motion.tr
                key={doc.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="hover:bg-gray-50/50"
              >
                <TableCell className="font-medium">
                  <div className="flex items-center">
                    <FileText className="h-4 w-4 mr-2 text-gray-500" />
                    {doc.name}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="secondary">{doc.type}</Badge>
                </TableCell>
                <TableCell>
                  <Badge variant={getStatusBadgeVariant(doc.status)}>{doc.status}</Badge>
                </TableCell>
                <TableCell>{doc.review_date ? new Date(doc.review_date).toLocaleDateString() : 'N/A'}</TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <TooltipProvider>
                       {doc.file_path && (
                         <Tooltip>
                          <TooltipTrigger asChild>
                             <Button variant="ghost" size="icon" onClick={() => handleDownload(doc)} disabled={downloading === doc.id} className="text-blue-600 hover:text-blue-800">
                               {downloading === doc.id ? <motion.div animate={{rotate:360}} transition={{duration:1, repeat:Infinity}} className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full" /> : <Download className="h-4 w-4" />}
                             </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Descargar Archivo</p>
                          </TooltipContent>
                        </Tooltip>
                       )}
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="ghost" size="icon" onClick={() => onEdit(doc)} disabled={isReadOnly} className="text-yellow-600 hover:text-yellow-800">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Editar</p>
                        </TooltipContent>
                      </Tooltip>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="ghost" size="icon" onClick={() => onDelete(doc)} disabled={isReadOnly} className="text-red-600 hover:text-red-800">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Eliminar</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </TableCell>
              </motion.tr>
            ))}
          </TableBody>
        </Table>
        {documents && documents.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No hay documentos legales en esta sección.
          </div>
        )}
      </div>
    </div>
  );
};

export default LegalDocumentsTable;