import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const BackupTestForm = ({ onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    test_date: new Date().toISOString().split('T')[0],
    backup_type: '',
    system_restored: '',
    result: 'Exitoso',
    notes: '',
    tested_by: '',
  });

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (id, value) => {
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 pt-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="test_date">Fecha de la Prueba</Label>
          <Input id="test_date" type="date" value={formData.test_date} onChange={handleChange} required />
        </div>
        <div>
          <Label htmlFor="result">Resultado</Label>
          <Select onValueChange={(v) => handleSelectChange('result', v)} value={formData.result} required>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Exitoso">Exitoso</SelectItem>
              <SelectItem value="Fallido">Fallido</SelectItem>
              <SelectItem value="Parcial">Parcial</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label htmlFor="system_restored">Sistema/Dato Restaurado</Label>
        <Input id="system_restored" value={formData.system_restored} onChange={handleChange} placeholder="Ej: Base de datos de clientes, Servidor web" required />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="backup_type">Tipo de Backup Probado</Label>
          <Input id="backup_type" value={formData.backup_type} onChange={handleChange} placeholder="Ej: Completo, Incremental" />
        </div>
        <div>
          <Label htmlFor="tested_by">Realizado por</Label>
          <Input id="tested_by" value={formData.tested_by} onChange={handleChange} required />
        </div>
      </div>
      <div>
        <Label htmlFor="notes">Notas / Observaciones</Label>
        <Textarea id="notes" value={formData.notes} onChange={handleChange} />
      </div>
      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">Guardar Prueba</Button>
      </div>
    </form>
  );
};

export default BackupTestForm;