import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';
import { saveAs } from 'file-saver';

const IncidentDetails = ({ incident, incidentesHook }) => {
  if (!incident) return null;

  const { getAttachmentUrl } = incidentesHook;

  const getSeverityBadge = (severity) => {
    switch(severity) {
      case 'Crítico': return 'destructive';
      case 'Alto': return 'secondary';
      case 'Medio': return 'outline';
      case 'Bajo': return 'default';
      default: return 'default';
    }
  };

  const handleDownload = async () => {
    if (!incident.attachment_path) return;
    const url = await getAttachmentUrl(incident.attachment_path);
    if (url) {
      saveAs(url, incident.attachment_name || 'download');
    }
  };


  return (
    <div className="space-y-6 p-2">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-2xl">{incident.name}</CardTitle>
            <div className="flex items-center gap-2">
              <Badge variant={getSeverityBadge(incident.severity)}>{incident.severity}</Badge>
              <Badge variant="outline">{incident.status}</Badge>
            </div>
          </div>
          <CardDescription>
            Fecha del incidente: {new Date(incident.incident_date).toLocaleString()}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-semibold">Descripción</h4>
            <p className="text-sm text-gray-600">{incident.description || 'No especificada.'}</p>
          </div>
          <div>
            <h4 className="font-semibold">Sistemas Afectados</h4>
            <p className="text-sm text-gray-600">{Array.isArray(incident.affected_systems) && incident.affected_systems.length > 0 ? incident.affected_systems.join(', ') : 'No especificados.'}</p>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader><CardTitle>Análisis y Respuesta</CardTitle></CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold">Causa Raíz</h4>
              <p className="text-sm text-gray-600 whitespace-pre-wrap">{incident.cause || 'No especificada.'}</p>
            </div>
            <div>
              <h4 className="font-semibold">Acciones de Contención</h4>
              <p className="text-sm text-gray-600 whitespace-pre-wrap">{incident.containment_actions || 'No especificadas.'}</p>
            </div>
            <div>
              <h4 className="font-semibold">Acciones de Erradicación</h4>
              <p className="text-sm text-gray-600 whitespace-pre-wrap">{incident.eradication_actions || 'No especificadas.'}</p>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold">Acciones de Recuperación</h4>
              <p className="text-sm text-gray-600 whitespace-pre-wrap">{incident.recovery_actions || 'No especificadas.'}</p>
            </div>
            <div>
              <h4 className="font-semibold">Lecciones Aprendidas</h4>
              <p className="text-sm text-gray-600 whitespace-pre-wrap">{incident.lessons_learned || 'No especificadas.'}</p>
            </div>
             {incident.attachment_name && (
              <div>
                <h4 className="font-semibold">Evidencia Adjunta</h4>
                <div className="flex items-center justify-between p-2 border rounded-md">
                    <span className="text-sm">{incident.attachment_name}</span>
                    <Button variant="outline" size="sm" onClick={handleDownload}>
                        <Download className="h-4 w-4 mr-2" />
                        Descargar
                    </Button>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default IncidentDetails;