import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Paperclip, X } from 'lucide-react';

const statusOptions = ['Nuevo', 'Investigando', 'Contenido', 'Erradicado', 'Recuperado', 'Cerrado'];
const severityOptions = ['Bajo', 'Medio', 'Alto', 'Crítico'];

const IncidenteForm = ({ open, onOpenChange, onSubmit, incidente }) => {
  const initialFormState = {
    name: '',
    description: '',
    incident_date: new Date().toISOString().slice(0, 16),
    status: 'Nuevo',
    severity: 'Bajo',
    affected_systems: [],
    cause: '',
    containment_actions: '',
    eradication_actions: '',
    recovery_actions: '',
    lessons_learned: '',
    attachment_name: '',
    attachment_path: '',
  };
  const [formData, setFormData] = useState(initialFormState);
  const [attachmentFile, setAttachmentFile] = useState(null);

  useEffect(() => {
    if (incidente) {
      setFormData({
        name: incidente.name || '',
        description: incidente.description || '',
        incident_date: incidente.incident_date ? new Date(incidente.incident_date).toISOString().slice(0, 16) : new Date().toISOString().slice(0, 16),
        status: incidente.status || 'Nuevo',
        severity: incidente.severity || 'Bajo',
        affected_systems: incidente.affected_systems || [],
        cause: incidente.cause || '',
        containment_actions: incidente.containment_actions || '',
        eradication_actions: incidente.eradication_actions || '',
        recovery_actions: incidente.recovery_actions || '',
        lessons_learned: incidente.lessons_learned || '',
        attachment_name: incidente.attachment_name || '',
        attachment_path: incidente.attachment_path || '',
      });
      setAttachmentFile(null);
    } else {
      setFormData(initialFormState);
      setAttachmentFile(null);
    }
  }, [incidente, open]);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };
  
  const handleSelectChange = (id, value) => {
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setAttachmentFile(e.target.files[0]);
      setFormData(prev => ({ ...prev, attachment_name: e.target.files[0].name }));
    }
  };

  const removeAttachment = () => {
    setAttachmentFile(null);
    setFormData(prev => ({ ...prev, attachment_name: '', attachment_path: '' }));
    // If you have an input ref, you might need to clear it here
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData, attachmentFile);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{incidente ? 'Editar Incidente' : 'Nuevo Incidente'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Nombre del Incidente</Label>
              <Input id="name" value={formData.name} onChange={handleChange} required />
            </div>
            <div>
              <Label htmlFor="incident_date">Fecha y Hora del Incidente</Label>
              <Input id="incident_date" type="datetime-local" value={formData.incident_date} onChange={handleChange} required />
            </div>
            <div>
              <Label htmlFor="status">Estado</Label>
              <Select onValueChange={(v) => handleSelectChange('status', v)} value={formData.status}>
                <SelectTrigger><SelectValue/></SelectTrigger>
                <SelectContent>
                  {statusOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="severity">Severidad</Label>
              <Select onValueChange={(v) => handleSelectChange('severity', v)} value={formData.severity}>
                <SelectTrigger><SelectValue/></SelectTrigger>
                <SelectContent>
                  {severityOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label htmlFor="description">Descripción Detallada</Label>
            <Textarea id="description" value={formData.description} onChange={handleChange} />
          </div>
          <div>
            <Label htmlFor="affected_systems">Sistemas Afectados (separados por comas)</Label>
            <Input id="affected_systems" value={Array.isArray(formData.affected_systems) ? formData.affected_systems.join(', ') : ''} onChange={(e) => setFormData(prev => ({...prev, affected_systems: e.target.value.split(',').map(s => s.trim())}))} />
          </div>
          <div>
            <Label htmlFor="cause">Causa Raíz (Análisis Post-mortem)</Label>
            <Textarea id="cause" value={formData.cause} onChange={handleChange} />
          </div>
           <div>
            <Label htmlFor="containment_actions">Acciones de Contención</Label>
            <Textarea id="containment_actions" value={formData.containment_actions} onChange={handleChange} />
          </div>
           <div>
            <Label htmlFor="eradication_actions">Acciones de Erradicación</Label>
            <Textarea id="eradication_actions" value={formData.eradication_actions} onChange={handleChange} />
          </div>
           <div>
            <Label htmlFor="recovery_actions">Acciones de Recuperación</Label>
            <Textarea id="recovery_actions" value={formData.recovery_actions} onChange={handleChange} />
          </div>
          <div>
            <Label htmlFor="lessons_learned">Lecciones Aprendidas</Label>
            <Textarea id="lessons_learned" value={formData.lessons_learned} onChange={handleChange} />
          </div>
          <div>
            <Label htmlFor="attachment">Adjuntar Evidencia</Label>
            {formData.attachment_name && !attachmentFile ? (
              <div className="flex items-center justify-between p-2 border rounded-md">
                <div className="flex items-center gap-2">
                  <Paperclip className="h-4 w-4 text-gray-500" />
                  <span className="text-sm">{formData.attachment_name}</span>
                </div>
                <Button variant="ghost" size="icon" onClick={removeAttachment}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <Input id="attachment" type="file" onChange={handleFileChange} />
            )}
            {attachmentFile && (
              <p className="text-xs text-gray-500 mt-1">Nuevo archivo: {attachmentFile.name}</p>
            )}
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit">{incidente ? 'Guardar Cambios' : 'Crear Incidente'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default IncidenteForm;