import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const BackupInventoryForm = ({ onSubmit, onCancel, item }) => {
  const initialFormState = {
    system_name: '',
    backup_type: 'Completo',
    frequency: 'Diario',
    storage_location: '',
    configuration_details: '',
    responsible_person: '',
    notes: '',
  };
  const [formData, setFormData] = useState(initialFormState);

  useEffect(() => {
    if (item) {
      setFormData({
        system_name: item.system_name || '',
        backup_type: item.backup_type || 'Completo',
        frequency: item.frequency || 'Diario',
        storage_location: item.storage_location || '',
        configuration_details: item.configuration_details || '',
        responsible_person: item.responsible_person || '',
        notes: item.notes || '',
      });
    } else {
      setFormData(initialFormState);
    }
  }, [item]);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (id, value) => {
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 pt-4">
      <div>
        <Label htmlFor="system_name">Nombre del Sistema / Activo</Label>
        <Input id="system_name" value={formData.system_name} onChange={handleChange} placeholder="Ej: Servidor de Ficheros, Base de Datos CRM" required />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="backup_type">Tipo de Backup</Label>
          <Select onValueChange={(v) => handleSelectChange('backup_type', v)} value={formData.backup_type}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Completo">Completo</SelectItem>
              <SelectItem value="Incremental">Incremental</SelectItem>
              <SelectItem value="Diferencial">Diferencial</SelectItem>
              <SelectItem value="Espejo (Mirror)">Espejo (Mirror)</SelectItem>
              <SelectItem value="Otro">Otro</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="frequency">Frecuencia</Label>
          <Select onValueChange={(v) => handleSelectChange('frequency', v)} value={formData.frequency}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Diario">Diario</SelectItem>
              <SelectItem value="Semanal">Semanal</SelectItem>
              <SelectItem value="Mensual">Mensual</SelectItem>
              <SelectItem value="Bajo demanda">Bajo demanda</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label htmlFor="storage_location">Ubicación del Almacenamiento</Label>
        <Input id="storage_location" value={formData.storage_location} onChange={handleChange} placeholder="Ej: AWS S3, Azure Blob, NAS Local" />
      </div>
      <div>
        <Label htmlFor="responsible_person">Persona / Equipo Responsable</Label>
        <Input id="responsible_person" value={formData.responsible_person} onChange={handleChange} placeholder="Ej: Equipo de IT" />
      </div>
      <div>
        <Label htmlFor="configuration_details">Detalles de Configuración</Label>
        <Textarea id="configuration_details" value={formData.configuration_details} onChange={handleChange} placeholder="Software utilizado, ruta de la configuración, política de retención..." />
      </div>
      <div>
        <Label htmlFor="notes">Notas Adicionales</Label>
        <Textarea id="notes" value={formData.notes} onChange={handleChange} />
      </div>
      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{item ? 'Guardar Cambios' : 'Añadir al Inventario'}</Button>
      </div>
    </form>
  );
};

export default BackupInventoryForm;