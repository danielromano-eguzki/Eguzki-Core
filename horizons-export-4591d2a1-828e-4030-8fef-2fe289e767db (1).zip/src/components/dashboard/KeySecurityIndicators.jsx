import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ShieldCheck, AlertTriangle, TrendingDown, Users, Briefcase, Activity, Gauge } from 'lucide-react';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";

const KeySecurityIndicators = ({ 
  setActiveTab, 
  selectedClientId,
  handleClientChange,
  clients,
  ensHook,
  iso27001Hook,
  riesgosHook,
  incidentesHook,
  trainingsHook,
  assetsHook
}) => {

  const kpiData = useMemo(() => {
    if (!selectedClientId) return [];

    const allRequirements = [
      ...(ensHook?.requirements || []),
      ...(iso27001Hook?.requirements || []),
    ];
    const totalControls = allRequirements.length;
    const completedControls = allRequirements.filter(r => r.estado_cumplimiento === 'Cumplido').length;
    const controlCompliance = totalControls > 0 ? Math.round((completedControls / totalControls) * 100) : 0;

    const openCriticalIncidents = (incidentesHook?.incidents || []).filter(i => 
      (i.severity === 'Crítica' || i.severity === 'Alta') && i.status !== 'Cerrado'
    ).length;

    const highOrCriticalRisks = (riesgosHook?.riesgos || []).filter(r => 
      r.level === 'Crítico' || r.level === 'Alto'
    ).length;

    const totalTrainings = (trainingsHook?.trainings || []).length;
    
    const assetsToReview = (assetsHook?.assets || []).filter(a => {
      if (!a.last_audit) return true; // Needs review if never audited
      const lastAuditDate = new Date(a.last_audit);
      const oneYearAgo = new Date();
      oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
      return lastAuditDate < oneYearAgo;
    }).length;

    const openIncidents = (incidentesHook?.incidents || []).filter(i => i.status !== 'Cerrado').length;

    return [
      {
        id: 'kpi-control-compliance',
        title: 'Cumplimiento de Controles',
        value: `${controlCompliance}%`,
        target: '95%',
        icon: ShieldCheck,
        color: 'text-primary',
        bgColor: 'bg-green-50',
        description: 'Porcentaje de controles implementados y efectivos.',
        navigateTo: 'ens', 
      },
      {
        id: 'kpi-critical-incidents',
        title: 'Incidentes Críticos Abiertos',
        value: openCriticalIncidents,
        target: '0',
        icon: AlertTriangle,
        color: 'text-red-500',
        bgColor: 'bg-red-50',
        description: 'Número de incidentes de alta prioridad sin resolver.',
        navigateTo: 'continuity_and_incidents',
      },
      {
        id: 'kpi-critical-risks',
        title: 'Riesgos Altos o Críticos',
        value: highOrCriticalRisks,
        target: '< 5',
        icon: TrendingDown, 
        color: 'text-amber-500',
        bgColor: 'bg-amber-50',
        description: 'Número de riesgos residuales con nivel alto o crítico.',
        navigateTo: 'riesgos',
      },
      {
        id: 'kpi-trainings-conducted',
        title: 'Formaciones Realizadas',
        value: totalTrainings,
        target: '> 4/año',
        icon: Users,
        color: 'text-blue-500',
        bgColor: 'bg-blue-50',
        description: 'Número total de formaciones de seguridad impartidas.',
        navigateTo: 'formacion',
      },
      {
        id: 'kpi-asset-review',
        title: 'Activos Críticos sin Revisar',
        value: assetsToReview,
        target: '0',
        icon: Briefcase,
        color: 'text-purple-500',
        bgColor: 'bg-purple-50',
        description: 'Activos críticos que no han sido auditados en el último año.',
        navigateTo: 'riesgos', // Assets are part of risks
      },
      {
        id: 'kpi-open-incidents',
        title: 'Total Incidentes Abiertos',
        value: openIncidents,
        target: '< 5',
        icon: Activity,
        color: 'text-indigo-500',
        bgColor: 'bg-indigo-50',
        description: 'Número total de incidentes de seguridad pendientes.',
        navigateTo: 'continuity_and_incidents', 
      },
    ];
  }, [selectedClientId, ensHook, iso27001Hook, riesgosHook, incidentesHook, trainingsHook, assetsHook]);

  const handleKpiClick = (navigateTo) => {
    if (navigateTo && setActiveTab) {
      setActiveTab(navigateTo);
    }
  };

  if (!selectedClientId) {
    return null; // The parent component will show a message to select a client
  }

  return (
    <div className="my-6">
      <motion.div 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="flex justify-between items-center mb-6"
      >
        <h3 className="text-2xl font-bold flex items-center text-gray-800">
          <Gauge className="w-7 h-7 mr-3 text-sky-600" />
          Indicadores Clave de Seguridad (KPIs/KRIs)
        </h3>
        {clients && clients.length > 1 && (
          <Select onValueChange={handleClientChange} value={selectedClientId}>
            <SelectTrigger className="w-[250px] bg-white/70 border-gray-300/70">
              <SelectValue placeholder="Seleccionar Cliente..." />
            </SelectTrigger>
            <SelectContent>
              {clients.map(client => (
                <SelectItem key={client.id} value={client.id}>
                  {client.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </motion.div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {kpiData.map((kpi, index) => (
          <motion.div
            key={kpi.id}
            id={kpi.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 + index * 0.1 }}
            onClick={() => handleKpiClick(kpi.navigateTo)}
            className={`${kpi.navigateTo ? 'cursor-pointer hover:scale-105 active:scale-95' : ''} transition-transform`}
          >
            <Card className="h-full shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white/80 backdrop-blur-md border border-gray-200/50 rounded-xl overflow-hidden">
              <CardHeader className={`p-4 ${kpi.bgColor} flex flex-row items-center justify-between space-y-0 pb-2`}>
                <CardTitle className={`text-sm font-medium ${kpi.color}`}>{kpi.title}</CardTitle>
                <kpi.icon className={`h-5 w-5 ${kpi.color}`} />
              </CardHeader>
              <CardContent className="p-4">
                <div className={`text-3xl font-bold ${kpi.color}`}>{kpi.value}</div>
                <p className="text-xs text-gray-500 pt-1">
                  Objetivo: {kpi.target}
                </p>
                <p className="text-sm text-gray-600 mt-2 min-h-[40px]">{kpi.description}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default KeySecurityIndicators;