import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, FileText, ShieldCheck, Search, Award, Repeat } from 'lucide-react';

const processSteps = [
  {
    icon: <FileText className="h-8 w-8 text-blue-500" />,
    title: "1. Preparación y Alcance",
    description: "Definir el alcance del sistema de información, identificar los servicios que presta y determinar la categoría del sistema (Básica, Media o Alta) según el impacto de un incidente de seguridad."
  },
  {
    icon: <ShieldCheck className="h-8 w-8 text-green-500" />,
    title: "2. Análisis de Riesgos y Declaración de Aplicabilidad",
    description: "Realizar un análisis de riesgos para identificar amenazas y vulnerabilidades. Elaborar la Declaración de Aplicabilidad (DdA), seleccionando las medidas de seguridad del Anexo II que se aplicarán."
  },
  {
    icon: <CheckCircle className="h-8 w-8 text-yellow-500" />,
    title: "3. Implantación de Medidas",
    description: "Implementar las medidas de seguridad seleccionadas en la DdA. Esto incluye políticas, procedimientos, configuraciones técnicas y formación al personal."
  },
  {
    icon: <Search className="h-8 w-8 text-purple-500" />,
    title: "4. Auditoría Interna",
    description: "Realizar una auditoría interna para verificar que las medidas de seguridad se han implementado correctamente y son eficaces. Corregir las no conformidades detectadas."
  },
  {
    icon: <Award className="h-8 w-8 text-red-500" />,
    title: "5. Auditoría de Certificación",
    description: "Contratar a una entidad de certificación acreditada por ENAC para realizar la auditoría externa. Esta auditoría verificará la conformidad del sistema con el ENS."
  },
  {
    icon: <Repeat className="h-8 w-8 text-indigo-500" />,
    title: "6. Mantenimiento y Mejora Continua",
    description: "Una vez obtenida la certificación, mantener y mejorar continuamente el sistema de seguridad. Esto implica auditorías de seguimiento periódicas (normalmente anuales) y una re-certificación cada dos años."
  }
];

const EnsCertificationProcess = () => {
  return (
    <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg">
      <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Proceso para la Certificación en el ENS</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {processSteps.map((step, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="h-full hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
                {step.icon}
                <CardTitle className="text-lg">{step.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">{step.description}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default EnsCertificationProcess;