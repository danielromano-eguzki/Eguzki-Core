import React, { useState, useMemo } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip.jsx";
import { Info } from 'lucide-react';

const StatusBadge = ({ status }) => {
  const statusStyles = {
    'Cumplido': 'bg-green-100 text-green-800',
    'Parcial': 'bg-yellow-100 text-yellow-800',
    'No cumplido': 'bg-red-100 text-red-800',
    'No aplica': 'bg-gray-100 text-gray-800',
    'Sin estado': 'bg-gray-200 text-gray-600',
  };
  return <Badge className={statusStyles[status] || statusStyles['Sin estado']}>{status || 'Sin estado'}</Badge>;
};

const EnsCertificationMatrix = ({ requirements, updateRequirement, loading, isReadOnly, evidences }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('todos');

  const handleStatusChange = (reqId, newStatus) => {
    if (isReadOnly) return;
    updateRequirement(reqId, { estado_cumplimiento: newStatus });
  };

  const filteredRequirements = useMemo(() => {
    return requirements.filter(req => {
      const term = searchTerm.toLowerCase();
      const matchesSearch = (
        req.codigo.toLowerCase().includes(term) ||
        req.titulo.toLowerCase().includes(term) ||
        (req.descripcion && req.descripcion.toLowerCase().includes(term))
      );
      const matchesStatus = (
        filterStatus === 'todos' ||
        req.estado_cumplimiento === filterStatus ||
        (filterStatus === 'Sin estado' && !req.estado_cumplimiento)
      );
      return matchesSearch && matchesStatus;
    });
  }, [requirements, searchTerm, filterStatus]);

  return (
    <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800">Matriz de Cumplimiento ENS</h2>
        <div className="flex items-center gap-2">
          <Input
            placeholder="Buscar por código o título..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-64"
          />
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtrar por estado" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos los estados</SelectItem>
              <SelectItem value="Cumplido">Cumplido</SelectItem>
              <SelectItem value="Parcial">Parcial</SelectItem>
              <SelectItem value="No cumplido">No cumplido</SelectItem>
              <SelectItem value="No aplica">No aplica</SelectItem>
              <SelectItem value="Sin estado">Sin estado</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="overflow-x-auto rounded-lg border">
        <Table>
          <TableHeader className="bg-gray-50/50">
            <TableRow>
              <TableHead className="w-[10%]">Código</TableHead>
              <TableHead className="w-[30%]">Requisito</TableHead>
              <TableHead className="w-[15%]">Nivel ENS</TableHead>
              <TableHead className="w-[15%]">Estado</TableHead>
              <TableHead className="w-[30%]">Observaciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={5} className="text-center">Cargando requisitos...</TableCell></TableRow>
            ) : filteredRequirements.length > 0 ? (
              filteredRequirements.map(req => (
                <TableRow key={req.id}>
                  <TableCell className="font-mono text-xs">{req.codigo}</TableCell>
                  <TableCell>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span className="font-semibold text-sm cursor-pointer">{req.titulo}</span>
                        </TooltipTrigger>
                        <TooltipContent className="max-w-md">
                          <p>{req.descripcion}</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{req.tipo_requisito}</Badge>
                  </TableCell>
                  <TableCell>
                    <Select
                      value={req.estado_cumplimiento || 'Sin estado'}
                      onValueChange={(value) => handleStatusChange(req.id, value === 'Sin estado' ? null : value)}
                      disabled={isReadOnly}
                    >
                      <SelectTrigger>
                        <SelectValue>
                          <StatusBadge status={req.estado_cumplimiento} />
                        </SelectValue>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Cumplido">Cumplido</SelectItem>
                        <SelectItem value="Parcial">Parcial</SelectItem>
                        <SelectItem value="No cumplido">No cumplido</SelectItem>
                        <SelectItem value="No aplica">No aplica</SelectItem>
                        <SelectItem value="Sin estado">Sin estado</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Input
                      defaultValue={req.observaciones || ''}
                      onBlur={(e) => updateRequirement(req.id, { observaciones: e.target.value })}
                      placeholder="Añadir observación..."
                      className="text-xs"
                      disabled={isReadOnly}
                    />
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow><TableCell colSpan={5} className="text-center">No se encontraron requisitos.</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default EnsCertificationMatrix;