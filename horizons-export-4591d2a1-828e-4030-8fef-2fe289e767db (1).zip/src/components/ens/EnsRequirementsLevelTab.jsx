import React, { useState, useMemo } from 'react';
import { PlusCircle, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import EnsRequirementForm from './EnsRequirementForm';
import RequirementsTable from '@/components/requisitos/RequirementsTable';
import EnsLevelInfo from './EnsLevelInfo';

const EnsRequirementsLevelTab = ({
  level,
  requirements,
  evidences,
  ensHook,
  isReadOnly
}) => {
  const { addRequirement, updateRequirement, deleteRequirement, getEvidenceFileUrl, linkEvidenceToRequirement, unlinkEvidenceFromRequirement } = ensHook;
  
  const [isFormOpen, setFormOpen] = useState(false);
  const [editingRequirement, setEditingRequirement] = useState(null);
  const [toDelete, setToDelete] = useState(null);
  
  const [filters, setFilters] = useState({
    searchTerm: '',
    status: 'all',
  });

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const levelRequirements = useMemo(() => {
    let result = requirements.filter(r => r.tipo_requisito === `ENS-${level}`);
    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      result = result.filter(r => 
        (r.titulo && r.titulo.toLowerCase().includes(term)) ||
        (r.codigo && r.codigo.toLowerCase().includes(term))
      );
    }
    if (filters.status && filters.status !== 'all') {
      result = result.filter(r => r.estado_cumplimiento === filters.status);
    }
    return result;
  }, [requirements, level, filters]);

  const handleSubmit = async (formData) => {
    if (editingRequirement) {
      await updateRequirement(editingRequirement.id, formData);
    } else {
      await addRequirement(formData);
    }
    setFormOpen(false);
    setEditingRequirement(null);
  };
  
  const openForm = (req = null) => { setEditingRequirement(req); setFormOpen(true); };

  const handleDelete = async () => {
    if (toDelete) {
      await deleteRequirement(toDelete.id);
      setToDelete(null);
    }
  };
  
  const requirementsHookForTable = { linkEvidenceToRequirement, unlinkEvidenceFromRequirement };

  return (
    <div>
      <EnsLevelInfo level={level} />
      <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">Requisitos Nivel {level}</h2>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <Input placeholder="Buscar..." className="pl-9" value={filters.searchTerm} onChange={e => handleFilterChange('searchTerm', e.target.value)} />
            </div>
            <Select value={filters.status} onValueChange={v => handleFilterChange('status', v)}>
              <SelectTrigger className="w-[150px]"><SelectValue placeholder="Estado" /></SelectTrigger>
              <SelectContent><SelectItem value="all">Todos</SelectItem><SelectItem value="Cumplido">Cumplido</SelectItem><SelectItem value="Parcial">Parcial</SelectItem><SelectItem value="No cumplido">No cumplido</SelectItem><SelectItem value="No aplica">No aplica</SelectItem></SelectContent>
            </Select>
            <Button onClick={() => openForm()} disabled={isReadOnly}><PlusCircle className="mr-2 h-4 w-4" /> Nuevo</Button>
          </div>
        </div>
        
        <RequirementsTable
          requirements={levelRequirements}
          evidences={evidences}
          isReadOnly={isReadOnly}
          onEdit={openForm}
          onDelete={req => setToDelete(req)}
          getEvidenceFileUrl={getEvidenceFileUrl}
          requirementsHook={requirementsHookForTable}
        />

        <Dialog open={isFormOpen} onOpenChange={(isOpen) => { if (!isOpen) setEditingRequirement(null); setFormOpen(isOpen); }}>
          <DialogContent className="sm:max-w-2xl"><DialogHeader><DialogTitle>{editingRequirement ? 'Editar' : 'Nuevo'} Requisito (Nivel {level})</DialogTitle></DialogHeader>
            <EnsRequirementForm
              onSubmit={handleSubmit} 
              onCancel={() => setFormOpen(false)} 
              existingRequirement={editingRequirement} 
              level={level}
              isReadOnly={isReadOnly} 
            />
          </DialogContent>
        </Dialog>
        
        <AlertDialog open={!!toDelete} onOpenChange={() => setToDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader><AlertDialogTitle>¿Confirmas la eliminación?</AlertDialogTitle></AlertDialogHeader>
            <AlertDialogDescription>Esta acción es permanente y no se podrá deshacer.</AlertDialogDescription>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
};

export default EnsRequirementsLevelTab;