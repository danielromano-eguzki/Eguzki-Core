import React from 'react';
import { motion } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, ShieldCheck, ShieldAlert, ShieldOff, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const COLORS = {
  'Cumplido': '#243430',
  'Parcial': '#f59e0b',
  'No cumplido': '#ef4444',
  'No aplica': '#a1a1aa',
  'Sin estado': '#64748b',
};

const applicabilityData = [
  { measure: 'op.org', description: 'Marco organizativo', low: '✔️', medium: '✔️', high: '✔️' },
  { measure: 'op.pl', description: 'Planificación', low: '✔️', medium: '✔️', high: '✔️' },
  { measure: 'op.acc', description: 'Control de acceso', low: '✔️', medium: '✔️', high: '✔️' },
  { measure: 'op.exp', description: 'Explotación', low: '✔️', medium: '✔️', high: '✔️' },
  { measure: 'op.com', description: 'Comunicaciones', low: '✔️', medium: '✔️', high: '✔️' },
  { measure: 'op.ext', description: 'Interconexión de sistemas', low: 'Reforzado', medium: '✔️', high: '✔️' },
  { measure: 'op.cont', description: 'Continuidad del servicio', low: 'Básico', medium: '✔️', high: '✔️' },
  { measure: 'op.mon', description: 'Monitorización del sistema', low: '✔️', medium: '✔️', high: '✔️' },
  { measure: 'mp.info', description: 'Protección de la información', low: '✔️', medium: '✔️', high: '✔️' },
  { measure: 'mp.if', description: 'Protección de las instalaciones', low: '✔️', medium: '✔️', high: '✔️' },
  { measure: 'mp.per', description: 'Personal', low: '✔️', medium: '✔️', high: '✔️' },
  { measure: 'mp.eq', description: 'Equipos', low: '✔️', medium: '✔️', high: '✔️' },
  { measure: 'mp.s', description: 'Soportes de información', low: '✔️', medium: '✔️', high: '✔️' },
  { measure: 'mp.app', description: 'Aplicaciones', low: '✔️', medium: '✔️', high: '✔️' },
];

const ApplicabilityTable = () => (
  <Card>
    <CardHeader>
      <CardTitle>Tabla de Aplicabilidad de Medidas por Nivel</CardTitle>
    </CardHeader>
    <CardContent>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Medida</TableHead>
            <TableHead>Descripción</TableHead>
            <TableHead className="text-center">Nivel Bajo</TableHead>
            <TableHead className="text-center">Nivel Medio</TableHead>
            <TableHead className="text-center">Nivel Alto</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {applicabilityData.map((item) => (
            <TableRow key={item.measure}>
              <TableCell className="font-mono">{item.measure}</TableCell>
              <TableCell>{item.description}</TableCell>
              <TableCell className="text-center">{item.low}</TableCell>
              <TableCell className="text-center">{item.medium}</TableCell>
              <TableCell className="text-center">{item.high}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </CardContent>
  </Card>
);

const EnsDashboard = ({ stats, loading, onSeed, hasRequirements, isReadOnly, normativeName }) => {
  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!hasRequirements) {
    return (
      <Card className="text-center p-8 bg-white/70">
        <CardHeader>
          <CardTitle>Comienza con {normativeName}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4 text-gray-600">
            Parece que aún no has inicializado los requisitos para este cliente.
            {onSeed && ' Haz clic en el botón para cargar la plantilla de requisitos.'}
          </p>
          {onSeed && (
            <Button onClick={onSeed} disabled={isReadOnly || loading}>
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Inicializar Requisitos {normativeName}
            </Button>
          )}
        </CardContent>
      </Card>
    );
  }

  const chartData = [
    { name: 'Cumplido', value: stats.cumplido },
    { name: 'Parcial', value: stats.parcial },
    { name: 'No cumplido', value: stats.no_cumplido },
    { name: 'No aplica', value: stats.no_aplica },
  ].filter(item => item.value > 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Requisitos</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cumplimiento</CardTitle>
            <ShieldCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.percentage}%</div>
            <p className="text-xs text-muted-foreground">{stats.cumplido} de {stats.total - stats.no_aplica} aplicables</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">No Cumplidos</CardTitle>
            <ShieldAlert className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.no_cumplido}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">No Aplican</CardTitle>
            <ShieldOff className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.no_aplica}</div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Estado General de Requisitos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={chartData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={120}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[entry.name]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        <ApplicabilityTable />
      </div>
    </div>
  );
};

export default EnsDashboard;