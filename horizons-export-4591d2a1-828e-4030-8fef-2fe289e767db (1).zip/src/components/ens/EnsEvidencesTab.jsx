import React, { useState, useMemo } from 'react';
import { PlusCircle, Search, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Input } from '@/components/ui/input';
import EvidenceForm from '@/components/evidencias/EvidenceForm';
import EvidencesInventoryTable from '@/components/evidencias/EvidencesInventoryTable';
import ExportMenu from '@/components/common/ExportMenu';

const evidenceHeaders = [
  { label: 'ID', key: 'evidence_id_custom' },
  { label: 'Nombre', key: 'nombre' },
  { label: 'Tipo', key: 'tipo' },
  { label: 'Departamento', key: 'departamento' },
  { label: 'Responsable', key: 'responsable' },
  { label: 'Fecha', key: 'fecha' },
];

const EnsEvidencesTab = ({
  evidenciasHook,
  requirements,
  certifications,
  isReadOnly,
  showToast
}) => {
  const { 
    evidences, 
    addEvidence, 
    updateEvidence, 
    deleteEvidence, 
    getEvidenceFileUrl, 
    calculateHash, 
    loading 
  } = evidenciasHook;
  
  const [isFormOpen, setFormOpen] = useState(false);
  const [editingEvidence, setEditingEvidence] = useState(null);
  const [toDelete, setToDelete] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredEvidences = useMemo(() => {
    if (!searchTerm) return evidences;
    const term = searchTerm.toLowerCase();
    return evidences.filter(ev => 
      (ev.nombre && ev.nombre.toLowerCase().includes(term)) ||
      (ev.evidence_id_custom && ev.evidence_id_custom.toLowerCase().includes(term)) ||
      (ev.responsable && ev.responsable.toLowerCase().includes(term))
    );
  }, [evidences, searchTerm]);

  const handleSubmit = async (formData, file, linkedReqs) => {
    if (editingEvidence) {
      await updateEvidence(editingEvidence.id, formData, file, linkedReqs);
    } else {
      await addEvidence(formData, file, linkedReqs);
    }
    setFormOpen(false);
    setEditingEvidence(null);
  };
  
  const openForm = (ev = null) => { setEditingEvidence(ev); setFormOpen(true); };

  const handleDelete = async () => {
    if (toDelete) {
      await deleteEvidence(toDelete.id);
      setToDelete(null);
    }
  };

  const handleDownload = async (evidence) => {
    if (!evidence.file_path) return;
    const url = await getEvidenceFileUrl(evidence.file_path);
    if (url) {
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', evidence.file_name || 'download');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleVerifyHash = (evidence) => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.onchange = async (e) => {
      const file = e.target.files[0];
      if (file) {
        const newHash = await calculateHash(file);
        showToast(newHash === evidence.hash ? "Verificación Exitosa" : "Verificación Fallida", newHash === evidence.hash ? "El hash coincide." : "El hash no coincide.", newHash === evidence.hash ? "default" : "destructive");
      }
    };
    fileInput.click();
  };
  
  if (loading) {
    return (
      <div className="flex items-center justify-center h-64 bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
      </div>
    );
  }

  return (
    <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-gray-800">Inventario de Evidencias</h2>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <Input placeholder="Buscar evidencias..." className="pl-9" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
          </div>
          <ExportMenu data={filteredEvidences} headers={evidenceHeaders} filenamePrefix="evidencias" reportTitle="Inventario de Evidencias" disabled={loading} />
          <Button onClick={() => openForm()} disabled={isReadOnly}><PlusCircle className="mr-2 h-4 w-4" /> Nueva Evidencia</Button>
        </div>
      </div>
      
      <EvidencesInventoryTable
        evidences={filteredEvidences}
        onEdit={openForm}
        onDelete={ev => setToDelete(ev)}
        onDownload={handleDownload}
        onUpload={openForm}
        onVerifyHash={handleVerifyHash}
        isReadOnly={isReadOnly}
      />

      <Dialog open={isFormOpen} onOpenChange={(isOpen) => { if (!isOpen) setEditingEvidence(null); setFormOpen(isOpen); }}>
        <DialogContent className="sm:max-w-2xl"><DialogHeader><DialogTitle>{editingEvidence ? 'Editar' : 'Nueva'} Evidencia</DialogTitle></DialogHeader>
          <EvidenceForm 
            onSubmit={handleSubmit} 
            onCancel={() => setFormOpen(false)} 
            existingEvidence={editingEvidence} 
            isReadOnly={isReadOnly}
            requirements={requirements}
            certifications={certifications}
            calculateHash={calculateHash}
          />
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={!!toDelete} onOpenChange={() => setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Confirmas la eliminación?</AlertDialogTitle></AlertDialogHeader>
          <AlertDialogDescription>Esta acción es permanente y no se podrá deshacer.</AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default EnsEvidencesTab;