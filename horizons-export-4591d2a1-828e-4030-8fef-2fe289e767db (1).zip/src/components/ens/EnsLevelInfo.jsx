import React from 'react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info } from 'lucide-react';

const levelInfoContent = {
  Bajo: {
    title: "Nivel Bajo",
    description: "Aplica a sistemas que manejan información con un impacto limitado en caso de incidente de seguridad. Las medidas de seguridad son las básicas y obligatorias para cualquier sistema de la Administración Pública. El objetivo es proteger contra amenazas comunes y de bajo impacto.",
    color: "border-blue-500/50"
  },
  Medio: {
    title: "Nivel Medio",
    description: "Destinado a sistemas que, en caso de un incidente, causarían un perjuicio grave a la organización o a los ciudadanos. Requiere todas las medidas del nivel bajo más un conjunto de controles adicionales para hacer frente a amenazas más sofisticadas y con mayor impacto.",
    color: "border-yellow-500/50"
  },
  Alto: {
    title: "Nivel Alto",
    description: "Reservado para sistemas críticos cuya afectación tendría un impacto muy grave o catastrófico para la seguridad nacional, los servicios esenciales o los derechos de los ciudadanos. Exige las medidas de los niveles bajo y medio, más controles de seguridad muy robustos y específicos.",
    color: "border-red-500/50"
  }
};

const EnsLevelInfo = ({ level }) => {
  const content = levelInfoContent[level];

  if (!content) return null;

  return (
    <Alert className={`mb-6 bg-white/80 ${content.color}`}>
      <Info className="h-4 w-4" />
      <AlertTitle className="font-bold">{content.title}</AlertTitle>
      <AlertDescription>
        {content.description}
      </AlertDescription>
    </Alert>
  );
};

export default EnsLevelInfo;