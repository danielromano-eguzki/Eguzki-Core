import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DialogFooter } from '@/components/ui/dialog';

const estadoOptions = ["Cumplido", "Parcial", "No cumplido", "No aplica"];

const EnsRequirementForm = ({ onSubmit, onCancel, existingRequirement, level, isReadOnly, isIso = false }) => {
  const [formData, setFormData] = useState({
    codigo: '',
    titulo: '',
    descripcion: '',
    estado_cumplimiento: 'No cumplido',
    observaciones: '',
    plan_accion: '',
    departamento_responsable: '',
    tipo_requisito: isIso ? level : `ENS-${level}`
  });

  useEffect(() => {
    const reqType = isIso ? level : `ENS-${level}`;
    if (existingRequirement) {
      setFormData({
        codigo: existingRequirement.codigo || '',
        titulo: existingRequirement.titulo || '',
        descripcion: existingRequirement.descripcion || '',
        estado_cumplimiento: existingRequirement.estado_cumplimiento || 'No cumplido',
        observaciones: existingRequirement.observaciones || '',
        plan_accion: existingRequirement.plan_accion || '',
        departamento_responsable: existingRequirement.departamento_responsable || '',
        tipo_requisito: existingRequirement.tipo_requisito || reqType
      });
    } else {
      setFormData(prev => ({ ...prev, tipo_requisito: reqType, codigo: '', titulo: '', descripcion: '', estado_cumplimiento: 'No cumplido', observaciones: '', plan_accion: '', departamento_responsable: '' }));
    }
  }, [existingRequirement, level, isIso]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isReadOnly) return;
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto p-1">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="codigo">Código</Label>
          <Input id="codigo" name="codigo" value={formData.codigo} onChange={handleChange} placeholder="Ej: CC1.1" disabled={isReadOnly} />
        </div>
         <div>
          <Label htmlFor="estado_cumplimiento">Estado</Label>
          <Select onValueChange={(value) => handleSelectChange('estado_cumplimiento', value)} value={formData.estado_cumplimiento} disabled={isReadOnly} required>
            <SelectTrigger id="estado_cumplimiento"><SelectValue /></SelectTrigger>
            <SelectContent>
              {estadoOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label htmlFor="titulo">Título del Requisito</Label>
        <Input id="titulo" name="titulo" value={formData.titulo} onChange={handleChange} placeholder="Título resumido del requisito" disabled={isReadOnly} required />
      </div>
      <div>
        <Label htmlFor="descripcion">Descripción</Label>
        <Textarea id="descripcion" name="descripcion" value={formData.descripcion} onChange={handleChange} placeholder="Descripción detallada del requisito" disabled={isReadOnly} />
      </div>
       <div className="border-t pt-4 mt-4 space-y-4">
          <h3 className="text-lg font-semibold text-gray-700">Plan de Acción</h3>
          <div>
            <Label htmlFor="plan_accion">Descripción del Plan de Acción</Label>
            <Textarea id="plan_accion" name="plan_accion" value={formData.plan_accion} onChange={handleChange} placeholder="Pasos a seguir para cumplir el requisito" disabled={isReadOnly} />
          </div>
          <div>
            <Label htmlFor="departamento_responsable">Departamento Responsable</Label>
            <Input id="departamento_responsable" name="departamento_responsable" value={formData.departamento_responsable} onChange={handleChange} placeholder="Ej: Departamento de IT" disabled={isReadOnly} />
          </div>
        </div>

      <div>
        <Label htmlFor="observaciones">Observaciones</Label>
        <Textarea id="observaciones" name="observaciones" value={formData.observaciones} onChange={handleChange} placeholder="Comentarios o justificaciones" disabled={isReadOnly} />
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        {!isReadOnly && <Button type="submit">{existingRequirement ? 'Actualizar Requisito' : 'Añadir Requisito'}</Button>}
      </DialogFooter>
    </form>
  );
};

export default EnsRequirementForm;