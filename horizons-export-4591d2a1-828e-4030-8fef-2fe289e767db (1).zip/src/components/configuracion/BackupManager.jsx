import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Database, DownloadCloud, UploadCloud, RotateCw, Server, Clock, AlertTriangle, Save } from 'lucide-react';
import { motion } from 'framer-motion';
import { saveAs } from 'file-saver';
import { 
  AlertDialog, 
  AlertDialogAction, 
  AlertDialogCancel, 
  AlertDialogContent, 
  AlertDialogDescription, 
  AlertDialogFooter, 
  AlertDialogHeader, 
  AlertDialogTitle, 
  AlertDialogTrigger 
} from '@/components/ui/alert-dialog';

const LoadingSpinner = () => (
  <motion.div
    animate={{ rotate: 360 }}
    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
    className="w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"
  ></motion.div>
);

const BackupManager = ({ showToast, supabase }) => {
  const [isExporting, setIsExporting] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [isCreatingManualBackup, setIsCreatingManualBackup] = useState(false);
  const fileInputRef = useRef(null);

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const { data, error } = await supabase.functions.invoke('export-data');
      if (error) throw error;
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const date = new Date().toISOString().slice(0, 10);
      saveAs(blob, `eguzki_core_backup_${date}.json`);

      showToast('Exportación Completa', 'Tu copia de seguridad ha sido descargada.', 'default');
    } catch (error) {
      showToast('Error de Exportación', `No se pudo generar la copia de seguridad: ${error.message}`, 'destructive');
    } finally {
      setIsExporting(false);
    }
  };

  const handleRestore = async () => {
    setIsRestoring(true);
    try {
      const { data, error } = await supabase.functions.invoke('restore-latest-data');
      if (error) throw error;
      showToast(data.message, data.details, 'default');
    } catch (error) {
      showToast('Error de Restauración', `No se pudo iniciar la restauración: ${error.message}`, 'destructive');
    } finally {
      setIsRestoring(false);
    }
  };
  
  const handleImportClick = () => {
    fileInputRef.current.click();
  };

  const handleFileSelected = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsImporting(true);
    try {
      const fileContent = await file.text();
      const jsonData = JSON.parse(fileContent);
      
      const { data, error } = await supabase.functions.invoke('import-data', {
        body: jsonData,
      });

      if (error) throw error;

      showToast('Importación Completa', data.message, 'default');
      setTimeout(() => window.location.reload(), 2000);

    } catch (error) {
      showToast('Error de Importación', `El archivo no es válido o la importación falló: ${error.message}`, 'destructive');
    } finally {
      setIsImporting(false);
      event.target.value = null;
    }
  };

  const handleManualBackup = async () => {
    setIsCreatingManualBackup(true);
    try {
      const { data, error } = await supabase.functions.invoke('manual-backup');
      if (error) throw error;
      showToast(data.message, data.details, 'default');
    } catch (error) {
      showToast('Error de Backup Manual', `No se pudo iniciar el backup: ${error.message}`, 'destructive');
    } finally {
      setIsCreatingManualBackup(false);
    }
  };

  return (
    <section>
      <h2 className="text-2xl font-semibold text-gray-700 mb-4 border-b pb-2 flex items-center">
        <Database className="w-6 h-6 mr-2 text-gray-600" />
        Copia de Seguridad y Restauración
      </h2>
      <div className="p-6 bg-white/60 backdrop-blur-lg rounded-xl shadow-md space-y-8">
        <div>
          <h3 className="font-semibold text-lg text-gray-800">Estado del Sistema</h3>
            <div className="mt-2 space-y-2 text-sm text-gray-600">
              <div className="flex items-center">
                <Server className="w-4 h-4 mr-3 text-blue-600" />
                <span>Estado: <span className="font-semibold text-green-700">Operacional</span></span>
              </div>
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-3 text-blue-600" />
                <span>Próximo backup automático: <span className="font-semibold">Cada Domingo (03:00 AM)</span></span>
              </div>
            </div>
        </div>

        <div className="space-y-4">
          <h3 className="font-semibold text-lg text-gray-800">Operaciones Manuales</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button onClick={handleManualBackup} disabled={isCreatingManualBackup}>
              {isCreatingManualBackup ? <LoadingSpinner /> : <Save className="w-4 h-4 mr-2" />}
              Crear Backup Manual
            </Button>

            <Button onClick={handleExport} disabled={isExporting} variant="outline">
              {isExporting ? <LoadingSpinner /> : <DownloadCloud className="w-4 h-4 mr-2" />}
              Exportar y Descargar
            </Button>

            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" disabled={isRestoring}>
                  {isRestoring ? <LoadingSpinner /> : <RotateCw className="w-4 h-4 mr-2" />}
                  Cargar Último Backup
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Esta acción restaurará los datos desde la última copia de seguridad automática. Se perderán todos los cambios no guardados en el backup. Esta acción es irreversible.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction onClick={handleRestore}>Confirmar Restauración</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>

             <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" disabled={isImporting}>
                  {isImporting ? <LoadingSpinner /> : <UploadCloud className="w-4 h-4 mr-2" />}
                  Importar desde Archivo
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle className="flex items-center"><AlertTriangle className="w-5 h-5 mr-2 text-red-500" />¡Acción Destructiva!</AlertDialogTitle>
                  <AlertDialogDescription>
                    Importar un archivo de backup reemplazará <span className="font-bold">TODOS</span> los datos actuales de la plataforma. Esta acción no se puede deshacer. Asegúrate de que el archivo es correcto antes de proceder.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={handleImportClick}>Entiendo, quiero importar</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            <input type="file" ref={fileInputRef} onChange={handleFileSelected} className="hidden" accept=".json" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default BackupManager;