import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Terminal, Calendar, User, Briefcase, Search, Filter } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const LogViewer = ({ logs, loading }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLogs = logs.filter(log => {
    const search = searchTerm.toLowerCase();
    return (
      log.action.toLowerCase().includes(search) ||
      log.details?.name?.toLowerCase().includes(search) ||
      log.details?.id?.toLowerCase().includes(search) ||
      (log.client?.name && log.client.name.toLowerCase().includes(search))
    );
  });
  
  const formatTimestamp = (ts) => {
      try {
          return format(parseISO(ts), "dd 'de' MMMM, yyyy 'a las' HH:mm:ss", { locale: es });
      } catch (e) {
          return "Fecha inválida";
      }
  };

  const LogItem = ({ log, index }) => (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className="p-4 rounded-lg bg-white/80 border border-gray-200/60 hover:bg-white transition-colors"
    >
      <div className="flex items-center justify-between mb-2">
        <p className="font-mono text-sm font-semibold text-green-700">{log.action}</p>
        <span className="text-xs text-gray-500 flex items-center">
            <Calendar className="w-3 h-3 mr-1.5" />
            {formatTimestamp(log.created_at)}
        </span>
      </div>
      <div className="text-xs text-gray-600 space-y-1">
        {log.client && (
          <p className="flex items-center"><Briefcase className="w-3 h-3 mr-1.5 text-gray-400" /> 
            <span className="font-medium mr-1">Cliente:</span> {log.client.name}
          </p>
        )}
        {log.details?.name && (
          <p className="flex items-center"><User className="w-3 h-3 mr-1.5 text-gray-400" />
            <span className="font-medium mr-1">Recurso:</span> {log.details.name}
          </p>
        )}
        {log.details?.id && (
          <p className="font-mono flex items-center text-gray-500">
            <span className="font-sans font-medium mr-1">ID:</span> {log.details.id}
          </p>
        )}
      </div>
    </motion.div>
  );

  return (
    <section>
      <h2 className="text-2xl font-semibold text-gray-700 mb-4 border-b pb-2 flex items-center">
        <Terminal className="w-6 h-6 mr-2 text-gray-600" />
        Registro de Actividad (Logs)
      </h2>
      <div className="p-6 bg-white/60 backdrop-blur-lg rounded-xl shadow-md">
        <div className="flex justify-between items-center mb-4">
            <h3 className="font-semibold text-lg text-gray-800">Últimas 100 acciones</h3>
            <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <Input 
                    placeholder="Buscar en logs..."
                    className="pl-10 w-64"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
        </div>

        <div className="max-h-[500px] overflow-y-auto space-y-3 p-2 bg-gray-50/50 rounded-lg border">
          {loading ? (
            <div className="flex justify-center items-center h-40">
                <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-8 h-8 border-4 border-gray-300 border-t-transparent rounded-full"></motion.div>
            </div>
          ) : filteredLogs.length > 0 ? (
            filteredLogs.map((log, index) => <LogItem key={log.id} log={log} index={index} />)
          ) : (
            <div className="text-center py-10 text-gray-500">
                <Filter className="w-12 h-12 mx-auto mb-2 text-gray-400" />
                No se encontraron registros con los filtros actuales.
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default LogViewer;