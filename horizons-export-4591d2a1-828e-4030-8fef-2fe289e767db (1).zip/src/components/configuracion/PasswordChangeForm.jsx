import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/hooks/useAuth';

const PasswordChangeForm = ({ showToast }) => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const auth = useAuth(showToast);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      showToast('Error', 'Las contraseñas no coinciden.', 'destructive');
      return;
    }
    if (password.length < 8) {
      showToast('Error', 'La contraseña debe tener al menos 8 caracteres.', 'destructive');
      return;
    }
    setIsSubmitting(true);
    await auth.updateUserPassword(password);
    setIsSubmitting(false);
    setPassword('');
    setConfirmPassword('');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="new-password">Nueva Contraseña</Label>
        <Input 
          id="new-password" 
          type="password" 
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Mínimo 8 caracteres"
        />
      </div>
      <div>
        <Label htmlFor="confirm-password">Confirmar Nueva Contraseña</Label>
        <Input 
          id="confirm-password" 
          type="password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          placeholder="Repite la contraseña"
        />
      </div>
      <Button type="submit" disabled={isSubmitting || !password || password !== confirmPassword}>
        {isSubmitting ? 'Actualizando...' : 'Cambiar Contraseña'}
      </Button>
    </form>
  );
};

export default PasswordChangeForm;