import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import FileInput from './FileInput';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator.jsx';

const ClientForm = ({
  formData,
  setFormData,
  files,
  setFiles,
  isReadOnly,
  existingClient,
  getClientFileUrl
}) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    const { name, files: selectedFiles } = e.target;
    if (selectedFiles.length > 0) {
      setFiles(prev => ({ ...prev, [name]: selectedFiles[0] }));
    }
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="name">Nombre del Cliente</Label>
        <Input id="name" name="name" value={formData.name} onChange={handleChange} disabled={isReadOnly} required />
      </div>
      <div className="space-y-2">
        <Label htmlFor="description">Descripción</Label>
        <Textarea id="description" name="description" value={formData.description} onChange={handleChange} disabled={isReadOnly} />
      </div>

      <Separator />

      <h4 className="text-md font-semibold text-gray-700 pt-2">Información de Contacto</h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="contact_name">Nombre de Contacto</Label>
          <Input id="contact_name" name="contact_name" value={formData.contact_name} onChange={handleChange} disabled={isReadOnly} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="contact_email">Email de Contacto</Label>
          <Input id="contact_email" name="contact_email" type="email" value={formData.contact_email} onChange={handleChange} disabled={isReadOnly} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="contact_phone">Teléfono de Contacto</Label>
          <Input id="contact_phone" name="contact_phone" value={formData.contact_phone} onChange={handleChange} disabled={isReadOnly} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="location">Ubicación</Label>
          <Input id="location" name="location" value={formData.location} onChange={handleChange} disabled={isReadOnly} />
        </div>
      </div>
      
      <Separator />
      
      <h4 className="text-md font-semibold text-gray-700 pt-2">Objetivos y Documentación</h4>
      <div className="space-y-2">
        <Label htmlFor="certification_goal">Objetivo de Certificación</Label>
        <Input id="certification_goal" name="certification_goal" value={formData.certification_goal} onChange={handleChange} disabled={isReadOnly} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <FileInput 
          label="NDA" 
          name="nda" 
          file={files.nda}
          existingFilePath={existingClient?.nda_path}
          onFileChange={handleFileChange}
          getClientFileUrl={getClientFileUrl} 
          disabled={isReadOnly}
        />
        <FileInput 
          label="Propuesta" 
          name="proposal"
          file={files.proposal}
          existingFilePath={existingClient?.proposal_path}
          onFileChange={handleFileChange}
          getClientFileUrl={getClientFileUrl}
          disabled={isReadOnly}
        />
        <FileInput 
          label="Contrato"
          name="contract"
          file={files.contract}
          existingFilePath={existingClient?.contract_path}
          onFileChange={handleFileChange}
          getClientFileUrl={getClientFileUrl}
          disabled={isReadOnly}
        />
      </div>

      {existingClient && (
        <div className="flex items-center space-x-2">
          <Label>Estado:</Label>
          <Badge variant={existingClient.status === 'Activo' ? 'default' : 'outline'}>{existingClient.status}</Badge>
        </div>
      )}
    </div>
  );
};

export default ClientForm;