import React from 'react';
import { Button } from '@/components/ui/button';
import { Briefcase, PlusCircle } from 'lucide-react';

const ClientsHeader = ({ onAddNew, isReadOnly }) => {
  return (
    <div className="flex flex-col md:flex-row justify-between items-center gap-4">
      <h2 className="text-3xl font-bold text-gray-900 flex items-center">
        <Briefcase className="w-8 h-8 mr-3 text-gradient" />
        Mis Clientes
      </h2>
      <Button onClick={onAddNew} disabled={isReadOnly}>
        <PlusCircle className="w-5 h-5 mr-2" />
        Añadir Nuevo Cliente
      </Button>
    </div>
  );
};

export default ClientsHeader;