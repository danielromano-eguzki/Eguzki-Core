import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ClientCard from './ClientCard.jsx';
import { Briefcase } from 'lucide-react';

const ClientList = ({ clients, loading, onEdit, onDelete, onShowDocs, onStatusChange, isReadOnly, isSuperAdmin }) => {
  if (loading) {
    return <p>Cargando clientes...</p>;
  }

  if (clients.length === 0) {
    return (
      <div className="text-center py-16">
        <Briefcase className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-semibold text-gray-900">No hay clientes</h3>
        <p className="mt-1 text-sm text-gray-500">No se encontraron clientes que coincidan con los filtros actuales.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
      <AnimatePresence>
        {clients.map((client, index) => (
          <ClientCard
            key={client.id}
            client={client}
            onEdit={onEdit}
            onDelete={onDelete}
            onShowDocs={onShowDocs}
            onStatusChange={onStatusChange}
            isReadOnly={isReadOnly}
            isSuperAdmin={isSuperAdmin}
            index={index}
          />
        ))}
      </AnimatePresence>
    </div>
  );
};

export default ClientList;