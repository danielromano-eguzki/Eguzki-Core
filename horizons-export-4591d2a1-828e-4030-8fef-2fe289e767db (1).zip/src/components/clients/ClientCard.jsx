import React from 'react';
import { motion } from 'framer-motion';
import { FileText, MoreVertical, Edit, Trash2, Eye, Archive, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuPortal,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";


const ClientCard = ({ client, onEdit, onDelete, onShowDocs, onStatusChange, isReadOnly, index }) => {
  const hasDocuments = client.nda_path || client.proposal_path || client.contract_path;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 50, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -50, scale: 0.9 }}
      transition={{ delay: index * 0.05 }}
      className={`bg-white/80 backdrop-blur-md rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col border border-gray-200/50 ${client.status === 'Inactivo' ? 'opacity-60' : ''}`}
    >
      <div className="p-6 flex-grow">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
             <h3 className="text-xl font-bold text-gray-800">{client.name}</h3>
             <Badge variant={client.status === 'Activo' ? 'default' : 'outline'}>{client.status}</Badge>
          </div>
          {!isReadOnly && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onEdit(client)}>
                  <Edit className="mr-2 h-4 w-4" />
                  <span>Gestionar</span>
                </DropdownMenuItem>
                {hasDocuments && (
                  <DropdownMenuItem onClick={() => onShowDocs(client)}>
                    <Eye className="mr-2 h-4 w-4" />
                    <span>Ver Documentos</span>
                  </DropdownMenuItem>
                )}
                
                <DropdownMenuSub>
                  <DropdownMenuSubTrigger>
                    <Archive className="mr-2 h-4 w-4" />
                    <span>Cambiar Estado</span>
                  </DropdownMenuSubTrigger>
                  <DropdownMenuPortal>
                    <DropdownMenuSubContent>
                      <DropdownMenuItem onClick={() => onStatusChange(client, 'Activo')} disabled={client.status === 'Activo'}>
                        <Check className="mr-2 h-4 w-4 text-green-500" />
                        Activo
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onStatusChange(client, 'Inactivo')} disabled={client.status === 'Inactivo'}>
                        <X className="mr-2 h-4 w-4 text-gray-500" />
                        Inactivo
                      </DropdownMenuItem>
                    </DropdownMenuSubContent>
                  </DropdownMenuPortal>
                </DropdownMenuSub>

                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => onDelete(client)}
                  className="text-red-600 focus:text-red-500 focus:bg-red-50"
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  <span>Eliminar Cliente</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
        <p className="text-sm text-gray-600 my-2 h-10 overflow-hidden">{client.description}</p>
        
        {client.certification_goal && (
          <div className="mb-4">
            <Badge variant="outline" className="text-emerald-700 border-emerald-300 bg-emerald-50">
              {client.certification_goal}
            </Badge>
          </div>
        )}
        
      </div>
      <div className="bg-gray-50/50 px-6 py-4 rounded-b-xl border-t border-gray-200/50 flex justify-between items-center">
        <div className="text-sm text-gray-500">
          <span className="font-medium">Contacto:</span> {client.contact_name || 'N/A'}
        </div>
        <Button
          variant="outline"
          size="sm"
          disabled={!hasDocuments}
          onClick={() => onShowDocs(client)}
          className="bg-white"
        >
          <FileText className="w-4 h-4 mr-2" />
          Documentos
        </Button>
      </div>
    </motion.div>
  );
};

export default ClientCard;