import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Download, UploadCloud, File as FileIcon, X } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const FileInput = ({ label, name, file, existingFilePath, onFileChange, getClientFileUrl, disabled }) => {
  const [downloadUrl, setDownloadUrl] = useState(null);
  const [currentFileName, setCurrentFileName] = useState('');

  useEffect(() => {
    const fetchUrl = async () => {
      if (existingFilePath) {
        const url = await getClientFileUrl(existingFilePath);
        setDownloadUrl(url);
        setCurrentFileName(existingFilePath.split('_').slice(2).join('_'));
      } else {
        setDownloadUrl(null);
        setCurrentFileName('');
      }
    };
    fetchUrl();
  }, [existingFilePath, getClientFileUrl]);

  useEffect(() => {
    if (file) {
      setCurrentFileName(file.name);
    } else if (!existingFilePath) {
      setCurrentFileName('');
    }
  }, [file, existingFilePath]);

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileChange(e);
    }
  };

  const handleRemoveFile = () => {
    const syntheticEvent = { target: { name, files: [] } };
    onFileChange(syntheticEvent);
  };

  const handleDownload = (e) => {
    e.preventDefault();
    if (downloadUrl) {
      window.open(downloadUrl, '_blank');
    }
  };

  const hasExistingFile = !!existingFilePath;
  const hasNewFile = !!file;

  return (
    <div className="space-y-2">
      <Label htmlFor={name}>{label}</Label>
      <div className="flex items-center space-x-2">
        <Input id={name} name={name} type="file" onChange={handleFileChange} className="hidden" disabled={disabled} />
        <Button type="button" variant="outline" onClick={() => document.getElementById(name).click()} disabled={disabled} className="flex-grow">
          <UploadCloud className="w-4 h-4 mr-2" />
          {hasExistingFile || hasNewFile ? 'Reemplazar' : 'Seleccionar'}
        </Button>
        {hasExistingFile && !hasNewFile && (
          <Button type="button" variant="secondary" size="icon" onClick={handleDownload} disabled={!downloadUrl}>
            <Download className="w-4 h-4" />
          </Button>
        )}
      </div>
      {(hasNewFile || hasExistingFile) && (
        <div className="mt-2 flex items-center justify-between p-2 bg-gray-100 rounded-md text-sm">
          <div className="flex items-center gap-2 truncate">
            <FileIcon className="w-4 h-4 text-gray-500 flex-shrink-0" />
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <span className="truncate text-gray-700">{currentFileName}</span>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{currentFileName}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          {hasNewFile && (
            <Button type="button" variant="ghost" size="icon" className="h-6 w-6 text-red-500" onClick={handleRemoveFile}>
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>
      )}
    </div>
  );
};

export default FileInput;