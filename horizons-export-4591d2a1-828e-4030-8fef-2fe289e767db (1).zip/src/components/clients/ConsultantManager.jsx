import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from '@/components/ui/label';
import { UserPlus, X, Crown, User } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const ConsultantManager = ({ allConsultants, assignedConsultants, setAssignedConsultants }) => {
  const [selectedConsultant, setSelectedConsultant] = useState('');

  const unassignedConsultants = allConsultants.filter(
    (c) => !assignedConsultants.some((ac) => ac.id === c.id)
  );

  const handleAddConsultant = () => {
    if (!selectedConsultant) return;
    const consultantToAdd = allConsultants.find((c) => c.id === selectedConsultant);
    if (consultantToAdd) {
      setAssignedConsultants([...assignedConsultants, { ...consultantToAdd, role: 'member' }]);
      setSelectedConsultant('');
    }
  };

  const handleRemoveConsultant = (consultantId) => {
    setAssignedConsultants(assignedConsultants.filter((c) => c.id !== consultantId));
  };
  
  const handleSetLead = (leadId) => {
    setAssignedConsultants(
      assignedConsultants.map((c) => ({
        ...c,
        role: c.id === leadId ? 'lead' : 'member',
      }))
    );
  };
  
  return (
    <div className="space-y-4">
      <Label>Equipo de Consultores Asignados</Label>
      <div className="p-4 border rounded-lg space-y-3 bg-slate-50/50">
        {assignedConsultants.length === 0 ? (
          <p className="text-sm text-gray-500 text-center">No hay consultores asignados.</p>
        ) : (
          assignedConsultants.map((consultant) => (
            <div key={consultant.id} className="flex items-center justify-between p-2 rounded-md bg-white shadow-sm">
              <div className="flex flex-col">
                 <span className="font-medium text-sm flex items-center">
                    {consultant.full_name}
                    {consultant.role === 'lead' && <Crown className="w-4 h-4 ml-2 text-amber-500" />}
                 </span>
                 <span className="text-xs text-gray-500">{consultant.email}</span>
              </div>
              <div className="flex items-center space-x-2">
                 {consultant.role !== 'lead' && (
                    <Button type="button" variant="outline" size="sm" onClick={() => handleSetLead(consultant.id)}>
                        <Crown className="w-4 h-4 mr-1" />
                        Hacer Lead
                    </Button>
                 )}
                 <Button type="button" variant="ghost" size="icon" className="h-8 w-8 text-red-500" onClick={() => handleRemoveConsultant(consultant.id)}>
                   <X className="w-4 h-4" />
                 </Button>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="flex items-end space-x-2">
        <div className="flex-grow">
          <Label htmlFor="consultant-select">Añadir consultor</Label>
          <Select value={selectedConsultant} onValueChange={setSelectedConsultant}>
            <SelectTrigger id="consultant-select">
              <SelectValue placeholder="Seleccionar consultor..." />
            </SelectTrigger>
            <SelectContent>
              {unassignedConsultants.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.full_name} ({c.email})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Button type="button" onClick={handleAddConsultant} disabled={!selectedConsultant}>
          <UserPlus className="w-4 h-4 mr-2" /> Añadir
        </Button>
      </div>
    </div>
  );
};

export default ConsultantManager;