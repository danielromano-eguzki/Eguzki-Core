import React from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { FileText } from 'lucide-react';

const DocumentViewerDialog = ({ client, onDownload, onClose }) => {
  if (!client) return null;

  return (
    <Dialog open={!!client} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Documentos de {client.name}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          {client.nda_path && <Button className="w-full justify-start" variant="outline" onClick={() => onDownload(client.nda_path)}><FileText className="mr-2 h-4 w-4" /> NDA</Button>}
          {client.proposal_path && <Button className="w-full justify-start" variant="outline" onClick={() => onDownload(client.proposal_path)}><FileText className="mr-2 h-4 w-4" /> Propuesta</Button>}
          {client.contract_path && <Button className="w-full justify-start" variant="outline" onClick={() => onDownload(client.contract_path)}><FileText className="mr-2 h-4 w-4" /> Contrato</Button>}
          {!client.nda_path && !client.proposal_path && !client.contract_path && (
            <p className="text-sm text-center text-gray-500">No hay documentos adjuntos para este cliente.</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DocumentViewerDialog;