import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import ClientForm from './ClientForm.jsx';

const ManageClientDialog = ({ open, onOpenChange, client, onSubmit, onCancel, isReadOnly, getClientFileUrl }) => {
  const [formData, setFormData] = useState({
    name: '', description: '', contact_name: '', contact_email: '',
    contact_phone: '', location: '', certification_goal: '',
  });
  const [files, setFiles] = useState({ nda: null, proposal: null, contract: null });

  useEffect(() => {
    if (client) {
      setFormData({
        name: client.name || '',
        description: client.description || '',
        contact_name: client.contact_name || '',
        contact_email: client.contact_email || '',
        contact_phone: client.contact_phone || '',
        location: client.location || '',
        certification_goal: client.certification_goal || '',
      });
    } else {
      setFormData({
        name: '', description: '', contact_name: '', contact_email: '',
        contact_phone: '', location: '', certification_goal: '',
      });
    }
    setFiles({ nda: null, proposal: null, contract: null });
  }, [client, open]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isReadOnly) return;
    const finalFormData = { ...formData, files };
    onSubmit(finalFormData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[625px]">
        <DialogHeader>
          <DialogTitle>{client ? 'Gestionar Cliente' : 'Añadir Nuevo Cliente'}</DialogTitle>
          <DialogDescription>
            {client ? 'Actualiza los detalles del cliente.' : 'Introduce los detalles para crear un nuevo cliente.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <ScrollArea className="h-[65vh] pr-6">
            <ClientForm
              formData={formData}
              setFormData={setFormData}
              files={files}
              setFiles={setFiles}
              isReadOnly={isReadOnly}
              existingClient={client}
              getClientFileUrl={getClientFileUrl}
            />
          </ScrollArea>
          {!isReadOnly && (
            <DialogFooter className="pt-4 mt-4 border-t">
              <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
              <Button type="submit">{client ? 'Guardar Cambios' : 'Crear Cliente'}</Button>
            </DialogFooter>
          )}
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ManageClientDialog;