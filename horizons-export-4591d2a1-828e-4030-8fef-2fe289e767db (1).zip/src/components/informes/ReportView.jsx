import React from 'react';
import ReportGenerator from './ReportGenerator';
import MonthlyUpdateContent from './content/MonthlyUpdateContent';
import FinalProjectContent from './content/FinalProjectContent';
import InternalAuditContent from './content/InternalAuditContent';
import GapAnalysisContent from './content/GapAnalysisContent';
import ImplementationDesignContent from './content/ImplementationDesignContent';
import FindingsActionPlansContent from './content/FindingsActionPlansContent';
import RiskReportContent from './content/RiskReportContent';

const reportContentMap = {
  monthly: MonthlyUpdateContent,
  final_project: FinalProjectContent,
  internal_audit: InternalAuditContent,
  gap_analysis: GapAnalysisContent,
  implementation_design: ImplementationDesignContent,
  findings_action_plans: FindingsActionPlansContent,
  risk_report: RiskReportContent,
};

const ReportView = ({ reportType, reportTitle, client, user, findings, incidents, evidences, auditoriaInternaHook, actionPlans, certifications, requirements, risks, assets }) => {
  const ContentComponent = reportContentMap[reportType] || (() => <div>Tipo de informe no reconocido.</div>);

  return (
    <ReportGenerator title={reportTitle} client={client} user={user}>
      <ContentComponent 
        client={client} 
        user={user} 
        findings={findings} 
        incidents={incidents} 
        evidences={evidences} 
        auditoriaInternaHook={auditoriaInternaHook}
        actionPlans={actionPlans}
        certifications={certifications}
        requirements={requirements}
        risks={risks}
        assets={assets}
      />
    </ReportGenerator>
  );
};

export default ReportView;