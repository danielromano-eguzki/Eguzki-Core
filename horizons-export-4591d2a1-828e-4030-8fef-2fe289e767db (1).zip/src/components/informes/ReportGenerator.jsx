import React, { useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';
import { generatePdfFromDom } from '@/lib/exportUtils';
import { useToast } from "@/components/ui/use-toast";

const ReportGenerator = ({ title, client, user, children }) => {
  const { toast } = useToast();
  const reportRef = useRef();
  const responsible = user?.email || 'Dato no disponible';
  const clientName = client?.name || 'Cliente no seleccionado';

  const handleExport = async () => {
    if (reportRef.current) {
      toast({
        title: "Exportando a PDF...",
        description: "El informe se está generando. Esta operación puede tardar unos segundos.",
      });
      try {
        await generatePdfFromDom({
          element: reportRef.current,
          documentTitle: title,
          clientName: clientName,
          responsible: responsible,
          filename: `Informe_${title.replace(/\s/g, '_')}_${clientName.replace(/\s/g, '_')}.pdf`
        });
        toast({
          title: "¡Éxito!",
          description: "El informe PDF ha sido generado y descargado.",
          variant: "success",
        });
      } catch (error) {
        console.error("Error al generar el PDF:", error);
        toast({
          title: "Error de exportación",
          description: "No se pudo generar el informe en PDF. Por favor, inténtalo de nuevo.",
          variant: "destructive",
        });
      }
    }
  };
  
  const formatDate = (date) => new Date(date).toLocaleDateString('es-ES', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="bg-white p-8 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold text-gray-800">{title}</h2>
        <Button onClick={handleExport}>
          <Download className="mr-2 h-4 w-4" />
          Exportar a PDF
        </Button>
      </div>

      <div ref={reportRef} id="report-content" className="report-container p-8 border rounded-md font-sans text-gray-800">
        {/* -- Portada (Solo para referencia visual, la portada real se genera en el PDF) -- */}
        <div id="pdf-cover-page" className="hidden">
           <h1 data-pdf-title>{title}</h1>
           <p data-pdf-client>{clientName}</p>
           <p data-pdf-date>{formatDate(new Date())}</p>
           <p data-pdf-responsible>{responsible}</p>
        </div>
        
        {/* -- Contenido del informe -- */}
        <main>
            {children}
        </main>
      </div>
    </div>
  );
};

export default ReportGenerator;