import React, { useState, useEffect } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const Section = ({ title, children }) => (
  <div className="mb-8">
    <h4 className="text-xl font-semibold text-gray-800 border-b-2 border-gray-200 pb-2 mb-4">{title}</h4>
    <div className="text-gray-700 space-y-4">
      {children}
    </div>
  </div>
);

const GapAnalysisContent = ({ client, user, certifications = [], requirements = [] }) => {
  const [selectedCertificationId, setSelectedCertificationId] = useState('');

  useEffect(() => {
    if (certifications.length > 0 && !selectedCertificationId) {
      setSelectedCertificationId(certifications[0].id);
    }
  }, [certifications, selectedCertificationId]);

  const filteredRequirements = requirements.filter(req => req.certificacion_id === selectedCertificationId);
  const detectedGaps = filteredRequirements.filter(req => req.estado_cumplimiento !== 'Cumple');

  const getComplianceStatusColor = (status) => {
    switch (status) {
      case 'Cumple': return 'bg-green-100 text-green-800';
      case 'No cumplido': return 'bg-red-100 text-red-800';
      case 'Parcialmente Cumple': return 'bg-yellow-100 text-yellow-800';
      case 'No Aplica': return 'bg-gray-100 text-gray-800';
      default: return 'bg-white';
    }
  };

  return (
    <div className="space-y-6">
      <Section title="1. Norma o Estándar de Referencia">
        <p>
          Este informe compara la situación actual de <strong>{client?.name || 'N/A'}</strong> con los requisitos de la norma o estándar seleccionado.
        </p>
        <div className="mb-4">
          <Label htmlFor="certification-select">Seleccionar Norma/Certificación</Label>
          <Select onValueChange={setSelectedCertificationId} value={selectedCertificationId}>
            <SelectTrigger className="w-full bg-gray-50">
              <SelectValue placeholder="Seleccionar Certificación" />
            </SelectTrigger>
            <SelectContent>
              {certifications.map(cert => (
                <SelectItem key={cert.id} value={cert.id}>
                  {cert.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {selectedCertificationId && (
          <div className="p-4 bg-gray-50 rounded-md border">
            <p><strong>Certificación Seleccionada:</strong> {certifications.find(c => c.id === selectedCertificationId)?.name || 'N/A'}</p>
            <p><strong>Descripción:</strong> {certifications.find(c => c.id === selectedCertificationId)?.description || 'N/A'}</p>
          </div>
        )}
      </Section>

      <Section title="2. Estado Actual vs Requisito">
        <p>
          A continuación se presenta el estado de cumplimiento de cada requisito de la norma seleccionada.
        </p>
        {filteredRequirements.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Código</TableHead>
                <TableHead>Requisito</TableHead>
                <TableHead>Estado de Cumplimiento</TableHead>
                <TableHead>Observaciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRequirements.map(req => (
                <TableRow key={req.id}>
                  <TableCell>{req.codigo || 'N/A'}</TableCell>
                  <TableCell>{req.titulo || req.descripcion}</TableCell>
                  <TableCell>
                    <Badge className={getComplianceStatusColor(req.estado_cumplimiento)}>
                      {req.estado_cumplimiento || 'Dato no disponible'}
                    </Badge>
                  </TableCell>
                  <TableCell>{req.observaciones || 'N/A'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No se han cargado requisitos para la certificación seleccionada o no hay datos disponibles.</p>
        )}
      </Section>

      <Section title="3. Brechas Detectadas">
        <p>
          Las siguientes brechas han sido identificadas, indicando los requisitos que no cumplen con la norma.
        </p>
        {detectedGaps.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Código</TableHead>
                <TableHead>Requisito</TableHead>
                <TableHead>Estado Actual</TableHead>
                <TableHead>Criticidad</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {detectedGaps.map(req => (
                <TableRow key={req.id}>
                  <TableCell>{req.codigo || 'N/A'}</TableCell>
                  <TableCell>{req.titulo || req.descripcion}</TableCell>
                  <TableCell>
                    <Badge className={getComplianceStatusColor(req.estado_cumplimiento)}>
                      {req.estado_cumplimiento || 'Dato no disponible'}
                    </Badge>
                  </TableCell>
                  <TableCell>{req.criticidad || 'N/A'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">¡Excelente! No se han detectado brechas significativas para la certificación seleccionada.</p>
        )}
      </Section>

      <Section title="4. Recomendaciones Priorizadas">
        <p>
          Se proponen las siguientes recomendaciones para abordar las brechas detectadas, priorizadas según su impacto y urgencia.
        </p>
        <Textarea
          placeholder="Ej: Implementar control de acceso físico en salas de servidores (Alta), Desarrollar política de uso aceptable de activos (Media), Realizar formación en concienciación de seguridad (Baja)."
          className="bg-gray-50"
          rows={5}
        />
      </Section>

      <Section title="5. Roadmap de Cierre de Brechas">
        <p>
          El siguiente roadmap describe los pasos y plazos estimados para el cierre de las brechas identificadas.
        </p>
        <Textarea
          placeholder="Ej: Fase 1 (Mes 1-3): Cierre de brechas críticas. Fase 2 (Mes 4-6): Cierre de brechas de prioridad alta. Fase 3 (Mes 7-12): Cierre de brechas de prioridad media y baja."
          className="bg-gray-50"
          rows={5}
        />
      </Section>
    </div>
  );
};

export default GapAnalysisContent;