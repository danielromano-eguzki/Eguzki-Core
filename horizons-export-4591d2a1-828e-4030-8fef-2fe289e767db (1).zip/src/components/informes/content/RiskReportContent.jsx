import React from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';

const Section = ({ title, children }) => (
  <div className="mb-8" data-pdf-section>
    <h4 className="text-xl font-semibold text-gray-800 border-b-2 border-gray-200 pb-2 mb-4">{title}</h4>
    <div className="text-gray-700 space-y-4">
      {children}
    </div>
  </div>
);

const getRiskLevelColor = (level) => {
  if (level === 'Crítico' || level === 'Muy Alto') return 'bg-red-100 text-red-700';
  if (level === 'Alto') return 'bg-orange-100 text-orange-700';
  if (level === 'Medio') return 'bg-yellow-100 text-yellow-700';
  return 'bg-green-100 text-green-700';
};

const getStatusColor = (status) => {
  if (status === 'Completado' || status === 'Implementado') return 'bg-green-100 text-green-700';
  if (status === 'En Progreso' || status === 'Evaluado') return 'bg-blue-100 text-blue-700';
  if (status === 'Cancelado' || status === 'Rechazado') return 'bg-red-100 text-red-700';
  return 'bg-gray-100 text-gray-700';
};

const parseValue = (str) => {
  if (!str) return 0;
  const match = str.match(/\((\d+)\)/);
  return match ? parseInt(match[1], 10) : 0;
};

const RiskReportContent = ({ client, user, risks = [], actionPlans = [], assets = [] }) => {
  const getAssetName = (assetId) => assets.find(a => a.id === assetId)?.name || 'Dato no disponible';

  const riskCountsByLevel = risks.reduce((acc, risk) => {
    acc[risk.level] = (acc[risk.level] || 0) + 1;
    return acc;
  }, {});

  const mageritNivelRiesgoOrder = ["Crítico", "Muy Alto", "Alto", "Medio", "Bajo", "Muy Bajo"];

  return (
    <div className="space-y-6">
      <Section title="1. Metodología de Análisis de Riesgos">
        <p>
          Este informe ha sido generado siguiendo la metodología de análisis de riesgos basada en Magerit v3, la cual permite identificar, evaluar y gestionar los riesgos de seguridad de la información de manera sistemática.
          La evaluación se basa en una escala de 5 niveles para la probabilidad y 5 para el impacto, lo que permite calcular el nivel de riesgo inherente.
        </p>
        <Label htmlFor="methodology-details">Detalles Específicos de la Metodología (Opcional)</Label>
        <Textarea
          id="methodology-details"
          placeholder="Puede añadir aquí detalles adicionales sobre la metodología utilizada, como las herramientas, el equipo de trabajo, o las fechas en las que se realizó el análisis."
          className="bg-gray-50"
          rows={4}
        />
      </Section>

      <Section title="2. Inventario de Riesgos">
        <p>
          A continuación se presenta el inventario de riesgos identificados para el cliente <strong>{client?.name || 'N/A'}</strong>.
        </p>
        {risks.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nombre del Riesgo</TableHead>
                <TableHead>Activo Afectado</TableHead>
                <TableHead>Amenaza</TableHead>
                <TableHead>Probabilidad</TableHead>
                <TableHead>Impacto</TableHead>
                <TableHead>Nivel de Riesgo</TableHead>
                <TableHead>Tratamiento</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {risks.map((risk) => (
                <TableRow key={risk.id}>
                  <TableCell className="font-medium">{risk.name || 'Dato no disponible'}</TableCell>
                  <TableCell>{getAssetName(risk.asset_id)}</TableCell>
                  <TableCell>{risk.threat || 'Dato no disponible'}</TableCell>
                  <TableCell>{risk.probability || 'Dato no disponible'}</TableCell>
                  <TableCell>{risk.impact || 'Dato no disponible'}</TableCell>
                  <TableCell>
                    <Badge className={`${getRiskLevelColor(risk.level)}`}>{risk.level || 'Dato no disponible'}</Badge>
                  </TableCell>
                  <TableCell>{risk.treatment || 'Dato no disponible'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No se han encontrado riesgos para este cliente.</p>
        )}
      </Section>

      <Section title="3. Evaluación de Impacto y Probabilidad">
        <p>
          La evaluación de los riesgos se ha realizado cuantificando su probabilidad de ocurrencia y el impacto potencial que generarían, según la escala de Magerit v3.
        </p>
        <div className="mt-4">
          <h5 className="text-lg font-semibold text-gray-700 mb-2">Distribución de Riesgos por Nivel</h5>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nivel de Riesgo</TableHead>
                <TableHead className="text-right">Número de Riesgos</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mageritNivelRiesgoOrder.map(level => (
                <TableRow key={level}>
                  <TableCell><Badge className={`${getRiskLevelColor(level)}`}>{level}</Badge></TableCell>
                  <TableCell className="text-right">{riskCountsByLevel[level] || 0}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Section>

      <Section title="4. Nivel de Riesgo Residual y Plan de Tratamiento">
        <p>
          Esta sección detalla los planes de acción implementados o en progreso para mitigar los riesgos, y el nivel de riesgo residual estimado tras la aplicación de las medidas.
        </p>
        {actionPlans.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Riesgo Asociado</TableHead>
                <TableHead>Descripción del Plan</TableHead>
                <TableHead>Responsable</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Efectividad</TableHead>
                <TableHead>Riesgo Residual Estimado</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {actionPlans.map((plan) => {
                const associatedRisk = risks.find(r => r.id === plan.risk_id);
                return (
                  <TableRow key={plan.id}>
                    <TableCell>{associatedRisk?.name || 'Riesgo Desconocido'}</TableCell>
                    <TableCell>{plan.description || 'Dato no disponible'}</TableCell>
                    <TableCell>{plan.responsible || 'Dato no disponible'}</TableCell>
                    <TableCell>
                      <Badge className={`${getStatusColor(plan.status)}`}>{plan.status || 'Dato no disponible'}</Badge>
                    </TableCell>
                    <TableCell>{plan.effectiveness || 'Dato no disponible'}</TableCell>
                    <TableCell>{plan.estimated_residual_risk || 'Dato no disponible'}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No se han definido planes de acción para los riesgos.</p>
        )}
      </Section>

      <Section title="5. Recomendaciones de Tratamiento">
        <p>
          Se resumen las estrategias de tratamiento aplicadas o recomendadas para los riesgos identificados, buscando reducir su impacto o probabilidad a un nivel aceptable.
        </p>
        {risks.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Riesgo</TableHead>
                <TableHead>Tratamiento Aplicado</TableHead>
                <TableHead>Detalles del Tratamiento</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {risks.map((risk) => (
                <TableRow key={risk.id}>
                  <TableCell className="font-medium">{risk.name || 'Dato no disponible'}</TableCell>
                  <TableCell>{risk.treatment || 'Dato no disponible'}</TableCell>
                  <TableCell>
                    {actionPlans.filter(ap => ap.risk_id === risk.id).map(ap => (
                      <div key={ap.id} className="mb-1 text-sm">
                        - {ap.description} (Responsable: {ap.responsible}, Estado: {ap.status})
                      </div>
                    ))}
                    {actionPlans.filter(ap => ap.risk_id === risk.id).length === 0 && 'No se han definido acciones específicas para este tratamiento.'}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No hay riesgos para recomendar tratamientos.</p>
        )}
      </Section>
    </div>
  );
};

export default RiskReportContent;