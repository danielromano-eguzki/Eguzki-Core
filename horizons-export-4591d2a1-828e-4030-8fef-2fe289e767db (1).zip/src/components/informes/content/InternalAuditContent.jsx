import React, { useState, useEffect } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const Section = ({ title, children }) => (
  <div className="mb-8">
    <h4 className="text-xl font-semibold text-gray-800 border-b-2 border-gray-200 pb-2 mb-4">{title}</h4>
    <div className="text-gray-700 space-y-4">
      {children}
    </div>
  </div>
);

const InternalAuditContent = ({ client, user, findings = [], auditoriaInternaHook, actionPlans = [] }) => {
  const { auditPrograms, requirements, compliance } = auditoriaInternaHook;
  const [selectedAuditProgramId, setSelectedAuditProgramId] = useState('');
  const [scopeAndMethodology, setScopeAndMethodology] = useState('');

  useEffect(() => {
    if (auditPrograms && auditPrograms.length > 0 && !selectedAuditProgramId) {
      setSelectedAuditProgramId(auditPrograms[0].id);
    }
  }, [auditPrograms, selectedAuditProgramId]);

  const selectedProgram = auditPrograms.find(p => p.id === selectedAuditProgramId);

  const getPriorityBadge = (priority) => {
    switch (priority) {
      case 'Crítica': return 'bg-red-600 text-white';
      case 'Alta': return 'bg-red-200 text-red-800';
      case 'Media': return 'bg-yellow-200 text-yellow-800';
      case 'Baja': return 'bg-blue-200 text-blue-800';
      default: return 'bg-gray-200 text-gray-800';
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Abierto': return 'bg-red-100 text-red-800';
      case 'En Progreso': return 'bg-yellow-100 text-yellow-800';
      case 'Resuelto': return 'bg-blue-100 text-blue-800';
      case 'Cerrado': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getComplianceStatusColor = (status) => {
    switch (status) {
      case 'Cumple': return 'bg-green-100 text-green-800';
      case 'No Cumple': return 'bg-red-100 text-red-800';
      case 'Parcialmente Cumple': return 'bg-yellow-100 text-yellow-800';
      case 'No Aplica': return 'bg-gray-100 text-gray-800';
      default: return 'bg-white';
    }
  };

  const findingsByPriority = findings.reduce((acc, finding) => {
    const priority = finding.priority || 'Sin Prioridad';
    if (!acc[priority]) {
      acc[priority] = [];
    }
    acc[priority].push(finding);
    return acc;
  }, {});

  const nonConformities = findings.filter(f => f.status !== 'Cerrado');
  const observations = compliance.filter(c => c.compliance_status === 'Parcialmente Cumple' || c.observations);

  return (
    <div className="space-y-6">
      <Section title="1. Alcance y Metodología de la Auditoría">
        <div className="mb-4">
          <Label htmlFor="audit-program-select">Programa de Auditoría Seleccionado</Label>
          <select
            id="audit-program-select"
            className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1"
            value={selectedAuditProgramId}
            onChange={(e) => setSelectedAuditProgramId(e.target.value)}
          >
            <option value="">Seleccionar Programa</option>
            {auditPrograms.map(program => (
              <option key={program.id} value={program.id}>{program.name}</option>
            ))}
          </select>
        </div>
        {selectedProgram && (
          <div className="mb-4 p-4 bg-gray-50 rounded-md border">
            <p><strong>Nombre del Programa:</strong> {selectedProgram.name}</p>
            <p><strong>Descripción:</strong> {selectedProgram.description || 'N/A'}</p>
            <p><strong>Estado:</strong> {selectedProgram.status}</p>
            <p><strong>Fechas:</strong> {selectedProgram.start_date ? format(new Date(selectedProgram.start_date), 'dd/MM/yyyy') : 'N/A'} - {selectedProgram.end_date ? format(new Date(selectedProgram.end_date), 'dd/MM/yyyy') : 'N/A'}</p>
          </div>
        )}
        <Textarea
          placeholder="Describa aquí el alcance de la auditoría (ej. sistemas, procesos, departamentos incluidos) y la metodología utilizada (ej. entrevistas, revisión documental, pruebas técnicas)."
          className="bg-gray-50"
          rows={6}
          value={scopeAndMethodology}
          onChange={(e) => setScopeAndMethodology(e.target.value)}
        />
      </Section>

      <Section title="2. Resultados por Control/Norma">
        <p>
          A continuación se presenta el estado de cumplimiento de los requisitos o controles auditados.
        </p>
        {compliance.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Requisito/Control</TableHead>
                <TableHead>Estado de Cumplimiento</TableHead>
                <TableHead>Observaciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {compliance.map(item => (
                <TableRow key={item.id}>
                  <TableCell>{item.requirement?.requirement_text || 'N/A'}</TableCell>
                  <TableCell>
                    <Badge className={getComplianceStatusColor(item.compliance_status)}>
                      {item.compliance_status}
                    </Badge>
                  </TableCell>
                  <TableCell>{item.observations || 'N/A'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No se han registrado resultados de cumplimiento para el programa seleccionado.</p>
        )}
      </Section>

      <Section title="3. Hallazgos Clasificados por Criticidad">
        <p>
          Los siguientes hallazgos han sido identificados durante la auditoría, clasificados por su nivel de criticidad.
        </p>
        {Object.keys(findingsByPriority).length > 0 ? (
          Object.keys(findingsByPriority).sort((a, b) => {
            const order = { 'Crítica': 1, 'Alta': 2, 'Media': 3, 'Baja': 4, 'Sin Prioridad': 5 };
            return order[a] - order[b];
          }).map(priority => (
            <div key={priority} className="mb-6">
              <h5 className="text-lg font-semibold text-gray-700 mt-4 mb-2">{priority}</h5>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Descripción</TableHead>
                    <TableHead>Fuente</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Fecha Límite</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {findingsByPriority[priority].map(finding => (
                    <TableRow key={finding.id}>
                      <TableCell>{finding.description}</TableCell>
                      <TableCell>{finding.source || 'Auditoría Interna'}</TableCell>
                      <TableCell>
                        <Badge className={getStatusBadge(finding.status)}>
                          {finding.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{finding.due_date ? format(new Date(finding.due_date), 'dd/MM/yyyy') : 'N/A'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ))
        ) : (
          <p className="text-gray-500 italic">No se han registrado hallazgos para el programa seleccionado.</p>
        )}
      </Section>

      <Section title="4. No Conformidades y Observaciones">
        <p>
          Se detallan las no conformidades y observaciones significativas detectadas durante la auditoría.
        </p>
        <h5 className="text-lg font-semibold text-gray-700 mt-4 mb-2">No Conformidades (Hallazgos Abiertos/En Progreso)</h5>
        {nonConformities.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Descripción</TableHead>
                <TableHead>Prioridad</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Plan de Acción Propuesto</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {nonConformities.map(finding => (
                <TableRow key={finding.id}>
                  <TableCell>{finding.description}</TableCell>
                  <TableCell>
                    <Badge className={getPriorityBadge(finding.priority)}>
                      {finding.priority}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusBadge(finding.status)}>
                      {finding.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{finding.proposed_solution || 'Pendiente de definir'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No se han identificado no conformidades activas.</p>
        )}

        <h5 className="text-lg font-semibold text-gray-700 mt-6 mb-2">Observaciones (Cumplimiento Parcial o Notas Relevantes)</h5>
        {observations.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Requisito/Control</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Observaciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {observations.map(item => (
                <TableRow key={item.id}>
                  <TableCell>{item.requirement?.requirement_text || 'N/A'}</TableCell>
                  <TableCell>
                    <Badge className={getComplianceStatusColor(item.compliance_status)}>
                      {item.compliance_status}
                    </Badge>
                  </TableCell>
                  <TableCell>{item.observations || 'N/A'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No se han registrado observaciones adicionales.</p>
        )}
      </Section>

      <Section title="5. Plan de Acciones Correctivas">
        <p>
          El siguiente plan de acciones correctivas se ha establecido para abordar los hallazgos y no conformidades identificadas.
        </p>
        {actionPlans.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Descripción</TableHead>
                <TableHead>Responsable</TableHead>
                <TableHead>Fecha Límite</TableHead>
                <TableHead>Estado</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {actionPlans.map(plan => (
                <TableRow key={plan.id}>
                  <TableCell>{plan.description}</TableCell>
                  <TableCell>{plan.responsible || 'N/A'}</TableCell>
                  <TableCell>{plan.due_date ? format(new Date(plan.due_date), 'dd/MM/yyyy') : 'N/A'}</TableCell>
                  <TableCell>
                    <Badge className={getStatusBadge(plan.status)}>
                      {plan.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No se han registrado planes de acción correctiva.</p>
        )}
      </Section>
    </div>
  );
};

export default InternalAuditContent;