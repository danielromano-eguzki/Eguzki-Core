import React from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

const Section = ({ title, children }) => (
  <div className="mb-8">
    <h4 className="text-xl font-semibold text-gray-800 border-b-2 border-gray-200 pb-2 mb-4">{title}</h4>
    <div className="text-gray-700 space-y-4">
      {children}
    </div>
  </div>
);

const MonthlyUpdateContent = ({ client, user, findings = [], incidents = [] }) => {
  const period = new Date().toLocaleString('es-ES', { month: 'long', year: 'numeric' });

  const oneMonthAgo = new Date();
  oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);

  const recentFindings = findings.filter(f => new Date(f.created_at) >= oneMonthAgo);
  const recentIncidents = incidents.filter(i => new Date(i.created_at) >= oneMonthAgo);

  return (
    <div className="space-y-6">
      <Section title="1. Introducción y Alcance del Mes">
        <p>
          El presente informe detalla las actividades de consultoría y el estado del sistema de gestión para <strong>{client?.name || 'N/A'}</strong> durante el periodo de <strong>{period}</strong>. El objetivo es proporcionar una visión clara del progreso, identificar desviaciones y establecer las prioridades para el próximo ciclo.
        </p>
        <Textarea 
          placeholder="Añada aquí un resumen de los objetivos específicos y el alcance para este mes..."
          className="bg-gray-50"
        />
      </Section>

      <Section title="2. Avances Realizados vs. Plan Inicial">
        <p>
          A continuación se describen los avances principales en comparación con la planificación establecida.
        </p>
        <Textarea 
          placeholder="Detalle aquí los hitos alcanzados, tareas completadas, reuniones importantes y cualquier otro progreso relevante del mes."
          className="bg-gray-50"
          rows={5}
        />
      </Section>

      <Section title="3. Incidencias o Desviaciones Detectadas">
        <p>
          Se han registrado las siguientes incidencias y hallazgos durante el último mes que requieren atención.
        </p>
        
        <h5 className="text-lg font-semibold text-gray-700 mt-6 mb-2">Hallazgos Recientes</h5>
        {recentFindings.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Descripción</TableHead>
                <TableHead>Prioridad</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Fecha Límite</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentFindings.map(finding => (
                <TableRow key={finding.id}>
                  <TableCell>{finding.description}</TableCell>
                  <TableCell><Badge variant={finding.priority === 'Alta' ? 'destructive' : 'secondary'}>{finding.priority}</Badge></TableCell>
                  <TableCell>{finding.status}</TableCell>
                  <TableCell>{finding.due_date ? format(new Date(finding.due_date), 'dd/MM/yyyy') : 'N/A'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No se han registrado nuevos hallazgos en el último mes.</p>
        )}

        <h5 className="text-lg font-semibold text-gray-700 mt-6 mb-2">Incidentes Recientes</h5>
        {recentIncidents.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nombre</TableHead>
                <TableHead>Severidad</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Fecha Incidente</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentIncidents.map(incident => (
                <TableRow key={incident.id}>
                  <TableCell>{incident.name}</TableCell>
                  <TableCell><Badge variant={incident.severity === 'Alta' ? 'destructive' : 'secondary'}>{incident.severity}</Badge></TableCell>
                  <TableCell>{incident.status}</TableCell>
                  <TableCell>{incident.incident_date ? format(new Date(incident.incident_date), 'dd/MM/yyyy') : 'N/A'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No se han registrado nuevos incidentes en el último mes.</p>
        )}
      </Section>

      <Section title="4. Mejoras Implementadas">
        <p>
          Detalle de las mejoras y acciones correctivas que se han completado durante este periodo.
        </p>
        <Textarea 
          placeholder="Ej: Se ha actualizado la política de control de acceso, se ha impartido formación sobre phishing al departamento de finanzas, etc."
          className="bg-gray-50"
          rows={4}
        />
      </Section>

      <Section title="5. Recomendaciones para el Siguiente Mes">
        <p>
          En base al estado actual, se proponen las siguientes acciones y focos de atención para el próximo mes.
        </p>
        <Textarea 
          placeholder="Ej: Priorizar la resolución del hallazgo H-005, realizar una revisión de los permisos de acceso a la carpeta compartida X, planificar la próxima auditoría interna, etc."
          className="bg-gray-50"
          rows={4}
        />
      </Section>
    </div>
  );
};

export default MonthlyUpdateContent;