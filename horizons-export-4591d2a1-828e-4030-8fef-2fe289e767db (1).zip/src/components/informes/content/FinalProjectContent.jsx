import React from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

const Section = ({ title, children }) => (
  <div className="mb-8">
    <h4 className="text-xl font-semibold text-gray-800 border-b-2 border-gray-200 pb-2 mb-4">{title}</h4>
    <div className="text-gray-700 space-y-4">
      {children}
    </div>
  </div>
);

const FinalProjectContent = ({ client, user, findings = [], incidents = [], evidences = [] }) => {
  return (
    <div className="space-y-6">
      <Section title="1. Resumen de Objetivos Iniciales">
        <p>
          Este informe resume los resultados y el cierre del proyecto de consultoría para <strong>{client?.name || 'N/A'}</strong>. A continuación, se detallan los objetivos planteados al inicio del proyecto y el grado de cumplimiento de los mismos.
        </p>
        <Textarea 
          placeholder="Describa aquí los objetivos iniciales del proyecto, por ejemplo: 'Implementación de un SGSI basado en ISO 27001', 'Análisis de brechas de GDPR', etc."
          className="bg-gray-50"
          rows={4}
        />
      </Section>

      <Section title="2. Entregables Alcanzados">
        <p>
          Durante el desarrollo del proyecto, se han generado y entregado los siguientes productos y resultados clave:
        </p>
        <Textarea 
          placeholder="Liste aquí los entregables específicos del proyecto, como 'Política de Seguridad de la Información', 'Informe de Análisis de Riesgos', 'Plan de Continuidad de Negocio', 'Procedimientos de Gestión de Incidentes', etc."
          className="bg-gray-50"
          rows={5}
        />
      </Section>

      <Section title="3. Principales Incidencias y Cómo se Resolvieron">
        <p>
          A lo largo del proyecto, se gestionaron las siguientes incidencias o desviaciones, las cuales fueron resueltas de la siguiente manera:
        </p>
        {incidents.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nombre Incidente</TableHead>
                <TableHead>Severidad</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Fecha</TableHead>
                <TableHead>Resolución</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {incidents.map(incident => (
                <TableRow key={incident.id}>
                  <TableCell>{incident.name}</TableCell>
                  <TableCell><Badge variant={incident.severity === 'Alta' ? 'destructive' : 'secondary'}>{incident.severity}</Badge></TableCell>
                  <TableCell>{incident.status}</TableCell>
                  <TableCell>{incident.incident_date ? format(new Date(incident.incident_date), 'dd/MM/yyyy') : 'N/A'}</TableCell>
                  <TableCell>{incident.lessons_learned || 'Pendiente de completar'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No se han registrado incidencias significativas durante el proyecto.</p>
        )}
        <Textarea 
          placeholder="Añada detalles adicionales sobre la gestión de incidencias o desafíos superados durante el proyecto."
          className="bg-gray-50 mt-4"
          rows={3}
        />
      </Section>

      <Section title="4. Evidencias Documentales y Técnicas">
        <p>
          Las siguientes evidencias respaldan los logros y el cumplimiento de los requisitos del proyecto:
        </p>
        {evidences.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nombre</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Fecha</TableHead>
                <TableHead>Responsable</TableHead>
                <TableHead>Comentarios</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {evidences.map(evidence => (
                <TableRow key={evidence.id}>
                  <TableCell>{evidence.nombre}</TableCell>
                  <TableCell>{evidence.tipo}</TableCell>
                  <TableCell>{evidence.fecha ? format(new Date(evidence.fecha), 'dd/MM/yyyy') : 'N/A'}</TableCell>
                  <TableCell>{evidence.responsable || 'N/A'}</TableCell>
                  <TableCell>{evidence.comentarios || 'N/A'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No se han registrado evidencias para este cliente.</p>
        )}
        <Textarea 
          placeholder="Puede añadir aquí cualquier otra evidencia relevante o enlaces a repositorios de documentos."
          className="bg-gray-50 mt-4"
          rows={3}
        />
      </Section>

      <Section title="5. Sostenibilidad y Seguimiento Post-Proyecto">
        <p>
          Para asegurar la continuidad de los beneficios del proyecto y el mantenimiento del sistema implementado, se recomiendan las siguientes acciones:
        </p>
        <Textarea 
          placeholder="Ej: Establecer revisiones periódicas de políticas, programar auditorías internas anuales, mantener la formación del personal, definir un plan de mejora continua, etc."
          className="bg-gray-50"
          rows={5}
        />
      </Section>
    </div>
  );
};

export default FinalProjectContent;