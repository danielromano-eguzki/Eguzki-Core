import React from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

const Section = ({ title, children }) => (
  <div className="mb-8">
    <h4 className="text-xl font-semibold text-gray-800 border-b-2 border-gray-200 pb-2 mb-4">{title}</h4>
    <div className="text-gray-700 space-y-4">
      {children}
    </div>
  </div>
);

const ImplementationDesignContent = ({ client, user }) => {
  return (
    <div className="space-y-6">
      <Section title="1. Alcance del Diseño">
        <p>
          Esta sección define el propósito y los límites del diseño de implementación, incluyendo los sistemas, procesos o áreas que serán afectados por las nuevas medidas.
        </p>
        <Label htmlFor="design-scope">Descripción del Alcance</Label>
        <Textarea
          id="design-scope"
          placeholder="Describa el alcance de este diseño de implementación (ej. qué áreas, sistemas o procesos cubre, qué normativas se buscan cumplir)."
          className="bg-gray-50"
          rows={6}
        />
      </Section>

      <Section title="2. Controles/Medidas Planificadas">
        <p>
          Detalle las medidas y controles de seguridad específicos que se planean implementar, incluyendo su objetivo y cómo contribuirán a mejorar la postura de seguridad.
        </p>
        <Label htmlFor="planned-measures">Descripción de Controles/Medidas</Label>
        <Textarea
          id="planned-measures"
          placeholder="Liste los controles y medidas planificadas (ej. Implementación de MFA en todos los accesos, Cifrado de bases de datos, Segmentación de red, etc.). Sea específico en cada medida."
          className="bg-gray-50"
          rows={8}
        />
      </Section>

      <Section title="3. Recursos y Responsables">
        <p>
          Identifique los recursos necesarios (humanos, tecnológicos, financieros) y asigne los responsables clave para cada fase o área del diseño de implementación.
        </p>
        <Label htmlFor="resources-responsibles">Asignación de Recursos y Responsables</Label>
        <Textarea
          id="resources-responsibles"
          placeholder="Detalle los recursos necesarios (ej. Equipo de TI, consultores externos, presupuesto, herramientas de software) y los responsables asignados a la implementación de cada control o medida."
          className="bg-gray-50"
          rows={6}
        />
      </Section>

      <Section title="4. Cronograma">
        <p>
          Presente un cronograma detallado con las fases, hitos y plazos esperados para la implementación de cada control o medida planificada.
        </p>
        <Label htmlFor="timeline">Detalle del Cronograma</Label>
        <Textarea
          id="timeline"
          placeholder="Establezca el cronograma de la implementación (ej. Fase 1: Recopilación de requisitos y diseño (Semanas 1-4), Fase 2: Implementación de controles (Semanas 5-12), Fase 3: Pruebas y validación (Semanas 13-16))."
          className="bg-gray-50"
          rows={6}
        />
      </Section>

      <Section title="5. Riesgos del Plan y Mitigaciones">
        <p>
          Identifique los posibles riesgos asociados a la implementación del plan de diseño y las estrategias de mitigación propuestas para abordarlos.
        </p>
        <Label htmlFor="plan-risks">Riesgos y Estrategias de Mitigación</Label>
        <Textarea
          id="plan-risks"
          placeholder="Enumere los riesgos potenciales del plan (ej. Retrasos por falta de recursos, Resistencia al cambio del personal, Problemas de compatibilidad técnica) y las medidas de mitigación para cada uno."
          className="bg-gray-50"
          rows={6}
        />
      </Section>
    </div>
  );
};

export default ImplementationDesignContent;