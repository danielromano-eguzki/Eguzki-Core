import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';

const Section = ({ title, children }) => (
  <div className="mb-8">
    <h4 className="text-xl font-semibold text-gray-800 border-b-2 border-gray-200 pb-2 mb-4">{title}</h4>
    <div className="text-gray-700 space-y-4">
      {children}
    </div>
  </div>
);

const FindingsActionPlansContent = ({ client, user, findings = [] }) => {
  const formatDate = (dateString) => dateString ? new Date(dateString).toLocaleDateString() : 'Dato no disponible';

  const getStatusBadge = (status) => {
    switch(status) {
      case 'Abierto': return 'bg-red-100 text-red-800';
      case 'En Progreso': return 'bg-yellow-100 text-yellow-800';
      case 'Cerrado': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityBadge = (priority) => {
    switch(priority) {
      case 'Crítica': return 'bg-red-100 text-red-800';
      case 'Alta': return 'bg-orange-100 text-orange-800';
      case 'Media': return 'bg-yellow-100 text-yellow-800';
      case 'Baja': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <Section title="1. Hallazgos Identificados">
        <p>
          Este informe documenta los hallazgos detectados durante auditorías o revisiones para el cliente <strong>{client?.name || 'N/A'}</strong>.
        </p>
        {findings.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Descripción</TableHead>
                <TableHead>Fuente</TableHead>
                <TableHead>Fecha Creación</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {findings.map(finding => (
                <TableRow key={finding.id}>
                  <TableCell>{finding.id.substring(0, 8)}</TableCell>
                  <TableCell>{finding.type || 'Dato no disponible'}</TableCell>
                  <TableCell>{finding.description || 'Dato no disponible'}</TableCell>
                  <TableCell>{finding.source || 'Dato no disponible'}</TableCell>
                  <TableCell>{formatDate(finding.created_at)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No se han encontrado hallazgos para este cliente.</p>
        )}
      </Section>

      <Section title="2. Clasificación por Criticidad e Impacto Potencial">
        <p>
          Los hallazgos se clasifican por su prioridad y el impacto potencial que podrían generar.
        </p>
        {findings.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Prioridad</TableHead>
                <TableHead>Impacto Potencial</TableHead>
                <TableHead>Descripción Breve</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {findings.map(finding => (
                <TableRow key={finding.id}>
                  <TableCell>{finding.id.substring(0, 8)}</TableCell>
                  <TableCell>
                    <Badge className={getPriorityBadge(finding.priority)}>
                      {finding.priority || 'Dato no disponible'}
                    </Badge>
                  </TableCell>
                  <TableCell>Dato no disponible</TableCell> {/* Placeholder as per instruction */}
                  <TableCell>{finding.description ? `${finding.description.substring(0, 50)}...` : 'Dato no disponible'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No hay hallazgos para clasificar.</p>
        )}
      </Section>

      <Section title="3. Acciones Correctivas/Preventivas">
        <p>
          Para cada hallazgo, se proponen o han sido implementadas acciones para mitigar el riesgo.
        </p>
        {findings.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID Hallazgo</TableHead>
                <TableHead>Solución Propuesta</TableHead>
                <TableHead>Solución Aplicada</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {findings.map(finding => (
                <TableRow key={finding.id}>
                  <TableCell>{finding.id.substring(0, 8)}</TableCell>
                  <TableCell>{finding.proposed_solution || 'Pendiente de definir'}</TableCell>
                  <TableCell>{finding.applied_solution || 'No aplicada aún'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No hay acciones correctivas/preventivas que mostrar.</p>
        )}
      </Section>

      <Section title="4. Seguimiento y Fecha de Cierre">
        <p>
          Estado actual y fecha límite de resolución para cada hallazgo.
        </p>
        {findings.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID Hallazgo</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Fecha Límite</TableHead>
                <TableHead>Fecha de Cierre (Real)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {findings.map(finding => (
                <TableRow key={finding.id}>
                  <TableCell>{finding.id.substring(0, 8)}</TableCell>
                  <TableCell>
                    <Badge className={getStatusBadge(finding.status)}>
                      {finding.status || 'Dato no disponible'}
                    </Badge>
                  </TableCell>
                  <TableCell>{formatDate(finding.due_date)}</TableCell>
                  <TableCell>{finding.status === 'Cerrado' ? formatDate(finding.updated_at) : 'No cerrado'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-gray-500 italic">No hay seguimiento de hallazgos disponible.</p>
        )}
      </Section>
    </div>
  );
};

export default FindingsActionPlansContent;