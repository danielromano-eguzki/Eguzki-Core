import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { UploadCloud, File as FileIcon, X } from 'lucide-react';

const ContractForm = ({ contractItem, onSubmit, onCancel, isReadOnly }) => {
  const [formData, setFormData] = useState({
    contract_id: '',
    party_name: '',
    party_role: 'processor',
    contract_date: new Date().toISOString().split('T')[0],
    review_date: '',
    description: '',
  });
  const [attachment, setAttachment] = useState(null);
  const [existingAttachmentName, setExistingAttachmentName] = useState('');
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (contractItem) {
      setFormData({
        ...contractItem,
        contract_date: contractItem.contract_date ? new Date(contractItem.contract_date).toISOString().split('T')[0] : '',
        review_date: contractItem.review_date ? new Date(contractItem.review_date).toISOString().split('T')[0] : '',
      });
      setExistingAttachmentName(contractItem.attachment_name || '');
    } else {
      setFormData(prev => ({ ...prev, contract_id: `CTR-${Date.now()}` }));
    }
  }, [contractItem]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    if (e.target.files[0]) {
      setAttachment(e.target.files[0]);
      setExistingAttachmentName('');
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData, attachment);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <form onSubmit={handleSubmit}>
        <Card className="bg-white/70 backdrop-blur-lg border-white/30">
          <CardHeader>
            <CardTitle>{contractItem ? 'Editar' : 'Añadir'} Contrato de Tratamiento</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[60vh] pr-6">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="contract_id">ID de Contrato</Label>
                    <Input id="contract_id" name="contract_id" value={formData.contract_id} onChange={handleChange} required disabled={isReadOnly} />
                  </div>
                  <div>
                    <Label htmlFor="party_name">Nombre de la Contraparte</Label>
                    <Input id="party_name" name="party_name" value={formData.party_name} onChange={handleChange} required disabled={isReadOnly} />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Rol de la Contraparte</Label>
                    <Select value={formData.party_role} onValueChange={(v) => handleSelectChange('party_role', v)} disabled={isReadOnly}>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar rol..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="processor">Encargado del Tratamiento</SelectItem>
                        <SelectItem value="controller">Responsable del Tratamiento</SelectItem>
                        <SelectItem value="joint_controller">Corresponsable</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                   <div>
                    <Label htmlFor="contract_date">Fecha del Contrato</Label>
                    <Input id="contract_date" name="contract_date" type="date" value={formData.contract_date} onChange={handleChange} disabled={isReadOnly} />
                  </div>
                </div>
                 <div>
                    <Label htmlFor="review_date">Próxima Revisión</Label>
                    <Input id="review_date" name="review_date" type="date" value={formData.review_date} onChange={handleChange} disabled={isReadOnly} />
                  </div>
                <div>
                  <Label htmlFor="description">Descripción / Objeto del Contrato</Label>
                  <Textarea id="description" name="description" value={formData.description} onChange={handleChange} disabled={isReadOnly} />
                </div>
                <div>
                  <Label>Adjunto</Label>
                  <div
                    className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md cursor-pointer"
                    onClick={() => !isReadOnly && fileInputRef.current.click()}
                  >
                    <div className="space-y-1 text-center">
                      <UploadCloud className="mx-auto h-12 w-12 text-gray-400" />
                      <div className="flex text-sm text-gray-600">
                        <p className="pl-1">
                          {attachment ? 'Archivo seleccionado:' : (existingAttachmentName ? 'Archivo existente:' : 'Sube un archivo o arrástralo aquí')}
                        </p>
                      </div>
                      <p className="text-xs text-gray-500">PDF, DOCX hasta 5MB</p>
                    </div>
                  </div>
                  <Input ref={fileInputRef} id="attachment" name="attachment" type="file" className="hidden" onChange={handleFileChange} disabled={isReadOnly} />
                  {(attachment || existingAttachmentName) && (
                    <div className="mt-2 flex items-center text-sm">
                      <FileIcon className="h-5 w-5 text-gray-500 mr-2" />
                      <span>{attachment?.name || existingAttachmentName}</span>
                      {!isReadOnly && (
                        <Button type="button" variant="ghost" size="icon" className="ml-2 h-6 w-6" onClick={() => { setAttachment(null); setExistingAttachmentName(''); }}>
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </ScrollArea>
          </CardContent>
          <CardFooter className="flex justify-end space-x-2">
            <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
            {!isReadOnly && <Button type="submit">{contractItem ? 'Actualizar' : 'Guardar'}</Button>}
          </CardFooter>
        </Card>
      </form>
    </motion.div>
  );
};

export default ContractForm;