import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';

const affectedDataOptions = [
  "Datos de contacto (nombre, email, teléfono)",
  "Datos de identificación (DNI, pasaporte)",
  "Datos financieros (tarjetas, cuentas bancarias)",
  "Credenciales de acceso (usuarios, contraseñas)",
  "Datos de salud",
  "Datos biométricos",
  "Otros datos sensibles",
];

const BreachForm = ({ breachItem, onSubmit, onCancel, isReadOnly }) => {
  const [formData, setFormData] = useState({
    breach_id: '',
    detection_date: new Date().toISOString().split('T')[0],
    description: '',
    affected_data: [],
    affected_subjects_count: 0,
    impact_assessment: '',
    actions_taken: '',
    notified_aepd: false,
    aepd_notification_date: null,
    notified_subjects: false,
    subjects_notification_date: null,
    status: 'detected',
  });

  useEffect(() => {
    if (breachItem) {
      setFormData({
        ...breachItem,
        detection_date: breachItem.detection_date ? new Date(breachItem.detection_date).toISOString().split('T')[0] : '',
        aepd_notification_date: breachItem.aepd_notification_date ? new Date(breachItem.aepd_notification_date).toISOString().split('T')[0] : null,
        subjects_notification_date: breachItem.subjects_notification_date ? new Date(breachItem.subjects_notification_date).toISOString().split('T')[0] : null,
        affected_data: breachItem.affected_data || [],
      });
    } else {
      setFormData(prev => ({ ...prev, breach_id: `BRCH-${Date.now()}` }));
    }
  }, [breachItem]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAffectedDataChange = (data) => {
    setFormData(prev => {
      const currentData = prev.affected_data || [];
      const newData = currentData.includes(data)
        ? currentData.filter(d => d !== data)
        : [...currentData, data];
      return { ...prev, affected_data: newData };
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <form onSubmit={handleSubmit}>
        <Card className="bg-white/70 backdrop-blur-lg border-white/30">
          <CardHeader>
            <CardTitle>{breachItem ? 'Editar' : 'Añadir'} Brecha de Seguridad</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[60vh] pr-6">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="breach_id">ID de Brecha</Label>
                    <Input id="breach_id" name="breach_id" value={formData.breach_id} onChange={handleChange} required disabled={isReadOnly} />
                  </div>
                  <div>
                    <Label htmlFor="detection_date">Fecha de Detección</Label>
                    <Input id="detection_date" name="detection_date" type="date" value={formData.detection_date} onChange={handleChange} disabled={isReadOnly} />
                  </div>
                </div>
                <div>
                  <Label htmlFor="description">Descripción de la Brecha</Label>
                  <Textarea id="description" name="description" value={formData.description} onChange={handleChange} required disabled={isReadOnly} />
                </div>
                <div>
                  <Label>Datos Afectados</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {affectedDataOptions.map(option => (
                      <Badge
                        key={option}
                        variant={formData.affected_data.includes(option) ? 'default' : 'secondary'}
                        onClick={() => !isReadOnly && handleAffectedDataChange(option)}
                        className="cursor-pointer"
                      >
                        {option}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="affected_subjects_count">Nº de Interesados Afectados</Label>
                    <Input id="affected_subjects_count" name="affected_subjects_count" type="number" value={formData.affected_subjects_count} onChange={handleChange} disabled={isReadOnly} />
                  </div>
                  <div>
                    <Label>Estado</Label>
                    <Select value={formData.status} onValueChange={(v) => handleSelectChange('status', v)} disabled={isReadOnly}>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar estado..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="detected">Detectada</SelectItem>
                        <SelectItem value="in_progress">En Investigación</SelectItem>
                        <SelectItem value="contained">Contenida</SelectItem>
                        <SelectItem value="resolved">Resuelta</SelectItem>
                        <SelectItem value="closed">Cerrada</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="impact_assessment">Evaluación de Impacto</Label>
                  <Textarea id="impact_assessment" name="impact_assessment" value={formData.impact_assessment} onChange={handleChange} disabled={isReadOnly} />
                </div>
                <div>
                  <Label htmlFor="actions_taken">Acciones Tomadas</Label>
                  <Textarea id="actions_taken" name="actions_taken" value={formData.actions_taken} onChange={handleChange} disabled={isReadOnly} />
                </div>
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="notified_aepd" name="notified_aepd" checked={formData.notified_aepd} onCheckedChange={(c) => handleSelectChange('notified_aepd', c)} disabled={isReadOnly} />
                    <Label htmlFor="notified_aepd">Notificado a la AEPD</Label>
                  </div>
                  {formData.notified_aepd && (
                    <div>
                      <Label htmlFor="aepd_notification_date">Fecha de Notificación a AEPD</Label>
                      <Input id="aepd_notification_date" name="aepd_notification_date" type="date" value={formData.aepd_notification_date || ''} onChange={handleChange} disabled={isReadOnly} />
                    </div>
                  )}
                  <div className="flex items-center space-x-2">
                    <Checkbox id="notified_subjects" name="notified_subjects" checked={formData.notified_subjects} onCheckedChange={(c) => handleSelectChange('notified_subjects', c)} disabled={isReadOnly} />
                    <Label htmlFor="notified_subjects">Notificado a los Interesados</Label>
                  </div>
                  {formData.notified_subjects && (
                    <div>
                      <Label htmlFor="subjects_notification_date">Fecha de Notificación a Interesados</Label>
                      <Input id="subjects_notification_date" name="subjects_notification_date" type="date" value={formData.subjects_notification_date || ''} onChange={handleChange} disabled={isReadOnly} />
                    </div>
                  )}
                </div>
              </div>
            </ScrollArea>
          </CardContent>
          <CardFooter className="flex justify-end space-x-2">
            <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
            {!isReadOnly && <Button type="submit">{breachItem ? 'Actualizar' : 'Guardar'}</Button>}
          </CardFooter>
        </Card>
      </form>
    </motion.div>
  );
};

export default BreachForm;