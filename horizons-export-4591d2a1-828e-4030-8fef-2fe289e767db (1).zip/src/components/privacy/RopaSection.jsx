import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle, FileText } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { v4 as uuidv4 } from 'uuid';

import RopaTable from './RopaTable';
import RopaForm from './RopaForm';
import ExportMenu from '@/components/common/ExportMenu';

const ropaExportHeaders = [
    { label: 'Actividad de Tratamiento', key: 'activity_name' },
    { label: 'Departamento', key: 'department' },
    { label: 'Responsable', key: 'data_controller' },
    { label: 'Encargado', key: 'data_processor' },
    { label: 'Finalidades', key: 'purposes' },
    { label: 'Interesados', key: 'data_subjects' },
    { label: 'Categorías de Datos', key: 'data_categories' },
    { label: 'Destinatarios', key: 'data_recipients' },
    { label: 'Transferencias Internacionales', key: 'third_country_transfers' },
    { label: 'Periodo de Retención', key: 'retention_period' },
    { label: 'Medidas de Seguridad', key: 'security_measures' },
];

const RopaSection = ({ ropa, addRopa, updateRopa, deleteRopa, loading, isReadOnly, userId, selectedClientId }) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedRopa, setSelectedRopa] = useState(null);

  const handleAddNew = () => {
    setSelectedRopa(null);
    setIsFormOpen(true);
  };

  const handleEdit = (item) => {
    setSelectedRopa(item);
    setIsFormOpen(true);
  };

  const handleCancel = () => {
    setIsFormOpen(false);
    setSelectedRopa(null);
  };

  const handleDelete = async (id) => {
    const ropaToDelete = ropa.find(r => r.id === id);
    if (ropaToDelete && ropaToDelete.attachment_path) {
      const { error } = await supabase.storage.from('ropa_attachments').remove([ropaToDelete.attachment_path]);
      if (error) {
        toast({ title: 'Error', description: `No se pudo eliminar el adjunto: ${error.message}`, variant: 'destructive' });
      }
    }
    await deleteRopa(id);
  };

  const handleSubmit = async (formData) => {
    try {
        if (selectedRopa) {
            await updateRopa(selectedRopa.id, formData);
        } else {
            await addRopa(formData);
        }
        handleCancel();
    } catch (error) {
        toast({ title: "Error", description: `Error al guardar: ${error.message}`, variant: "destructive" });
    }
  };

  const handleDownloadAttachment = async (item) => {
    toast({ title: '🚧 Funcionalidad no implementada', description: 'La descarga de archivos se implementará próximamente.'});
  };
  
  const preparedRopaData = ropa.map(item => ({
    ...item,
    purposes: item.purposes?.join(', '),
    data_subjects: item.data_subjects?.join(', '),
    data_categories: item.data_categories?.join(', '),
    data_recipients: item.data_recipients?.join(', '),
  }));

  return (
    <div className="space-y-6">
      <AnimatePresence>
        {isFormOpen ? (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <RopaForm
              ropaItem={selectedRopa}
              onSubmit={handleSubmit}
              onCancel={handleCancel}
              isReadOnly={isReadOnly}
            />
          </motion.div>
        ) : (
          <motion.div
            key="table"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
          >
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center space-x-2">
                <FileText className="h-6 w-6 text-gray-700" />
                <h3 className="text-xl font-bold text-gray-800">Inventario ROPA</h3>
              </div>
              <div className="flex items-center space-x-2">
                <ExportMenu 
                  data={preparedRopaData} 
                  headers={ropaExportHeaders} 
                  filenamePrefix="ropa" 
                  reportTitle="Inventario ROPA"
                  disabled={isReadOnly}
                />
                {!isReadOnly && (
                  <Button onClick={handleAddNew}>
                    <PlusCircle className="mr-2 h-4 w-4" /> Añadir Registro
                  </Button>
                )}
              </div>
            </div>
            {loading ? (
              <p>Cargando registros ROPA...</p>
            ) : (
              <RopaTable
                ropaList={ropa}
                onEdit={handleEdit}
                onDelete={handleDelete}
                onDownloadAttachment={handleDownloadAttachment}
                isReadOnly={isReadOnly}
              />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default RopaSection;