import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const InternationalTransferForm = ({ transferItem, onSubmit, onCancel, isReadOnly }) => {
  const [formData, setFormData] = useState({
    transfer_id: '',
    country: '',
    recipient_entity: '',
    purpose: '',
    legal_basis: 'adequacy_decision',
    safeguards_description: '',
    transfer_date: new Date().toISOString().split('T')[0],
  });

  useEffect(() => {
    if (transferItem) {
      setFormData({
        ...transferItem,
        transfer_date: transferItem.transfer_date ? new Date(transferItem.transfer_date).toISOString().split('T')[0] : '',
      });
    } else {
      setFormData(prev => ({ ...prev, transfer_id: `INTL-${Date.now()}` }));
    }
  }, [transferItem]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <form onSubmit={handleSubmit}>
        <Card className="bg-white/70 backdrop-blur-lg border-white/30">
          <CardHeader>
            <CardTitle>{transferItem ? 'Editar' : 'Añadir'} Transferencia Internacional</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[60vh] pr-6">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="transfer_id">ID de Transferencia</Label>
                    <Input id="transfer_id" name="transfer_id" value={formData.transfer_id} onChange={handleChange} required disabled={isReadOnly} />
                  </div>
                  <div>
                    <Label htmlFor="country">País de Destino</Label>
                    <Input id="country" name="country" value={formData.country} onChange={handleChange} required disabled={isReadOnly} />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="recipient_entity">Entidad Receptora</Label>
                    <Input id="recipient_entity" name="recipient_entity" value={formData.recipient_entity} onChange={handleChange} required disabled={isReadOnly} />
                  </div>
                  <div>
                    <Label htmlFor="transfer_date">Fecha de Transferencia</Label>
                    <Input id="transfer_date" name="transfer_date" type="date" value={formData.transfer_date} onChange={handleChange} disabled={isReadOnly} />
                  </div>
                </div>
                <div>
                  <Label htmlFor="purpose">Finalidad de la Transferencia</Label>
                  <Textarea id="purpose" name="purpose" value={formData.purpose} onChange={handleChange} disabled={isReadOnly} />
                </div>
                <div>
                  <Label>Base Jurídica</Label>
                  <Select value={formData.legal_basis} onValueChange={(v) => handleSelectChange('legal_basis', v)} disabled={isReadOnly}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar base jurídica..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="adequacy_decision">Decisión de Adecuación</SelectItem>
                      <SelectItem value="scc">Cláusulas Contractuales Tipo (SCC)</SelectItem>
                      <SelectItem value="bcr">Normas Corporativas Vinculantes (BCR)</SelectItem>
                      <SelectItem value="derogation">Excepciones (Art. 49 GDPR)</SelectItem>
                      <SelectItem value="other">Otra</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="safeguards_description">Descripción de las Garantías</Label>
                  <Textarea id="safeguards_description" name="safeguards_description" value={formData.safeguards_description} onChange={handleChange} disabled={isReadOnly} />
                </div>
              </div>
            </ScrollArea>
          </CardContent>
          <CardFooter className="flex justify-end space-x-2">
            <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
            {!isReadOnly && <Button type="submit">{transferItem ? 'Actualizar' : 'Guardar'}</Button>}
          </CardFooter>
        </Card>
      </form>
    </motion.div>
  );
};

export default InternationalTransferForm;