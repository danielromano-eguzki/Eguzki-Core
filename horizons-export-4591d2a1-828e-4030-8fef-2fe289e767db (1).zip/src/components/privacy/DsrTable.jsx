import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit, Trash2, ChevronDown, ChevronUp, Mail, User, Calendar, Type } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { format, differenceInDays } from 'date-fns';
import { es } from 'date-fns/locale';

const DsrTable = ({ dsrList, onEdit, onDelete, isReadOnly }) => {
  const [expandedRow, setExpandedRow] = useState(null);
  const [itemToDelete, setItemToDelete] = useState(null);

  const toggleRow = (id) => {
    setExpandedRow(expandedRow === id ? null : id);
  };

  const confirmDelete = () => {
    if (itemToDelete) {
      onDelete(itemToDelete.id);
      setItemToDelete(null);
    }
  };

  const statusConfig = {
    received: { label: 'Recibida', color: 'bg-blue-500' },
    in_progress: { label: 'En Proceso', color: 'bg-yellow-500' },
    resolved: { label: 'Resuelta', color: 'bg-green-500' },
    rejected: { label: 'Rechazada', color: 'bg-red-500' },
  };

  const requestTypeConfig = {
    access: 'Acceso',
    rectification: 'Rectificación',
    erasure: 'Supresión',
    restriction: 'Limitación',
    portability: 'Portabilidad',
    objection: 'Oposición',
  };

  const getDaysLeftBadge = (dueDate) => {
    if (!dueDate) return null;
    const days = differenceInDays(new Date(dueDate), new Date());
    if (days < 0) return <Badge variant="destructive">Vencido</Badge>;
    if (days <= 7) return <Badge className="bg-orange-500 text-white">{days} días</Badge>;
    return <Badge variant="secondary">{days} días</Badge>;
  };

  return (
    <>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white/70 backdrop-blur-lg rounded-xl border border-white/20 shadow-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-10"></TableHead>
              <TableHead>ID Solicitud</TableHead>
              <TableHead>Interesado</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead>Vencimiento</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {dsrList.length > 0 ? (
              dsrList.map(item => (
                <React.Fragment key={item.id}>
                  <TableRow className="cursor-pointer" onClick={() => toggleRow(item.id)}>
                    <TableCell>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        {expandedRow === item.id ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{item.request_id}</TableCell>
                    <TableCell className="font-medium">{item.subject_name}</TableCell>
                    <TableCell>{requestTypeConfig[item.request_type] || item.request_type}</TableCell>
                    <TableCell>
                      <Badge className={`${statusConfig[item.status]?.color || 'bg-gray-400'} text-white`}>
                        {statusConfig[item.status]?.label || 'Desconocido'}
                      </Badge>
                    </TableCell>
                    <TableCell>{getDaysLeftBadge(item.due_date)}</TableCell>
                    <TableCell className="text-right">
                      {!isReadOnly && (
                        <>
                          <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); onEdit(item); }}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-600" onClick={(e) => { e.stopPropagation(); setItemToDelete(item); }}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                    </TableCell>
                  </TableRow>
                  {expandedRow === item.id && (
                    <TableRow>
                      <TableCell colSpan={7} className="p-0">
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="bg-gray-50 p-4"
                        >
                          <div className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                                <div className="flex items-center"><User className="h-4 w-4 mr-2 text-gray-500"/><span>{item.subject_name}</span></div>
                                <div className="flex items-center"><Mail className="h-4 w-4 mr-2 text-gray-500"/><span>{item.subject_email}</span></div>
                                <div className="flex items-center"><Type className="h-4 w-4 mr-2 text-gray-500"/><span>{requestTypeConfig[item.request_type]}</span></div>
                                <div className="flex items-center"><Calendar className="h-4 w-4 mr-2 text-gray-500"/>Solicitud: {item.request_date ? format(new Date(item.request_date), 'dd MMM yyyy', { locale: es }) : 'N/A'}</div>
                                <div className="flex items-center"><Calendar className="h-4 w-4 mr-2 text-red-500"/>Vencimiento: {item.due_date ? format(new Date(item.due_date), 'dd MMM yyyy', { locale: es }) : 'N/A'}</div>
                            </div>
                            <div>
                                <h4 className="font-semibold mb-1">Detalles de la Resolución</h4>
                                <p className="text-sm text-gray-600 bg-white p-2 rounded-md">{item.resolution_details || 'No especificados'}</p>
                            </div>
                          </div>
                        </motion.div>
                      </TableCell>
                    </TableRow>
                  )}
                </React.Fragment>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={7} className="h-24 text-center">
                  No hay solicitudes DSR registradas todavía.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </motion.div>

      <AlertDialog open={!!itemToDelete} onOpenChange={() => setItemToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. Esto eliminará permanentemente la solicitud de derechos.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default DsrTable;