import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit, Trash2, Download } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const ContractTable = ({ contractList, onEdit, onDelete, isReadOnly, getFileUrl }) => {
  const [itemToDelete, setItemToDelete] = useState(null);

  const confirmDelete = () => {
    if (itemToDelete) {
      onDelete(itemToDelete.id);
      setItemToDelete(null);
    }
  };

  const handleDownload = async (item) => {
    if (item.attachment_path) {
      const url = await getFileUrl(item.attachment_path);
      if (url) {
        window.open(url, '_blank');
      }
    }
  };

  const roleConfig = {
    processor: { label: 'Encargado', color: 'bg-blue-500' },
    controller: { label: 'Responsable', color: 'bg-purple-500' },
    joint_controller: { label: 'Corresponsable', color: 'bg-indigo-500' },
  };

  return (
    <>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white/70 backdrop-blur-lg rounded-xl border border-white/20 shadow-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID Contrato</TableHead>
              <TableHead>Contraparte</TableHead>
              <TableHead>Rol</TableHead>
              <TableHead>Fecha Contrato</TableHead>
              <TableHead>Próxima Revisión</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {contractList.length > 0 ? (
              contractList.map(item => (
                <TableRow key={item.id}>
                  <TableCell className="font-mono text-xs">{item.contract_id}</TableCell>
                  <TableCell className="font-medium">{item.party_name}</TableCell>
                  <TableCell>
                    <Badge className={`${roleConfig[item.party_role]?.color || 'bg-gray-400'} text-white`}>
                      {roleConfig[item.party_role]?.label || 'Desconocido'}
                    </Badge>
                  </TableCell>
                  <TableCell>{item.contract_date ? format(new Date(item.contract_date), 'dd MMM yyyy', { locale: es }) : 'N/A'}</TableCell>
                  <TableCell>{item.review_date ? format(new Date(item.review_date), 'dd MMM yyyy', { locale: es }) : 'N/A'}</TableCell>
                  <TableCell className="text-right">
                    {item.attachment_path && (
                      <Button variant="ghost" size="icon" onClick={() => handleDownload(item)}>
                        <Download className="h-4 w-4" />
                      </Button>
                    )}
                    {!isReadOnly && (
                      <>
                        <Button variant="ghost" size="icon" onClick={() => onEdit(item)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-600" onClick={() => setItemToDelete(item)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </>
                    )}
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center">
                  No hay contratos registrados todavía.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </motion.div>

      <AlertDialog open={!!itemToDelete} onOpenChange={() => setItemToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. Esto eliminará permanentemente el contrato y su adjunto.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default ContractTable;