import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle, Globe } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import InternationalTransferTable from './InternationalTransferTable';
import InternationalTransferForm from './InternationalTransferForm';
import ExportMenu from '@/components/common/ExportMenu';

const transferExportHeaders = [
    { label: 'ID Transferencia', key: 'transfer_id' },
    { label: 'País Destino', key: 'country' },
    { label: 'Entidad Receptora', key: 'recipient_entity' },
    { label: 'Finalidad', key: 'purpose' },
    { label: 'Base Jurídica', key: 'legal_basis' },
    { label: 'Garantías', key: 'safeguards_description' },
    { label: 'Fecha Transferencia', key: 'transfer_date' },
];

const InternationalTransferSection = ({ transfers, addTransfer, updateTransfer, deleteTransfer, loading, isReadOnly }) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedTransfer, setSelectedTransfer] = useState(null);

  const handleAddNew = () => {
    setSelectedTransfer(null);
    setIsFormOpen(true);
  };

  const handleEdit = (item) => {
    setSelectedTransfer(item);
    setIsFormOpen(true);
  };

  const handleCancel = () => {
    setIsFormOpen(false);
    setSelectedTransfer(null);
  };

  const handleSubmit = async (formData) => {
    try {
      if (selectedTransfer) {
        await updateTransfer(selectedTransfer.id, formData);
      } else {
        await addTransfer(formData);
      }
      handleCancel();
    } catch (error) {
      toast({ title: "Error", description: `Error al guardar la transferencia: ${error.message}`, variant: "destructive" });
    }
  };

  return (
    <div className="space-y-6">
      <AnimatePresence>
        {isFormOpen ? (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <InternationalTransferForm
              transferItem={selectedTransfer}
              onSubmit={handleSubmit}
              onCancel={handleCancel}
              isReadOnly={isReadOnly}
            />
          </motion.div>
        ) : (
          <motion.div
            key="table"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
          >
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center space-x-2">
                <Globe className="h-6 w-6 text-gray-700" />
                <h3 className="text-xl font-bold text-gray-800">Transferencias Internacionales</h3>
              </div>
              <div className="flex items-center space-x-2">
                <ExportMenu 
                  data={transfers} 
                  headers={transferExportHeaders} 
                  filenamePrefix="transferencias_internacionales" 
                  reportTitle="Transferencias Internacionales"
                  disabled={isReadOnly}
                />
                {!isReadOnly && (
                  <Button onClick={handleAddNew}>
                    <PlusCircle className="mr-2 h-4 w-4" /> Añadir Transferencia
                  </Button>
                )}
              </div>
            </div>
            {loading ? (
              <p>Cargando transferencias...</p>
            ) : (
              <InternationalTransferTable
                transferList={transfers}
                onEdit={handleEdit}
                onDelete={deleteTransfer}
                isReadOnly={isReadOnly}
              />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default InternationalTransferSection;