import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Gavel, Cookie, FileText as FileTextIcon } from 'lucide-react';
import PolicyEditor from './PolicyEditor';

const policyTypes = [
  { id: 'privacy', label: 'Política de Privacidad', icon: Gavel },
  { id: 'cookies', label: 'Política de Cookies', icon: Cookie },
  { id: 'terms', label: 'Términos y Condiciones', icon: FileTextIcon },
];

const PolicySection = ({ policies, savePolicy, loading, isReadOnly }) => {
  const [activePolicy, setActivePolicy] = useState('privacy');

  const currentPolicy = (policies && Array.isArray(policies) ? policies.find(p => p.policy_type === activePolicy) : null) || {
    policy_type: activePolicy,
    content: '',
    version: '1.0',
    last_updated: new Date().toISOString(),
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      <div className="md:col-span-1">
        <h3 className="text-xl font-bold text-gray-800 mb-4">Políticas y Textos Legales</h3>
        <div className="space-y-2">
          {policyTypes.map(policy => (
            <Button
              key={policy.id}
              variant={activePolicy === policy.id ? 'default' : 'ghost'}
              className="w-full justify-start"
              onClick={() => setActivePolicy(policy.id)}
            >
              <policy.icon className="mr-2 h-4 w-4" />
              {policy.label}
            </Button>
          ))}
        </div>
      </div>
      <div className="md:col-span-3">
        <motion.div
          key={activePolicy}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <PolicyEditor
            policy={currentPolicy}
            onSave={savePolicy}
            loading={loading}
            isReadOnly={isReadOnly}
            policyTypeLabel={policyTypes.find(p => p.id === activePolicy)?.label || ''}
          />
        </motion.div>
      </div>
    </div>
  );
};

export default PolicySection;