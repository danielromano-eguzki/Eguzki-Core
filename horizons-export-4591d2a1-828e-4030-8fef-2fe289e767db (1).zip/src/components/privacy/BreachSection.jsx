import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle, ShieldAlert } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

import BreachTable from './BreachTable';
import BreachForm from './BreachForm';
import ExportMenu from '@/components/common/ExportMenu';

const breachExportHeaders = [
    { label: 'ID Brecha', key: 'breach_id' },
    { label: 'Fecha Detección', key: 'detection_date' },
    { label: 'Descripción', key: 'description' },
    { label: 'Datos Afectados', key: 'affected_data' },
    { label: 'Nº Interesados Afectados', key: 'affected_subjects_count' },
    { label: 'Impacto', key: 'impact_assessment' },
    { label: 'Acciones Tomadas', key: 'actions_taken' },
    { label: 'Notificado AEPD', key: 'notified_aepd' },
    { label: 'Fecha Notif. AEPD', key: 'aepd_notification_date' },
    { label: 'Notificado Interesados', key: 'notified_subjects' },
    { label: 'Fecha Notif. Interesados', key: 'subjects_notification_date' },
    { label: 'Estado', key: 'status' },
];

const BreachSection = ({ breaches, addBreach, updateBreach, deleteBreach, loading, isReadOnly }) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedBreach, setSelectedBreach] = useState(null);

  const handleAddNew = () => {
    setSelectedBreach(null);
    setIsFormOpen(true);
  };

  const handleEdit = (item) => {
    setSelectedBreach(item);
    setIsFormOpen(true);
  };

  const handleCancel = () => {
    setIsFormOpen(false);
    setSelectedBreach(null);
  };

  const handleSubmit = async (formData) => {
    try {
      if (selectedBreach) {
        await updateBreach(selectedBreach.id, formData);
      } else {
        await addBreach(formData);
      }
      handleCancel();
    } catch (error) {
      toast({ title: "Error", description: `Error al guardar la brecha: ${error.message}`, variant: "destructive" });
    }
  };

  const preparedBreachData = breaches.map(item => ({
    ...item,
    affected_data: item.affected_data?.join(', '),
  }));

  return (
    <div className="space-y-6">
      <AnimatePresence>
        {isFormOpen ? (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <BreachForm
              breachItem={selectedBreach}
              onSubmit={handleSubmit}
              onCancel={handleCancel}
              isReadOnly={isReadOnly}
            />
          </motion.div>
        ) : (
          <motion.div
            key="table"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
          >
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center space-x-2">
                <ShieldAlert className="h-6 w-6 text-gray-700" />
                <h3 className="text-xl font-bold text-gray-800">Notificación de Brechas de Seguridad</h3>
              </div>
              <div className="flex items-center space-x-2">
                <ExportMenu 
                  data={preparedBreachData} 
                  headers={breachExportHeaders} 
                  filenamePrefix="brechas" 
                  reportTitle="Brechas de Seguridad"
                  disabled={isReadOnly}
                />
                {!isReadOnly && (
                  <Button onClick={handleAddNew}>
                    <PlusCircle className="mr-2 h-4 w-4" /> Añadir Brecha
                  </Button>
                )}
              </div>
            </div>
            {loading ? (
              <p>Cargando brechas de seguridad...</p>
            ) : (
              <BreachTable
                breachList={breaches}
                onEdit={handleEdit}
                onDelete={deleteBreach}
                isReadOnly={isReadOnly}
              />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default BreachSection;