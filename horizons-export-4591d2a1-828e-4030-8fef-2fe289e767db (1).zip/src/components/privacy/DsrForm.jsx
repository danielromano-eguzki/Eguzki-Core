import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const DsrForm = ({ dsrItem, onSubmit, onCancel, isReadOnly }) => {
  const [formData, setFormData] = useState({
    request_id: '',
    subject_name: '',
    subject_email: '',
    request_type: 'access',
    request_date: new Date().toISOString().split('T')[0],
    due_date: '',
    status: 'received',
    resolution_details: '',
  });

  useEffect(() => {
    if (dsrItem) {
      setFormData({
        ...dsrItem,
        request_date: dsrItem.request_date ? new Date(dsrItem.request_date).toISOString().split('T')[0] : '',
        due_date: dsrItem.due_date ? new Date(dsrItem.due_date).toISOString().split('T')[0] : '',
      });
    } else {
      const today = new Date();
      const dueDate = new Date(today);
      dueDate.setMonth(today.getMonth() + 1);
      
      setFormData({
        request_id: `DSR-${Date.now()}`,
        subject_name: '',
        subject_email: '',
        request_type: 'access',
        request_date: today.toISOString().split('T')[0],
        due_date: dueDate.toISOString().split('T')[0],
        status: 'received',
        resolution_details: '',
      });
    }
  }, [dsrItem]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <form onSubmit={handleSubmit}>
        <Card className="bg-white/70 backdrop-blur-lg border-white/30">
          <CardHeader>
            <CardTitle>{dsrItem ? 'Editar' : 'Añadir'} Solicitud de Derechos (DSR)</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[60vh] pr-6">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="request_id">ID de Solicitud</Label>
                    <Input id="request_id" name="request_id" value={formData.request_id} onChange={handleChange} required disabled={isReadOnly} />
                  </div>
                  <div>
                    <Label>Tipo de Solicitud</Label>
                    <Select value={formData.request_type} onValueChange={(v) => handleSelectChange('request_type', v)} disabled={isReadOnly}>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar tipo..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="access">Acceso</SelectItem>
                        <SelectItem value="rectification">Rectificación</SelectItem>
                        <SelectItem value="erasure">Supresión (Olvido)</SelectItem>
                        <SelectItem value="restriction">Limitación</SelectItem>
                        <SelectItem value="portability">Portabilidad</SelectItem>
                        <SelectItem value="objection">Oposición</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="subject_name">Nombre del Interesado</Label>
                    <Input id="subject_name" name="subject_name" value={formData.subject_name} onChange={handleChange} required disabled={isReadOnly} />
                  </div>
                  <div>
                    <Label htmlFor="subject_email">Email del Interesado</Label>
                    <Input id="subject_email" name="subject_email" type="email" value={formData.subject_email} onChange={handleChange} required disabled={isReadOnly} />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="request_date">Fecha de Solicitud</Label>
                    <Input id="request_date" name="request_date" type="date" value={formData.request_date} onChange={handleChange} disabled={isReadOnly} />
                  </div>
                  <div>
                    <Label htmlFor="due_date">Fecha de Vencimiento</Label>
                    <Input id="due_date" name="due_date" type="date" value={formData.due_date} onChange={handleChange} disabled={isReadOnly} />
                  </div>
                </div>
                <div>
                  <Label>Estado</Label>
                  <Select value={formData.status} onValueChange={(v) => handleSelectChange('status', v)} disabled={isReadOnly}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar estado..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="received">Recibida</SelectItem>
                      <SelectItem value="in_progress">En Proceso</SelectItem>
                      <SelectItem value="resolved">Resuelta</SelectItem>
                      <SelectItem value="rejected">Rechazada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="resolution_details">Detalles de la Resolución</Label>
                  <Textarea id="resolution_details" name="resolution_details" value={formData.resolution_details} onChange={handleChange} disabled={isReadOnly} />
                </div>
              </div>
            </ScrollArea>
          </CardContent>
          <CardFooter className="flex justify-end space-x-2">
            <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
            {!isReadOnly && <Button type="submit">{dsrItem ? 'Actualizar' : 'Guardar'}</Button>}
          </CardFooter>
        </Card>
      </form>
    </motion.div>
  );
};

export default DsrForm;