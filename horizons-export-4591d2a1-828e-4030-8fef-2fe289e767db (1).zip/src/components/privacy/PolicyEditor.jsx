import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const PolicyEditor = ({ policy, onSave, loading, isReadOnly, policyTypeLabel }) => {
  const [content, setContent] = useState('');
  const [version, setVersion] = useState('');

  useEffect(() => {
    setContent(policy.content || '');
    setVersion(policy.version || '1.0');
  }, [policy]);

  const handleSave = () => {
    if (!content.trim()) {
      toast({
        title: "Contenido vacío",
        description: "La política no puede estar vacía.",
        variant: "destructive",
      });
      return;
    }
    onSave({
      ...policy,
      content,
      version,
    });
  };

  return (
    <Card className="bg-white/70 backdrop-blur-lg border-white/30">
      <CardHeader>
        <CardTitle>{policyTypeLabel}</CardTitle>
        <CardDescription>
          Última actualización: {policy.last_updated ? format(new Date(policy.last_updated), 'dd MMMM yyyy', { locale: es }) : 'Nunca'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="policy-content">Contenido de la Política</Label>
          <Textarea
            id="policy-content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={`Escribe aquí el contenido de la ${policyTypeLabel}...`}
            className="h-96"
            disabled={isReadOnly}
          />
        </div>
        <div>
          <Label htmlFor="policy-version">Versión</Label>
          <Input
            id="policy-version"
            value={version}
            onChange={(e) => setVersion(e.target.value)}
            className="w-40"
            disabled={isReadOnly}
          />
        </div>
      </CardContent>
      <CardFooter className="flex justify-end">
        {!isReadOnly && (
          <Button onClick={handleSave} disabled={loading}>
            {loading ? 'Guardando...' : 'Guardar Cambios'}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default PolicyEditor;