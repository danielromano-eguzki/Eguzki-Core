import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, Plus, Trash2 } from 'lucide-react';

const PiaForm = ({ piaItem, onSubmit, onCancel, isReadOnly }) => {
  const [formData, setFormData] = useState({
    project_name: '',
    project_description: '',
    status: 'pending',
    assessment_date: new Date().toISOString().split('T')[0],
    dpo_opinion: '',
    risks_identified: [],
    mitigation_measures: [],
  });

  const [newRisk, setNewRisk] = useState('');
  const [newMeasure, setNewMeasure] = useState('');

  useEffect(() => {
    if (piaItem) {
      setFormData({
        ...piaItem,
        assessment_date: piaItem.assessment_date ? new Date(piaItem.assessment_date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
        risks_identified: piaItem.risks_identified || [],
        mitigation_measures: piaItem.mitigation_measures || [],
      });
    } else {
      setFormData({
        project_name: '',
        project_description: '',
        status: 'pending',
        assessment_date: new Date().toISOString().split('T')[0],
        dpo_opinion: '',
        risks_identified: [],
        mitigation_measures: [],
      });
    }
  }, [piaItem]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleStatusChange = (value) => {
    setFormData(prev => ({ ...prev, status: value }));
  };

  const handleAddItem = (field, value, setter) => {
    if (value.trim()) {
      setFormData(prev => ({
        ...prev,
        [field]: [...prev[field], value.trim()],
      }));
      setter('');
    }
  };

  const handleRemoveItem = (field, index) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index),
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const renderListInput = (label, field, value, setter, placeholder) => (
    <div className="space-y-2">
      <Label>{label}</Label>
      <div className="flex space-x-2">
        <Input
          value={value}
          onChange={(e) => setter(e.target.value)}
          placeholder={placeholder}
          className="flex-grow"
          disabled={isReadOnly}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              handleAddItem(field, value, setter);
            }
          }}
        />
        <Button type="button" size="icon" onClick={() => handleAddItem(field, value, setter)} disabled={isReadOnly} variant="outline">
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <div className="space-y-2">
        {formData[field]?.map((item, index) => (
          <div key={index} className="flex items-center justify-between bg-gray-100 rounded-md p-2 text-sm">
            <span className="flex-grow">{item}</span>
            {!isReadOnly && (
              <Button type="button" variant="ghost" size="icon" onClick={() => handleRemoveItem(field, index)} className="text-red-500 hover:text-red-600 h-6 w-6">
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <form onSubmit={handleSubmit}>
        <Card className="bg-white/70 backdrop-blur-lg border-white/30">
          <CardHeader>
            <CardTitle>{piaItem ? 'Editar' : 'Añadir'} Evaluación de Impacto (PIA)</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[60vh] pr-6">
              <div className="space-y-6">
                <div>
                  <Label htmlFor="project_name">Nombre del Proyecto/Tratamiento</Label>
                  <Input id="project_name" name="project_name" value={formData.project_name} onChange={handleChange} required disabled={isReadOnly} />
                </div>
                <div>
                  <Label htmlFor="project_description">Descripción del Proyecto</Label>
                  <Textarea id="project_description" name="project_description" value={formData.project_description} onChange={handleChange} disabled={isReadOnly} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="assessment_date">Fecha de Evaluación</Label>
                    <Input id="assessment_date" name="assessment_date" type="date" value={formData.assessment_date} onChange={handleChange} disabled={isReadOnly} />
                  </div>
                  <div>
                    <Label>Estado</Label>
                    <Select value={formData.status} onValueChange={handleStatusChange} disabled={isReadOnly}>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar estado..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pendiente</SelectItem>
                        <SelectItem value="in_progress">En Progreso</SelectItem>
                        <SelectItem value="completed">Completada</SelectItem>
                        <SelectItem value="requires_review">Requiere Revisión</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="dpo_opinion">Opinión del DPO</Label>
                  <Textarea id="dpo_opinion" name="dpo_opinion" value={formData.dpo_opinion} onChange={handleChange} disabled={isReadOnly} />
                </div>
                {renderListInput('Riesgos Identificados', 'risks_identified', newRisk, setNewRisk, 'Añadir riesgo...')}
                {renderListInput('Medidas de Mitigación', 'mitigation_measures', newMeasure, setNewMeasure, 'Añadir medida...')}
              </div>
            </ScrollArea>
          </CardContent>
          <CardFooter className="flex justify-end space-x-2">
            <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
            {!isReadOnly && <Button type="submit">{piaItem ? 'Actualizar' : 'Guardar'}</Button>}
          </CardFooter>
        </Card>
      </form>
    </motion.div>
  );
};

export default PiaForm;