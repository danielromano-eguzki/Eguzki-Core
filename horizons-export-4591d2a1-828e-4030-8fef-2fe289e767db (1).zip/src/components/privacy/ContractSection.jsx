import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle, FileSignature } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import ContractTable from './ContractTable';
import ContractForm from './ContractForm';
import ExportMenu from '@/components/common/ExportMenu';

const contractExportHeaders = [
    { label: 'ID Contrato', key: 'contract_id' },
    { label: 'Contraparte', key: 'party_name' },
    { label: 'Rol Contraparte', key: 'party_role' },
    { label: 'Fecha Contrato', key: 'contract_date' },
    { label: 'Fecha Revisión', key: 'review_date' },
    { label: 'Descripción', key: 'description' },
];

const ContractSection = ({ contracts, addContract, updateContract, deleteContract, loading, isReadOnly, supabase }) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedContract, setSelectedContract] = useState(null);

  const handleAddNew = () => {
    setSelectedContract(null);
    setIsFormOpen(true);
  };

  const handleEdit = (item) => {
    setSelectedContract(item);
    setIsFormOpen(true);
  };

  const handleCancel = () => {
    setIsFormOpen(false);
    setSelectedContract(null);
  };

  const handleSubmit = async (formData, attachment) => {
    try {
      if (selectedContract) {
        await updateContract(selectedContract.id, formData, attachment);
      } else {
        await addContract(formData, attachment);
      }
      handleCancel();
    } catch (error) {
      toast({ title: "Error", description: `Error al guardar el contrato: ${error.message}`, variant: "destructive" });
    }
  };

  const getFileUrl = async (path) => {
    const { data, error } = await supabase.storage.from('contract_attachments').createSignedUrl(path, 3600);
    if (error) {
      toast({ title: "Error", description: "No se pudo obtener la URL del archivo.", variant: "destructive" });
      return null;
    }
    return data.signedUrl;
  };

  return (
    <div className="space-y-6">
      <AnimatePresence>
        {isFormOpen ? (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <ContractForm
              contractItem={selectedContract}
              onSubmit={handleSubmit}
              onCancel={handleCancel}
              isReadOnly={isReadOnly}
            />
          </motion.div>
        ) : (
          <motion.div
            key="table"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
          >
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center space-x-2">
                <FileSignature className="h-6 w-6 text-gray-700" />
                <h3 className="text-xl font-bold text-gray-800">Contratos de Tratamiento</h3>
              </div>
              <div className="flex items-center space-x-2">
                 <ExportMenu 
                  data={contracts} 
                  headers={contractExportHeaders} 
                  filenamePrefix="contratos" 
                  reportTitle="Contratos de Tratamiento"
                  disabled={isReadOnly}
                />
                {!isReadOnly && (
                  <Button onClick={handleAddNew}>
                    <PlusCircle className="mr-2 h-4 w-4" /> Añadir Contrato
                  </Button>
                )}
              </div>
            </div>
            {loading ? (
              <p>Cargando contratos...</p>
            ) : (
              <ContractTable
                contractList={contracts}
                onEdit={handleEdit}
                onDelete={deleteContract}
                isReadOnly={isReadOnly}
                getFileUrl={getFileUrl}
              />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ContractSection;