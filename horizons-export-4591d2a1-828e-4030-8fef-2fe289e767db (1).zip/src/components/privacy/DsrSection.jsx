import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle, UserCheck } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

import DsrTable from './DsrTable';
import DsrForm from './DsrForm';
import ExportMenu from '@/components/common/ExportMenu';

const dsrExportHeaders = [
    { label: 'ID Solicitud', key: 'request_id' },
    { label: 'Nombre Interesado', key: 'subject_name' },
    { label: 'Email Interesado', key: 'subject_email' },
    { label: 'Tipo de Solicitud', key: 'request_type' },
    { label: 'Fecha Solicitud', key: 'request_date' },
    { label: 'Fecha Vencimiento', key: 'due_date' },
    { label: 'Estado', key: 'status' },
    { label: 'Detalles Resolución', key: 'resolution_details' },
];

const DsrSection = ({ dsr, addDsr, updateDsr, deleteDsr, loading, isReadOnly }) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedDsr, setSelectedDsr] = useState(null);

  const handleAddNew = () => {
    setSelectedDsr(null);
    setIsFormOpen(true);
  };

  const handleEdit = (item) => {
    setSelectedDsr(item);
    setIsFormOpen(true);
  };

  const handleCancel = () => {
    setIsFormOpen(false);
    setSelectedDsr(null);
  };

  const handleSubmit = async (formData) => {
    try {
      if (selectedDsr) {
        await updateDsr(selectedDsr.id, formData);
      } else {
        await addDsr(formData);
      }
      handleCancel();
    } catch (error) {
      toast({ title: "Error", description: `Error al guardar la solicitud DSR: ${error.message}`, variant: "destructive" });
    }
  };

  return (
    <div className="space-y-6">
      <AnimatePresence>
        {isFormOpen ? (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <DsrForm
              dsrItem={selectedDsr}
              onSubmit={handleSubmit}
              onCancel={handleCancel}
              isReadOnly={isReadOnly}
            />
          </motion.div>
        ) : (
          <motion.div
            key="table"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
          >
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center space-x-2">
                <UserCheck className="h-6 w-6 text-gray-700" />
                <h3 className="text-xl font-bold text-gray-800">Solicitudes de Derechos (DSR)</h3>
              </div>
              <div className="flex items-center space-x-2">
                <ExportMenu 
                  data={dsr} 
                  headers={dsrExportHeaders} 
                  filenamePrefix="dsr" 
                  reportTitle="Solicitudes de Derechos (DSR)"
                  disabled={isReadOnly}
                />
                {!isReadOnly && (
                  <Button onClick={handleAddNew}>
                    <PlusCircle className="mr-2 h-4 w-4" /> Añadir Solicitud
                  </Button>
                )}
              </div>
            </div>
            {loading ? (
              <p>Cargando solicitudes DSR...</p>
            ) : (
              <DsrTable
                dsrList={dsr}
                onEdit={handleEdit}
                onDelete={deleteDsr}
                isReadOnly={isReadOnly}
              />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default DsrSection;