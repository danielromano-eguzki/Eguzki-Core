import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { X, Tag, Plus, Trash2 } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const RopaForm = ({ ropaItem, onSubmit, onCancel, isReadOnly }) => {
  const [formData, setFormData] = useState({
    activity_name: '',
    department: '',
    data_controller: '',
    data_processor: '',
    purposes: [],
    data_subjects: [],
    data_categories: [],
    data_recipients: [],
    third_country_transfers: '',
    retention_period: '',
    security_measures: '',
    attachment_name: '',
    attachment_path: '',
  });

  const [tagInputs, setTagInputs] = useState({
    purposes: '',
    data_subjects: '',
    data_categories: '',
    data_recipients: '',
  });

  useEffect(() => {
    if (ropaItem) {
      setFormData({
        ...ropaItem,
        purposes: ropaItem.purposes || [],
        data_subjects: ropaItem.data_subjects || [],
        data_categories: ropaItem.data_categories || [],
        data_recipients: ropaItem.data_recipients || [],
      });
    } else {
      setFormData({
        activity_name: '',
        department: '',
        data_controller: '',
        data_processor: '',
        purposes: [],
        data_subjects: [],
        data_categories: [],
        data_recipients: [],
        third_country_transfers: '',
        retention_period: '',
        security_measures: '',
        attachment_name: '',
        attachment_path: '',
      });
    }
  }, [ropaItem]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleTagInputChange = (e) => {
    const { name, value } = e.target;
    setTagInputs(prev => ({ ...prev, [name]: value }));
  };

  const handleAddTag = (field) => {
    const value = tagInputs[field].trim();
    if (value && !formData[field].includes(value)) {
      setFormData(prev => ({ ...prev, [field]: [...prev[field], value] }));
      setTagInputs(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleRemoveTag = (field, tag) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].filter(t => t !== tag),
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };
  
  const renderTagInput = (field, placeholder) => (
    <div className="space-y-2">
      <div className="flex space-x-2">
        <Input
          name={field}
          value={tagInputs[field]}
          onChange={handleTagInputChange}
          placeholder={placeholder}
          className="flex-grow"
          disabled={isReadOnly}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              handleAddTag(field);
            }
          }}
        />
        <Button type="button" size="icon" onClick={() => handleAddTag(field)} disabled={isReadOnly} variant="outline">
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <div className="flex flex-wrap gap-2">
        {formData[field]?.map(tag => (
          <div key={tag} className="flex items-center bg-gray-100 rounded-full px-3 py-1 text-sm">
            <Tag className="h-3 w-3 mr-2 text-gray-500" />
            <span>{tag}</span>
            {!isReadOnly && (
              <button type="button" onClick={() => handleRemoveTag(field, tag)} className="ml-2 text-gray-500 hover:text-red-500">
                <X className="h-3 w-3" />
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <form onSubmit={handleSubmit}>
        <Card className="bg-white/70 backdrop-blur-lg border-white/30">
          <CardHeader>
            <CardTitle>{ropaItem ? 'Editar' : 'Añadir'} Registro ROPA</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[60vh] pr-6">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="activity_name">Actividad de Tratamiento</Label>
                    <Input id="activity_name" name="activity_name" value={formData.activity_name} onChange={handleChange} required disabled={isReadOnly} />
                  </div>
                  <div>
                    <Label htmlFor="department">Departamento</Label>
                    <Input id="department" name="department" value={formData.department} onChange={handleChange} disabled={isReadOnly} />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="data_controller">Responsable del Tratamiento</Label>
                    <Input id="data_controller" name="data_controller" value={formData.data_controller} onChange={handleChange} disabled={isReadOnly} />
                  </div>
                  <div>
                    <Label htmlFor="data_processor">Encargado del Tratamiento</Label>
                    <Input id="data_processor" name="data_processor" value={formData.data_processor} onChange={handleChange} disabled={isReadOnly} />
                  </div>
                </div>
                <div>
                  <Label>Finalidades del Tratamiento</Label>
                  {renderTagInput('purposes', 'Añadir finalidad...')}
                </div>
                <div>
                  <Label>Categorías de Interesados</Label>
                  {renderTagInput('data_subjects', 'Añadir categoría de interesado...')}
                </div>
                <div>
                  <Label>Categorías de Datos Personales</Label>
                  {renderTagInput('data_categories', 'Añadir categoría de datos...')}
                </div>
                <div>
                  <Label>Destinatarios o Categorías de Destinatarios</Label>
                  {renderTagInput('data_recipients', 'Añadir destinatario...')}
                </div>
                <div>
                  <Label htmlFor="third_country_transfers">Transferencias a Terceros Países</Label>
                  <Textarea id="third_country_transfers" name="third_country_transfers" value={formData.third_country_transfers} onChange={handleChange} disabled={isReadOnly} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="retention_period">Plazo de Conservación</Label>
                    <Input id="retention_period" name="retention_period" value={formData.retention_period} onChange={handleChange} disabled={isReadOnly} />
                  </div>
                  <div>
                    <Label htmlFor="attachment">Adjunto</Label>
                    <Input id="attachment" type="file" disabled={isReadOnly} onChange={() => toast({ title: '🚧 Funcionalidad no implementada', description: 'La subida de archivos se implementará próximamente.'})} />
                  </div>
                </div>
                <div>
                  <Label htmlFor="security_measures">Medidas de Seguridad</Label>
                  <Textarea id="security_measures" name="security_measures" value={formData.security_measures} onChange={handleChange} disabled={isReadOnly} />
                </div>
              </div>
            </ScrollArea>
          </CardContent>
          <CardFooter className="flex justify-end space-x-2">
            <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>
            {!isReadOnly && <Button type="submit">{ropaItem ? 'Actualizar' : 'Guardar'}</Button>}
          </CardFooter>
        </Card>
      </form>
    </motion.div>
  );
};

export default RopaForm;