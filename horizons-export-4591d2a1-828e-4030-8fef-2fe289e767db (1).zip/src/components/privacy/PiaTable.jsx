import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit, Trash2, ChevronDown, ChevronUp, AlertTriangle, ShieldCheck } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const PiaTable = ({ piaList, onEdit, onDelete, isReadOnly }) => {
  const [expandedRow, setExpandedRow] = useState(null);
  const [itemToDelete, setItemToDelete] = useState(null);

  const toggleRow = (id) => {
    setExpandedRow(expandedRow === id ? null : id);
  };

  const confirmDelete = () => {
    if (itemToDelete) {
      onDelete(itemToDelete.id);
      setItemToDelete(null);
    }
  };

  const statusConfig = {
    pending: { label: 'Pendiente', color: 'bg-yellow-500' },
    in_progress: { label: 'En Progreso', color: 'bg-blue-500' },
    completed: { label: 'Completada', color: 'bg-green-500' },
    requires_review: { label: 'Requiere Revisión', color: 'bg-orange-500' },
  };

  return (
    <>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white/70 backdrop-blur-lg rounded-xl border border-white/20 shadow-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-10"></TableHead>
              <TableHead>Proyecto</TableHead>
              <TableHead>Fecha Evaluación</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {piaList.length > 0 ? (
              piaList.map(item => (
                <React.Fragment key={item.id}>
                  <TableRow className="cursor-pointer" onClick={() => toggleRow(item.id)}>
                    <TableCell>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        {expandedRow === item.id ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </TableCell>
                    <TableCell className="font-medium">{item.project_name}</TableCell>
                    <TableCell>{item.assessment_date ? format(new Date(item.assessment_date), 'dd MMM yyyy', { locale: es }) : 'N/A'}</TableCell>
                    <TableCell>
                      <Badge className={`${statusConfig[item.status]?.color || 'bg-gray-400'} text-white`}>
                        {statusConfig[item.status]?.label || 'Desconocido'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      {!isReadOnly && (
                        <>
                          <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); onEdit(item); }}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-600" onClick={(e) => { e.stopPropagation(); setItemToDelete(item); }}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                    </TableCell>
                  </TableRow>
                  {expandedRow === item.id && (
                    <TableRow>
                      <TableCell colSpan={5} className="p-0">
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="bg-gray-50 p-4"
                        >
                          <div className="space-y-4">
                            <div>
                                <h4 className="font-semibold mb-1">Descripción del Proyecto</h4>
                                <p className="text-sm text-gray-600">{item.project_description || 'No especificada'}</p>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <h4 className="font-semibold mb-2 flex items-center"><AlertTriangle className="h-4 w-4 mr-2 text-red-500"/>Riesgos Identificados</h4>
                                    <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                                        {item.risks_identified?.length > 0 ? item.risks_identified.map((risk, i) => <li key={i}>{risk}</li>) : <li>No hay riesgos identificados.</li>}
                                    </ul>
                                </div>
                                <div>
                                    <h4 className="font-semibold mb-2 flex items-center"><ShieldCheck className="h-4 w-4 mr-2 text-green-500"/>Medidas de Mitigación</h4>
                                    <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                                        {item.mitigation_measures?.length > 0 ? item.mitigation_measures.map((measure, i) => <li key={i}>{measure}</li>) : <li>No hay medidas de mitigación.</li>}
                                    </ul>
                                </div>
                            </div>
                            <div>
                                <h4 className="font-semibold mb-1">Opinión del DPO</h4>
                                <p className="text-sm text-gray-600">{item.dpo_opinion || 'No especificada'}</p>
                            </div>
                          </div>
                        </motion.div>
                      </TableCell>
                    </TableRow>
                  )}
                </React.Fragment>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center">
                  No hay PIAs registradas todavía.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </motion.div>

      <AlertDialog open={!!itemToDelete} onOpenChange={() => setItemToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. Esto eliminará permanentemente la evaluación de impacto.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default PiaTable;