import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit, Trash2, FileDown, ChevronDown, ChevronUp } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

const RopaTable = ({ ropaList, onEdit, onDelete, onDownloadAttachment, isReadOnly }) => {
  const [expandedRow, setExpandedRow] = useState(null);
  const [itemToDelete, setItemToDelete] = useState(null);

  const toggleRow = (id) => {
    setExpandedRow(expandedRow === id ? null : id);
  };
  
  const confirmDelete = () => {
    if (itemToDelete) {
      onDelete(itemToDelete.id);
      setItemToDelete(null);
    }
  };

  return (
    <>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white/70 backdrop-blur-lg rounded-xl border border-white/20 shadow-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-10"></TableHead>
              <TableHead>Actividad de Tratamiento</TableHead>
              <TableHead>Departamento</TableHead>
              <TableHead>Responsable</TableHead>
              <TableHead>Encargado</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {ropaList.length > 0 ? (
              ropaList.map(item => (
                <React.Fragment key={item.id}>
                  <TableRow className="cursor-pointer" onClick={() => toggleRow(item.id)}>
                    <TableCell>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        {expandedRow === item.id ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </TableCell>
                    <TableCell className="font-medium">{item.activity_name}</TableCell>
                    <TableCell>{item.department}</TableCell>
                    <TableCell>{item.data_controller}</TableCell>
                    <TableCell>{item.data_processor}</TableCell>
                    <TableCell className="text-right">
                      {!isReadOnly && (
                        <>
                          <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); onEdit(item); }}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-600" onClick={(e) => { e.stopPropagation(); setItemToDelete(item); }}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                      {item.attachment_path && (
                        <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); onDownloadAttachment(item); }}>
                          <FileDown className="h-4 w-4" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                  {expandedRow === item.id && (
                    <TableRow>
                      <TableCell colSpan={6} className="p-0">
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="bg-gray-50 p-4"
                        >
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <h4 className="font-semibold mb-2">Finalidades</h4>
                              <div className="flex flex-wrap gap-2">
                                {item.purposes?.map(p => <Badge key={p} variant="secondary">{p}</Badge>)}
                              </div>
                            </div>
                            <div>
                              <h4 className="font-semibold mb-2">Interesados</h4>
                              <div className="flex flex-wrap gap-2">
                                {item.data_subjects?.map(s => <Badge key={s} variant="secondary">{s}</Badge>)}
                              </div>
                            </div>
                            <div>
                              <h4 className="font-semibold mb-2">Categorías de Datos</h4>
                              <div className="flex flex-wrap gap-2">
                                {item.data_categories?.map(c => <Badge key={c} variant="secondary">{c}</Badge>)}
                              </div>
                            </div>
                            <div>
                              <h4 className="font-semibold mb-2">Destinatarios</h4>
                              <div className="flex flex-wrap gap-2">
                                {item.data_recipients?.map(r => <Badge key={r} variant="secondary">{r}</Badge>)}
                              </div>
                            </div>
                            <div className="col-span-1 md:col-span-2">
                                <h4 className="font-semibold mb-1">Medidas de Seguridad</h4>
                                <p className="text-sm text-gray-600">{item.security_measures}</p>
                            </div>
                          </div>
                        </motion.div>
                      </TableCell>
                    </TableRow>
                  )}
                </React.Fragment>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center">
                  No hay registros ROPA todavía.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </motion.div>

      <AlertDialog open={!!itemToDelete} onOpenChange={() => setItemToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. Esto eliminará permanentemente el registro ROPA y cualquier adjunto asociado.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default RopaTable;