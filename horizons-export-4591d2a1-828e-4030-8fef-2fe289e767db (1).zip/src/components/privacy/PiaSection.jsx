import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PlusCircle, ClipboardList } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

import PiaTable from './PiaTable';
import PiaForm from './PiaForm';
import ExportMenu from '@/components/common/ExportMenu';

const piaExportHeaders = [
    { label: 'Proyecto', key: 'project_name' },
    { label: 'Descripción', key: 'project_description' },
    { label: 'Estado', key: 'status' },
    { label: 'Fecha de Evaluación', key: 'assessment_date' },
    { label: 'Opinión del DPO', key: 'dpo_opinion' },
    { label: 'Riesgos Identificados', key: 'risks_identified' },
    { label: 'Medidas de Mitigación', key: 'mitigation_measures' },
];

const PiaSection = ({ pia, addPia, updatePia, deletePia, loading, isReadOnly }) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedPia, setSelectedPia] = useState(null);

  const handleAddNew = () => {
    setSelectedPia(null);
    setIsFormOpen(true);
  };

  const handleEdit = (item) => {
    setSelectedPia(item);
    setIsFormOpen(true);
  };

  const handleCancel = () => {
    setIsFormOpen(false);
    setSelectedPia(null);
  };

  const handleSubmit = async (formData) => {
    try {
      if (selectedPia) {
        await updatePia(selectedPia.id, formData);
      } else {
        await addPia(formData);
      }
      handleCancel();
    } catch (error) {
      toast({ title: "Error", description: `Error al guardar la PIA: ${error.message}`, variant: "destructive" });
    }
  };
  
  const preparedPiaData = pia.map(item => ({
    ...item,
    risks_identified: item.risks_identified?.join(', '),
    mitigation_measures: item.mitigation_measures?.join(', '),
  }));

  return (
    <div className="space-y-6">
      <AnimatePresence>
        {isFormOpen ? (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <PiaForm
              piaItem={selectedPia}
              onSubmit={handleSubmit}
              onCancel={handleCancel}
              isReadOnly={isReadOnly}
            />
          </motion.div>
        ) : (
          <motion.div
            key="table"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
          >
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center space-x-2">
                <ClipboardList className="h-6 w-6 text-gray-700" />
                <h3 className="text-xl font-bold text-gray-800">Evaluaciones de Impacto (PIA)</h3>
              </div>
              <div className="flex items-center space-x-2">
                <ExportMenu 
                  data={preparedPiaData} 
                  headers={piaExportHeaders} 
                  filenamePrefix="pia" 
                  reportTitle="Evaluaciones de Impacto (PIA)"
                  disabled={isReadOnly}
                />
                {!isReadOnly && (
                  <Button onClick={handleAddNew}>
                    <PlusCircle className="mr-2 h-4 w-4" /> Añadir PIA
                  </Button>
                )}
              </div>
            </div>
            {loading ? (
              <p>Cargando PIAs...</p>
            ) : (
              <PiaTable
                piaList={pia}
                onEdit={handleEdit}
                onDelete={deletePia}
                isReadOnly={isReadOnly}
              />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default PiaSection;