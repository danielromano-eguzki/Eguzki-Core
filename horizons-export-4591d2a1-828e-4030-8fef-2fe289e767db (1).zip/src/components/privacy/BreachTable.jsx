import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit, Trash2, ChevronDown, ChevronUp, AlertTriangle, CheckCircle, Users, ShieldOff } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const BreachTable = ({ breachList, onEdit, onDelete, isReadOnly }) => {
  const [expandedRow, setExpandedRow] = useState(null);
  const [itemToDelete, setItemToDelete] = useState(null);

  const toggleRow = (id) => {
    setExpandedRow(expandedRow === id ? null : id);
  };

  const confirmDelete = () => {
    if (itemToDelete) {
      onDelete(itemToDelete.id);
      setItemToDelete(null);
    }
  };

  const statusConfig = {
    detected: { label: 'Detectada', color: 'bg-yellow-500' },
    in_progress: { label: 'En Investigación', color: 'bg-orange-500' },
    contained: { label: 'Contenida', color: 'bg-blue-500' },
    resolved: { label: 'Resuelta', color: 'bg-green-500' },
    closed: { label: 'Cerrada', color: 'bg-gray-500' },
  };

  return (
    <>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white/70 backdrop-blur-lg rounded-xl border border-white/20 shadow-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-10"></TableHead>
              <TableHead>ID Brecha</TableHead>
              <TableHead>Fecha Detección</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead>Interesados Afectados</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {breachList.length > 0 ? (
              breachList.map(item => (
                <React.Fragment key={item.id}>
                  <TableRow className="cursor-pointer" onClick={() => toggleRow(item.id)}>
                    <TableCell>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        {expandedRow === item.id ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{item.breach_id}</TableCell>
                    <TableCell>{item.detection_date ? format(new Date(item.detection_date), 'dd MMM yyyy', { locale: es }) : 'N/A'}</TableCell>
                    <TableCell>
                      <Badge className={`${statusConfig[item.status]?.color || 'bg-gray-400'} text-white`}>
                        {statusConfig[item.status]?.label || 'Desconocido'}
                      </Badge>
                    </TableCell>
                    <TableCell>{item.affected_subjects_count}</TableCell>
                    <TableCell className="text-right">
                      {!isReadOnly && (
                        <>
                          <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); onEdit(item); }}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-600" onClick={(e) => { e.stopPropagation(); setItemToDelete(item); }}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                    </TableCell>
                  </TableRow>
                  {expandedRow === item.id && (
                    <TableRow>
                      <TableCell colSpan={6} className="p-0">
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="bg-gray-50 p-4 space-y-4"
                        >
                          <div>
                            <h4 className="font-semibold mb-1">Descripción</h4>
                            <p className="text-sm text-gray-600 bg-white p-2 rounded-md">{item.description}</p>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <h4 className="font-semibold mb-1 flex items-center"><ShieldOff className="h-4 w-4 mr-2 text-red-500"/>Datos Afectados</h4>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {item.affected_data?.map(d => <Badge key={d} variant="secondary">{d}</Badge>) || <p className="text-sm">No especificados</p>}
                              </div>
                            </div>
                            <div>
                              <h4 className="font-semibold mb-1 flex items-center"><Users className="h-4 w-4 mr-2 text-gray-500"/>Notificaciones</h4>
                              <div className="text-sm space-y-1">
                                <p className="flex items-center">{item.notified_aepd ? <CheckCircle className="h-4 w-4 mr-2 text-green-500"/> : <AlertTriangle className="h-4 w-4 mr-2 text-yellow-500"/>} AEPD {item.aepd_notification_date ? `(${format(new Date(item.aepd_notification_date), 'dd/MM/yy')})` : ''}</p>
                                <p className="flex items-center">{item.notified_subjects ? <CheckCircle className="h-4 w-4 mr-2 text-green-500"/> : <AlertTriangle className="h-4 w-4 mr-2 text-yellow-500"/>} Interesados {item.subjects_notification_date ? `(${format(new Date(item.subjects_notification_date), 'dd/MM/yy')})` : ''}</p>
                              </div>
                            </div>
                          </div>
                          <div>
                            <h4 className="font-semibold mb-1">Acciones Tomadas</h4>
                            <p className="text-sm text-gray-600 bg-white p-2 rounded-md">{item.actions_taken || 'No especificadas'}</p>
                          </div>
                        </motion.div>
                      </TableCell>
                    </TableRow>
                  )}
                </React.Fragment>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center">
                  No hay brechas de seguridad registradas todavía.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </motion.div>

      <AlertDialog open={!!itemToDelete} onOpenChange={() => setItemToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. Esto eliminará permanentemente el registro de la brecha de seguridad.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default BreachTable;