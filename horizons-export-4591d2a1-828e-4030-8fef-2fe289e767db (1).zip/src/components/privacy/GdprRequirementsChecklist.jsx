import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';

const getInitialGdprRequirements = () => [
  {
    chapter: 'Capítulo II: Principios',
    requirements: [
      { id: 'art5-1', text: 'Art. 5: Licitud, lealtad y transparencia en el tratamiento de datos.', checked: false, codigo: 'Art. 5.1.a' },
      { id: 'art5-2', text: 'Art. 5: Limitación de la finalidad (fines determinados, explícitos y legítimos).', checked: false, codigo: 'Art. 5.1.b' },
      { id: 'art5-3', text: 'Art. 5: Minimización de datos (adecuados, pertinentes y limitados).', checked: false, codigo: 'Art. 5.1.c' },
      { id: 'art5-4', text: 'Art. 5: Exactitud de los datos (actualizados y exactos).', checked: false, codigo: 'Art. 5.1.d' },
      { id: 'art5-5', text: 'Art. 5: Limitación del plazo de conservación.', checked: false, codigo: 'Art. 5.1.e' },
      { id: 'art5-6', text: 'Art. 5: Integridad y confidencialidad (seguridad adecuada).', checked: false, codigo: 'Art. 5.1.f' },
      { id: 'art5-7', text: 'Art. 5: Responsabilidad proactiva (accountability).', checked: false, codigo: 'Art. 5.2' },
    ],
  },
  {
    chapter: 'Capítulo III: Derechos del Interesado',
    requirements: [
      { id: 'art12', text: 'Art. 12: Información y comunicación transparente sobre el ejercicio de derechos.', checked: false, codigo: 'Art. 12' },
      { id: 'art13-14', text: 'Art. 13-14: Deber de informar al recoger datos (cláusulas informativas).', checked: false, codigo: 'Art. 13-14' },
      { id: 'art15', text: 'Art. 15: Derecho de acceso del interesado.', checked: false, codigo: 'Art. 15' },
      { id: 'art16', text: 'Art. 16: Derecho de rectificación.', checked: false, codigo: 'Art. 16' },
      { id: 'art17', text: 'Art. 17: Derecho de supresión ("derecho al olvido").', checked: false, codigo: 'Art. 17' },
      { id: 'art18', text: 'Art. 18: Derecho a la limitación del tratamiento.', checked: false, codigo: 'Art. 18' },
      { id: 'art19', text: 'Art. 19: Obligación de notificar la rectificación, supresión o limitación.', checked: false, codigo: 'Art. 19' },
      { id: 'art20', text: 'Art. 20: Derecho a la portabilidad de los datos.', checked: false, codigo: 'Art. 20' },
      { id: 'art21', text: 'Art. 21: Derecho de oposición.', checked: false, codigo: 'Art. 21' },
      { id: 'art22', text: 'Art. 22: Derecho a no ser objeto de decisiones individuales automatizadas.', checked: false, codigo: 'Art. 22' },
    ],
  },
  {
    chapter: 'Capítulo IV: Responsable y Encargado del Tratamiento',
    requirements: [
      { id: 'art24', text: 'Art. 24: Responsabilidad del responsable del tratamiento.', checked: false, codigo: 'Art. 24' },
      { id: 'art25', text: 'Art. 25: Protección de datos desde el diseño y por defecto.', checked: false, codigo: 'Art. 25' },
      { id: 'art28', text: 'Art. 28: Contratos de encargado del tratamiento.', checked: false, codigo: 'Art. 28' },
      { id: 'art30', text: 'Art. 30: Registro de actividades de tratamiento (ROPA).', checked: false, codigo: 'Art. 30' },
      { id: 'art32', text: 'Art. 32: Seguridad del tratamiento (medidas técnicas y organizativas).', checked: false, codigo: 'Art. 32' },
      { id: 'art33', text: 'Art. 33: Notificación de violaciones de seguridad a la autoridad de control.', checked: false, codigo: 'Art. 33' },
      { id: 'art34', text: 'Art. 34: Comunicación de violaciones de seguridad a los interesados.', checked: false, codigo: 'Art. 34' },
      { id: 'art35', text: 'Art. 35: Evaluación de Impacto relativa a la Protección de Datos (EIPD/PIA).', checked: false, codigo: 'Art. 35' },
      { id: 'art37-39', text: 'Art. 37-39: Designación, posición y funciones del Delegado de Protección de Datos (DPD/DPO).', checked: false, codigo: 'Art. 37-39' },
    ],
  },
  {
    chapter: 'Capítulo V: Transferencias Internacionales de Datos',
    requirements: [
      { id: 'art44', text: 'Art. 44: Principio general para las transferencias.', checked: false, codigo: 'Art. 44' },
      { id: 'art45', text: 'Art. 45: Transferencias basadas en una decisión de adecuación.', checked: false, codigo: 'Art. 45' },
      { id: 'art46', text: 'Art. 46: Transferencias mediante garantías adecuadas (ej. Cláusulas Contractuales Tipo).', checked: false, codigo: 'Art. 46' },
      { id: 'art49', text: 'Art. 49: Excepciones para situaciones específicas.', checked: false, codigo: 'Art. 49' },
    ],
  },
];

const GdprRequirementsChecklist = ({ onRequirementsChange }) => {
  const [requirementsData, setRequirementsData] = useState(getInitialGdprRequirements());

  useEffect(() => {
    const allReqs = requirementsData.flatMap(section => section.requirements);
    onRequirementsChange(allReqs);
  }, [requirementsData, onRequirementsChange]);

  const handleCheckChange = (chapter, id) => {
    setRequirementsData(prevData =>
      prevData.map(section => {
        if (section.chapter === chapter) {
          return {
            ...section,
            requirements: section.requirements.map(req =>
              req.id === id ? { ...req, checked: !req.checked } : req
            ),
          };
        }
        return section;
      })
    );
  };

  return (
    <Card className="mt-4">
      <CardHeader>
        <CardTitle>Checklist de Requisitos del GDPR</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[60vh]">
          <Accordion type="multiple" defaultValue={requirementsData.map(c => c.chapter)} className="w-full pr-4">
            {requirementsData.map((section) => (
              <AccordionItem value={section.chapter} key={section.chapter}>
                <AccordionTrigger className="text-lg font-semibold">{section.chapter}</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-3">
                    {section.requirements.map((req) => (
                      <div key={req.id} className="flex items-center space-x-3 p-2 rounded-md hover:bg-gray-50">
                        <Checkbox
                          id={req.id}
                          checked={req.checked}
                          onCheckedChange={() => handleCheckChange(section.chapter, req.id)}
                        />
                        <Label htmlFor={req.id} className="text-sm font-normal cursor-pointer flex-1">
                          {req.text}
                        </Label>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default GdprRequirementsChecklist;