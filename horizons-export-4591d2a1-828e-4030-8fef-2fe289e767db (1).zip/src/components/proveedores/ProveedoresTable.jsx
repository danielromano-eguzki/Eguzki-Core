import React, { useState } from 'react';
    import { Button } from '@/components/ui/button';
    import { Edit3, Trash2, Download, FileText, FileQuestion } from 'lucide-react';
    import { motion } from 'framer-motion';
    
    const ProveedoresTable = ({ suppliers, onEdit, onDelete, onDownloadFile, loading, isReadOnly }) => {
      const [downloading, setDownloading] = useState(null);
    
      const handleDownload = async (path, fileName) => {
        setDownloading(path);
        await onDownloadFile(path, fileName);
        setDownloading(null);
      };
    
      const criticalityColor = {
        'Bajo': 'bg-green-100 text-green-800',
        'Medio': 'bg-yellow-100 text-yellow-800',
        'Alto': 'bg-orange-100 text-orange-800',
        'Crítico': 'bg-red-100 text-red-800',
      };
    
      return (
        <div className="bg-white/70 backdrop-blur-lg shadow-lg rounded-xl overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200/50">
            <thead className="bg-gradient-to-r from-green-500/10 to-teal-500/10">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Nombre</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Servicios</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Fecha Contrato</th>
                <th className="px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Criticidad</th>
                <th className="px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Documentos</th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Acciones</th>
              </tr>
            </thead>
            <tbody className="bg-white/50 divide-y divide-gray-200/30">
              {suppliers.map(supplier => (
                <motion.tr 
                  key={supplier.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                  className="hover:bg-green-500/5"
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{supplier.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 max-w-xs truncate" title={supplier.services}>{supplier.services}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{supplier.agreement_date ? new Date(supplier.agreement_date).toLocaleDateString() : 'N/A'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm">
                    <span className={`px-2.5 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full ${criticalityColor[supplier.criticality_level] || 'bg-gray-100 text-gray-800'}`}>
                      {supplier.criticality_level}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                    <div className="flex items-center justify-center space-x-2">
                      {supplier.contract_path && (
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600" onClick={() => handleDownload(supplier.contract_path, `contrato_${supplier.name}.pdf`)} disabled={downloading === supplier.contract_path}>
                          {downloading === supplier.contract_path ? <motion.div animate={{rotate:360}} transition={{duration:1, repeat:Infinity}} className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full" /> : <FileText className="w-4 h-4" title="Descargar Contrato" />}
                        </Button>
                      )}
                      {supplier.security_questionnaire_path && (
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-purple-600" onClick={() => handleDownload(supplier.security_questionnaire_path, `cuestionario_${supplier.name}.pdf`)} disabled={downloading === supplier.security_questionnaire_path}>
                          {downloading === supplier.security_questionnaire_path ? <motion.div animate={{rotate:360}} transition={{duration:1, repeat:Infinity}} className="w-4 h-4 border-2 border-purple-600 border-t-transparent rounded-full" /> : <FileQuestion className="w-4 h-4" title="Descargar Cuestionario" />}
                        </Button>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end space-x-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-600" onClick={() => onEdit(supplier)} disabled={isReadOnly}><Edit3 className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500" onClick={() => onDelete(supplier)} disabled={isReadOnly}><Trash2 className="w-4 h-4" /></Button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    };
    
    export default ProveedoresTable;