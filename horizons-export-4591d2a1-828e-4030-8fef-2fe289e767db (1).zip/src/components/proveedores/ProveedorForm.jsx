import React, { useState, useEffect, useRef } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { File, X } from 'lucide-react';
    
    const criticalityLevels = ['Bajo', 'Medio', 'Alto', 'Crítico'];
    
    const ProveedorForm = ({ onSubmit, onCancel, existingSupplier, isReadOnly }) => {
      const [formData, setFormData] = useState({
        name: '',
        services: '',
        agreement_date: '',
        criticality_level: 'Medio',
      });
      const [contractFile, setContractFile] = useState(null);
      const [questionnaireFile, setQuestionnaireFile] = useState(null);
      const contractFileRef = useRef(null);
      const questionnaireFileRef = useRef(null);
    
      useEffect(() => {
        if (existingSupplier) {
          setFormData({
            name: existingSupplier.name || '',
            services: existingSupplier.services || '',
            agreement_date: existingSupplier.agreement_date ? existingSupplier.agreement_date.split('T')[0] : '',
            criticality_level: existingSupplier.criticality_level || 'Medio',
          });
        }
      }, [existingSupplier]);
    
      const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData((prev) => ({ ...prev, [id]: value }));
      };
    
      const handleSelectChange = (value) => {
        setFormData((prev) => ({ ...prev, criticality_level: value }));
      };
    
      const handleFileChange = (e, setFile) => {
        if (e.target.files && e.target.files.length > 0) {
          setFile(e.target.files[0]);
        }
      };
    
      const handleSubmit = (e) => {
        e.preventDefault();
        if(isReadOnly) return;
        onSubmit(formData, contractFile, questionnaireFile);
      };
    
      const FileInputDisplay = ({ file, existingPath, setFile, inputRef, label }) => (
        <div className="space-y-2">
          <Label>{label}</Label>
          {file ? (
            <div className="flex items-center justify-between p-2 border rounded-md bg-gray-50">
              <div className="flex items-center gap-2 text-sm text-gray-700">
                <File className="w-4 h-4" />
                <span className="truncate max-w-xs">{file.name}</span>
              </div>
              <Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={() => setFile(null)} disabled={isReadOnly}><X className="w-4 h-4" /></Button>
            </div>
          ) : existingPath ? (
             <div className="flex items-center justify-between p-2 border rounded-md bg-gray-50">
                <span className="text-sm text-green-600 truncate max-w-xs">Archivo existente</span>
                <Button type="button" variant="outline" size="sm" onClick={() => inputRef.current.click()} disabled={isReadOnly}>Reemplazar</Button>
             </div>
          ) : (
            <Button type="button" variant="outline" className="w-full" onClick={() => inputRef.current.click()} disabled={isReadOnly}>Subir archivo</Button>
          )}
          <Input ref={inputRef} type="file" className="hidden" onChange={(e) => handleFileChange(e, setFile)} disabled={isReadOnly} />
        </div>
      );
    
      return (
        <form onSubmit={handleSubmit} className="space-y-4 p-1">
          <div className="space-y-2">
            <Label htmlFor="name">Nombre del Proveedor</Label>
            <Input id="name" value={formData.name} onChange={handleChange} required disabled={isReadOnly} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="services">Servicios Prestados</Label>
            <Textarea id="services" value={formData.services} onChange={handleChange} disabled={isReadOnly} />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="agreement_date">Fecha de Contrato</Label>
              <Input id="agreement_date" type="date" value={formData.agreement_date} onChange={handleChange} disabled={isReadOnly} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="criticality_level">Nivel de Criticidad</Label>
              <Select onValueChange={handleSelectChange} value={formData.criticality_level} disabled={isReadOnly}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {criticalityLevels.map(level => <SelectItem key={level} value={level}>{level}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FileInputDisplay file={contractFile} existingPath={existingSupplier?.contract_path} setFile={setContractFile} inputRef={contractFileRef} label="Contrato" />
            <FileInputDisplay file={questionnaireFile} existingPath={existingSupplier?.security_questionnaire_path} setFile={setQuestionnaireFile} inputRef={questionnaireFileRef} label="Cuestionario de Seguridad" />
          </div>
          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
            {!isReadOnly && <Button type="submit">{existingSupplier ? 'Guardar Cambios' : 'Crear Proveedor'}</Button>}
          </div>
        </form>
      );
    };
    
    export default ProveedorForm;