import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DialogFooter } from '@/components/ui/dialog';
import { PlusCircle, Paperclip } from 'lucide-react';

const criticidadOptions = ["Alta", "Media", "Baja"];
const tipoRequisitoOptions = ["Legal", "Técnico", "Organizativo", "Otro"];
const estadoOptions = ["Cumplido", "Parcial", "No cumplido", "No aplica"];

const RequirementForm = ({ onSubmit, onCancel, existingRequirement, certifications, evidences, onOpenEvidenceForm, isReadOnly }) => {
  const [formData, setFormData] = useState({
    certificacion_id: '',
    codigo: '',
    titulo: '',
    descripcion: '',
    criticidad: '',
    tipo_requisito: '',
    estado_cumplimiento: 'No cumplido',
    observaciones: '',
    plan_accion: '',
    departamento_responsable: '',
    linked_evidence_id: '',
  });

  const [newEvidenceFile, setNewEvidenceFile] = useState(null);

  useEffect(() => {
    if (existingRequirement) {
      setFormData({
        certificacion_id: existingRequirement.certificacion_id || '',
        codigo: existingRequirement.codigo || '',
        titulo: existingRequirement.titulo || '',
        descripcion: existingRequirement.descripcion || '',
        criticidad: existingRequirement.criticidad || '',
        tipo_requisito: existingRequirement.tipo_requisito || '',
        estado_cumplimiento: existingRequirement.estado_cumplimiento || 'No cumplido',
        observaciones: existingRequirement.observaciones || '',
        plan_accion: existingRequirement.plan_accion || '',
        departamento_responsable: existingRequirement.departamento_responsable || '',
        linked_evidence_id: existingRequirement.linked_evidences?.[0]?.id || '',
      });
    } else {
       setFormData({
        certificacion_id: certifications.length > 0 && certifications[0] ? certifications[0].id : '',
        codigo: '',
        titulo: '',
        descripcion: '',
        criticidad: '',
        tipo_requisito: '',
        estado_cumplimiento: 'No cumplido',
        observaciones: '',
        plan_accion: '',
        departamento_responsable: '',
        linked_evidence_id: '',
      });
    }
  }, [existingRequirement, certifications]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFileChange = (e) => {
    setNewEvidenceFile(e.target.files[0] || null);
  };

  const handleSelectChange = (name, value) => {
    const finalValue = value === 'none' ? '' : value;
    setFormData(prev => ({ ...prev, [name]: finalValue }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isReadOnly) return;
    const { linked_evidence_id, ...restOfData } = formData;
    onSubmit(restOfData, linked_evidence_id, newEvidenceFile);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto p-1">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="certificacion_id">Certificación</Label>
          <Select onValueChange={(value) => handleSelectChange('certificacion_id', value)} value={formData.certificacion_id} disabled={isReadOnly} required>
            <SelectTrigger id="certificacion_id"><SelectValue placeholder="Seleccionar certificación" /></SelectTrigger>
            <SelectContent>
              {certifications.map(cert => <SelectItem key={cert.id} value={cert.id}>{cert.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="codigo">Código</Label>
          <Input id="codigo" name="codigo" value={formData.codigo} onChange={handleChange} placeholder="Ej: A.5.1" disabled={isReadOnly} />
        </div>
      </div>
      <div>
        <Label htmlFor="titulo">Título del Requisito</Label>
        <Input id="titulo" name="titulo" value={formData.titulo} onChange={handleChange} placeholder="Título resumido del requisito" disabled={isReadOnly} required />
      </div>
      <div>
        <Label htmlFor="descripcion">Descripción</Label>
        <Textarea id="descripcion" name="descripcion" value={formData.descripcion} onChange={handleChange} placeholder="Descripción detallada del requisito" disabled={isReadOnly} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <Label htmlFor="criticidad">Criticidad</Label>
          <Select onValueChange={(value) => handleSelectChange('criticidad', value)} value={formData.criticidad} disabled={isReadOnly}>
            <SelectTrigger id="criticidad"><SelectValue placeholder="Seleccionar criticidad" /></SelectTrigger>
            <SelectContent>
              {criticidadOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="tipo_requisito">Tipo de Requisito</Label>
          <Select onValueChange={(value) => handleSelectChange('tipo_requisito', value)} value={formData.tipo_requisito} disabled={isReadOnly}>
            <SelectTrigger id="tipo_requisito"><SelectValue placeholder="Seleccionar tipo" /></SelectTrigger>
            <SelectContent>
              {tipoRequisitoOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="estado_cumplimiento">Estado</Label>
          <Select onValueChange={(value) => handleSelectChange('estado_cumplimiento', value)} value={formData.estado_cumplimiento} disabled={isReadOnly} required>
            <SelectTrigger id="estado_cumplimiento"><SelectValue placeholder="Seleccionar estado" /></SelectTrigger>
            <SelectContent>
              {estadoOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

       <div className="border-t pt-4 mt-4 space-y-4">
          <h3 className="text-lg font-semibold text-gray-700">Evidencia y Plan de Acción</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div>
                <Label htmlFor="linked_evidence_id">Evidencia Asociada</Label>
                <div className="flex gap-2">
                <Select onValueChange={(value) => handleSelectChange('linked_evidence_id', value)} value={formData.linked_evidence_id || 'none'} disabled={isReadOnly}>
                    <SelectTrigger id="linked_evidence_id"><SelectValue placeholder="Seleccionar evidencia" /></SelectTrigger>
                    <SelectContent>
                    <SelectItem value="none">Sin asociar</SelectItem>
                    {evidences.map(ev => <SelectItem key={ev.id} value={ev.id}>{ev.nombre}</SelectItem>)}
                    </SelectContent>
                </Select>
                <Button type="button" variant="outline" size="icon" onClick={onOpenEvidenceForm} disabled={isReadOnly}>
                    <PlusCircle className="h-4 w-4" />
                </Button>
                </div>
            </div>
             <div>
                <Label htmlFor="new-evidence-file">Adjuntar Nueva Evidencia</Label>
                <Input id="new-evidence-file" type="file" onChange={handleFileChange} className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20" disabled={isReadOnly} />
            </div>
          </div>
          <div>
            <Label htmlFor="plan_accion">Descripción del Plan de Acción</Label>
            <Textarea id="plan_accion" name="plan_accion" value={formData.plan_accion} onChange={handleChange} placeholder="Pasos a seguir para cumplir el requisito" disabled={isReadOnly} />
          </div>
          <div>
            <Label htmlFor="departamento_responsable">Departamento Responsable</Label>
            <Input id="departamento_responsable" name="departamento_responsable" value={formData.departamento_responsable} onChange={handleChange} placeholder="Ej: Departamento de IT" disabled={isReadOnly} />
          </div>
        </div>

      <div>
        <Label htmlFor="observaciones">Observaciones</Label>
        <Textarea id="observaciones" name="observaciones" value={formData.observaciones} onChange={handleChange} placeholder="Comentarios o justificaciones" disabled={isReadOnly} />
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        {!isReadOnly && <Button type="submit">{existingRequirement ? 'Actualizar Requisito' : 'Añadir Requisito'}</Button>}
      </DialogFooter>
    </form>
  );
};

export default RequirementForm;