import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Edit, Trash, Download, Paperclip, ChevronDown, ChevronRight, Link as LinkIcon, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const getStatusBadgeColor = (status) => {
  const colors = {
    'Cumplido': 'bg-green-100 text-green-800',
    'Parcial': 'bg-yellow-100 text-yellow-800',
    'No cumplido': 'bg-red-100 text-red-800',
    'No aplica': 'bg-gray-100 text-gray-800',
  };
  return colors[status] || 'bg-gray-100 text-gray-800';
};

const RequirementRow = ({ requirement, evidences, onEdit, onDelete, getEvidenceFileUrl, isReadOnly, requirementsHook }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [selectedEvidence, setSelectedEvidence] = useState('');
  
  const linkedEvidences = requirement.linked_evidences || [];
  const availableEvidences = evidences.filter(ev => !linkedEvidences.some(le => le.id === ev.id));
  
  const handleLinkEvidence = async () => {
    if (selectedEvidence) {
      await requirementsHook.linkEvidenceToRequirement(requirement.id, selectedEvidence);
      setSelectedEvidence('');
    }
  };

  return (
    <>
      <tr className="bg-white border-b hover:bg-gray-50/70">
        <td className="px-2 py-3">
          <Button variant="ghost" size="icon" onClick={() => setIsExpanded(!isExpanded)} className="h-6 w-6">
            {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </Button>
        </td>
        <td className="px-4 py-3 font-medium text-gray-900">{requirement.codigo}</td>
        <td className="px-4 py-3 max-w-sm truncate" title={requirement.titulo}>{requirement.titulo}</td>
        <td className="px-4 py-3">
          <Badge className={getStatusBadgeColor(requirement.estado_cumplimiento)}>
            {requirement.estado_cumplimiento}
          </Badge>
        </td>
        <td className="px-4 py-3">
          <div className="flex items-center gap-1">
             <Paperclip className="h-4 w-4 text-gray-400" /> {linkedEvidences.length}
          </div>
        </td>
        <td className="px-4 py-3 text-center">
          <div className="flex justify-center items-center space-x-1">
            {!isReadOnly && (
              <>
                <Button variant="ghost" size="icon" onClick={() => onEdit(requirement)} title="Editar Requisito">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => onDelete(requirement)} title="Eliminar Requisito">
                  <Trash className="h-4 w-4 text-red-500" />
                </Button>
              </>
            )}
          </div>
        </td>
      </tr>
      <AnimatePresence>
        {isExpanded && (
          <motion.tr
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="bg-slate-50"
          >
            <td colSpan="6" className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Descripción Completa</h4>
                      <p className="text-xs text-gray-600">{requirement.descripcion || 'Sin descripción.'}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Plan de Acción</h4>
                      <p className="text-xs text-gray-600">{requirement.plan_accion || 'Sin plan de acción definido.'}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Observaciones</h4>
                      <p className="text-xs text-gray-600">{requirement.observaciones || 'Sin observaciones.'}</p>
                    </div>
                </div>

                <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-sm mb-2">Evidencias Vinculadas</h4>
                      {linkedEvidences.length > 0 ? (
                        <ul className="space-y-1">
                          {linkedEvidences.map(ev => ev && (
                            <li key={ev.id} className="flex items-center justify-between text-xs p-1 rounded bg-white border">
                              <span className="font-medium truncate pr-2">{ev.nombre}</span>
                              <div className='flex items-center shrink-0'>
                                {ev.file_path && (
                                   <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => getEvidenceFileUrl(ev.file_path).then(url => window.open(url, '_blank'))} title="Descargar Evidencia">
                                    <Download className="h-4 w-4 text-blue-500" />
                                  </Button>
                                )}
                                {!isReadOnly && (
                                   <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => requirementsHook.unlinkEvidenceFromRequirement(requirement.id, ev.id)} title="Desvincular Evidencia">
                                    <X className="h-4 w-4 text-red-500" />
                                  </Button>
                                )}
                              </div>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-xs text-gray-500">No hay evidencias vinculadas a este requisito.</p>
                      )}
                    </div>
                    {!isReadOnly && (
                       <div>
                         <h4 className="font-semibold text-sm mb-2">Vincular Evidencia Existente</h4>
                         <div className="flex items-center gap-2">
                           <Select onValueChange={setSelectedEvidence} value={selectedEvidence}>
                             <SelectTrigger><SelectValue placeholder="Seleccionar evidencia..." /></SelectTrigger>
                             <SelectContent>
                              {availableEvidences.map(ev => (
                                <SelectItem key={ev.id} value={ev.id}>{ev.evidence_id_custom || ev.nombre}</SelectItem>
                              ))}
                             </SelectContent>
                           </Select>
                           <Button size="sm" onClick={handleLinkEvidence} disabled={!selectedEvidence}>
                             <LinkIcon className="h-4 w-4 mr-2" /> Vincular
                           </Button>
                         </div>
                       </div>
                    )}
                </div>
              </div>
            </td>
          </motion.tr>
        )}
      </AnimatePresence>
    </>
  );
};

const RequirementsTable = ({ requirements, evidences, onEdit, onDelete, getEvidenceFileUrl, isReadOnly, requirementsHook }) => {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm text-left text-gray-500">
        <thead className="text-xs text-gray-700 uppercase bg-gray-50/50">
          <tr>
            <th scope="col" className="px-2 py-3 w-12"></th>
            <th scope="col" className="px-4 py-3">Código</th>
            <th scope="col" className="px-4 py-3">Título</th>
            <th scope="col" className="px-4 py-3">Estado</th>
            <th scope="col" className="px-4 py-3">Evidencias</th>
            <th scope="col" className="px-4 py-3 text-center">Acciones</th>
          </tr>
        </thead>
        <tbody>
          {requirements.map(req => (
            <RequirementRow 
              key={req.id} 
              requirement={req} 
              evidences={evidences} 
              onEdit={onEdit} 
              onDelete={onDelete} 
              getEvidenceFileUrl={getEvidenceFileUrl} 
              isReadOnly={isReadOnly}
              requirementsHook={requirementsHook}
            />
          ))}
          {requirements.length === 0 && (
            <tr>
              <td colSpan="6" className="text-center py-10 text-gray-500">
                No hay requisitos que coincidan con los filtros actuales.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default RequirementsTable;