import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { DialogFooter } from '@/components/ui/dialog';

const CertificationForm = ({ onSubmit, onCancel, existingFramework, isReadOnly }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    if (existingFramework) {
      setName(existingFramework.name || '');
      setDescription(existingFramework.description || '');
    } else {
      setName('');
      setDescription('');
    }
  }, [existingFramework]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isReadOnly) return;
    onSubmit({ name, description });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="framework-name">Nombre de la Certificación</Label>
        <Input
          id="framework-name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Ej: ISO 27001"
          required
          disabled={isReadOnly}
        />
      </div>
      <div>
        <Label htmlFor="framework-description">Descripción</Label>
        <Textarea
          id="framework-description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Breve descripción de la certificación o normativa"
          disabled={isReadOnly}
        />
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        {!isReadOnly && (
          <Button type="submit">
            {existingFramework ? 'Actualizar' : 'Crear'} Certificación
          </Button>
        )}
      </DialogFooter>
    </form>
  );
};

export default CertificationForm;