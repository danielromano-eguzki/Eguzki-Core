import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

const CriticalAssetBcForm = ({ item, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    asset_name: '',
    asset_type: '',
    description: '',
    location: '',
    owner: '',
    rto_actual: '',
    rpo_actual: '',
    recovery_procedure_link: '',
  });

  useEffect(() => {
    if (item) {
      setFormData({
        asset_name: item.asset_name || '',
        asset_type: item.asset_type || '',
        description: item.description || '',
        location: item.location || '',
        owner: item.owner || '',
        rto_actual: item.rto_actual || '',
        rpo_actual: item.rpo_actual || '',
        recovery_procedure_link: item.recovery_procedure_link || '',
      });
    }
  }, [item]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="asset_name">Nombre del Activo</Label>
          <Input id="asset_name" name="asset_name" value={formData.asset_name} onChange={handleChange} required />
        </div>
        <div>
          <Label htmlFor="asset_type">Tipo de Activo</Label>
          <Input id="asset_type" name="asset_type" placeholder="Ej: Servidor, Software, Red" value={formData.asset_type} onChange={handleChange} />
        </div>
      </div>
      <div>
        <Label htmlFor="description">Descripción</Label>
        <Textarea id="description" name="description" value={formData.description} onChange={handleChange} />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="location">Ubicación</Label>
          <Input id="location" name="location" value={formData.location} onChange={handleChange} />
        </div>
        <div>
          <Label htmlFor="owner">Propietario</Label>
          <Input id="owner" name="owner" value={formData.owner} onChange={handleChange} />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="rto_actual">RTO Actual</Label>
          <Input id="rto_actual" name="rto_actual" placeholder="Ej: 2 horas" value={formData.rto_actual} onChange={handleChange} />
        </div>
        <div>
          <Label htmlFor="rpo_actual">RPO Actual</Label>
          <Input id="rpo_actual" name="rpo_actual" placeholder="Ej: 30 minutos" value={formData.rpo_actual} onChange={handleChange} />
        </div>
      </div>
      <div>
        <Label htmlFor="recovery_procedure_link">Enlace al Procedimiento de Recuperación</Label>
        <Input id="recovery_procedure_link" name="recovery_procedure_link" placeholder="URL o referencia a documento" value={formData.recovery_procedure_link} onChange={handleChange} />
      </div>
      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{item ? 'Actualizar' : 'Guardar'}</Button>
      </div>
    </form>
  );
};

export default CriticalAssetBcForm;