import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';

const impactAreasOptions = [
  'Financiero', 'Reputacional', 'Operacional', 'Legal y Regulatorio', 'Seguridad del Personal'
];

const BiaForm = ({ item, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    process_name: '',
    description: '',
    rto_target: '',
    rpo_target: '',
    criticality_level: 'Bajo',
    dependencies: '',
    impact_areas: [],
  });

  useEffect(() => {
    if (item) {
      setFormData({
        process_name: item.process_name || '',
        description: item.description || '',
        rto_target: item.rto_target || '',
        rpo_target: item.rpo_target || '',
        criticality_level: item.criticality_level || 'Bajo',
        dependencies: item.dependencies || '',
        impact_areas: item.impact_areas || [],
      });
    }
  }, [item]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleImpactAreaChange = (area) => {
    setFormData(prev => {
      const newImpactAreas = prev.impact_areas.includes(area)
        ? prev.impact_areas.filter(a => a !== area)
        : [...prev.impact_areas, area];
      return { ...prev, impact_areas: newImpactAreas };
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="process_name">Nombre del Proceso</Label>
        <Input id="process_name" name="process_name" value={formData.process_name} onChange={handleChange} required />
      </div>
      <div>
        <Label htmlFor="description">Descripción</Label>
        <Textarea id="description" name="description" value={formData.description} onChange={handleChange} />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="rto_target">RTO (Recovery Time Objective)</Label>
          <Input id="rto_target" name="rto_target" placeholder="Ej: 4 horas" value={formData.rto_target} onChange={handleChange} />
        </div>
        <div>
          <Label htmlFor="rpo_target">RPO (Recovery Point Objective)</Label>
          <Input id="rpo_target" name="rpo_target" placeholder="Ej: 1 hora" value={formData.rpo_target} onChange={handleChange} />
        </div>
      </div>
      <div>
        <Label htmlFor="criticality_level">Nivel de Criticidad</Label>
        <Select name="criticality_level" value={formData.criticality_level} onValueChange={(value) => handleSelectChange('criticality_level', value)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="Bajo">Bajo</SelectItem>
            <SelectItem value="Medio">Medio</SelectItem>
            <SelectItem value="Alto">Alto</SelectItem>
            <SelectItem value="Crítico">Crítico</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label htmlFor="dependencies">Dependencias</Label>
        <Textarea id="dependencies" name="dependencies" placeholder="Sistemas, personal, proveedores..." value={formData.dependencies} onChange={handleChange} />
      </div>
      <div>
        <Label>Áreas de Impacto</Label>
        <div className="grid grid-cols-2 gap-2 mt-2">
          {impactAreasOptions.map(area => (
            <div key={area} className="flex items-center space-x-2">
              <Checkbox
                id={`impact-${area}`}
                checked={formData.impact_areas.includes(area)}
                onCheckedChange={() => handleImpactAreaChange(area)}
              />
              <Label htmlFor={`impact-${area}`} className="font-normal">{area}</Label>
            </div>
          ))}
        </div>
      </div>
      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{item ? 'Actualizar' : 'Guardar'}</Button>
      </div>
    </form>
  );
};

export default BiaForm;