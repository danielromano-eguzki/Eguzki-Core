import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const ContinuitySystemForm = ({ item, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    last_tested_date: '',
    next_test_date: '',
    status: 'Activo',
  });
  const [file, setFile] = useState(null);

  useEffect(() => {
    if (item) {
      setFormData({
        name: item.name || '',
        description: item.description || '',
        last_tested_date: item.last_tested_date ? new Date(item.last_tested_date).toISOString().split('T')[0] : '',
        next_test_date: item.next_test_date ? new Date(item.next_test_date).toISOString().split('T')[0] : '',
        status: item.status || 'Activo',
        document_name: item.document_name,
        document_path: item.document_path,
      });
    }
  }, [item]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData, file);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Nombre del Sistema/Plan</Label>
        <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
      </div>
      <div>
        <Label htmlFor="description">Descripción</Label>
        <Textarea id="description" name="description" value={formData.description} onChange={handleChange} />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="last_tested_date">Última Prueba</Label>
          <Input type="date" id="last_tested_date" name="last_tested_date" value={formData.last_tested_date} onChange={handleChange} />
        </div>
        <div>
          <Label htmlFor="next_test_date">Próxima Prueba</Label>
          <Input type="date" id="next_test_date" name="next_test_date" value={formData.next_test_date} onChange={handleChange} />
        </div>
      </div>
      <div>
        <Label htmlFor="status">Estado</Label>
        <Select name="status" value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="Activo">Activo</SelectItem>
            <SelectItem value="En desarrollo">En desarrollo</SelectItem>
            <SelectItem value="Obsoleto">Obsoleto</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label htmlFor="document">Documento (PDF, Word, Excel)</Label>
        <Input id="document" type="file" onChange={handleFileChange} accept=".pdf,.doc,.docx,.xls,.xlsx" />
        {item && item.document_name && <p className="text-sm text-gray-500 mt-1">Archivo actual: {item.document_name}</p>}
      </div>
      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{item ? 'Actualizar' : 'Guardar'}</Button>
      </div>
    </form>
  );
};

export default ContinuitySystemForm;