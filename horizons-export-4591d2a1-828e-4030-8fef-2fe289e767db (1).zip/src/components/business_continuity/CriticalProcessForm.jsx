import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const CriticalProcessForm = ({ item, onSubmit, onCancel, bias }) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    owner: '',
    recovery_strategy: '',
    bia_id: null,
  });

  useEffect(() => {
    if (item) {
      setFormData({
        name: item.name || '',
        description: item.description || '',
        owner: item.owner || '',
        recovery_strategy: item.recovery_strategy || '',
        bia_id: item.bia_id || null,
      });
    }
  }, [item]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Nombre del Proceso</Label>
        <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
      </div>
      <div>
        <Label htmlFor="bia_id">BIA Asociado</Label>
        <Select name="bia_id" value={formData.bia_id || ''} onValueChange={(value) => handleSelectChange('bia_id', value || null)}>
          <SelectTrigger>
            <SelectValue placeholder="Seleccionar un BIA..." />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={null}>Ninguno</SelectItem>
            {bias && bias.map(bia => (
              <SelectItem key={bia.id} value={bia.id}>{bia.process_name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label htmlFor="description">Descripción</Label>
        <Textarea id="description" name="description" value={formData.description} onChange={handleChange} />
      </div>
      <div>
        <Label htmlFor="owner">Propietario / Responsable</Label>
        <Input id="owner" name="owner" value={formData.owner} onChange={handleChange} />
      </div>
      <div>
        <Label htmlFor="recovery_strategy">Estrategia de Recuperación</Label>
        <Textarea id="recovery_strategy" name="recovery_strategy" value={formData.recovery_strategy} onChange={handleChange} />
      </div>
      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{item ? 'Actualizar' : 'Guardar'}</Button>
      </div>
    </form>
  );
};

export default CriticalProcessForm;