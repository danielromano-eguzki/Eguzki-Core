import React from 'react';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { PlusCircle, Edit, Trash2 } from 'lucide-react';

const CriticalProcessesSection = ({ data, loading, onAdd, onEdit, onDelete, dependencies }) => {
  if (loading) return <p>Cargando procesos críticos...</p>;

  const getBiaName = (biaId) => {
    if (!dependencies?.bias || !biaId) return 'N/A';
    const bia = dependencies.bias.find(b => b.id === biaId);
    return bia ? bia.process_name : 'Desconocido';
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={onAdd}><PlusCircle className="mr-2 h-4 w-4" /> Añadir Proceso</Button>
      </div>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Proceso Crítico</TableHead>
              <TableHead>Propietario</TableHead>
              <TableHead>BIA Asociado</TableHead>
              <TableHead>Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data && data.length > 0 ? (
              data.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.name}</TableCell>
                  <TableCell>{item.owner}</TableCell>
                  <TableCell>{getBiaName(item.bia_id)}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="icon" onClick={() => onEdit(item)}><Edit className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => onDelete(item)}><Trash2 className="h-4 w-4 text-red-500" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan="4" className="text-center">No hay procesos críticos registrados.</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default CriticalProcessesSection;