import React from 'react';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { PlusCircle, Edit, Trash2 } from 'lucide-react';

const CriticalAssetsBcSection = ({ data, loading, onAdd, onEdit, onDelete }) => {
  if (loading) return <p>Cargando activos críticos...</p>;

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={onAdd}><PlusCircle className="mr-2 h-4 w-4" /> Añadir Activo</Button>
      </div>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Activo</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>RTO Actual</TableHead>
              <TableHead>RPO Actual</TableHead>
              <TableHead>Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data && data.length > 0 ? (
              data.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.asset_name}</TableCell>
                  <TableCell>{item.asset_type}</TableCell>
                  <TableCell>{item.rto_actual}</TableCell>
                  <TableCell>{item.rpo_actual}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="icon" onClick={() => onEdit(item)}><Edit className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => onDelete(item)}><Trash2 className="h-4 w-4 text-red-500" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan="5" className="text-center">No hay activos críticos registrados.</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default CriticalAssetsBcSection;