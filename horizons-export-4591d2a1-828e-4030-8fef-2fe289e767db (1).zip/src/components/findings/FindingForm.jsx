import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';

const findingTypes = ['No Conformidad Mayor', 'No Conformidad Menor', 'Observación', 'Oportunidad de Mejora'];
const findingStatuses = ['Abierto', 'En Progreso', 'Cerrado', 'Cancelado'];
const findingPriorities = ['Crítica', 'Alta', 'Media', 'Baja'];

const FindingForm = ({ onSubmit, onCancel, existingFinding, session, isReadOnly, isHistorical }) => {
  const [formData, setFormData] = useState({
    finding_id_custom: '',
    type: '',
    description: '',
    source: '',
    status: 'Abierto',
    priority: 'Media',
    proposed_solution: '',
    applied_solution: '',
    requirement_text: '',
    due_date: '',
    responsible: '',
    comments: '',
    evidence_id: null,
    user_id: session.user.id
  });
  const [evidenceFile, setEvidenceFile] = useState(null);

  useEffect(() => {
    if (existingFinding) {
      setFormData({
        finding_id_custom: existingFinding.finding_id_custom || '',
        type: existingFinding.type || '',
        description: existingFinding.description || '',
        source: existingFinding.source || '',
        status: existingFinding.status || 'Abierto',
        priority: existingFinding.priority || 'Media',
        proposed_solution: existingFinding.proposed_solution || '',
        applied_solution: existingFinding.applied_solution || '',
        requirement_text: existingFinding.requirement_text || '',
        due_date: existingFinding.due_date ? new Date(existingFinding.due_date).toISOString().split('T')[0] : '',
        responsible: existingFinding.responsible || '',
        comments: existingFinding.comments || '',
        evidence_id: existingFinding.evidence_id || null,
        user_id: existingFinding.user_id || session.user.id
      });
    } else {
       setFormData({
        finding_id_custom: '',
        type: '',
        description: '',
        source: '',
        status: 'Abierto',
        priority: 'Media',
        proposed_solution: '',
        applied_solution: '',
        requirement_text: '',
        due_date: '',
        responsible: '',
        comments: '',
        evidence_id: null,
        user_id: session.user.id
      });
    }
  }, [existingFinding, session.user.id]);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };
  
  const handleSelectChange = (id, value) => {
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const handleFileChange = (e) => {
    setEvidenceFile(e.target.files[0] || null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isReadOnly) return;
    onSubmit(formData, evidenceFile);
  };

  const gridClass = "grid grid-cols-1 md:grid-cols-2 gap-4";
  
  return (
    <ScrollArea className="max-h-[75vh] p-4">
      <form onSubmit={handleSubmit} className="space-y-6 p-1">
        <div className={gridClass}>
          <div className="space-y-2">
            <Label htmlFor="finding_id_custom">ID Hallazgo (Personalizado)</Label>
            <Input id="finding_id_custom" value={formData.finding_id_custom} onChange={handleChange} placeholder="Ej: AUDIT-2024-001" disabled={isReadOnly} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="type">Tipo / Criticidad</Label>
            <Select onValueChange={(value) => handleSelectChange('type', value)} value={formData.type} disabled={isReadOnly}>
              <SelectTrigger><SelectValue placeholder="Seleccionar tipo..." /></SelectTrigger>
              <SelectContent>{findingTypes.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Título / Descripción</Label>
          <Textarea id="description" value={formData.description} onChange={handleChange} required rows={3} disabled={isReadOnly} />
        </div>

        <div className={gridClass}>
          <div className="space-y-2">
            <Label htmlFor="requirement_text">Requisito Afectado</Label>
            <Input id="requirement_text" value={formData.requirement_text} onChange={handleChange} placeholder="Ej: ISO 27001 A.5.1" disabled={isReadOnly} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="source">Alcance / Fuente</Label>
            <Input id="source" value={formData.source} onChange={handleChange} placeholder="Ej: Auditoría Interna ISO 27001" disabled={isReadOnly} />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="comments">Observaciones / Comentarios</Label>
          <Textarea id="comments" value={formData.comments} onChange={handleChange} rows={3} disabled={isReadOnly} />
        </div>

        <div className="space-y-2">
          <Label htmlFor="proposed_solution">Propuesta de Solución</Label>
          <Textarea id="proposed_solution" value={formData.proposed_solution} onChange={handleChange} rows={3} disabled={isReadOnly} />
        </div>

        {isHistorical && (
          <div className="space-y-2">
            <Label htmlFor="applied_solution">Solución Aplicada (si aplica)</Label>
            <Textarea id="applied_solution" value={formData.applied_solution} onChange={handleChange} rows={3} disabled={isReadOnly} />
          </div>
        )}

        <div className={gridClass}>
          <div className="space-y-2">
            <Label htmlFor="status">Estado</Label>
            <Select onValueChange={(value) => handleSelectChange('status', value)} value={formData.status} disabled={isReadOnly}>
              <SelectTrigger><SelectValue placeholder="Seleccionar estado..." /></SelectTrigger>
              <SelectContent>{findingStatuses.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="priority">Prioridad</Label>
            <Select onValueChange={(value) => handleSelectChange('priority', value)} value={formData.priority} disabled={isReadOnly}>
              <SelectTrigger><SelectValue placeholder="Seleccionar prioridad..." /></SelectTrigger>
              <SelectContent>{findingPriorities.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>

        <div className={gridClass}>
          <div className="space-y-2">
            <Label htmlFor="responsible">Responsable de Solución</Label>
            <Input id="responsible" value={formData.responsible} onChange={handleChange} placeholder="Email o nombre del responsable" disabled={isReadOnly} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="due_date">Fecha Límite de Solución</Label>
            <Input id="due_date" type="date" value={formData.due_date} onChange={handleChange} disabled={isReadOnly} />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="evidenceFile">Adjuntar Evidencia</Label>
          <Input id="evidenceFile" type="file" onChange={handleFileChange} disabled={isReadOnly} />
          {existingFinding?.evidence_id && !evidenceFile && <p className="text-xs text-gray-500 mt-1">Hay una evidencia adjunta. Subir un nuevo fichero la reemplazará.</p>}
        </div>

        <div className="flex justify-end space-x-2 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
          {!isReadOnly && <Button type="submit">{existingFinding ? 'Guardar Cambios' : 'Crear Hallazgo'}</Button>}
        </div>
      </form>
    </ScrollArea>
  );
};

export default FindingForm;