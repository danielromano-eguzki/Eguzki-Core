import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';

const FindingDetailsModal = ({ finding, isOpen, onOpenChange, session, getEvidenceUrl }) => {
  const [evidenceUrl, setEvidenceUrl] = useState(null);
  const [evidenceName, setEvidenceName] = useState(null);

  useEffect(() => {
    const fetchEvidenceUrl = async () => {
      if (finding?.evidence_id && getEvidenceUrl) {
        // This is a placeholder. The actual evidence object needs to be fetched.
        // For now, we assume we can't get the URL and show a message.
        // This part needs to be connected to the evidences hook properly.
        setEvidenceName("Fichero adjunto"); // Placeholder
      } else {
        setEvidenceUrl(null);
        setEvidenceName(null);
      }
    };
    fetchEvidenceUrl();
  }, [finding, getEvidenceUrl]);


  if (!finding) return null;
  
  const ownerEmail = finding.user_id === session?.user?.id ? session?.user?.email : 'Otro Usuario';

  const DetailItem = ({ label, value, children }) => (
    <div>
      <p className="text-sm font-semibold text-gray-600">{label}</p>
      <div className="text-sm text-gray-800 pl-2">{children || value || <span className="italic text-gray-500">N/A</span>}</div>
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader><DialogTitle>Detalles del Hallazgo: {finding.finding_id_custom || finding.id.substring(0,8)}</DialogTitle></DialogHeader>
        <div className="space-y-4 py-4 max-h-[70vh] overflow-y-auto text-sm">
          <DetailItem label="Tipo / Criticidad" value={finding.type} />
          <DetailItem label="Título / Descripción" value={finding.description} />
          <DetailItem label="Estado" value={finding.status} />
          <DetailItem label="Prioridad" value={finding.priority} />
          <DetailItem label="Alcance / Fuente" value={finding.source} />
          <DetailItem label="Requisito Afectado" value={finding.requirement_text} />
          <DetailItem label="Observaciones / Comentarios" value={finding.comments} />
          <DetailItem label="Propuesta de Solución" value={finding.proposed_solution} />
          <DetailItem label="Solución Aplicada" value={finding.applied_solution} />
          <DetailItem label="Responsable de Solución" value={finding.responsible} />
          <DetailItem label="Fecha de Resolución (Límite)" value={finding.due_date ? new Date(finding.due_date).toLocaleDateString() : 'N/A'} />
          <DetailItem label="Evidencia">
            {finding.evidence_id ? (
              <span className="italic text-gray-500">Funcionalidad de descarga pendiente</span>
            ) : (
              <span className="italic text-gray-500">Sin evidencia adjunta</span>
            )}
          </DetailItem>
          <DetailItem label="Creador" value={ownerEmail} />
          <DetailItem label="Creado" value={new Date(finding.created_at).toLocaleString()} />
          <DetailItem label="Actualizado" value={new Date(finding.updated_at).toLocaleString()} />
        </div>
        <DialogFooter><Button onClick={() => onOpenChange(false)}>Cerrar</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default FindingDetailsModal;