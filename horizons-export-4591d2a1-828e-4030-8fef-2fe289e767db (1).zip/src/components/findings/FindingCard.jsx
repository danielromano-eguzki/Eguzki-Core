import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ClipboardList, AlertTriangle, AlertCircle, Lightbulb, Edit3, Trash2, Eye, Archive } from 'lucide-react';

const getIconAndColor = (type) => {
  switch (type) {
    case 'No Conformidad Mayor': return { icon: <AlertTriangle className="text-red-500" />, color: 'border-l-red-500', bgColor: 'bg-red-50' };
    case 'No Conformidad Menor': return { icon: <AlertCircle className="text-orange-500" />, color: 'border-l-orange-500', bgColor: 'bg-orange-50' };
    case 'Observación': return { icon: <ClipboardList className="text-blue-500" />, color: 'border-l-blue-500', bgColor: 'bg-blue-50' };
    case 'Oportunidad de Mejora': return { icon: <Lightbulb className="text-primary" />, color: 'border-l-primary', bgColor: 'bg-green-50' };
    default: return { icon: <ClipboardList className="text-gray-500" />, color: 'border-l-gray-500', bgColor: 'bg-gray-50' };
  }
};

const formatDate = (dateString) => dateString ? new Date(dateString).toLocaleDateString() : 'N/A';

const FindingCard = ({ finding, onEdit, onDelete, onArchive, onShowDetails, index, isReadOnly }) => {
  const { icon, color, bgColor } = getIconAndColor(finding.type);
  
  return (
    <motion.div
      key={finding.id}
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className={`rounded-lg p-5 shadow-md border-l-4 ${color} ${bgColor} hover:shadow-xl transition-shadow duration-300 flex flex-col`}
    >
      <div className="flex-grow">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-2">
          <div className="flex items-center mb-2 sm:mb-0">
            {icon}
            <h3 className="text-lg font-semibold ml-3 text-gray-800">{finding.finding_id_custom || finding.id.substring(0,8)}</h3>
          </div>
          <span className={`px-2.5 py-0.5 text-xs font-semibold rounded-full ${
            finding.status === 'Abierto' ? 'bg-red-200 text-red-800' :
            finding.status === 'En Progreso' ? 'bg-yellow-200 text-yellow-800' :
            finding.status === 'Cerrado' ? 'bg-green-200 text-primary' :
            'bg-gray-200 text-gray-800'
          }`}>
            {finding.status}
          </span>
        </div>
        <p className="text-gray-700 mb-1 text-sm line-clamp-2"><strong className="font-medium">Descripción:</strong> {finding.description}</p>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-gray-600 mb-3">
          <p><strong className="font-medium">Tipo:</strong> {finding.type}</p>
          <p><strong className="font-medium">Prioridad:</strong> {finding.priority}</p>
          <p><strong className="font-medium">Fuente:</strong> {finding.source || 'N/A'}</p>
          <p><strong className="font-medium">Responsable:</strong> {finding.responsible || 'N/A'}</p>
          <p><strong className="font-medium">Límite:</strong> {formatDate(finding.due_date)}</p>
          <p><strong className="font-medium">Creado:</strong> {formatDate(finding.created_at)}</p>
        </div>
      </div>
      <div className="flex justify-end space-x-1 mt-3">
        <Button variant="ghost" size="sm" onClick={() => onShowDetails(finding)} className="text-blue-600 hover:text-blue-700"><Eye className="w-4 h-4 mr-1" />Detalles</Button>
        {!isReadOnly && (
          <>
            {onArchive && <Button variant="ghost" size="sm" onClick={() => onArchive(finding)} className="text-gray-600 hover:text-gray-700"><Archive className="w-4 h-4 mr-1" />Archivar</Button>}
            <Button variant="ghost" size="sm" onClick={() => onEdit(finding)} className="text-gray-600 hover:text-gray-700"><Edit3 className="w-4 h-4 mr-1" />Editar</Button>
            <Button variant="ghost" size="sm" onClick={() => onDelete(finding)} className="text-red-500 hover:text-red-600"><Trash2 className="w-4 h-4 mr-1" />Eliminar</Button>
          </>
        )}
      </div>
    </motion.div>
  );
};

export default FindingCard;