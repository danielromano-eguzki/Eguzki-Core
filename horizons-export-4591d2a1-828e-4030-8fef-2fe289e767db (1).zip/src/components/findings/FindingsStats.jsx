import React, { useMemo } from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

const findingTypes = ['No Conformidad Mayor', 'No Conformidad Menor', 'Observación', 'Oportunidad de Mejora'];
const findingStatuses = ['Abierto', 'En Progreso', 'Cerrado', 'Cancelado'];

const FindingsStats = ({ findings }) => {
  const findingsByTypeChartData = useMemo(() => {
    const counts = findingTypes.reduce((acc, type) => ({ ...acc, [type]: 0 }), {});
    (findings || []).forEach(f => { if (counts[f.type] !== undefined) counts[f.type]++; });
    return {
      labels: findingTypes,
      datasets: [{
        label: 'Findings por Tipo',
        data: findingTypes.map(type => counts[type]),
        backgroundColor: [
          'rgba(239, 68, 68, 0.7)', 
          'rgba(249, 115, 22, 0.7)', 
          'rgba(59, 130, 246, 0.7)', 
          'rgba(36, 52, 48, 0.7)', 
        ],
        borderColor: [
          'rgba(239, 68, 68, 1)',
          'rgba(249, 115, 22, 1)',
          'rgba(59, 130, 246, 1)',
          'rgba(36, 52, 48, 1)',
        ],
        borderWidth: 1
      }]
    };
  }, [findings]);

  const findingsByStatusChartData = useMemo(() => {
    const counts = findingStatuses.reduce((acc, status) => ({ ...acc, [status]: 0 }), {});
    (findings || []).forEach(f => { if (counts[f.status] !== undefined) counts[f.status]++; });
    return {
      labels: findingStatuses,
      datasets: [{
        label: 'Findings por Estado',
        data: findingStatuses.map(status => counts[status]),
        backgroundColor: [
          'rgba(239, 68, 68, 0.7)', 
          'rgba(245, 158, 11, 0.7)',
          'rgba(36, 52, 48, 0.7)', 
          'rgba(107, 114, 128, 0.7)',
        ],
        hoverOffset: 4
      }]
    };
  }, [findings]);

  const chartOptions = { 
    responsive: true, 
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        font: { size: 14 }
      }
    }
   };
  
   const doughnutOptions = { ...chartOptions, plugins: { ...chartOptions.plugins, title: { ...chartOptions.plugins.title, text: 'Findings por Estado' }}};
   const barOptions = { ...chartOptions, plugins: { ...chartOptions.plugins, title: { ...chartOptions.plugins.title, text: 'Findings por Tipo' }}};


  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
      <div className="bg-white/70 backdrop-blur-lg p-4 rounded-lg shadow-md h-64 md:h-80">
        <Bar options={barOptions} data={findingsByTypeChartData} />
      </div>
      <div className="bg-white/70 backdrop-blur-lg p-4 rounded-lg shadow-md h-64 md:h-80 flex justify-center items-center">
        <div className="w-full h-full max-w-[300px] max-h-[300px]">
          <Doughnut options={doughnutOptions} data={findingsByStatusChartData} />
        </div>
      </div>
    </div>
  );
};

export default FindingsStats;