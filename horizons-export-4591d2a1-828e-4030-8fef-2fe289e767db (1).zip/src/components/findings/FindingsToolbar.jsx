import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Filter } from 'lucide-react';

const FindingsToolbar = ({ searchTerm, onSearchChange, viewMode, onViewModeChange, onFilterClick }) => {
  return (
    <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-4">
      <div className="relative flex-grow w-full md:w-auto">
        <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        <Input 
          type="text" 
          placeholder="Buscar findings..." 
          className="pl-10 pr-4 py-2 w-full bg-white/80" 
          value={searchTerm} 
          onChange={(e) => onSearchChange(e.target.value)} 
        />
      </div>
      <div className="flex gap-2">
         <Button 
           variant={viewMode === 'cards' ? 'default' : 'outline'} 
           onClick={() => onViewModeChange('cards')}
         >
           Vista Tarjetas
         </Button>
         <Button 
           variant={viewMode === 'table' ? 'default' : 'outline'} 
           onClick={() => onViewModeChange('table')}
         >
           Vista Tabla
         </Button>
         <Button variant="outline" onClick={onFilterClick}>
           <Filter className="w-5 h-5 mr-2" /> Filtros
         </Button>
      </div>
    </div>
  );
};

export default FindingsToolbar;