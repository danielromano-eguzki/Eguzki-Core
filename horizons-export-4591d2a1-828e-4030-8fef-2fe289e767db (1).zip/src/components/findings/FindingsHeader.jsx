import React from 'react';
import { Button } from '@/components/ui/button';
import { ClipboardList, PlusCircle } from 'lucide-react';

const FindingsHeader = ({ onNewFindingClick }) => {
  return (
    <div className="flex flex-col md:flex-row justify-between items-center gap-4">
      <h2 className="text-3xl font-bold text-gray-900 flex items-center">
        <ClipboardList className="w-8 h-8 mr-3 text-gradient" />
        Gestión de Findings
      </h2>
      <Button onClick={onNewFindingClick}>
        <PlusCircle className="w-5 h-5 mr-2" /> Nuevo Finding
      </Button>
    </div>
  );
};

export default FindingsHeader;