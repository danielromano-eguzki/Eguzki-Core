import React from 'react';
import { Button } from '@/components/ui/button';
import { Edit3, Trash2, Eye, Archive } from 'lucide-react';

const FindingsTable = ({ findings, onEdit, onDelete, onArchive, onShowDetails, isReadOnly }) => {

  const formatDate = (dateString) => dateString ? new Date(dateString).toLocaleDateString() : 'N/A';
  
  const getStatusBadge = (status) => {
     switch(status) {
        case 'Abierto': return 'bg-red-100 text-red-800';
        case 'En Progreso': return 'bg-yellow-100 text-yellow-800';
        case 'Cerrado': return 'bg-green-100 text-primary';
        default: return 'bg-gray-100 text-gray-800';
     }
  };

  return (
    <div className="bg-white/70 backdrop-blur-lg shadow-lg rounded-xl overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200/50">
        <thead className="bg-gradient-to-r from-primary/10 to-teal-500/10">
          <tr>
            <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">ID</th>
            <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Tipo</th>
            <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Descripción</th>
            <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Estado</th>
            <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Responsable</th>
            <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Fecha Límite</th>
            <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Acciones</th>
          </tr>
        </thead>
        <tbody className="bg-white/50 divide-y divide-gray-200/30">
          {findings.map((finding) => (
            <tr key={finding.id} className="hover:bg-primary/5 transition-colors">
              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-700 font-medium">{finding.finding_id_custom || finding.id.substring(0,8)}</td>
              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-700">{finding.type}</td>
              <td className="px-4 py-3 text-sm text-gray-700 max-w-xs truncate" title={finding.description}>{finding.description}</td>
              <td className="px-4 py-3 whitespace-nowrap text-sm">
                 <span className={`px-2.5 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadge(finding.status)}`}>
                  {finding.status}
                </span>
              </td>
              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-700">{finding.responsible || 'N/A'}</td>
              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-700">{finding.status === 'Cerrado' ? formatDate(finding.updated_at) : formatDate(finding.due_date)}</td>
              <td className="px-4 py-3 whitespace-nowrap text-sm font-medium">
                <div className="flex items-center space-x-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600 hover:text-blue-700" onClick={() => onShowDetails(finding)}><Eye className="w-4 h-4" /></Button>
                  {!isReadOnly && (
                    <>
                      {onArchive && <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-600 hover:text-gray-700" onClick={() => onArchive(finding)}><Archive className="w-4 h-4" /></Button>}
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-600 hover:text-gray-700" onClick={() => onEdit(finding)}><Edit3 className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500 hover:text-red-600" onClick={() => onDelete(finding)}><Trash2 className="w-4 h-4" /></Button>
                    </>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default FindingsTable;