import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PlusCircle, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const AuditRequirements = ({ hook, programId, isReadOnly }) => {
  const { requirements, addRequirement, deleteRequirement } = hook;
  const [newRequirement, setNewRequirement] = useState('');

  const handleAddRequirement = () => {
    if (newRequirement.trim() && !isReadOnly) {
      addRequirement(programId, newRequirement);
      setNewRequirement('');
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Requisitos de la Auditoría</CardTitle>
      </CardHeader>
      <CardContent>
        {!isReadOnly && (
          <div className="flex gap-2 mb-4">
            <Input
              placeholder="Añadir nuevo requisito a auditar..."
              value={newRequirement}
              onChange={(e) => setNewRequirement(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAddRequirement()}
            />
            <Button onClick={handleAddRequirement}><PlusCircle className="w-4 h-4 mr-2" />Añadir</Button>
          </div>
        )}
        <ul className="space-y-2">
          <AnimatePresence>
            {requirements.map((req, index) => (
              <motion.li
                key={req.id}
                layout
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ delay: index * 0.05 }}
                className="flex justify-between items-center p-3 bg-slate-50 rounded-md"
              >
                <p>{req.requirement_text}</p>
                {!isReadOnly && (
                  <Button size="icon" variant="ghost" className="h-8 w-8 text-red-600" onClick={() => deleteRequirement(req.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </motion.li>
            ))}
          </AnimatePresence>
        </ul>
      </CardContent>
    </Card>
  );
};

export default AuditRequirements;