import React from 'react';
import { motion } from 'framer-motion';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Edit3, Trash2, Download, Link as LinkIcon, UploadCloud } from 'lucide-react';

const AuditSectionItemCard = ({ 
  item, 
  onToggleComplete, 
  onEdit, 
  onDelete, 
  onFileUpload, 
  onDownloadFile,
  showToast,
  isReadOnly
}) => {
  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      onFileUpload(item, e.target.files[0]);
    }
  };

  return (
    <motion.li 
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex items-start p-3 bg-slate-50/50 rounded-md border border-slate-200/80 hover:shadow-md transition-shadow"
    >
      <Checkbox 
        id={`item-${item.id}`} 
        checked={!!item.is_completed} 
        onCheckedChange={() => onToggleComplete(item, null)} 
        className="mr-3 mt-1 flex-shrink-0"
        disabled={isReadOnly}
      />
      <div className="flex-grow">
        <Label 
          htmlFor={`item-${item.id}`} 
          className={`font-medium ${item.is_completed ? 'line-through text-gray-500' : 'text-gray-700'}`}
        >
          {item.title}
        </Label>
        {item.description && <p className="text-xs text-gray-500">{item.description}</p>}
        
        {item.item_type === 'document' && (
          <div className="mt-2 flex items-center gap-2 flex-wrap">
            {item.file_path ? (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => onDownloadFile(item.file_path, item.file_name)}
              >
                <Download className="w-3 h-3 mr-1.5" /> {item.file_name || 'Descargar'}
              </Button>
            ) : <span className="text-xs text-orange-500">Pendiente de adjuntar</span>}
            {!isReadOnly && (
              <>
                <Label htmlFor={`file-upload-${item.id}`} className="text-xs cursor-pointer text-blue-600 hover:underline flex items-center">
                  <UploadCloud className="w-3 h-3 mr-1" /> {item.file_path ? 'Reemplazar Archivo' : 'Adjuntar Archivo'}
                </Label>
                <Input id={`file-upload-${item.id}`} type="file" className="hidden" onChange={handleFileChange} disabled={isReadOnly} />
              </>
            )}
          </div>
        )}
        {item.item_type === 'link' && item.link_url && (
          <a 
            href={item.link_url.startsWith('http') ? item.link_url : `https://${item.link_url}`} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="mt-1 text-xs text-blue-600 hover:underline flex items-center"
          >
            <LinkIcon className="w-3 h-3 mr-1" />{item.link_url}
          </a>
        )}
          {item.item_type === 'template_download' && item.template_key && (
            <Button 
              variant="link" 
              size="sm" 
              onClick={() => showToast("Descarga de Plantilla", `Funcionalidad para descargar plantilla '${item.template_key}' no implementada. Para usarla, puedes añadir un ítem de tipo 'documento' y subir tu plantilla una vez completada.`)} 
              className="p-0 h-auto text-xs mt-1 text-blue-600"
            >
              <Download className="w-3 h-3 mr-1" /> Descargar Plantilla ({item.template_key})
            </Button>
        )}
      </div>
      {!isReadOnly && (
        <div className="flex-shrink-0 ml-2 flex items-center">
          <Button variant="ghost" size="icon" className="h-7 w-7 text-gray-600 hover:text-blue-600" onClick={() => onEdit(item)}>
            <Edit3 className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7 text-gray-600 hover:text-red-600" onClick={() => onDelete(item)}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      )}
    </motion.li>
  );
};

export default AuditSectionItemCard;