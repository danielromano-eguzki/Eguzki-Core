import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from '@/components/ui/textarea';
import { motion } from 'framer-motion';

const complianceStatusOptions = ['Cumple', 'No Cumple', 'Parcialmente Cumple', 'No Aplica'];

const getStatusColor = (status) => {
  switch (status) {
    case 'Cumple': return 'bg-green-100 text-green-800';
    case 'No Cumple': return 'bg-red-100 text-red-800';
    case 'Parcialmente Cumple': return 'bg-yellow-100 text-yellow-800';
    case 'No Aplica': return 'bg-gray-100 text-gray-800';
    default: return 'bg-white';
  }
};

const AuditComplianceAnalysis = ({ hook, programId, evidences, isReadOnly }) => {
  const { requirements, compliance, upsertCompliance } = hook;

  const handleUpdate = (requirementId, field, value) => {
    if (isReadOnly) return;
    const existingEntry = compliance.find(c => c.requirement_id === requirementId) || {};
    const updatedEntry = {
      ...existingEntry,
      audit_program_id: programId,
      requirement_id: requirementId,
      [field]: value,
    };
    upsertCompliance(updatedEntry);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Análisis de Cumplimiento</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto rounded-lg border">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left font-medium text-gray-600 w-2/5">Requisito</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600 w-1/5">Evidencia</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600 w-1/5">Estado</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600 w-1/5">Notas</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {requirements.map((req, index) => {
                const complianceEntry = compliance.find(c => c.requirement_id === req.id) || {};
                return (
                  <motion.tr
                    key={req.id}
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: index * 0.02 }}
                  >
                    <td className="px-4 py-3 align-top">{req.requirement_text}</td>
                    <td className="px-4 py-3 align-top">
                      <Select
                        value={complianceEntry.evidence_id || ''}
                        onValueChange={(value) => handleUpdate(req.id, 'evidence_id', value === 'none' ? null : value)}
                        disabled={isReadOnly}
                      >
                        <SelectTrigger><SelectValue placeholder="Asociar..." /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Sin evidencia</SelectItem>
                          {evidences.map(e => (
                            <SelectItem key={e.id} value={e.id}>{e.nombre}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="px-4 py-3 align-top">
                      <Select
                        value={complianceEntry.compliance_status || ''}
                        onValueChange={(value) => handleUpdate(req.id, 'compliance_status', value)}
                        disabled={isReadOnly}
                      >
                        <SelectTrigger className={getStatusColor(complianceEntry.compliance_status)}>
                          <SelectValue placeholder="Evaluar..." />
                        </SelectTrigger>
                        <SelectContent>
                          {complianceStatusOptions.map(status => (
                            <SelectItem key={status} value={status}>{status}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="px-4 py-3 align-top">
                      <Textarea
                        placeholder="Añadir notas..."
                        value={complianceEntry.notes || ''}
                        onChange={(e) => handleUpdate(req.id, 'notes', e.target.value)}
                        className="min-h-[40px]"
                        disabled={isReadOnly}
                      />
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
};

export default AuditComplianceAnalysis;