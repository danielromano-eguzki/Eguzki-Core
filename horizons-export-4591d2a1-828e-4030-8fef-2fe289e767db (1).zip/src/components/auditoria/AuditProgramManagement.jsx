import React, { useState } from 'react';
import { PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import AuditProgramForm from '@/components/auditoria/AuditProgramForm';
import ConfirmationDialog from '@/components/common/ConfirmationDialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreHorizontal } from 'lucide-react';

const AuditProgramManagement = ({
  auditPrograms,
  selectedProgramId,
  setSelectedProgramId,
  addAuditProgram,
  updateAuditProgram,
  deleteAuditProgram,
  isReadOnly,
  showToast,
}) => {
  const [isProgramModalOpen, setIsProgramModalOpen] = useState(false);
  const [editingProgram, setEditingProgram] = useState(null);
  const [programToDelete, setProgramToDelete] = useState(null);

  const handleProgramFormSubmit = async (programData) => {
    if (isReadOnly) {
      showToast("Modo de solo lectura", "Tu rol de auditor no permite realizar modificaciones.", "destructive");
      return;
    }
    let success = false;
    if (editingProgram) {
      const updated = await updateAuditProgram(editingProgram.id, programData);
      if (updated !== null) success = true;
    } else {
      const newProgram = await addAuditProgram(programData);
      if (newProgram && newProgram.id) {
        setSelectedProgramId(newProgram.id);
        success = true;
      }
    }
    if (success) {
      setIsProgramModalOpen(false);
      setEditingProgram(null);
    }
  };

  const openEditProgramModal = (program) => {
    if (isReadOnly) return;
    setEditingProgram(program);
    setIsProgramModalOpen(true);
  };
  
  const openDeleteProgramModal = (program) => {
    if (isReadOnly) return;
    setProgramToDelete(program);
  };
  
  const confirmDeleteProgram = async () => {
    if (isReadOnly) return;
    if (programToDelete) {
      await deleteAuditProgram(programToDelete.id);
      if (selectedProgramId === programToDelete.id) {
        const remainingPrograms = auditPrograms.filter(p => p.id !== programToDelete.id);
        setSelectedProgramId(remainingPrograms.length > 0 ? remainingPrograms[0].id : '');
      }
      setProgramToDelete(null);
    }
  };

  return (
    <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
      <h2 className="text-xl md:text-2xl font-semibold text-gray-800">Programas de Auditoría</h2>
      <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
        <Dialog open={isProgramModalOpen} onOpenChange={(isOpen) => { setIsProgramModalOpen(isOpen); if (!isOpen) setEditingProgram(null); }}>
          <DialogTrigger asChild>
            <Button className="w-full sm:w-auto" onClick={() => { setEditingProgram(null); setIsProgramModalOpen(true); }} disabled={isReadOnly}>
              <PlusCircle className="w-4 h-4 mr-2" /> Nuevo Programa
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader><DialogTitle>{editingProgram ? 'Editar' : 'Nuevo'} Programa de Auditoría</DialogTitle></DialogHeader>
            <AuditProgramForm onSubmit={handleProgramFormSubmit} onCancel={() => setIsProgramModalOpen(false)} existingProgram={editingProgram} />
          </DialogContent>
        </Dialog>
        {(auditPrograms || []).length > 0 && (
          <div className="flex items-center gap-1">
            <Select onValueChange={setSelectedProgramId} value={selectedProgramId || ''}>
              <SelectTrigger className="w-full sm:w-auto md:w-[250px]">
                <SelectValue placeholder="Seleccionar Programa..." />
              </SelectTrigger>
              <SelectContent>
                {(auditPrograms || []).map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
              </SelectContent>
            </Select>
            {selectedProgramId && !isReadOnly && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => openEditProgramModal(auditPrograms.find(p => p.id === selectedProgramId))}>
                    Editar Programa
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => openDeleteProgramModal(auditPrograms.find(p => p.id === selectedProgramId))} className="text-red-600">
                    Eliminar Programa
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        )}
      </div>
      <ConfirmationDialog
        open={!!programToDelete}
        onOpenChange={() => setProgramToDelete(null)}
        onConfirm={confirmDeleteProgram}
        title="¿Estás seguro?"
        description="Esta acción no se puede deshacer. Esto eliminará permanentemente el programa de auditoría y todos sus datos asociados."
      />
    </div>
  );
};

export default AuditProgramManagement;