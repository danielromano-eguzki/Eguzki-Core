import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { DialogFooter } from "@/components/ui/dialog";

const AuditProgramForm = ({ onSubmit, onCancel, existingProgram }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState('Planificado');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  useEffect(() => {
    if (existingProgram) {
      setName(existingProgram.name || '');
      setDescription(existingProgram.description || '');
      setStatus(existingProgram.status || 'Planificado');
      setStartDate(existingProgram.start_date ? existingProgram.start_date.split('T')[0] : '');
      setEndDate(existingProgram.end_date ? existingProgram.end_date.split('T')[0] : '');
    } else {
      setName('');
      setDescription('');
      setStatus('Planificado');
      setStartDate('');
      setEndDate('');
    }
  }, [existingProgram]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ 
      name, 
      description, 
      status, 
      start_date: startDate || null, 
      end_date: endDate || null 
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="program-name">Nombre del Programa</Label>
        <Input id="program-name" value={name} onChange={e => setName(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="program-desc">Descripción</Label>
        <Textarea id="program-desc" value={description} onChange={e => setDescription(e.target.value)} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="program-status">Estado</Label>
          <Select onValueChange={setStatus} value={status}>
            <SelectTrigger id="program-status">
              <SelectValue placeholder="Seleccionar estado..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Planificado">Planificado</SelectItem>
              <SelectItem value="En Progreso">En Progreso</SelectItem>
              <SelectItem value="Completado">Completado</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="program-start">Fecha Inicio</Label>
          <Input id="program-start" type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
        </div>
        <div>
          <Label htmlFor="program-end">Fecha Fin</Label>
          <Input id="program-end" type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
        </div>
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{existingProgram ? 'Actualizar Programa' : 'Crear Programa'}</Button>
      </DialogFooter>
    </form>
  );
};

export default AuditProgramForm;