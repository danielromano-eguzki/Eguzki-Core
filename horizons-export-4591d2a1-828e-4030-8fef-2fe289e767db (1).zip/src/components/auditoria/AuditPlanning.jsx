import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { PlusCircle, Trash2, Edit, Users, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import ConfirmationDialog from '@/components/common/ConfirmationDialog';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';

const AuditPlanning = ({ hook, programId, isReadOnly }) => {
  const { planning, addPlanningEntry, deletePlanningEntry, meetings, addMeeting, updateMeeting, deleteMeeting } = hook;

  const [newResponsible, setNewResponsible] = useState('');
  const [newDepartment, setNewDepartment] = useState('');

  const [isMeetingModalOpen, setIsMeetingModalOpen] = useState(false);
  const [editingMeeting, setEditingMeeting] = useState(null);
  const [meetingToDelete, setMeetingToDelete] = useState(null);

  const handleAddPlanningEntry = async () => {
    if ((newResponsible.trim() || newDepartment.trim()) && !isReadOnly) {
      await addPlanningEntry(programId, { responsible_person: newResponsible, department: newDepartment });
      setNewResponsible('');
      setNewDepartment('');
    }
  };

  const handleMeetingFormSubmit = async (e) => {
    e.preventDefault();
    if (isReadOnly) return;
    const formData = new FormData(e.target);
    const meetingData = {
      meeting_date: formData.get('meeting_date'),
      attendees: formData.get('attendees'),
      notes: formData.get('notes'),
    };

    if (editingMeeting) {
      await updateMeeting(editingMeeting.id, meetingData);
    } else {
      await addMeeting(programId, meetingData);
    }
    setIsMeetingModalOpen(false);
    setEditingMeeting(null);
  };

  const openEditMeetingModal = (meeting) => {
    setEditingMeeting(meeting);
    setIsMeetingModalOpen(true);
  };

  const confirmDeleteMeeting = () => {
    if (meetingToDelete && !isReadOnly) {
      deleteMeeting(meetingToDelete.id);
      setMeetingToDelete(null);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Users className="w-5 h-5" /> Responsables y Departamentos</CardTitle>
        </CardHeader>
        <CardContent>
          {!isReadOnly && (
            <div className="flex flex-col sm:flex-row gap-2 mb-4">
              <Input placeholder="Responsable..." value={newResponsible} onChange={(e) => setNewResponsible(e.target.value)} />
              <Input placeholder="Departamento..." value={newDepartment} onChange={(e) => setNewDepartment(e.target.value)} />
              <Button onClick={handleAddPlanningEntry} className="flex-shrink-0"><PlusCircle className="w-4 h-4 mr-2" />Añadir</Button>
            </div>
          )}
          <ul className="space-y-2">
            <AnimatePresence>
              {planning.map(p => (
                <motion.li
                  key={p.id}
                  layout
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="flex justify-between items-center p-2 bg-slate-50 rounded-md"
                >
                  <span><strong>{p.responsible_person}</strong> ({p.department || 'Sin departamento'})</span>
                  {!isReadOnly && (
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-red-600" onClick={() => deletePlanningEntry(p.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </motion.li>
              ))}
            </AnimatePresence>
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2"><Calendar className="w-5 h-5" /> Calendario y Notas de Reuniones</CardTitle>
          {!isReadOnly && (
            <Button onClick={() => { setEditingMeeting(null); setIsMeetingModalOpen(true); }}>
              <PlusCircle className="w-4 h-4 mr-2" /> Nueva Reunión
            </Button>
          )}
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            <AnimatePresence>
              {meetings.map(m => (
                <motion.li
                  key={m.id}
                  layout
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="p-3 bg-slate-50 rounded-md border"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-bold">{new Date(m.meeting_date).toLocaleDateString()}</p>
                      <p className="text-sm text-gray-600"><strong>Asistentes:</strong> {m.attendees}</p>
                    </div>
                    {!isReadOnly && (
                      <div className="flex gap-1">
                        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEditMeetingModal(m)}><Edit className="w-4 h-4" /></Button>
                        <Button size="icon" variant="ghost" className="h-8 w-8 text-red-600" onClick={() => setMeetingToDelete(m)}><Trash2 className="w-4 h-4" /></Button>
                      </div>
                    )}
                  </div>
                  <p className="text-sm mt-2 whitespace-pre-wrap">{m.notes}</p>
                </motion.li>
              ))}
            </AnimatePresence>
          </ul>
        </CardContent>
      </Card>

      <Dialog open={isMeetingModalOpen} onOpenChange={setIsMeetingModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingMeeting ? 'Editar' : 'Nueva'} Reunión</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleMeetingFormSubmit} className="space-y-4 pt-4">
            <div>
              <Label htmlFor="meeting_date">Fecha</Label>
              <Input id="meeting_date" name="meeting_date" type="datetime-local" defaultValue={editingMeeting?.meeting_date ? editingMeeting.meeting_date.slice(0,16) : ''} required />
            </div>
            <div>
              <Label htmlFor="attendees">Asistentes</Label>
              <Input id="attendees" name="attendees" defaultValue={editingMeeting?.attendees} placeholder="Nombres separados por comas" />
            </div>
            <div>
              <Label htmlFor="notes">Notas</Label>
              <Textarea id="notes" name="notes" defaultValue={editingMeeting?.notes} rows={5} />
            </div>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setIsMeetingModalOpen(false)}>Cancelar</Button>
              <Button type="submit">{editingMeeting ? 'Guardar Cambios' : 'Añadir Reunión'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      <ConfirmationDialog
        open={!!meetingToDelete}
        onOpenChange={() => setMeetingToDelete(null)}
        onConfirm={confirmDeleteMeeting}
        title="¿Confirmar eliminación?"
        description="Esta acción eliminará permanentemente la nota de la reunión."
      />
    </div>
  );
};

export default AuditPlanning;