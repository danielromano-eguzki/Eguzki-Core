import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronUp, PlusCircle } from 'lucide-react';
import AuditSectionItemCard from '@/components/auditoria/AuditSectionItemCard';

const AuditSectionCard = ({ 
  section, 
  sectionConfig, 
  items, 
  onAddItem,
  onToggleCompleteItem,
  onEditItem,
  onDeleteItem,
  onFileUploadItem,
  onDownloadFileItem,
  showToast,
  isReadOnly
}) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const Icon = sectionConfig?.icon;

  return (
    <motion.div layout className="bg-white/70 backdrop-blur-lg rounded-xl p-4 md:p-6 border border-white/20 shadow-lg">
      <div 
        className="flex justify-between items-center cursor-pointer mb-3" 
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center text-green-600">
          {Icon && <Icon className="w-6 h-6 md:w-7 md:h-7 mr-3" />}
          <h3 className="text-lg md:text-xl font-semibold text-gray-800">{section.title}</h3>
        </div>
        {isExpanded ? <ChevronUp className="w-5 h-5 text-gray-600" /> : <ChevronDown className="w-5 h-5 text-gray-600" />}
      </div>
      
      {isExpanded && (
        <motion.div 
          initial={{ opacity: 0, height: 0 }} 
          animate={{ opacity: 1, height: 'auto' }} 
          exit={{ opacity: 0, height: 0 }} 
          className="overflow-hidden"
        >
          {sectionConfig?.description && <p className="text-gray-600 text-sm mb-4">{sectionConfig.description}</p>}
          {items && items.length > 0 ? (
            <ul className="space-y-3 mb-4">
              {items.map(item => (
                <AuditSectionItemCard 
                  key={item.id}
                  item={item}
                  onToggleComplete={onToggleCompleteItem}
                  onEdit={onEditItem}
                  onDelete={onDeleteItem}
                  onFileUpload={onFileUploadItem}
                  onDownloadFile={onDownloadFileItem}
                  showToast={showToast}
                  isReadOnly={isReadOnly}
                />
              ))}
            </ul>
          ) : (
            <p className="text-sm text-gray-500 mb-4 italic">No hay ítems en esta sección todavía.</p>
          )}
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onAddItem(section.id)}
            className="border-gray-300 hover:border-green-500"
            disabled={isReadOnly}
          >
            <PlusCircle className="w-4 h-4 mr-2" /> Añadir Ítem a "{section.title}"
          </Button>
        </motion.div>
      )}
    </motion.div>
  );
};

export default AuditSectionCard;