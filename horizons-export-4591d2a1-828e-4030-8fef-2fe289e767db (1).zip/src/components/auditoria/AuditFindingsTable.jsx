import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Edit, Trash2, Search, Filter } from 'lucide-react';
import ConfirmationDialog from '@/components/common/ConfirmationDialog';

const priorityOptions = ['Baja', 'Media', 'Alta', 'Crítica'];
const statusOptions = ['Abierto', 'En Progreso', 'Resuelto', 'Cerrado'];

const getPriorityBadge = (priority) => {
  switch (priority) {
    case 'Crítica': return 'bg-red-600 text-white';
    case 'Alta': return 'bg-red-200 text-red-800';
    case 'Media': return 'bg-yellow-200 text-yellow-800';
    case 'Baja': return 'bg-blue-200 text-blue-800';
    default: return 'bg-gray-200 text-gray-800';
  }
};

const getStatusBadge = (status) => {
    switch (status) {
      case 'Abierto': return 'bg-red-100 text-red-800';
      case 'En Progreso': return 'bg-yellow-100 text-yellow-800';
      case 'Resuelto': return 'bg-blue-100 text-blue-800';
      case 'Cerrado': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
};

const AuditFindingsTable = ({ findings, onEditFinding, onDeleteFinding, isReadOnly }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [findingToDelete, setFindingToDelete] = useState(null);

  const filteredFindings = useMemo(() => {
    return (findings || []).filter(finding => {
      const matchesSearch = finding.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            (finding.control?.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                            (finding.control?.control_id_ext || '').toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = !statusFilter || finding.status === statusFilter;
      const matchesPriority = !priorityFilter || finding.priority === priorityFilter;
      return matchesSearch && matchesStatus && matchesPriority;
    });
  }, [findings, searchTerm, statusFilter, priorityFilter]);

  const handleDeleteClick = (finding) => {
    if (isReadOnly) return;
    setFindingToDelete(finding);
  };

  const confirmDelete = () => {
    if (findingToDelete) {
      onDeleteFinding(findingToDelete.id);
      setFindingToDelete(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar por descripción o control..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value === 'all' ? '' : value)}>
          <SelectTrigger className="w-full md:w-[180px]"><SelectValue placeholder="Filtrar por estado..." /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los estados</SelectItem>
            {statusOptions.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={priorityFilter} onValueChange={(value) => setPriorityFilter(value === 'all' ? '' : value)}>
          <SelectTrigger className="w-full md:w-[180px]"><SelectValue placeholder="Filtrar por prioridad..." /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas las prioridades</SelectItem>
            {priorityOptions.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="overflow-x-auto rounded-lg border">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Descripción</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Control Afectado</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Prioridad</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Estado</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Fecha Límite</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Acciones</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredFindings.map((finding, index) => (
              <motion.tr key={finding.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: index * 0.02 }}>
                <td className="px-4 py-3 align-top w-1/3"><p className="text-gray-800">{finding.description}</p></td>
                <td className="px-4 py-3 align-top">
                  {finding.control ? (
                    <div>
                      <p className="font-semibold">{finding.control.control_id_ext}</p>
                      <p className="text-gray-600 text-xs">{finding.control.name}</p>
                    </div>
                  ) : (
                    <span className="text-gray-500 italic">Manual</span>
                  )}
                </td>
                <td className="px-4 py-3 align-top">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getPriorityBadge(finding.priority)}`}>
                    {finding.priority || 'N/A'}
                  </span>
                </td>
                <td className="px-4 py-3 align-top">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusBadge(finding.status)}`}>
                        {finding.status}
                    </span>
                </td>
                <td className="px-4 py-3 align-top">{finding.due_date ? new Date(finding.due_date).toLocaleDateString() : 'N/A'}</td>
                <td className="px-4 py-3 align-top">
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onEditFinding(finding)} disabled={isReadOnly}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600" onClick={() => handleDeleteClick(finding)} disabled={isReadOnly}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </td>
              </motion.tr>
            ))}
            {filteredFindings.length === 0 && (
              <tr>
                <td colSpan="6" className="text-center py-10 text-gray-500">
                  <Filter className="w-12 h-12 mx-auto mb-2 text-gray-400" />
                  No se encontraron hallazgos con los filtros actuales.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <ConfirmationDialog
        open={!!findingToDelete}
        onOpenChange={() => setFindingToDelete(null)}
        onConfirm={confirmDelete}
        title="¿Confirmar eliminación?"
        description="Esta acción eliminará permanentemente el hallazgo. No se puede deshacer."
      />
    </div>
  );
};

export default AuditFindingsTable;