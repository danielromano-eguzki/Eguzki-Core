import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Textarea } from '@/components/ui/textarea';
import { AlertTriangle, Search, Filter } from 'lucide-react';

const complianceStatusOptions = ['Cumple', 'No Cumple', 'Parcialmente Cumple', 'No Aplica'];

const getStatusColor = (status) => {
  switch (status) {
    case 'Cumple': return 'bg-green-100 text-green-800';
    case 'No Cumple': return 'bg-red-100 text-red-800';
    case 'Parcialmente Cumple': return 'bg-yellow-100 text-yellow-800';
    case 'No Aplica': return 'bg-gray-100 text-gray-800';
    default: return 'bg-white';
  }
};

const AuditComplianceTable = ({ controls, evidences, auditComplianceData, onUpdateCompliance, auditProgramId, onCreateFinding, isReadOnly }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const filteredControls = useMemo(() => {
    return controls.filter(control => {
      const compliance = auditComplianceData.find(c => c.control_id === control.id);
      const matchesSearch = control.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            control.control_id_ext.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = !statusFilter || (compliance?.compliance_status === statusFilter);
      return matchesSearch && matchesStatus;
    });
  }, [controls, searchTerm, statusFilter, auditComplianceData]);

  const handleUpdate = (controlId, field, value) => {
    if (isReadOnly) return;
    const existingEntry = auditComplianceData.find(c => c.control_id === controlId) || {};
    const updatedEntry = {
      ...existingEntry,
      audit_program_id: auditProgramId,
      control_id: controlId,
      [field]: value,
    };
    onUpdateCompliance(updatedEntry);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar por nombre o ID de control..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex-none">
          <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value === 'all' ? '' : value)}>
            <SelectTrigger className="w-full md:w-[200px]">
              <SelectValue placeholder="Filtrar por estado..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los estados</SelectItem>
              {complianceStatusOptions.map(status => (
                <SelectItem key={status} value={status}>{status}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="overflow-x-auto rounded-lg border">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Control</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Evidencia Asociada</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Estado</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Observaciones</th>
              <th className="px-4 py-3 text-left font-medium text-gray-600">Acciones</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredControls.map((control, index) => {
              const compliance = auditComplianceData.find(c => c.control_id === control.id) || {};
              const isNonCompliant = compliance.compliance_status === 'No Cumple' || compliance.compliance_status === 'Parcialmente Cumple';
              return (
                <motion.tr 
                  key={control.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.02 }}
                  className={isNonCompliant ? 'bg-red-50/50' : ''}
                >
                  <td className="px-4 py-3 align-top w-1/4">
                    <p className="font-semibold text-gray-800">{control.control_id_ext}</p>
                    <p className="text-gray-600">{control.name}</p>
                  </td>
                  <td className="px-4 py-3 align-top w-1/4">
                    <Select
                      value={compliance.evidence_id || ''}
                      onValueChange={(value) => handleUpdate(control.id, 'evidence_id', value === 'none' ? null : value)}
                      disabled={isReadOnly}
                    >
                      <SelectTrigger><SelectValue placeholder="Asociar evidencia..." /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Sin evidencia</SelectItem>
                        {evidences.map(e => (
                          <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="px-4 py-3 align-top w-[150px]">
                    <Select
                      value={compliance.compliance_status || ''}
                      onValueChange={(value) => handleUpdate(control.id, 'compliance_status', value)}
                      disabled={isReadOnly}
                    >
                      <SelectTrigger className={getStatusColor(compliance.compliance_status)}>
                        <SelectValue placeholder="Evaluar..." />
                      </SelectTrigger>
                      <SelectContent>
                        {complianceStatusOptions.map(status => (
                          <SelectItem key={status} value={status}>{status}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="px-4 py-3 align-top w-1/3">
                    <Textarea
                      placeholder="Añadir observaciones..."
                      value={compliance.observations || ''}
                      onChange={(e) => handleUpdate(control.id, 'observations', e.target.value)}
                      className="min-h-[40px]"
                      disabled={isReadOnly}
                    />
                  </td>
                  <td className="px-4 py-3 align-top text-center">
                    {isNonCompliant && (
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => onCreateFinding(control)}
                        disabled={isReadOnly}
                      >
                        <AlertTriangle className="w-4 h-4 mr-2" />
                        Crear Finding
                      </Button>
                    )}
                  </td>
                </motion.tr>
              );
            })}
             {filteredControls.length === 0 && (
              <tr>
                <td colSpan="5" className="text-center py-10 text-gray-500">
                  <Filter className="w-12 h-12 mx-auto mb-2 text-gray-400" />
                  No se encontraron controles con los filtros actuales.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AuditComplianceTable;