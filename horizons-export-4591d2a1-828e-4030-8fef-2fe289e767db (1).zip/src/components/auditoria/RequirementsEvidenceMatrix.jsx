import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText } from 'lucide-react';

const RequirementsEvidenceMatrix = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <Card className="bg-white/70 backdrop-blur-lg border border-white/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-6 h-6 text-blue-600" />
            Matriz de Requisitos y Evidencias
          </CardTitle>
        </CardHeader>
        <CardContent className="p-8 text-center">
          <p className="text-gray-500">
            Esta sección ha sido rediseñada y ahora se encuentra en la pestaña "Requisitos y Evidencias".
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default RequirementsEvidenceMatrix;