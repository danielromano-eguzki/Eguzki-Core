import React from 'react';
import { Button } from '@/components/ui/button';

const AuditProgramQuickAccess = ({ sectionsConfig, showToast }) => {
  if (!sectionsConfig || sectionsConfig.length === 0) return null;

  return (
    <div className="mb-8 p-4 md:p-6 bg-white/50 backdrop-blur-md rounded-xl shadow-lg border border-gray-200/50">
      <h3 className="text-lg md:text-xl font-semibold text-gray-800 mb-4">Accesos Rápidos a Plantillas y Guías</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {sectionsConfig.map((section) => (
          <Button 
            key={`btn-quick-${section.key}`}
            variant="outline" 
            className="justify-start text-left h-auto py-3 px-4 border-gray-300 hover:bg-gray-100/80 hover:border-green-500 transition-all"
            onClick={() => showToast(section.title, section.originalToastMessage)}
          >
            {section.icon && <section.icon className="w-5 h-5 mr-3 text-green-600 flex-shrink-0" />}
            <div>
              <p className="font-medium text-gray-700">{section.title}</p>
              {section.description && <p className="text-xs text-gray-500">{section.description}</p>}
            </div>
          </Button>
        ))}
      </div>
    </div>
  );
};

export default AuditProgramQuickAccess;