import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { FileDown } from 'lucide-react';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

const AuditReportGenerator = ({ hook, program }) => {
  const { compliance } = hook;

  const generateReport = () => {
    if (!program) return;
    const doc = new jsPDF();
    const passed = compliance.filter(c => c.compliance_status === 'Cumple');
    const failed = compliance.filter(c => ['No Cumple', 'Parcialmente Cumple'].includes(c.compliance_status));

    doc.setFontSize(18);
    doc.text(`Informe de Auditoría: ${program.name}`, 14, 22);
    doc.setFontSize(11);
    doc.text(`Fecha de generación: ${new Date().toLocaleDateString()}`, 14, 30);

    doc.setFontSize(14);
    doc.text('Resumen de Cumplimiento', 14, 45);
    doc.autoTable({
      startY: 50,
      head: [['Estado', 'Cantidad']],
      body: [
        ['Cumple', passed.length],
        ['No Cumple / Parcialmente Cumple', failed.length],
        ['No Aplica', compliance.filter(c => c.compliance_status === 'No Aplica').length],
        ['Sin Evaluar', (hook.requirements.length - compliance.length)],
      ],
      theme: 'striped',
    });

    if (failed.length > 0) {
      doc.addPage();
      doc.setFontSize(16);
      doc.text('Hallazgos (Requisitos No Cumplidos o Parcialmente Cumplidos)', 14, 22);
      doc.autoTable({
        startY: 30,
        head: [['Requisito', 'Estado', 'Evidencia', 'Notas']],
        body: failed.map(item => [
          item.requirement?.requirement_text || 'Requisito no encontrado',
          item.compliance_status,
          item.evidence?.nombre || 'N/A',
          item.notes || ''
        ]),
        theme: 'grid',
        styles: { cellPadding: 2, fontSize: 9 },
        headStyles: { fillColor: [200, 20, 20] },
      });
    }

    if (passed.length > 0) {
      doc.addPage();
      doc.setFontSize(16);
      doc.text('Requisitos Cumplidos', 14, 22);
      doc.autoTable({
        startY: 30,
        head: [['Requisito', 'Evidencia', 'Notas']],
        body: passed.map(item => [
          item.requirement?.requirement_text || 'Requisito no encontrado',
          item.evidence?.nombre || 'N/A',
          item.notes || ''
        ]),
        theme: 'grid',
        styles: { cellPadding: 2, fontSize: 9 },
        headStyles: { fillColor: [20, 120, 70] },
      });
    }

    doc.save(`Informe_Auditoria_${program.name.replace(/\s/g, '_')}.pdf`);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Generador de Informes</CardTitle>
        <CardDescription>Crea un informe en PDF con los resultados de la auditoría.</CardDescription>
      </CardHeader>
      <CardContent className="text-center">
        <Button onClick={generateReport} size="lg" disabled={!program}>
          <FileDown className="w-5 h-5 mr-2" />
          Generar Informe de Auditoría
        </Button>
      </CardContent>
    </Card>
  );
};

export default AuditReportGenerator;