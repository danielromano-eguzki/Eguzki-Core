import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { DialogFooter } from "@/components/ui/dialog";

const AuditSectionItemForm = ({ onSubmit, onCancel, existingItem, sectionId }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [itemType, setItemType] = useState('task');
  const [linkUrl, setLinkUrl] = useState('');
  const [file, setFile] = useState(null);

  useEffect(() => {
    if (existingItem) {
      setTitle(existingItem.title || '');
      setDescription(existingItem.description || '');
      setItemType(existingItem.item_type || 'task');
      setLinkUrl(existingItem.link_url || '');
    } else {
      setTitle('');
      setDescription('');
      setItemType('task');
      setLinkUrl('');
    }
    setFile(null);
  }, [existingItem]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ 
      audit_section_id: sectionId, 
      title, 
      description, 
      item_type: itemType, 
      link_url: itemType === 'link' ? linkUrl : null 
    }, file);
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="item-title">Título del Ítem</Label>
        <Input id="item-title" value={title} onChange={e => setTitle(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="item-desc">Descripción</Label>
        <Textarea id="item-desc" value={description} onChange={e => setDescription(e.target.value)} />
      </div>
      <div>
        <Label htmlFor="item-type">Tipo de Ítem</Label>
        <Select onValueChange={setItemType} value={itemType}>
          <SelectTrigger id="item-type">
            <SelectValue placeholder="Seleccionar tipo..." />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="task">Tarea</SelectItem>
            <SelectItem value="document">Documento</SelectItem>
            <SelectItem value="link">Enlace</SelectItem>
            <SelectItem value="template_download">Descarga de Plantilla</SelectItem>
          </SelectContent>
        </Select>
      </div>
      {itemType === 'link' && (
        <div>
          <Label htmlFor="item-link">URL del Enlace</Label>
          <Input id="item-link" type="url" value={linkUrl} onChange={e => setLinkUrl(e.target.value)} placeholder="https://ejemplo.com" />
        </div>
      )}
      {itemType === 'document' && (
        <div>
          <Label htmlFor="item-file">Archivo</Label>
          <Input id="item-file" type="file" onChange={e => setFile(e.target.files[0])} />
          {existingItem?.file_name && !file && <p className="text-sm text-gray-500 mt-1">Archivo actual: {existingItem.file_name}</p>}
          {!existingItem?.file_name && !file && itemType === 'document' && <p className="text-xs text-orange-500 mt-1">Adjuntar un archivo es opcional al crear, pero puede ser requerido para completar.</p>}
        </div>
      )}
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{existingItem ? 'Actualizar Ítem' : 'Añadir Ítem'}</Button>
      </DialogFooter>
    </form>
  );
};

export default AuditSectionItemForm;