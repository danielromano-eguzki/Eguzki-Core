import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { DialogFooter } from "@/components/ui/dialog";

const priorityOptions = ['Baja', 'Media', 'Alta', 'Crítica'];
const statusOptions = ['Abierto', 'En Progreso', 'Resuelto', 'Cerrado'];

const AuditFindingForm = ({ onSubmit, onCancel, existingFinding, control, controls }) => {
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState('Abierto');
  const [priority, setPriority] = useState('Media');
  const [dueDate, setDueDate] = useState('');
  const [responsible, setResponsible] = useState('');
  const [actionPlan, setActionPlan] = useState('');
  const [controlId, setControlId] = useState('');

  useEffect(() => {
    if (existingFinding) {
      setDescription(existingFinding.description || '');
      setStatus(existingFinding.status || 'Abierto');
      setPriority(existingFinding.priority || 'Media');
      setDueDate(existingFinding.due_date ? existingFinding.due_date.split('T')[0] : '');
      setResponsible(existingFinding.responsible || '');
      setActionPlan(existingFinding.action_plan || '');
      setControlId(existingFinding.control_id || '');
    } else if (control) {
      setDescription(`Incumplimiento detectado para el control: ${control.control_id_ext} - ${control.name}`);
      setControlId(control.id);
      setStatus('Abierto');
      setPriority('Media');
      setDueDate('');
      setResponsible('');
      setActionPlan('');
    } else {
      setDescription('');
      setStatus('Abierto');
      setPriority('Media');
      setDueDate('');
      setResponsible('');
      setActionPlan('');
      setControlId('');
    }
  }, [existingFinding, control]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ 
      description, 
      status, 
      priority, 
      due_date: dueDate || null,
      responsible,
      action_plan: actionPlan,
      control_id: controlId || null,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="finding-desc">Descripción del Hallazgo</Label>
        <Textarea id="finding-desc" value={description} onChange={e => setDescription(e.target.value)} required />
      </div>
      
      {!control && (
        <div>
          <Label htmlFor="finding-control">Control Afectado (Opcional)</Label>
          <Select onValueChange={setControlId} value={controlId}>
            <SelectTrigger id="finding-control">
              <SelectValue placeholder="Seleccionar control..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Sin control específico</SelectItem>
              {controls.map(c => (
                <SelectItem key={c.id} value={c.id}>{c.control_id_ext} - {c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="finding-priority">Prioridad</Label>
          <Select onValueChange={setPriority} value={priority}>
            <SelectTrigger id="finding-priority"><SelectValue /></SelectTrigger>
            <SelectContent>
              {priorityOptions.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="finding-status">Estado</Label>
          <Select onValueChange={setStatus} value={status}>
            <SelectTrigger id="finding-status"><SelectValue /></SelectTrigger>
            <SelectContent>
              {statusOptions.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="finding-responsible">Responsable</Label>
          <Input id="finding-responsible" value={responsible} onChange={e => setResponsible(e.target.value)} />
        </div>
        <div>
          <Label htmlFor="finding-due-date">Fecha Límite</Label>
          <Input id="finding-due-date" type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} />
        </div>
      </div>

      <div>
        <Label htmlFor="finding-action-plan">Plan de Acción</Label>
        <Textarea id="finding-action-plan" value={actionPlan} onChange={e => setActionPlan(e.target.value)} />
      </div>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{existingFinding ? 'Actualizar Hallazgo' : 'Crear Hallazgo'}</Button>
      </DialogFooter>
    </form>
  );
};

export default AuditFindingForm;