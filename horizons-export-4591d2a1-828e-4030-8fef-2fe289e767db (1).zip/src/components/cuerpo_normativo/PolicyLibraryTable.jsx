import React from 'react';
import { motion } from 'framer-motion';
import { BookCopy, PlusSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const predefinedPolicies = [
  {
    id: 'pol-sec-info',
    title: 'Política de Seguridad de la Información',
    description: 'Establece el marco general para la gestión de la seguridad de la información en la organización.',
    category: 'Gobernanza',
  },
  {
    id: 'pol-access-control',
    title: 'Política de Control de Acceso',
    description: 'Define las reglas para el acceso a los sistemas de información, datos y recursos de la red.',
    category: 'Operacional',
  },
  {
    id: 'pol-acceptable-use',
    title: 'Política de Uso Aceptable de los Activos',
    description: 'Describe el uso apropiado de los activos de información de la empresa por parte de los empleados.',
    category: 'Operacional',
  },
  {
    id: 'pol-backup',
    title: 'Política de Copias de Seguridad',
    description: 'Establece los requisitos para la realización de copias de seguridad y la recuperación de datos.',
    category: 'Continuidad',
  },
  {
    id: 'pol-incident-management',
    title: 'Política de Gestión de Incidentes',
    description: 'Define el proceso para la notificación, gestión y respuesta a incidentes de seguridad.',
    category: 'Operacional',
  },
  {
    id: 'pol-remote-work',
    title: 'Política de Teletrabajo',
    description: 'Establece las medidas de seguridad para los empleados que trabajan de forma remota.',
    category: 'Recursos Humanos',
  },
  {
    id: 'pol-clean-desk',
    title: 'Política de Escritorio Limpio y Pantalla Limpia',
    description: 'Define las reglas para proteger la información sensible en los espacios de trabajo físicos y digitales.',
    category: 'Físico',
  },
];

const PolicyLibraryTable = ({ onAdopt, isReadOnly }) => {
  return (
    <div className="bg-white/60 backdrop-blur-lg rounded-xl shadow-md p-6 border border-gray-200/50">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Título de la Política</TableHead>
              <TableHead>Descripción</TableHead>
              <TableHead>Categoría</TableHead>
              <TableHead>Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {predefinedPolicies.map((policy, index) => (
              <motion.tr
                key={policy.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="hover:bg-gray-50/50"
              >
                <TableCell className="font-medium">
                  <div className="flex items-center">
                    <BookCopy className="h-4 w-4 mr-2 text-gray-500" />
                    {policy.title}
                  </div>
                </TableCell>
                <TableCell className="text-sm text-gray-600">{policy.description}</TableCell>
                <TableCell>
                  <Badge variant="secondary">{policy.category}</Badge>
                </TableCell>
                <TableCell>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onAdopt(policy)}
                          disabled={isReadOnly}
                          className="text-emerald-600 border-emerald-600 hover:bg-emerald-50 hover:text-emerald-700"
                        >
                          <PlusSquare className="h-4 w-4 mr-2" />
                          Adoptar
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Añadir esta política a tu documentación interna.</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </TableCell>
              </motion.tr>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default PolicyLibraryTable;