import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { DialogFooter } from '@/components/ui/dialog';
    import { ScrollArea } from '@/components/ui/scroll-area';
    import { Checkbox } from '@/components/ui/checkbox';
    import { Badge } from '@/components/ui/badge';
    import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
    
    
    const documentTypes = ['Política', 'Procedimiento', 'Instrucción Técnica', 'Informe de Auditoría Interna', 'Informe de Gap Analysis', 'Documento Interno'];
    
    const NormativeDocumentForm = ({ onSubmit, onCancel, existingDocument, certifications, isReadOnly }) => {
      const [formData, setFormData] = useState({
        doc_id: '',
        description: '',
        type: 'Política',
        summary: '',
        responsible_department: '',
        approval_date: '',
      });
      const [attachmentFile, setAttachmentFile] = useState(null);
      const [selectedRequirements, setSelectedRequirements] = useState([]);
    
      useEffect(() => {
        if (existingDocument) {
          setFormData({
            doc_id: existingDocument.doc_id || '',
            description: existingDocument.description || '',
            type: existingDocument.type || 'Política',
            summary: existingDocument.summary || '',
            responsible_department: existingDocument.responsible_department || '',
            approval_date: existingDocument.approval_date ? existingDocument.approval_date.split('T')[0] : '',
          });
          if (existingDocument.linked_requirements) {
            setSelectedRequirements(existingDocument.linked_requirements.map(link => link.requirement_id));
          }
        }
      }, [existingDocument]);
      
      const allRequirements = certifications.flatMap(cert => 
        cert.requirements.map(req => ({...req, certName: cert.name}))
      );
      
      const handleRequirementToggle = (reqId) => {
        setSelectedRequirements(prev =>
          prev.includes(reqId) ? prev.filter(id => id !== reqId) : [...prev, reqId]
        );
      };
    
      const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
      };
    
      const handleTypeChange = (value) => {
        setFormData(prev => ({ ...prev, type: value }));
      };
    
      const handleFileChange = (e) => {
        if (e.target.files && e.target.files.length > 0) {
          setAttachmentFile(e.target.files[0]);
        }
      };
    
      const handleSubmit = (e) => {
        e.preventDefault();
        if(isReadOnly) return;
        onSubmit(formData, attachmentFile, selectedRequirements);
      };
    
      return (
        <form onSubmit={handleSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto p-1 pr-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="doc_id">ID Documento</Label>
              <Input id="doc_id" name="doc_id" value={formData.doc_id} onChange={handleChange} placeholder="Ej: POL-SEG-001" required disabled={isReadOnly} />
            </div>
            <div>
              <Label htmlFor="type">Tipo de Documento</Label>
              <Select onValueChange={handleTypeChange} value={formData.type} disabled={isReadOnly}>
                <SelectTrigger id="type"><SelectValue placeholder="Seleccionar tipo" /></SelectTrigger>
                <SelectContent>
                  {documentTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label htmlFor="description">Descripción</Label>
            <Input id="description" name="description" value={formData.description} onChange={handleChange} placeholder="Nombre completo del documento" required disabled={isReadOnly} />
          </div>
          <div>
            <Label htmlFor="summary">Resumen</Label>
            <Textarea id="summary" name="summary" value={formData.summary} onChange={handleChange} placeholder="Breve resumen del propósito y alcance del documento." disabled={isReadOnly} />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="responsible_department">Departamento Responsable</Label>
              <Input id="responsible_department" name="responsible_department" value={formData.responsible_department} onChange={handleChange} placeholder="Ej: TI, RRHH" disabled={isReadOnly} />
            </div>
            <div>
              <Label htmlFor="approval_date">Fecha de Aprobación/Revisión</Label>
              <Input id="approval_date" name="approval_date" type="date" value={formData.approval_date} onChange={handleChange} disabled={isReadOnly} />
            </div>
          </div>
          <div>
            <Label htmlFor="attachmentFile">Archivo Adjunto</Label>
            <Input id="attachmentFile" type="file" onChange={handleFileChange} disabled={isReadOnly} />
            {existingDocument?.file_name && !attachmentFile && <p className="text-sm text-gray-500 mt-1">Archivo actual: {existingDocument.file_name}</p>}
          </div>
    
          <div className="space-y-2 pt-2">
            <Label>Vincular a Requisitos de Certificaciones</Label>
            <div className="border rounded-md p-2">
                <ScrollArea className="h-48">
                  <Accordion type="multiple" className="w-full">
                    {certifications.map(cert => (
                      <AccordionItem value={cert.id} key={cert.id}>
                        <AccordionTrigger>
                          <div className="flex justify-between w-full pr-4 items-center">
                            <span>{cert.name}</span>
                            <Badge variant="secondary">
                              {cert.requirements.filter(r => selectedRequirements.includes(r.id)).length} / {cert.requirements.length}
                            </Badge>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent>
                          <div className="space-y-2 p-2">
                          {cert.requirements.length > 0 ? cert.requirements.map(req => (
                            <div key={req.id} className="flex items-center space-x-2">
                              <Checkbox
                                id={`req-${req.id}`}
                                checked={selectedRequirements.includes(req.id)}
                                onCheckedChange={() => handleRequirementToggle(req.id)}
                                disabled={isReadOnly}
                              />
                              <label htmlFor={`req-${req.id}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                {req.codigo} - {req.titulo}
                              </label>
                            </div>
                          )) : <p className="text-sm text-gray-500">No hay requisitos para esta certificación.</p>}
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </ScrollArea>
            </div>
          </div>
    
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
            {!isReadOnly && <Button type="submit">{existingDocument ? 'Actualizar Documento' : 'Añadir Documento'}</Button>}
          </DialogFooter>
        </form>
      );
    };
    
    export default NormativeDocumentForm;