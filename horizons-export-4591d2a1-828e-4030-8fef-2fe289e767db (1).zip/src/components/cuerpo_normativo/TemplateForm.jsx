import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DialogFooter } from '@/components/ui/dialog';

const documentTypes = ['Política', 'Procedimiento', 'Instrucción Técnica', 'Documento Interno'];

const TemplateForm = ({ onSubmit, onCancel, existingTemplate, isReadOnly }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    document_type: 'Política',
    category: '',
  });
  const [file, setFile] = useState(null);

  useEffect(() => {
    if (existingTemplate) {
      setFormData({
        title: existingTemplate.title || '',
        description: existingTemplate.description || '',
        document_type: existingTemplate.document_type || 'Política',
        category: existingTemplate.category || '',
      });
    }
  }, [existingTemplate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleTypeChange = (value) => {
    setFormData(prev => ({ ...prev, document_type: value }));
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isReadOnly) return;
    onSubmit(formData, file);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-1">
      <div>
        <Label htmlFor="title">Título de la Plantilla</Label>
        <Input id="title" name="title" value={formData.title} onChange={handleChange} placeholder="Ej: Política de Control de Acceso" required disabled={isReadOnly} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="document_type">Tipo de Documento</Label>
          <Select onValueChange={handleTypeChange} value={formData.document_type} disabled={isReadOnly}>
            <SelectTrigger id="document_type"><SelectValue placeholder="Seleccionar tipo" /></SelectTrigger>
            <SelectContent>
              {documentTypes.map(type => (
                <SelectItem key={type} value={type}>{type}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="category">Categoría/Grupo</Label>
          <Input id="category" name="category" value={formData.category} onChange={handleChange} placeholder="Ej: Seguridad, RRHH" disabled={isReadOnly} />
        </div>
      </div>
      <div>
        <Label htmlFor="description">Descripción</Label>
        <Textarea id="description" name="description" value={formData.description} onChange={handleChange} placeholder="Breve descripción de la plantilla." disabled={isReadOnly} />
      </div>
      <div>
        <Label htmlFor="file">Archivo de Plantilla</Label>
        <Input id="file" type="file" onChange={handleFileChange} disabled={isReadOnly} />
        {existingTemplate?.file_name && !file && <p className="text-sm text-gray-500 mt-1">Archivo actual: {existingTemplate.file_name}</p>}
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        {!isReadOnly && <Button type="submit">{existingTemplate ? 'Actualizar Plantilla' : 'Crear Plantilla'}</Button>}
      </DialogFooter>
    </form>
  );
};

export default TemplateForm;