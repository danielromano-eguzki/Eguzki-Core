import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Edit, Trash2, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const TemplatesTable = ({ templates, loading, onEdit, onDelete, onDownload, isReadOnly }) => {
  const [downloading, setDownloading] = useState(null);

  const handleDownload = async (template) => {
    setDownloading(template.id);
    const url = await onDownload(template.file_path);
    if (url) {
      try {
        const response = await fetch(url);
        const blob = await response.blob();
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = template.file_name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(link.href);
      } catch (error) {
        console.error("Download error:", error);
      }
    }
    setDownloading(null);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full"></motion.div>
      </div>
    );
  }

  return (
    <div className="bg-white/60 backdrop-blur-lg rounded-xl shadow-md p-6 border border-gray-200/50">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Título</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Categoría</TableHead>
              <TableHead>Descripción</TableHead>
              <TableHead>Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {templates && templates.map((template, index) => (
              <motion.tr
                key={template.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="hover:bg-gray-50/50"
              >
                <TableCell className="font-medium">
                  <div className="flex items-center">
                    <FileText className="h-4 w-4 mr-2 text-gray-500" />
                    {template.title}
                  </div>
                </TableCell>
                <TableCell><Badge variant="secondary">{template.document_type}</Badge></TableCell>
                <TableCell><Badge variant="outline">{template.category}</Badge></TableCell>
                <TableCell className="text-sm text-gray-600">{template.description}</TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <TooltipProvider>
                      {template.file_path && (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" onClick={() => handleDownload(template)} disabled={downloading === template.id} className="text-blue-600 hover:text-blue-800">
                              {downloading === template.id ? <motion.div animate={{rotate:360}} transition={{duration:1, repeat:Infinity}} className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full" /> : <Download className="h-4 w-4" />}
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent><p>Descargar Archivo</p></TooltipContent>
                        </Tooltip>
                      )}
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="ghost" size="icon" onClick={() => onEdit(template)} disabled={isReadOnly} className="text-yellow-600 hover:text-yellow-800">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>Editar</p></TooltipContent>
                      </Tooltip>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="ghost" size="icon" onClick={() => onDelete(template)} disabled={isReadOnly} className="text-red-600 hover:text-red-800">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>Eliminar</p></TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </TableCell>
              </motion.tr>
            ))}
          </TableBody>
        </Table>
        {templates && templates.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No has creado ninguna plantilla todavía.
          </div>
        )}
      </div>
    </div>
  );
};

export default TemplatesTable;