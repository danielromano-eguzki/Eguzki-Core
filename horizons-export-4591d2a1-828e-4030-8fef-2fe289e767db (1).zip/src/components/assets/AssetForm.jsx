import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { DialogFooter } from '@/components/ui/dialog';

const assetTypes = ["Servidor", "Portátil", "Red", "Software", "Almacenamiento", "EPI", "Monitor", "Teléfono móvil", "Línea telefónica", "Otro"];
const assetValues = ["Crítico", "Alto", "Medio", "Bajo"];

const AssetForm = ({ onSubmit, onCancel, existingAsset, isAuditorMode }) => {
  const [name, setName] = useState('');
  const [type, setType] = useState('');
  const [location, setLocation] = useState('');
  const [owner, setOwner] = useState('');
  const [value, setValue] = useState('');
  const [lastAudit, setLastAudit] = useState(new Date().toISOString().split('T')[0]);
  const [byod, setByod] = useState(false);

  useEffect(() => {
    if (existingAsset) {
      setName(existingAsset.name || '');
      setType(existingAsset.type || '');
      setLocation(existingAsset.location || '');
      setOwner(existingAsset.owner || '');
      setValue(existingAsset.value || '');
      setLastAudit(existingAsset.last_audit ? new Date(existingAsset.last_audit).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]);
      setByod(existingAsset.byod || false);
    } else {
      setName('');
      setType('');
      setLocation('');
      setOwner('');
      setValue('');
      setLastAudit(new Date().toISOString().split('T')[0]);
      setByod(false);
    }
  }, [existingAsset]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isAuditorMode) return;
    const assetData = {
      name,
      type,
      location,
      owner,
      value,
      last_audit: lastAudit,
      byod,
    };
    onSubmit(assetData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto p-1 pr-4">
      <div>
        <Label htmlFor="asset-name">Nombre del Activo</Label>
        <Input id="asset-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej: Servidor Principal" required disabled={isAuditorMode} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="asset-type">Tipo de Activo</Label>
          <Select onValueChange={setType} value={type} required disabled={isAuditorMode}>
            <SelectTrigger id="asset-type">
              <SelectValue placeholder="Seleccionar tipo" />
            </SelectTrigger>
            <SelectContent>
              {assetTypes.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="asset-value">Valor del Activo</Label>
          <Select onValueChange={setValue} value={value} required disabled={isAuditorMode}>
            <SelectTrigger id="asset-value">
              <SelectValue placeholder="Seleccionar valor" />
            </SelectTrigger>
            <SelectContent>
              {assetValues.map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label htmlFor="asset-location">Ubicación</Label>
        <Input id="asset-location" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Ej: Centro de Datos A" disabled={isAuditorMode} />
      </div>
      <div>
        <Label htmlFor="asset-owner">Propietario</Label>
        <Input id="asset-owner" value={owner} onChange={(e) => setOwner(e.target.value)} placeholder="Ej: Departamento IT" disabled={isAuditorMode} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
        <div>
          <Label htmlFor="asset-last-audit">Última Auditoría</Label>
          <Input id="asset-last-audit" type="date" value={lastAudit} onChange={(e) => setLastAudit(e.target.value)} disabled={isAuditorMode} />
        </div>
        <div className="flex items-center space-x-2 pt-6">
          <Checkbox id="byod" checked={byod} onCheckedChange={setByod} disabled={isAuditorMode} />
          <Label htmlFor="byod" className="font-medium">
            BYOD (Bring Your Own Device)
          </Label>
        </div>
      </div>
      <DialogFooter className="pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit" disabled={isAuditorMode}>{existingAsset ? 'Actualizar Activo' : 'Añadir Activo'}</Button>
      </DialogFooter>
    </form>
  );
};

export default AssetForm;