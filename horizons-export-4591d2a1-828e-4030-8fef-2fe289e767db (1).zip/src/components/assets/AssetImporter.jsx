import React, { useState } from 'react';
    import Papa from 'papaparse';
    import * as XLSX from 'xlsx';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { ScrollArea } from '@/components/ui/scroll-area';
    import { Upload, File, Check, AlertTriangle } from 'lucide-react';
    
    const assetFields = [
      { key: 'name', label: 'Nombre del Activo', required: true },
      { key: 'type', label: 'Tipo' },
      { key: 'location', label: 'Ubicación' },
      { key: 'owner', label: 'Propietario' },
      { key: 'value', label: 'Valor' },
      { key: 'last_audit', label: 'Última Auditoría (YYYY-MM-DD)' },
    ];
    
    const AssetImporter = ({ onSubmit, onCancel }) => {
      const [step, setStep] = useState(1);
      const [file, setFile] = useState(null);
      const [fileName, setFileName] = useState('');
      const [parsedData, setParsedData] = useState([]);
      const [headers, setHeaders] = useState([]);
      const [mapping, setMapping] = useState({});
      const [error, setError] = useState('');
    
      const handleFileChange = (e) => {
        const selectedFile = e.target.files[0];
        if (selectedFile) {
          setFile(selectedFile);
          setFileName(selectedFile.name);
          setError('');
        }
      };
    
      const handleParseFile = () => {
        if (!file) {
          setError('Por favor, selecciona un fichero.');
          return;
        }
    
        const reader = new FileReader();
        reader.onload = (e) => {
          const data = e.target.result;
          let parsed;
          if (file.name.endsWith('.csv')) {
            parsed = Papa.parse(data, { header: true, skipEmptyLines: true });
          } else if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
            const workbook = XLSX.read(data, { type: 'binary' });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
            const [headerRow, ...dataRows] = jsonData;
            parsed = {
              data: dataRows.map(row => headerRow.reduce((obj, key, i) => ({ ...obj, [key]: row[i] }), {})),
              meta: { fields: headerRow }
            };
          } else {
            setError('Formato de fichero no soportado. Usa CSV o XLSX.');
            return;
          }
    
          if (parsed.errors && parsed.errors.length > 0) {
            setError('Error al parsear el fichero CSV.');
            return;
          }
    
          setHeaders(parsed.meta.fields);
          setParsedData(parsed.data);
          setStep(2);
        };
    
        if (file.name.endsWith('.csv')) {
          reader.readAsText(file);
        } else {
          reader.readAsBinaryString(file);
        }
      };
    
      const handleMappingChange = (fieldKey, header) => {
        setMapping(prev => ({ ...prev, [fieldKey]: header }));
      };
    
      const handleImport = () => {
        if (!mapping.name) {
          setError('El campo "Nombre del Activo" es obligatorio.');
          return;
        }
    
        const importedAssets = parsedData.map(row => {
          const asset = {};
          for (const field of assetFields) {
            if (mapping[field.key]) {
              asset[field.key] = row[mapping[field.key]];
            }
          }
          return asset;
        }).filter(asset => asset.name); // Solo importar filas con nombre
    
        onSubmit(importedAssets);
      };
    
      return (
        <div className="space-y-6">
          {error && (
            <div className="p-3 bg-red-100 text-red-700 rounded-md flex items-center">
              <AlertTriangle className="w-4 h-4 mr-2" />
              {error}
            </div>
          )}
    
          {step === 1 && (
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Paso 1: Sube tu fichero</h3>
              <div className="p-6 border-2 border-dashed border-gray-300 rounded-lg text-center">
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <Label htmlFor="file-upload" className="mt-2 block text-sm font-medium text-gray-600">
                  Arrastra y suelta o{' '}
                  <span className="text-emerald-600 cursor-pointer">busca un fichero</span>
                </Label>
                <Input id="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept=".csv, .xlsx, .xls" />
                <p className="mt-1 text-xs text-gray-500">CSV o XLSX hasta 10MB</p>
              </div>
              {fileName && (
                <div className="flex items-center p-2 bg-gray-100 rounded-md">
                  <File className="w-4 h-4 mr-2 text-gray-500" />
                  <span className="text-sm text-gray-700">{fileName}</span>
                </div>
              )}
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={onCancel}>Cancelar</Button>
                <Button onClick={handleParseFile} disabled={!file}>Siguiente</Button>
              </div>
            </div>
          )}
    
          {step === 2 && (
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Paso 2: Mapea las columnas</h3>
              <p className="text-sm text-gray-600">Asigna las columnas de tu fichero a los campos de activos correspondientes.</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {assetFields.map(field => (
                  <div key={field.key} className="flex items-center space-x-2">
                    <Label className="w-1/2">
                      {field.label} {field.required && <span className="text-red-500">*</span>}
                    </Label>
                    <Select onValueChange={(value) => handleMappingChange(field.key, value)}>
                      <SelectTrigger className="w-1/2">
                        <SelectValue placeholder="Seleccionar columna" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">No importar</SelectItem>
                        {headers.map(header => (
                          <SelectItem key={header} value={header}>{header}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                ))}
              </div>
    
              <h4 className="font-semibold pt-4">Previsualización de datos</h4>
              <ScrollArea className="h-64 border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      {assetFields.map(field => mapping[field.key] && <TableHead key={field.key}>{field.label}</TableHead>)}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {parsedData.slice(0, 5).map((row, rowIndex) => (
                      <TableRow key={rowIndex}>
                        {assetFields.map(field => mapping[field.key] && (
                          <TableCell key={field.key}>{row[mapping[field.key]]}</TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
    
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setStep(1)}>Atrás</Button>
                <Button onClick={handleImport} disabled={!mapping.name}>
                  <Check className="w-4 h-4 mr-2" />
                  Importar {parsedData.length} Activos
                </Button>
              </div>
            </div>
          )}
        </div>
      );
    };
    
    export default AssetImporter;