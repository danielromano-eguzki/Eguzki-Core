import React from 'react';
import { motion } from 'framer-motion';
import { Archive, Server, Tag } from 'lucide-react';

const AssetStatsCards = ({ assets }) => {
  const totalAssets = assets.length;
  const criticalAssets = assets.filter(asset => asset.value === 'Crítico').length;
  const pendingAudits = assets.filter(asset => {
    if (!asset.last_audit) return true;
    const lastAuditDate = new Date(asset.last_audit);
    const oneYearAgo = new Date();
    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
    return lastAuditDate < oneYearAgo;
  }).length;

  const stats = [
    { title: "Total Activos", value: totalAssets, icon: Archive, gradient: "from-sky-500 to-cyan-500" },
    { title: "Activos Críticos", value: criticalAssets, icon: Server, gradient: "from-emerald-500 to-lime-500" },
    { title: "Auditorías Pendientes", value: pendingAudits, icon: Tag, gradient: "from-amber-500 to-yellow-500" },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: index * 0.1 }}
          className={`bg-gradient-to-r ${stat.gradient} rounded-xl p-6 text-white shadow-lg hover-lift`}>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-lg font-semibold">{stat.title}</h3>
            <stat.icon className="w-8 h-8 opacity-70" />
          </div>
          <p className="text-3xl font-bold">{stat.value}</p>
        </motion.div>
      ))}
    </div>
  );
};

export default AssetStatsCards;