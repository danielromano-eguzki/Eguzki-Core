import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Archive, Server, Laptop, HardDrive, Wifi, Link as LinkIcon,
  Search, Filter, ArrowUpDown, ChevronDown, ChevronUp, Edit3, Trash2, AlertTriangle,
  HardHat, Monitor, Smartphone, Phone, CheckCircle2, XCircle
} from 'lucide-react';

const assetTypes = ["Servidor", "Portátil", "Red", "Software", "Almacenamiento", "EPI", "Monitor", "Teléfono móvil", "Línea telefónica", "Otro"];
const assetValues = ["Crítico", "Alto", "Medio", "Bajo"];

const getAssetIcon = (type) => {
  switch (type) {
    case 'Servidor': return <Server className="w-5 h-5 text-blue-600" />;
    case 'Portátil': return <Laptop className="w-5 h-5 text-green-600" />;
    case 'Red': return <Wifi className="w-5 h-5 text-purple-600" />;
    case 'Software': return <HardDrive className="w-5 h-5 text-orange-600" />;
    case 'Almacenamiento': return <Archive className="w-5 h-5 text-red-600" />;
    case 'EPI': return <HardHat className="w-5 h-5 text-yellow-600" />;
    case 'Monitor': return <Monitor className="w-5 h-5 text-indigo-600" />;
    case 'Teléfono móvil': return <Smartphone className="w-5 h-5 text-pink-600" />;
    case 'Línea telefónica': return <Phone className="w-5 h-5 text-teal-600" />;
    default: return <Archive className="w-5 h-5 text-gray-600" />;
  }
};

const AssetTableFilters = ({ filters, handleFilterChange, uniqueOwners, clearFilters }) => (
  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-4 p-4 bg-gray-50/50 rounded-lg">
    <div>
      <Label htmlFor="filter-type" className="text-sm font-medium text-gray-700">Filtrar por Tipo</Label>
      <Select onValueChange={(value) => handleFilterChange('type', value === 'all' ? '' : value)} value={filters.type || 'all'}>
        <SelectTrigger id="filter-type" className="bg-white"><SelectValue placeholder="Todos los tipos" /></SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Todos los tipos</SelectItem>
          {assetTypes.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
        </SelectContent>
      </Select>
    </div>
    <div>
      <Label htmlFor="filter-value" className="text-sm font-medium text-gray-700">Filtrar por Valor</Label>
      <Select onValueChange={(value) => handleFilterChange('value', value === 'all' ? '' : value)} value={filters.value || 'all'}>
        <SelectTrigger id="filter-value" className="bg-white"><SelectValue placeholder="Todos los valores" /></SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Todos los valores</SelectItem>
          {assetValues.map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}
        </SelectContent>
      </Select>
    </div>
    <div>
      <Label htmlFor="filter-owner" className="text-sm font-medium text-gray-700">Filtrar por Propietario</Label>
      <Select onValueChange={(value) => handleFilterChange('owner', value === 'all' ? '' : value)} value={filters.owner || 'all'}>
        <SelectTrigger id="filter-owner" className="bg-white"><SelectValue placeholder="Todos los propietarios" /></SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Todos los propietarios</SelectItem>
          {uniqueOwners.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
        </SelectContent>
      </Select>
    </div>
    <div>
      <Label className="text-sm font-medium text-gray-700 block mb-2 opacity-0">Reset</Label>
      <Button variant="outline" onClick={clearFilters} className="w-full bg-white">
        <Filter className="w-4 h-4 mr-2" /> Limpiar Filtros
      </Button>
    </div>
  </div>
);

const SortableHeader = ({ columnKey, title, sortConfig, requestSort }) => (
  <th scope="col" className="px-4 py-3 cursor-pointer hover:bg-gray-200/70" onClick={() => requestSort(columnKey)}>
    <div className="flex items-center justify-between">
      {title}
      {sortConfig.key === columnKey ? (
        sortConfig.direction === 'ascending' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
      ) : <ArrowUpDown className="w-4 h-4 opacity-30" />}
    </div>
  </th>
);

const AssetTableRow = ({ asset, index, onEdit, onDelete, setActiveTab }) => (
  <motion.tr
    key={asset.id}
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    transition={{ delay: index * 0.02, duration: 0.3 }}
    className="bg-white/80 border-b border-gray-200/80 hover:bg-gray-50/70"
  >
    <td className="px-4 py-3 font-medium text-gray-900 whitespace-nowrap">{asset.id.substring(0, 8)}...</td>
    <td className="px-4 py-3 flex items-center">
      {getAssetIcon(asset.type)}
      <span className="ml-2">{asset.name}</span>
    </td>
    <td className="px-4 py-3">{asset.type}</td>
    <td className="px-4 py-3">{asset.location}</td>
    <td className="px-4 py-3">{asset.owner}</td>
    <td className="px-4 py-3">
      <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
        asset.value === 'Alto' ? 'bg-red-100 text-red-700' :
        asset.value === 'Medio' ? 'bg-yellow-100 text-yellow-700' :
        asset.value === 'Crítico' ? 'bg-purple-100 text-purple-700' :
        'bg-green-100 text-green-700'
      }`}>
        {asset.value}
      </span>
    </td>
    <td className="px-4 py-3">{asset.last_audit}</td>
    <td className="px-4 py-3 text-center">
      {asset.byod ? (
        <CheckCircle2 className="w-5 h-5 text-green-500 mx-auto" />
      ) : (
        <XCircle className="w-5 h-5 text-red-500 mx-auto" />
      )}
    </td>
     <td className="px-4 py-3">
      <Badge variant="secondary" className="flex items-center gap-1.5">
        <AlertTriangle className="w-3.5 h-3.5" />
        {asset.asset_risk_link?.length || 0} Riesgos
      </Badge>
    </td>
    <td className="px-4 py-3">
      <Button variant="ghost" size="icon" onClick={() => onEdit(asset)}><Edit3 className="w-4 h-4" /></Button>
      <Button variant="ghost" size="icon" onClick={() => onDelete(asset)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
      <Button variant="ghost" size="icon" onClick={() => setActiveTab('riesgos')}>
        <LinkIcon className="w-4 h-4" />
      </Button>
    </td>
  </motion.tr>
);

const AssetTable = ({ assets, sortConfig, requestSort, onEdit, onDelete, setActiveTab }) => (
  <div className="overflow-x-auto">
    <table className="w-full text-sm text-left text-gray-700">
      <thead className="text-xs text-gray-700 uppercase bg-gray-100/50">
        <tr>
          <SortableHeader columnKey="id" title="ID" sortConfig={sortConfig} requestSort={requestSort} />
          <SortableHeader columnKey="name" title="Nombre" sortConfig={sortConfig} requestSort={requestSort} />
          <SortableHeader columnKey="type" title="Tipo" sortConfig={sortConfig} requestSort={requestSort} />
          <SortableHeader columnKey="location" title="Ubicación" sortConfig={sortConfig} requestSort={requestSort} />
          <SortableHeader columnKey="owner" title="Propietario" sortConfig={sortConfig} requestSort={requestSort} />
          <SortableHeader columnKey="value" title="Valor" sortConfig={sortConfig} requestSort={requestSort} />
          <SortableHeader columnKey="last_audit" title="Última Auditoría" sortConfig={sortConfig} requestSort={requestSort} />
          <SortableHeader columnKey="byod" title="BYOD" sortConfig={sortConfig} requestSort={requestSort} />
          <th scope="col" className="px-4 py-3">Riesgos Vinculados</th>
          <th scope="col" className="px-4 py-3">Acciones</th>
        </tr>
      </thead>
      <tbody>
        {assets.map((asset, index) => (
          <AssetTableRow asset={asset} index={index} onEdit={onEdit} onDelete={onDelete} setActiveTab={setActiveTab} key={asset.id} />
        ))}
        {assets.length === 0 && (
          <tr>
            <td colSpan="10" className="text-center py-10 text-gray-500">
              <Filter className="w-12 h-12 mx-auto mb-2 text-gray-400" />
              No se encontraron activos con los filtros actuales.
            </td>
          </tr>
        )}
      </tbody>
    </table>
  </div>
);

export { AssetTable, AssetTableFilters };