import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { DialogFooter } from "@/components/ui/dialog";

const controlStatusOptions = ['Pendiente', 'En Progreso', 'Implementado', 'No Aplica', 'Revisión Necesaria'];
const controlTipoOptions = ['Normativo', 'Interno'];

export const ControlForm = ({ onSubmit, onCancel, existingControl, frameworks }) => {
  const [frameworkId, setFrameworkId] = useState(existingControl?.framework_id || '');
  const [domain, setDomain] = useState(existingControl?.domain || '');
  const [controlIdExt, setControlIdExt] = useState(existingControl?.control_id_ext || '');
  const [name, setName] = useState(existingControl?.name || '');
  const [description, setDescription] = useState(existingControl?.description || '');
  const [status, setStatus] = useState(existingControl?.status || 'Pendiente');
  const [tipo, setTipo] = useState(existingControl?.type || (frameworks.find(f => f.id === frameworkId)?.name === 'Controles Internos' ? 'Interno' : 'Normativo'));

  useEffect(() => {
    const selectedFramework = frameworks.find(f => f.id === frameworkId);
    if (selectedFramework?.name === 'Controles Internos') {
      setTipo('Interno');
    } else if (selectedFramework) {
      setTipo('Normativo');
    }
  }, [frameworkId, frameworks]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const controlData = {
      framework_id: frameworkId,
      domain,
      control_id_ext: controlIdExt,
      name,
      description,
      status,
      type: tipo,
    };
    if (existingControl?.id) {
      controlData.id = existingControl.id;
    }
    onSubmit(controlData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto p-1">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="control-framework">Certificación/Framework</Label>
          <Select onValueChange={setFrameworkId} value={frameworkId} required>
            <SelectTrigger id="control-framework"><SelectValue placeholder="Seleccionar certificación" /></SelectTrigger>
            <SelectContent>
              {frameworks.map(fw => <SelectItem key={fw.id} value={fw.id}>{fw.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="control-tipo">Tipo de Control</Label>
          <Select onValueChange={setTipo} value={tipo} required disabled={frameworks.find(f => f.id === frameworkId)?.name === 'Controles Internos'}>
            <SelectTrigger id="control-tipo"><SelectValue placeholder="Seleccionar tipo" /></SelectTrigger>
            <SelectContent>
              {controlTipoOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="control-domain">Dominio (Ej: A.9, op.acc)</Label>
          <Input id="control-domain" value={domain} onChange={(e) => setDomain(e.target.value)} placeholder="Dominio del control" />
        </div>
        <div>
          <Label htmlFor="control-id-ext">ID Control (Ej: A.9.1.1)</Label>
          <Input id="control-id-ext" value={controlIdExt} onChange={(e) => setControlIdExt(e.target.value)} placeholder="ID específico del control" required />
        </div>
      </div>
      <div>
        <Label htmlFor="control-name">Nombre del Control</Label>
        <Input id="control-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Nombre descriptivo del control" required />
      </div>
      <div>
        <Label htmlFor="control-description">Descripción</Label>
        <Input id="control-description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Descripción detallada del control" />
      </div>
      <div>
        <Label htmlFor="control-status">Estado</Label>
        <Select onValueChange={setStatus} value={status} required>
          <SelectTrigger id="control-status"><SelectValue placeholder="Seleccionar estado" /></SelectTrigger>
          <SelectContent>
            {controlStatusOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{existingControl ? 'Actualizar Control' : 'Añadir Control'}</Button>
      </DialogFooter>
    </form>
  );
};