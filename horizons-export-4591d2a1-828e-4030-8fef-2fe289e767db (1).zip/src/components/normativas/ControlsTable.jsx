import React from 'react';
import { motion } from 'framer-motion';
import { Award, Filter as FilterIcon, Search, ArrowUpDown, ChevronDown, ChevronUp, Edit3, Trash2, ListChecks } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";

const controlStatusOptions = ['Pendiente', 'En Progreso', 'Implementado', 'No Aplica', 'Revisión Necesaria'];
const controlTipoOptions = ['Normativo', 'Interno'];

const SortableHeader = ({ columnKey, title, sortConfig, requestSort }) => (
  <th scope="col" className="px-4 py-3 cursor-pointer hover:bg-gray-200/70" onClick={() => requestSort(columnKey)}>
    <div className="flex items-center justify-between">
      {title}
      {sortConfig.key === columnKey ? (
        sortConfig.direction === 'ascending' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
      ) : <ArrowUpDown className="w-4 h-4 opacity-30" />}
    </div>
  </th>
);

const getStatusColor = (status) => {
  if (status === 'Implementado') return 'bg-green-100 text-green-700';
  if (status === 'En Progreso') return 'bg-blue-100 text-blue-700';
  if (status === 'Pendiente') return 'bg-yellow-100 text-yellow-700';
  if (status === 'No Aplica') return 'bg-gray-100 text-gray-700';
  if (status === 'Revisión Necesaria') return 'bg-red-100 text-red-700';
  return 'bg-gray-100 text-gray-700';
};

export const ControlsTable = ({ 
  controls, frameworks, searchTerm, onSearchTermChange, filters, onFilterChange, 
  sortConfig, onRequestSort, onClearFilters, onEditControl, onDeleteControl 
}) => {
  return (
    <div className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 shadow-lg">
      <div className="flex flex-col sm:flex-row justify-between items-center mb-4 gap-4">
        <h3 className="text-xl font-bold text-gray-800 flex items-center">
          <Award className="w-6 h-6 mr-2 text-gradient" />
          Catálogo de Controles
        </h3>
        <div className="relative w-full sm:w-auto">
          <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input 
            type="text"
            placeholder="Buscar en controles..."
            className="pl-10 pr-4 py-2 w-full sm:w-64 bg-white/80"
            value={searchTerm}
            onChange={(e) => onSearchTermChange(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-4 p-4 bg-gray-50/50 rounded-lg">
        <div>
          <Label htmlFor="filter-framework" className="text-sm font-medium text-gray-700">Certificación</Label>
          <Select onValueChange={(value) => onFilterChange('framework_id', value === 'all' ? '' : value)} value={filters.framework_id || 'all'}>
            <SelectTrigger id="filter-framework" className="bg-white"><SelectValue placeholder="Todas" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas las Certificaciones</SelectItem>
              {frameworks.map(fw => <SelectItem key={fw.id} value={fw.id}>{fw.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="filter-status" className="text-sm font-medium text-gray-700">Estado</Label>
          <Select onValueChange={(value) => onFilterChange('status', value === 'all' ? '' : value)} value={filters.status || 'all'}>
            <SelectTrigger id="filter-status" className="bg-white"><SelectValue placeholder="Todos" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los Estados</SelectItem>
              {controlStatusOptions.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="filter-tipo" className="text-sm font-medium text-gray-700">Tipo</Label>
          <Select onValueChange={(value) => onFilterChange('type', value === 'all' ? '' : value)} value={filters.type || 'all'}>
            <SelectTrigger id="filter-tipo" className="bg-white"><SelectValue placeholder="Todos" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los Tipos</SelectItem>
              {controlTipoOptions.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-sm font-medium text-gray-700 block mb-2 opacity-0">Reset</Label>
          <Button variant="outline" onClick={onClearFilters} className="w-full bg-white">
            <ListChecks className="w-4 h-4 mr-2" /> Limpiar Filtros
          </Button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-gray-700">
          <thead className="text-xs text-gray-700 uppercase bg-gray-100/50">
            <tr>
              <SortableHeader columnKey="id" title="ID Control" sortConfig={sortConfig} requestSort={onRequestSort} />
              <SortableHeader columnKey="name" title="Nombre Control" sortConfig={sortConfig} requestSort={onRequestSort} />
              <SortableHeader columnKey="framework_id" title="Certificación" sortConfig={sortConfig} requestSort={onRequestSort} />
              <SortableHeader columnKey="control_id_ext" title="ID Específico" sortConfig={sortConfig} requestSort={onRequestSort} />
              <SortableHeader columnKey="status" title="Estado" sortConfig={sortConfig} requestSort={onRequestSort} />
              <SortableHeader columnKey="type" title="Tipo" sortConfig={sortConfig} requestSort={onRequestSort} />
              <th scope="col" className="px-4 py-3">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {controls.map((control, index) => (
              <motion.tr 
                key={control.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white/80 border-b border-gray-200/80 hover:bg-gray-50/70"
              >
                <td className="px-4 py-3 font-medium text-gray-900">{control.id.substring(0,8)}...</td>
                <td className="px-4 py-3">{control.name}</td>
                <td className="px-4 py-3">{frameworks.find(f => f.id === control.framework_id)?.name || control.framework_id.substring(0,8)+'...'}</td>
                <td className="px-4 py-3">{control.control_id_ext}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(control.status)}`}>
                    {control.status}
                  </span>
                </td>
                <td className="px-4 py-3">{control.type}</td>
                <td className="px-4 py-3">
                  <Button variant="ghost" size="icon" onClick={() => onEditControl(control)}><Edit3 className="w-4 h-4" /></Button>
                  <Button variant="ghost" size="icon" onClick={() => onDeleteControl(control)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                </td>
              </motion.tr>
            ))}
            {controls.length === 0 && (
              <tr>
                <td colSpan="7" className="text-center py-10 text-gray-500">
                  <FilterIcon className="w-12 h-12 mx-auto mb-2 text-gray-400" />
                  No se encontraron controles con los filtros actuales.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};