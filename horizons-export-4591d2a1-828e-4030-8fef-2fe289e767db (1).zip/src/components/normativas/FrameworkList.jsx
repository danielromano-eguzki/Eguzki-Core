import React from 'react';
import { motion } from 'framer-motion';
import { ListChecks, Edit3, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

export const FrameworkList = ({ frameworks, controls, onEditFramework, onDeleteFramework, onFilterByFramework }) => {
  const calculateFrameworkProgress = (frameworkId) => {
    const relevantControls = controls.filter(c => c.framework_id === frameworkId);
    if (relevantControls.length === 0) return 0;
    const implementedControls = relevantControls.filter(c => c.status === 'Implementado').length;
    return Math.round((implementedControls / relevantControls.length) * 100);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
      {frameworks.map((framework, index) => {
        const progress = calculateFrameworkProgress(framework.id);
        const frameworkControlsCount = controls.filter(c => c.framework_id === framework.id).length;
        return (
          <motion.div 
            key={framework.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            className="bg-white/70 backdrop-blur-lg rounded-xl p-6 border border-white/20 hover-lift group"
          >
            <div className="flex items-center justify-between mb-4">
              <ListChecks className="w-8 h-8" style={{color: framework.color || '#3B82F6'}} />
              <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); onEditFramework(framework);}}><Edit3 className="w-4 h-4" /></Button>
                <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); onDeleteFramework(framework);}}><Trash2 className="w-4 h-4 text-red-500" /></Button>
              </div>
            </div>
            <div onClick={() => onFilterByFramework(framework.id, framework.name)} className="cursor-pointer">
              <h3 className="text-lg font-bold mb-1">{framework.name}</h3>
              <p className="text-gray-600 text-xs mb-2 truncate" title={framework.description}>{framework.description}</p>
              <p className="text-gray-600 text-sm mb-3">{frameworkControlsCount} controles</p>
              <div className="w-full bg-gray-200 rounded-full h-2.5 mb-1">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ delay: index * 0.1, duration: 0.8 }}
                  className="h-2.5 rounded-full"
                  style={{backgroundColor: framework.color || '#3B82F6'}}
                ></motion.div>
              </div>
              <p className="text-sm font-medium">{progress}% completado</p>
            </div>
          </motion.div>
        );
      })}
      {frameworks.length === 0 && (
        <div className="col-span-full text-center py-10 text-gray-500">
          <ListChecks className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <p className="text-xl">No hay frameworks definidos.</p>
          <p>Puedes añadir uno manualmente o seleccionar uno de los predefinidos.</p>
        </div>
      )}
    </div>
  );
};