import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { DialogFooter } from "@/components/ui/dialog";

export const FrameworkForm = ({ onSubmit, onCancel, existingFramework }) => {
  const [name, setName] = useState(existingFramework?.name || '');
  const [description, setDescription] = useState(existingFramework?.description || '');
  const [color, setColor] = useState(existingFramework?.color || '#3B82F6');

  const handleSubmit = (e) => {
    e.preventDefault();
    const frameworkData = { name, description, color };
    if (existingFramework?.id) {
      frameworkData.id = existingFramework.id;
    }
    onSubmit(frameworkData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="framework-name">Nombre de la Certificación</Label>
        <Input id="framework-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej: ISO 27001" required />
      </div>
      <div>
        <Label htmlFor="framework-description">Descripción</Label>
        <Input id="framework-description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Breve descripción de la certificación" />
      </div>
      <div>
        <Label htmlFor="framework-color">Color Representativo</Label>
        <Input id="framework-color" type="color" value={color} onChange={(e) => setColor(e.target.value)} className="w-full h-10" />
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{existingFramework ? 'Actualizar Certificación' : 'Añadir Certificación'}</Button>
      </DialogFooter>
    </form>
  );
};