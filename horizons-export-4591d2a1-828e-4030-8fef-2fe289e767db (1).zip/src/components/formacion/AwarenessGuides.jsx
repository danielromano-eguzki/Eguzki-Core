import React from 'react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Fish, ShieldCheck, CheckCircle, AlertTriangle, MailWarning, UserCheck, Lock, Laptop, Wifi, KeyRound } from 'lucide-react';

const GuideStep = ({ icon, title, children }) => (
  <li className="flex items-start space-x-4 py-2">
    <div className="flex-shrink-0 w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center">
      {icon}
    </div>
    <div>
      <h4 className="font-semibold text-gray-800">{title}</h4>
      <p className="text-gray-600 text-sm">{children}</p>
    </div>
  </li>
);

const AwarenessGuides = () => {
  return (
    <div className="p-6 bg-white/60 backdrop-blur-lg rounded-xl shadow-md">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Guías de Concienciación</h2>
      <p className="text-sm text-gray-600 mb-4">
        Utiliza estas guías como material de apoyo para tus programas de formación en ciberseguridad.
      </p>
      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="item-1">
          <AccordionTrigger className="font-semibold text-lg hover:no-underline">
            <div className="flex items-center space-x-3">
              <Fish className="w-6 h-6 text-blue-500" />
              <span>Guía de Concienciación sobre Phishing</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-4">
            <p className="mb-4 text-gray-700">El phishing es una de las amenazas más comunes. Sigue estos pasos para formar a tus empleados:</p>
            <ul className="space-y-3 list-inside">
              <GuideStep icon={<AlertTriangle className="w-5 h-5" />} title="Paso 1: ¿Qué es el Phishing?">
                Explica que es una técnica para engañar a las personas y hacer que revelen información confidencial (contraseñas, datos bancarios) haciéndose pasar por una entidad de confianza.
              </GuideStep>
              <GuideStep icon={<MailWarning className="w-5 h-5" />} title="Paso 2: Identificar Correos Sospechosos">
                Enseña a verificar la dirección del remitente, buscar errores gramaticales, desconfiar de enlaces y adjuntos inesperados, y sospechar de mensajes que crean un sentido de urgencia.
              </GuideStep>
              <GuideStep icon={<CheckCircle className="w-5 h-5" />} title="Paso 3: Qué Hacer y Qué No Hacer">
                Instruye a los empleados a NUNCA hacer clic en enlaces sospechosos ni descargar adjuntos. Deben informar inmediatamente al departamento de TI y eliminar el correo.
              </GuideStep>
              <GuideStep icon={<UserCheck className="w-5 h-5" />} title="Paso 4: Simulación y Práctica">
                Realiza campañas de phishing simuladas para poner a prueba a los empleados en un entorno seguro y reforzar el aprendizaje. Analiza los resultados y ofrece formación adicional a quienes lo necesiten.
              </GuideStep>
            </ul>
          </AccordionContent>
        </AccordionItem>
        <AccordionItem value="item-2">
          <AccordionTrigger className="font-semibold text-lg hover:no-underline">
            <div className="flex items-center space-x-3">
              <ShieldCheck className="w-6 h-6 text-teal-500" />
              <span>Guía de Buenas Prácticas de Seguridad</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-4">
            <p className="mb-4 text-gray-700">Fomentar una cultura de seguridad es clave. Estas son las prácticas esenciales que todos deben seguir:</p>
            <ul className="space-y-3 list-inside">
              <GuideStep icon={<Lock className="w-5 h-5" />} title="Paso 1: Gestión de Contraseñas">
                Promueve el uso de contraseñas largas y complejas (combinando letras, números y símbolos). Recomienda el uso de un gestor de contraseñas y la activación de la autenticación de dos factores (MFA) siempre que sea posible.
              </GuideStep>
              <GuideStep icon={<Laptop className="w-5 h-5" />} title="Paso 2: Seguridad de los Equipos">
                Insiste en la importancia de mantener el software actualizado (sistema operativo, navegador, antivirus). Enseña a bloquear el equipo siempre que se ausenten del puesto de trabajo.
              </GuideStep>
              <GuideStep icon={<Wifi className="w-5 h-5" />} title="Paso 3: Uso Seguro de Redes">
                Advierte sobre los peligros de las redes Wi-Fi públicas. Recomienda el uso de la VPN corporativa para cualquier conexión fuera de la oficina.
              </GuideStep>
              <GuideStep icon={<KeyRound className="w-5 h-5" />} title="Paso 4: Manejo de la Información">
                Establece pautas claras sobre cómo manejar información sensible. Explica la importancia de no compartir datos confidenciales por canales no seguros y de seguir la política de clasificación de la información de la empresa.
              </GuideStep>
            </ul>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
};

export default AwarenessGuides;