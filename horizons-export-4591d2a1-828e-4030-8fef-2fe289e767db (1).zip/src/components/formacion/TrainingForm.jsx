import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { File, X } from 'lucide-react';

const TrainingForm = ({ onSubmit, onCancel, existingTraining }) => {
  const [formData, setFormData] = useState({
    name: '',
    topic: '',
    training_date: '',
    distribution_method: '',
    employees_reached: '',
    review_date: '',
  });
  const [attachmentFile, setAttachmentFile] = useState(null);
  const attachmentFileRef = useRef(null);

  useEffect(() => {
    if (existingTraining) {
      setFormData({
        name: existingTraining.name || '',
        topic: existingTraining.topic || '',
        training_date: existingTraining.training_date || '',
        distribution_method: existingTraining.distribution_method || '',
        employees_reached: existingTraining.employees_reached || '',
        review_date: existingTraining.review_date || '',
      });
      setAttachmentFile(null);
    }
  }, [existingTraining]);

  const handleChange = (e) => {
    const { id, value, type } = e.target;
    setFormData((prev) => ({ 
      ...prev, 
      [id]: type === 'number' ? (value === '' ? '' : Number(value)) : value 
    }));
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setAttachmentFile(e.target.files[0]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData, attachmentFile);
  };

  const FileInputDisplay = () => (
    <div className="space-y-2">
      <Label>Adjunto</Label>
      {attachmentFile ? (
        <div className="flex items-center justify-between p-2 border rounded-md bg-gray-50">
          <div className="flex items-center gap-2 text-sm text-gray-700">
            <File className="w-4 h-4" />
            <span className="truncate max-w-xs">{attachmentFile.name}</span>
          </div>
          <Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={() => setAttachmentFile(null)}><X className="w-4 h-4" /></Button>
        </div>
      ) : existingTraining?.attachment_path ? (
         <div className="flex items-center justify-between p-2 border rounded-md bg-gray-50">
            <span className="text-sm text-green-600">Archivo existente</span>
            <Button type="button" variant="outline" size="sm" onClick={() => attachmentFileRef.current.click()}>Reemplazar</Button>
         </div>
      ) : (
        <Button type="button" variant="outline" className="w-full" onClick={() => attachmentFileRef.current.click()}>Subir archivo</Button>
      )}
      <Input ref={attachmentFileRef} type="file" className="hidden" onChange={handleFileChange} />
    </div>
  );

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-1">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Nombre de la Formación</Label>
          <Input id="name" value={formData.name} onChange={handleChange} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="topic">Tema</Label>
          <Input id="topic" value={formData.topic} onChange={handleChange} />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="training_date">Fecha de Realización</Label>
          <Input id="training_date" type="date" value={formData.training_date} onChange={handleChange} />
        </div>
        <div className="space-y-2">
            <Label htmlFor="review_date">Próxima Revisión</Label>
            <Input id="review_date" type="date" value={formData.review_date} onChange={handleChange} />
        </div>
      </div>
       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="distribution_method">Método de Difusión</Label>
          <Input id="distribution_method" value={formData.distribution_method} onChange={handleChange} placeholder="Ej: Email, Taller, Plataforma online..." />
        </div>
        <div className="space-y-2">
          <Label htmlFor="employees_reached">Nº de Trabajadores Alcanzados</Label>
          <Input id="employees_reached" type="number" value={formData.employees_reached} onChange={handleChange} />
        </div>
      </div>
      <FileInputDisplay />
      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button type="submit">{existingTraining ? 'Guardar Cambios' : 'Crear Formación'}</Button>
      </div>
    </form>
  );
};

export default TrainingForm;