import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Edit3, Trash2 } from 'lucide-react';
import { motion } from 'framer-motion';

const TrainingsTable = ({ trainings, onEdit, onDelete, onDownloadFile }) => {
  const [downloading, setDownloading] = useState(null);

  const handleDownload = async (path, fileName) => {
    setDownloading(path);
    await onDownloadFile(path, fileName);
    setDownloading(null);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <div className="bg-white/70 backdrop-blur-lg shadow-lg rounded-xl overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200/50">
        <thead className="bg-gradient-to-r from-green-500/10 to-teal-500/10">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Nombre</th>
            <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Tema</th>
            <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Fecha</th>
            <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Difusión</th>
            <th className="px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Nº Empleados</th>
            <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Revisión</th>
            <th className="px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Adjunto</th>
            <th className="px-6 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Acciones</th>
          </tr>
        </thead>
        <tbody className="bg-white/50 divide-y divide-gray-200/30">
          {trainings.map(training => (
            <motion.tr 
              key={training.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="hover:bg-green-500/5"
            >
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{training.name}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{training.topic}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{formatDate(training.training_date)}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{training.distribution_method}</td>
              <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-700">{training.employees_reached}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{formatDate(training.review_date)}</td>
              <td className="px-6 py-4 whitespace-nowrap text-center">
                {training.attachment_path && (
                  <Button variant="link" size="sm" className="h-8 text-blue-600" onClick={() => handleDownload(training.attachment_path, `formacion_${training.name}.pdf`)} disabled={downloading === training.attachment_path}>
                    {downloading === training.attachment_path ? <motion.div animate={{rotate:360}} transition={{duration:1, repeat:Infinity}} className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full" /> : 'Descargar'}
                  </Button>
                )}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <div className="flex items-center justify-end space-x-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-600" onClick={() => onEdit(training)}><Edit3 className="w-4 h-4" /></Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500" onClick={() => onDelete(training)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              </td>
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TrainingsTable;