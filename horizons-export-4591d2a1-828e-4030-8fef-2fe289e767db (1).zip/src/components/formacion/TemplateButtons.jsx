import React from 'react';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';

const TemplateButtons = ({ showToast }) => {
  const handleDownload = (templateName) => {
    showToast(`Descarga de Plantilla: ${templateName}`, "Próximamente podrás descargar esta plantilla de formación directamente desde aquí.");
  };

  return (
    <div className="p-6 bg-white/60 backdrop-blur-lg rounded-xl shadow-md mb-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Plantillas de Formación</h2>
      <p className="text-sm text-gray-600 mb-4">
        Utiliza estas plantillas como punto de partida para tus programas de concienciación en ciberseguridad.
      </p>
      <div className="flex flex-col sm:flex-row gap-4">
        <Button className="flex-1" onClick={() => handleDownload('Phishing')}>
          <Download className="mr-2 h-4 w-4" />
          Concienciación sobre Phishing
        </Button>
        <Button className="flex-1" variant="outline" onClick={() => handleDownload('Buenas Prácticas')}>
          <Download className="mr-2 h-4 w-4" />
          Buenas Prácticas de Seguridad
        </Button>
      </div>
    </div>
  );
};

export default TemplateButtons;