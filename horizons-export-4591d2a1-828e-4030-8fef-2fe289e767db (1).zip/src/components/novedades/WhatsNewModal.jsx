import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { motion } from 'framer-motion';
import { Megaphone } from 'lucide-react';

const WhatsNewModal = ({ open, onClose, updates }) => {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl bg-white/90 backdrop-blur-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center text-2xl">
            <Megaphone className="w-6 h-6 mr-3 text-emerald-500" />
            Novedades y Actualizaciones
          </DialogTitle>
          <DialogDescription>
            Aquí están las últimas mejoras y funcionalidades que hemos añadido a Eguzki Core.
          </DialogDescription>
        </DialogHeader>
        <div className="max-h-[60vh] overflow-y-auto pr-4 -mr-4 mt-4">
          <div className="relative pl-6">
            <div className="absolute left-0 top-0 h-full w-0.5 bg-gray-200" style={{left: '11px'}}></div>
            {updates.map((update, index) => (
              <motion.div
                key={update.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="mb-8 relative"
              >
                <div className="absolute -left-1.5 top-1.5 w-4 h-4 bg-white border-2 border-emerald-500 rounded-full z-10"></div>
                <div className="ml-8">
                  <div className="flex items-center gap-4 mb-2">
                    <p className="text-sm text-gray-500">
                      {format(new Date(update.publish_date), "d 'de' MMMM 'de' yyyy", { locale: es })}
                    </p>
                    {update.version && (
                      <Badge variant="outline">{update.version}</Badge>
                    )}
                  </div>
                  <h4 className="font-bold text-lg text-gray-800">{update.title}</h4>
                  <p className="text-gray-600 mt-1">{update.description}</p>
                </div>
              </motion.div>
            ))}
             {updates.length === 0 && (
                <div className="text-center py-10 text-gray-500">
                    <p>No hay novedades importantes por ahora.</p>
                </div>
             )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default WhatsNewModal;