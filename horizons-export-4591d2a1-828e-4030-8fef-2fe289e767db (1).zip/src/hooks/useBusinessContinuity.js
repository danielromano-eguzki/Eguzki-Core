import { useState, useEffect, useCallback } from 'react';
import { useBia } from '@/hooks/business_continuity/useBia';
import { useCriticalProcesses } from '@/hooks/business_continuity/useCriticalProcesses';
import { useContinuitySystems } from '@/hooks/business_continuity/useContinuitySystems';
import { useCriticalAssetsBc } from '@/hooks/business_continuity/useCriticalAssetsBc';
import { useBackupInventory } from '@/hooks/business_continuity/useBackupInventory';
import { useBackupTests } from '@/hooks/business_continuity/useBackupTests';

export const useBusinessContinuity = (userId, selectedClientId, showToast, supabase) => {
  const [loading, setLoading] = useState(false);

  const biaHook = useBia(userId, selectedClientId, showToast, supabase);
  const criticalProcessesHook = useCriticalProcesses(userId, selectedClientId, showToast, supabase);
  const continuitySystemsHook = useContinuitySystems(userId, selectedClientId, showToast, supabase);
  const criticalAssetsBcHook = useCriticalAssetsBc(userId, selectedClientId, showToast, supabase);
  const backupInventoryHook = useBackupInventory(userId, selectedClientId, showToast, supabase);
  const backupTestsHook = useBackupTests(userId, selectedClientId, showToast, supabase);

  const refetchAll = useCallback(() => {
    biaHook.refetch();
    criticalProcessesHook.refetch();
    continuitySystemsHook.refetch();
    criticalAssetsBcHook.refetch();
    backupInventoryHook.refetch();
    backupTestsHook.refetch();
  }, [biaHook, criticalProcessesHook, continuitySystemsHook, criticalAssetsBcHook, backupInventoryHook, backupTestsHook]);

  useEffect(() => {
    const anyLoading = biaHook.loading || criticalProcessesHook.loading || continuitySystemsHook.loading || criticalAssetsBcHook.loading || backupInventoryHook.loading || backupTestsHook.loading;
    setLoading(anyLoading);
  }, [biaHook.loading, criticalProcessesHook.loading, continuitySystemsHook.loading, criticalAssetsBcHook.loading, backupInventoryHook.loading, backupTestsHook.loading]);

  return {
    bias: biaHook.bias,
    addBia: biaHook.addBia,
    updateBia: biaHook.updateBia,
    deleteBia: biaHook.deleteBia,
    
    criticalProcesses: criticalProcessesHook.criticalProcesses,
    addCriticalProcess: criticalProcessesHook.addCriticalProcess,
    updateCriticalProcess: criticalProcessesHook.updateCriticalProcess,
    deleteCriticalProcess: criticalProcessesHook.deleteCriticalProcess,

    continuitySystems: continuitySystemsHook.continuitySystems,
    addContinuitySystem: continuitySystemsHook.addContinuitySystem,
    updateContinuitySystem: continuitySystemsHook.updateContinuitySystem,
    deleteContinuitySystem: continuitySystemsHook.deleteContinuitySystem,
    getContinuityDocumentUrl: continuitySystemsHook.getContinuityDocumentUrl,

    criticalAssetsBc: criticalAssetsBcHook.criticalAssetsBc,
    addCriticalAssetBc: criticalAssetsBcHook.addCriticalAssetBc,
    updateCriticalAssetBc: criticalAssetsBcHook.updateCriticalAssetBc,
    deleteCriticalAssetBc: criticalAssetsBcHook.deleteCriticalAssetBc,

    backupInventory: backupInventoryHook.backupInventory,
    addBackupInventoryItem: backupInventoryHook.addBackupInventoryItem,
    updateBackupInventoryItem: backupInventoryHook.updateBackupInventoryItem,
    deleteBackupInventoryItem: backupInventoryHook.deleteBackupInventoryItem,

    backupTests: backupTestsHook.backupTests,
    addBackupTest: backupTestsHook.addBackupTest,
    
    loading,
    refetchAll
  };
};