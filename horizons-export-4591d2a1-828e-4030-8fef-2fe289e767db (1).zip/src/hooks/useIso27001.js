import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { v4 as uuidv4 } from 'uuid';

export const useIso27001 = (userId, clientId, showToast) => {
  const [certification, setCertification] = useState(null);
  const [requirements, setRequirements] = useState([]);
  const [evidences, setEvidences] = useState([]);
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({ total: 0, cumplido: 0, parcial: 0, no_cumplido: 0, no_aplica: 0, percentage: 0 });
  const CERTIFICATION_NAME = 'ISO/IEC 27001:2022';

  const loadCertificationData = useCallback(async (currentClientId) => {
    if (!userId || !currentClientId) {
      setCertification(null);
      setRequirements([]);
      setEvidences([]);
      setStats({ total: 0, cumplido: 0, parcial: 0, no_cumplido: 0, no_aplica: 0, percentage: 0 });
      return;
    }
    setLoading(true);

    try {
      let { data: cert, error: certError } = await supabase
        .from('certificaciones')
        .select('*')
        .eq('client_id', currentClientId)
        .eq('name', CERTIFICATION_NAME)
        .maybeSingle();

      if (certError) throw certError;

      if (!cert) {
        await supabase.rpc('seed_iso27001_2022_requirements_for_client', { p_user_id: userId, p_client_id: currentClientId });
        let { data: newCert, error: newCertError } = await supabase
          .from('certificaciones')
          .select('*')
          .eq('client_id', currentClientId)
          .eq('name', CERTIFICATION_NAME)
          .single();
        if (newCertError) throw newCertError;
        cert = newCert;
      }
      
      setCertification(cert);

      if (cert) {
        const [reqsRes, evsRes] = await Promise.all([
          supabase.from('requisitos_certificacion').select('*, linked_evidences:requisito_evidencia_link(evidencias(*))').eq('certificacion_id', cert.id),
          supabase.from('evidencias').select('*, linked_requirements:requisito_evidencia_link(requisitos_certificacion(*, certificacion:certificaciones(name)))').eq('client_id', currentClientId)
        ]);

        if (reqsRes.error) throw reqsRes.error;
        const currentRequirements = reqsRes.data.map(r => ({
          ...r,
          linked_evidences: r.linked_evidences.map(le => le.evidencias).filter(Boolean)
        }));
        setRequirements(currentRequirements);

        if (evsRes.error) throw evsRes.error;
        setEvidences(evsRes.data);
      } else {
        setRequirements([]);
        setEvidences([]);
      }
    } catch (error) {
      showToast("Error", `Error al cargar datos de ISO 27001: ${error.message}`, "destructive");
      setCertification(null);
      setRequirements([]);
      setEvidences([]);
    } finally {
      setLoading(false);
    }
  }, [userId, showToast]);
  
  useEffect(() => {
    if (clientId) {
      loadCertificationData(clientId);
    } else {
      setCertification(null);
      setRequirements([]);
      setEvidences([]);
    }
  }, [clientId, loadCertificationData]);

  useEffect(() => {
    if (requirements.length > 0) {
      const newStats = requirements.reduce((acc, req) => {
        acc.total++;
        switch (req.estado_cumplimiento) {
          case 'Cumplido': acc.cumplido++; break;
          case 'Parcial': acc.parcial++; break;
          case 'No cumplido': acc.no_cumplido++; break;
          case 'No aplica': acc.no_aplica++; break;
          default: acc.no_cumplido++; break;
        }
        return acc;
      }, { total: 0, cumplido: 0, parcial: 0, no_cumplido: 0, no_aplica: 0 });
      
      const applicableReqs = newStats.total - newStats.no_aplica;
      newStats.percentage = applicableReqs > 0 ? Math.round((newStats.cumplido / applicableReqs) * 100) : 0;
      setStats(newStats);
    } else {
      setStats({ total: 0, cumplido: 0, parcial: 0, no_cumplido: 0, no_aplica: 0, percentage: 0 });
    }
  }, [requirements]);

  const addRequirement = async (reqData) => {
    const { data, error } = await supabase
      .from('requisitos_certificacion')
      .insert([{ ...reqData, user_id: userId, client_id: clientId, certificacion_id: certification.id }])
      .select('*, linked_evidences:requisito_evidencia_link(evidencias(*))')
      .single();
    if (error) showToast("Error", `Error al añadir requisito: ${error.message}`, "destructive");
    else {
      setRequirements(prev => [...prev, { ...data, linked_evidences: [] }]);
      showToast("Éxito", "Requisito añadido correctamente.", "default");
    }
  };

  const updateRequirement = async (id, reqData) => {
    const { data, error } = await supabase
      .from('requisitos_certificacion')
      .update(reqData)
      .eq('id', id)
      .select('*, linked_evidences:requisito_evidencia_link(evidencias(*))')
      .single();
    if (error) showToast("Error", `Error al actualizar requisito: ${error.message}`, "destructive");
    else {
      setRequirements(prev => prev.map(r => r.id === id ? { ...data, linked_evidences: data.linked_evidences.map(le => le.evidencias).filter(Boolean) } : r));
      showToast("Éxito", "Requisito actualizado.", "default");
    }
  };

  const deleteRequirement = async (id) => {
    await supabase.from('requisito_evidencia_link').delete().eq('requisito_id', id);
    const { error } = await supabase.from('requisitos_certificacion').delete().eq('id', id);
    if (error) showToast("Error", `Error al eliminar requisito: ${error.message}`, "destructive");
    else {
      setRequirements(prev => prev.filter(r => r.id !== id));
      showToast("Éxito", "Requisito eliminado.", "default");
    }
  };

  const calculateHash = async (file) => {
    if(!file) return null;
    const buffer = await file.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  };

  const addEvidence = async (evidenceData, file, linkedReqs) => {
    let file_path = null, file_name = null, hash = null;
    if (file) {
      file_path = `${userId}/${clientId}/${uuidv4()}-${file.name}`;
      file_name = file.name;
      hash = await calculateHash(file);
      const { error: uploadError } = await supabase.storage.from('evidences').upload(file_path, file);
      if (uploadError) {
        showToast("Error de subida", uploadError.message, "destructive");
        return;
      }
    }

    const { data, error } = await supabase
      .from('evidencias')
      .insert([{ ...evidenceData, user_id: userId, client_id: clientId, file_path, file_name, hash }])
      .select('*, linked_requirements:requisito_evidencia_link(requisitos_certificacion(*, certificacion:certificaciones(name)))')
      .single();

    if (error) showToast("Error", `Error al añadir evidencia: ${error.message}`, "destructive");
    else {
      for (const reqId of linkedReqs) {
        await linkEvidenceToRequirement(reqId, data.id, false);
      }
      await loadCertificationData(clientId);
      showToast("Éxito", "Evidencia añadida.", "default");
    }
  };

  const updateEvidence = async (id, evidenceData, file, linkedReqs) => {
    let file_path = evidenceData.file_path, file_name = evidenceData.file_name, hash = evidenceData.hash;
    if (file) {
      file_path = `${userId}/${clientId}/${uuidv4()}-${file.name}`;
      file_name = file.name;
      hash = await calculateHash(file);
      const { error: uploadError } = await supabase.storage.from('evidences').upload(file_path, file);
      if (uploadError) {
        showToast("Error de subida", uploadError.message, "destructive");
        return;
      }
    }

    const { data, error } = await supabase
      .from('evidencias')
      .update({ ...evidenceData, file_path, file_name, hash })
      .eq('id', id)
      .select('*, linked_requirements:requisito_evidencia_link(requisitos_certificacion(*, certificacion:certificaciones(name)))')
      .single();

    if (error) showToast("Error", `Error al actualizar evidencia: ${error.message}`, "destructive");
    else {
      await supabase.from('requisito_evidencia_link').delete().eq('evidencia_id', id);
      for (const reqId of linkedReqs) {
        await linkEvidenceToRequirement(reqId, id, false);
      }
      await loadCertificationData(clientId);
      showToast("Éxito", "Evidencia actualizada.", "default");
    }
  };

  const deleteEvidence = async (id) => {
    const evidenceToDelete = evidences.find(e => e.id === id);
    if (evidenceToDelete && evidenceToDelete.file_path) {
      await supabase.storage.from('evidences').remove([evidenceToDelete.file_path]);
    }
    await supabase.from('requisito_evidencia_link').delete().eq('evidencia_id', id);
    const { error } = await supabase.from('evidencias').delete().eq('id', id);
    if (error) showToast("Error", `Error al eliminar evidencia: ${error.message}`, "destructive");
    else {
      setEvidences(prev => prev.filter(e => e.id !== id));
      await loadCertificationData(clientId);
      showToast("Éxito", "Evidencia eliminada.", "default");
    }
  };

  const getEvidenceFileUrl = async (filePath) => {
    const { data } = supabase.storage.from('evidences').getPublicUrl(filePath);
    return data.publicUrl;
  };

  const linkEvidenceToRequirement = async (requirementId, evidenceId, shouldReload = true) => {
    const { error } = await supabase.from('requisito_evidencia_link').insert({
      user_id: userId,
      client_id: clientId,
      requisito_id: requirementId,
      evidencia_id: evidenceId
    });
    if (error) showToast("Error", `Error al vincular evidencia: ${error.message}`, "destructive");
    else {
      if(shouldReload) await loadCertificationData(clientId);
      showToast("Éxito", "Evidencia vinculada.", "default");
    }
  };

  const unlinkEvidenceFromRequirement = async (requirementId, evidenceId) => {
    const { error } = await supabase.from('requisito_evidencia_link')
      .delete()
      .match({ requisito_id: requirementId, evidencia_id: evidenceId });
    if (error) showToast("Error", `Error al desvincular evidencia: ${error.message}`, "destructive");
    else {
      await loadCertificationData(clientId);
      showToast("Éxito", "Evidencia desvinculada.", "default");
    }
  };

  return {
    certification,
    requirements,
    stats,
    evidences,
    loading,
    loadCertificationData,
    addRequirement,
    updateRequirement,
    deleteRequirement,
    addEvidence,
    updateEvidence,
    deleteEvidence,
    getEvidenceFileUrl,
    calculateHash,
    linkEvidenceToRequirement,
    unlinkEvidenceFromRequirement,
    showToast
  };
};