import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/lib/customSupabaseClient';

export const useRequirements = (userId, clientId, showToast) => {
  const [certifications, setCertifications] = useState([]);
  const [requirements, setRequirements] = useState([]);
  const [evidences, setEvidences] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchData = useCallback(async () => {
    if (!userId || !clientId) {
      setCertifications([]);
      setRequirements([]);
      setEvidences([]);
      return;
    }
    setLoading(true);
    
    const certPromise = supabase.from('certificaciones').select('*').eq('client_id', clientId);
    const reqPromise = supabase.from('requisitos_certificacion').select('*').eq('client_id', clientId);
    const eviPromise = supabase.from('evidencias').select('*, linked_requirements:requisito_evidencia_link(requisitos_certificacion(id, codigo, titulo))').eq('client_id', clientId);

    const [{ data: certData, error: certError }, { data: reqData, error: reqError }, { data: eviData, error: eviError }] = await Promise.all([certPromise, reqPromise, eviPromise]);

    if (certError) showToast("Error cargando certificaciones", certError.message, "destructive");
    else setCertifications(certData || []);

    if (reqError) showToast("Error cargando requisitos", reqError.message, "destructive");
    else setRequirements(reqData || []);

    if (eviError) showToast("Error cargando evidencias", eviError.message, "destructive");
    else setEvidences(eviData || []);

    setLoading(false);
  }, [userId, clientId, showToast]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const addCertification = async (certData) => {
    const { data, error } = await supabase.from('certificaciones').insert([{ ...certData, user_id: userId, client_id: clientId }]).select().single();
    if (error) { showToast("Error", error.message, "destructive"); return null; }
    setCertifications(prev => [...prev, data]);
    return data;
  };

  const updateCertification = async (id, certData) => {
    const { data, error } = await supabase.from('certificaciones').update(certData).eq('id', id).select().single();
    if (error) { showToast("Error", error.message, "destructive"); return null; }
    setCertifications(prev => prev.map(c => c.id === id ? data : c));
    return data;
  };

  const deleteCertification = async (id) => {
    const { error } = await supabase.from('certificaciones').delete().eq('id', id);
    if (error) { showToast("Error", "Asegúrese que no tiene requisitos asociados.", "destructive"); return; }
    setCertifications(prev => prev.filter(c => c.id !== id));
  };

  const addRequirement = async (reqData) => {
    const { data, error } = await supabase.from('requisitos_certificacion').insert([{ ...reqData, user_id: userId, client_id: clientId }]).select().single();
    if (error) { showToast("Error", error.message, "destructive"); return null; }
    setRequirements(prev => [...prev, data]);
    return data;
  };

  const updateRequirement = async (id, reqData) => {
    const { data, error } = await supabase.from('requisitos_certificacion').update(reqData).eq('id', id).select().single();
    if (error) { showToast("Error", error.message, "destructive"); return null; }
    setRequirements(prev => prev.map(r => r.id === id ? data : r));
    return data;
  };

  const deleteRequirement = async (id) => {
    const { error } = await supabase.from('requisitos_certificacion').delete().eq('id', id);
    if (error) { showToast("Error", error.message, "destructive"); return; }
    setRequirements(prev => prev.filter(r => r.id !== id));
  };

  const addEvidence = async (evidenceData, file, linkedReqs) => {
    let filePath = null, fileName = null;
    if (file) {
      const uniqueFileName = `${userId}/${clientId}/evidences/${uuidv4()}-${file.name}`;
      const { data: uploadData, error: uploadError } = await supabase.storage.from('evidences').upload(uniqueFileName, file);
      if (uploadError) { showToast("Error subiendo archivo", uploadError.message, "destructive"); return null; }
      filePath = uploadData.path;
      fileName = file.name;
    }
    const { data, error } = await supabase.from('evidencias').insert([{ ...evidenceData, user_id: userId, client_id: clientId, file_path: filePath, file_name: fileName }]).select().single();
    if (error) { showToast("Error", error.message, "destructive"); return null; }
    
    if (linkedReqs && linkedReqs.length > 0) {
      const links = linkedReqs.map(reqId => ({ user_id: userId, client_id: clientId, requisito_id: reqId, evidencia_id: data.id }));
      const { error: linkError } = await supabase.from('requisito_evidencia_link').insert(links);
      if (linkError) showToast("Error vinculando requisitos", linkError.message, "destructive");
    }
    
    await fetchData();
    return data;
  };

  const updateEvidence = async (id, evidenceData, file, linkedReqs) => {
    const existingEvidence = evidences.find(e => e.id === id);
    let filePath = existingEvidence.file_path, fileName = existingEvidence.file_name;
    if (file) {
      if (existingEvidence.file_path) { await supabase.storage.from('evidences').remove([existingEvidence.file_path]); }
      const uniqueFileName = `${userId}/${clientId}/evidences/${uuidv4()}-${file.name}`;
      const { data: uploadData, error: uploadError } = await supabase.storage.from('evidences').upload(uniqueFileName, file);
      if (uploadError) { showToast("Error subiendo archivo", uploadError.message, "destructive"); return null; }
      filePath = uploadData.path;
      fileName = file.name;
    }
    const { data, error } = await supabase.from('evidencias').update({ ...evidenceData, file_path: filePath, file_name: fileName }).eq('id', id).select().single();
    if (error) { showToast("Error", error.message, "destructive"); return null; }

    await supabase.from('requisito_evidencia_link').delete().eq('evidencia_id', id);
    if (linkedReqs && linkedReqs.length > 0) {
      const links = linkedReqs.map(reqId => ({ user_id: userId, client_id: clientId, requisito_id: reqId, evidencia_id: data.id }));
      const { error: linkError } = await supabase.from('requisito_evidencia_link').insert(links);
      if (linkError) showToast("Error actualizando vínculos", linkError.message, "destructive");
    }

    await fetchData();
    return data;
  };

  const deleteEvidence = async (id) => {
    const evidenceToDelete = evidences.find(e => e.id === id);
    if (evidenceToDelete.file_path) { await supabase.storage.from('evidences').remove([evidenceToDelete.file_path]); }
    const { error } = await supabase.from('evidencias').delete().eq('id', id);
    if (error) { showToast("Error", error.message, "destructive"); return; }
    await fetchData();
  };

  const getEvidenceFileUrl = async (path) => {
    const { data, error } = await supabase.storage.from('evidences').download(path);
    if (error) { showToast("Error de descarga", error.message, "destructive"); return null; }
    return window.URL.createObjectURL(data);
  };

  return {
    certifications, requirements, evidences, loading,
    addCertification, updateCertification, deleteCertification,
    addRequirement, updateRequirement, deleteRequirement,
    addEvidence, updateEvidence, deleteEvidence, getEvidenceFileUrl,
    refetch: fetchData,
  };
};