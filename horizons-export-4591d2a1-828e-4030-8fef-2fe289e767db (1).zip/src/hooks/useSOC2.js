import { useState, useEffect, useCallback } from 'react';
    import { supabase } from '@/lib/customSupabaseClient';
    import { v4 as uuidv4 } from 'uuid';
    
    export const useSOC2 = (userId, clientId, showToast) => {
      const [requirements, setRequirements] = useState([]);
      const [evidences, setEvidences] = useState([]);
      const [certification, setCertification] = useState(null);
      const [loading, setLoading] = useState(true);
      const [stats, setStats] = useState({ total: 0, cumplido: 0, no_cumplido: 0, parcial: 0, no_aplica: 0, percentage: 0 });
    
      const NORMATIVE_NAME = 'SOC 2';
    
      const fetchCertification = useCallback(async () => {
        if (!clientId) return null;
        const { data, error } = await supabase
          .from('certificaciones')
          .select('*')
          .eq('client_id', clientId)
          .eq('name', NORMATIVE_NAME)
          .maybeSingle();
        if (error) {
          showToast("Error", `Error al cargar la certificación SOC 2: ${error.message}`, "destructive");
          return null;
        }
        return data;
      }, [clientId, showToast]);
    
      const fetchRequirements = useCallback(async (certificationId) => {
        if (!certificationId) return [];
        const { data, error } = await supabase
          .from('requisitos_certificacion')
          .select('*, linked_evidences:requisito_evidencia_link(evidencia_id, evidencia:evidencias(id, nombre, file_path))')
          .eq('certificacion_id', certificationId);
        if (error) {
          showToast("Error", `Error al cargar los requisitos SOC 2: ${error.message}`, "destructive");
          return [];
        }
        return data.map(r => ({
          ...r,
          linked_evidences: r.linked_evidences.map(l => l.evidencia).filter(Boolean)
        }));
      }, [showToast]);
    
      const fetchEvidences = useCallback(async () => {
        if (!clientId) return [];
        const { data, error } = await supabase
          .from('evidencias')
          .select('*')
          .eq('client_id', clientId);
        if (error) {
          showToast("Error", `Error al cargar las evidencias: ${error.message}`, "destructive");
          return [];
        }
        return data;
      }, [clientId, showToast]);
    
      const fetchData = useCallback(async () => {
        setLoading(true);
        const cert = await fetchCertification();
        setCertification(cert);
        if (cert) {
          const [reqs, evs] = await Promise.all([
            fetchRequirements(cert.id),
            fetchEvidences()
          ]);
          setRequirements(reqs);
          setEvidences(evs);
        } else {
          setRequirements([]);
          setEvidences([]);
        }
        setLoading(false);
      }, [fetchCertification, fetchRequirements, fetchEvidences]);
    
      useEffect(() => {
        if (userId && clientId) {
          fetchData();
        } else {
          setLoading(false);
          setRequirements([]);
          setEvidences([]);
          setCertification(null);
        }
      }, [userId, clientId, fetchData]);
    
      useEffect(() => {
        const total = requirements.length;
        const aplicables = requirements.filter(r => r.estado_cumplimiento !== 'No aplica').length;
        const cumplido = requirements.filter(r => r.estado_cumplimiento === 'Cumplido').length;
        const no_cumplido = requirements.filter(r => r.estado_cumplimiento === 'No cumplido').length;
        const parcial = requirements.filter(r => r.estado_cumplimiento === 'Parcial').length;
        const no_aplica = total - aplicables;
        const percentage = aplicables > 0 ? Math.round((cumplido / aplicables) * 100) : 0;
        setStats({ total, cumplido, no_cumplido, parcial, no_aplica, percentage });
      }, [requirements]);
    
      const seedSOC2Method = async () => {
        if (!userId || !clientId) return;
        setLoading(true);
        const { error } = await supabase.rpc('seed_soc2_requirements_for_client', {
          p_user_id: userId,
          p_client_id: clientId
        });
        if (error) {
          showToast("Error", `Error al inicializar los controles SOC 2: ${error.message}`, "destructive");
        } else {
          showToast("Éxito", "Controles de SOC 2 inicializados correctamente.");
          await fetchData();
        }
        setLoading(false);
      };
    
      const addRequirement = async (formData) => {
        if (!certification) {
          showToast("Error", "No se ha encontrado la certificación para este cliente.", "destructive");
          return;
        }
        const { data, error } = await supabase
          .from('requisitos_certificacion')
          .insert([{ ...formData, user_id: userId, client_id: clientId, certificacion_id: certification.id }])
          .select()
          .single();
        if (error) {
          showToast("Error", `Error al añadir el requisito: ${error.message}`, "destructive");
        } else {
          setRequirements(prev => [...prev, { ...data, linked_evidences: [] }]);
          showToast("Éxito", "Requisito añadido correctamente.");
        }
      };
    
      const updateRequirement = async (id, formData) => {
        const { data, error } = await supabase
          .from('requisitos_certificacion')
          .update(formData)
          .eq('id', id)
          .select()
          .single();
        if (error) {
          showToast("Error", `Error al actualizar el requisito: ${error.message}`, "destructive");
        } else {
          setRequirements(prev => prev.map(r => r.id === id ? { ...r, ...data } : r));
          showToast("Éxito", "Requisito actualizado correctamente.");
        }
      };
    
      const deleteRequirement = async (id) => {
        const { error } = await supabase.from('requisitos_certificacion').delete().eq('id', id);
        if (error) {
          showToast("Error", `Error al eliminar el requisito: ${error.message}`, "destructive");
        } else {
          setRequirements(prev => prev.filter(r => r.id !== id));
          showToast("Éxito", "Requisito eliminado correctamente.");
        }
      };
    
      const addEvidence = async (formData, file, linkedReqs) => {
        let filePath = null;
        let fileName = null;
        if (file) {
          filePath = `${userId}/${clientId}/${uuidv4()}-${file.name}`;
          fileName = file.name;
          const { error: uploadError } = await supabase.storage.from('evidences').upload(filePath, file);
          if (uploadError) {
            showToast("Error de subida", uploadError.message, "destructive");
            return;
          }
        }
        const { data, error } = await supabase
          .from('evidencias')
          .insert([{ ...formData, user_id: userId, client_id: clientId, file_path: filePath, file_name: fileName }])
          .select()
          .single();
        if (error) {
          showToast("Error", `Error al crear la evidencia: ${error.message}`, "destructive");
        } else {
          setEvidences(prev => [...prev, data]);
          if (linkedReqs && linkedReqs.length > 0) {
            for (const reqId of linkedReqs) {
              await linkEvidenceToRequirement(reqId, data.id);
            }
          }
          showToast("Éxito", "Evidencia creada y vinculada correctamente.");
          await fetchData();
        }
      };
    
      const updateEvidence = async (id, formData, file, linkedReqs) => {
        let filePath = formData.file_path;
        let fileName = formData.file_name;
        if (file) {
          filePath = `${userId}/${clientId}/${uuidv4()}-${file.name}`;
          fileName = file.name;
          const { error: uploadError } = await supabase.storage.from('evidences').upload(filePath, file);
          if (uploadError) {
            showToast("Error de subida", uploadError.message, "destructive");
            return;
          }
        }
        const { data, error } = await supabase
          .from('evidencias')
          .update({ ...formData, file_path: filePath, file_name: fileName })
          .eq('id', id)
          .select()
          .single();
        if (error) {
          showToast("Error", `Error al actualizar la evidencia: ${error.message}`, "destructive");
        } else {
          setEvidences(prev => prev.map(e => e.id === id ? data : e));
          const { error: deleteLinksError } = await supabase.from('requisito_evidencia_link').delete().eq('evidencia_id', id);
          if (deleteLinksError) console.error("Error clearing old links:", deleteLinksError);
          if (linkedReqs && linkedReqs.length > 0) {
            for (const reqId of linkedReqs) {
              await linkEvidenceToRequirement(reqId, data.id);
            }
          }
          showToast("Éxito", "Evidencia actualizada correctamente.");
          await fetchData();
        }
      };
    
      const deleteEvidence = async (id) => {
        const evidenceToDelete = evidences.find(e => e.id === id);
        if (evidenceToDelete?.file_path) {
          const { error: storageError } = await supabase.storage.from('evidences').remove([evidenceToDelete.file_path]);
          if (storageError) showToast("Error", `Error al eliminar el archivo: ${storageError.message}`, "destructive");
        }
        const { error } = await supabase.from('evidencias').delete().eq('id', id);
        if (error) {
          showToast("Error", `Error al eliminar la evidencia: ${error.message}`, "destructive");
        } else {
          setEvidences(prev => prev.filter(e => e.id !== id));
          showToast("Éxito", "Evidencia eliminada.");
          await fetchData();
        }
      };
    
      const getEvidenceFileUrl = async (filePath) => {
        const { data } = supabase.storage.from('evidences').getPublicUrl(filePath);
        return data.publicUrl;
      };
    
      const calculateHash = async (file) => {
        const buffer = await file.arrayBuffer();
        const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      };
    
      const linkEvidenceToRequirement = async (requirementId, evidenceId) => {
        const { error } = await supabase.from('requisito_evidencia_link').insert({
          user_id: userId,
          client_id: clientId,
          requisito_id: requirementId,
          evidencia_id: evidenceId
        });
        if (error) {
          showToast("Error", `Error al vincular evidencia: ${error.message}`, "destructive");
        } else {
          showToast("Éxito", "Evidencia vinculada.");
          await fetchData();
        }
      };
    
      const unlinkEvidenceFromRequirement = async (requirementId, evidenceId) => {
        const { error } = await supabase.from('requisito_evidencia_link')
          .delete()
          .match({ requisito_id: requirementId, evidencia_id: evidenceId });
        if (error) {
          showToast("Error", `Error al desvincular evidencia: ${error.message}`, "destructive");
        } else {
          showToast("Éxito", "Evidencia desvinculada.");
          await fetchData();
        }
      };
    
      return {
        requirements,
        evidences,
        loading,
        stats,
        certification,
        seedSOC2Method,
        addRequirement,
        updateRequirement,
        deleteRequirement,
        addEvidence,
        updateEvidence,
        deleteEvidence,
        getEvidenceFileUrl,
        calculateHash,
        linkEvidenceToRequirement,
        unlinkEvidenceFromRequirement,
        showToast
      };
    };