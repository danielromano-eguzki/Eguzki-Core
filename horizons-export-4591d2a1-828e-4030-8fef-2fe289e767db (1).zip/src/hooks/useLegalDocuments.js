import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { v4 as uuidv4 } from 'uuid';

export const useLegalDocuments = (userId, selectedClientId, showToast) => {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchDocuments = useCallback(async () => {
    if (!userId || !selectedClientId) {
      setDocuments([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('legal_documents')
        .select('*')
        .eq('user_id', userId)
        .eq('client_id', selectedClientId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDocuments(data || []);
    } catch (error) {
      showToast('Error', 'No se pudieron cargar los documentos legales.', 'destructive');
      console.error('Error fetching legal documents:', error);
    } finally {
      setLoading(false);
    }
  }, [userId, selectedClientId, showToast]);

  useEffect(() => {
    fetchDocuments();
  }, [fetchDocuments]);

  const uploadFile = async (file) => {
    if (!file) return { path: null, name: null };
    const filePath = `${userId}/${uuidv4()}-${file.name}`;
    const { error } = await supabase.storage.from('legal_documents').upload(filePath, file);
    if (error) throw error;
    return { path: filePath, name: file.name };
  };

  const addDocument = async (formData, file) => {
    if (!userId || !selectedClientId) return;
    try {
      let fileData = {};
      if (file) {
        const { path, name } = await uploadFile(file);
        fileData = { file_path: path, file_name: name };
      }

      const newDocument = {
        ...formData,
        user_id: userId,
        client_id: selectedClientId,
        ...fileData,
      };

      const { data, error } = await supabase
        .from('legal_documents')
        .insert(newDocument)
        .select()
        .single();

      if (error) throw error;
      setDocuments(prev => [data, ...prev]);
      showToast('Éxito', 'Documento legal añadido correctamente.');
    } catch (error) {
      showToast('Error', 'No se pudo añadir el documento legal.', 'destructive');
      console.error('Error adding legal document:', error);
    }
  };

  const updateDocument = async (id, formData, file) => {
    try {
      let fileData = {};
      if (file) {
        const { path, name } = await uploadFile(file);
        fileData = { file_path: path, file_name: name };
      }

      const updatedDocument = { ...formData, ...fileData };

      const { data, error } = await supabase
        .from('legal_documents')
        .update(updatedDocument)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      setDocuments(prev => prev.map(doc => (doc.id === id ? data : doc)));
      showToast('Éxito', 'Documento legal actualizado correctamente.');
    } catch (error) {
      showToast('Error', 'No se pudo actualizar el documento legal.', 'destructive');
      console.error('Error updating legal document:', error);
    }
  };

  const deleteDocument = async (id) => {
    try {
      const docToDelete = documents.find(doc => doc.id === id);
      if (docToDelete && docToDelete.file_path) {
        const { error: storageError } = await supabase.storage.from('legal_documents').remove([docToDelete.file_path]);
        if (storageError) {
          console.warn('Storage error on delete:', storageError.message);
        }
      }

      const { error } = await supabase.from('legal_documents').delete().eq('id', id);
      if (error) throw error;
      setDocuments(prev => prev.filter(doc => doc.id !== id));
      showToast('Éxito', 'Documento legal eliminado correctamente.');
    } catch (error) {
      showToast('Error', 'No se pudo eliminar el documento legal.', 'destructive');
      console.error('Error deleting legal document:', error);
    }
  };

  const getFileUrl = async (filePath) => {
    try {
      const { data, error } = await supabase.storage.from('legal_documents').createSignedUrl(filePath, 3600); // URL válida por 1 hora
      if (error) throw error;
      return data.signedUrl;
    } catch (error) {
      showToast('Error', 'No se pudo obtener la URL del archivo.', 'destructive');
      console.error('Error getting file URL:', error);
      return null;
    }
  };

  return { documents, loading, addDocument, updateDocument, deleteDocument, getFileUrl, refetch: fetchDocuments };
};