import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useEvidencias } from '@/hooks/useEvidencias';

export const useDORA = (userId, clientId, showToast) => {
  const [requirements, setRequirements] = useState([]);
  const [certification, setCertification] = useState(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ total: 0, cumplido: 0, parcial: 0, no_cumplido: 0, no_aplica: 0, percentage: 0 });

  const evidenciasHook = useEvidencias(userId, clientId, showToast, 'DORA');

  const fetchRequirements = useCallback(async () => {
    if (!userId || !clientId) {
      setRequirements([]);
      setCertification(null);
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      let { data: certData, error: certError } = await supabase
        .from('certificaciones')
        .select('*')
        .eq('client_id', clientId)
        .eq('name', 'DORA')
        .maybeSingle();

      if (certError) {
        throw certError;
      }
      setCertification(certData);

      if (certData) {
        const { data: reqData, error: reqError } = await supabase
          .from('requisitos_certificacion')
          .select(`
            *,
            linked_evidences:normative_document_requirement_link(
              normative_documents(id, nombre, file_path)
            )
          `)
          .eq('client_id', clientId)
          .eq('certificacion_id', certData.id)
          .order('codigo', { ascending: true });

        if (reqError) throw reqError;
        
        const formattedData = reqData.map(r => ({
          ...r,
          linked_evidences: r.linked_evidences.map(l => l.normative_documents)
        }));
        setRequirements(formattedData);
      } else {
        setRequirements([]);
      }
    } catch (error) {
      showToast("Error", `Error al cargar los requisitos de DORA: ${error.message}`, "destructive");
    } finally {
      setLoading(false);
    }
  }, [userId, clientId, showToast]);

  useEffect(() => {
    fetchRequirements();
  }, [fetchRequirements]);

  useEffect(() => {
    const total = requirements.length;
    const cumplido = requirements.filter(r => r.estado_cumplimiento === 'Cumplido').length;
    const parcial = requirements.filter(r => r.estado_cumplimiento === 'Parcial').length;
    const no_cumplido = requirements.filter(r => r.estado_cumplimiento === 'No cumplido').length;
    const no_aplica = requirements.filter(r => r.estado_cumplimiento === 'No aplica').length;
    const applicable = total - no_aplica;
    const percentage = applicable > 0 ? Math.round((cumplido / applicable) * 100) : 0;
    setStats({ total, cumplido, parcial, no_cumplido, no_aplica, percentage });
  }, [requirements]);

  const seedDORAMethod = async () => {
    if (!userId || !clientId) return;
    setLoading(true);
    try {
      const { error } = await supabase.rpc('seed_dora_requirements_for_client', {
        p_user_id: userId,
        p_client_id: clientId
      });
      if (error) throw error;
      showToast("Éxito", "Los requisitos de DORA se han inicializado correctamente.", "default");
      await fetchRequirements();
    } catch (error) {
      showToast("Error", `Error al inicializar los requisitos de DORA: ${error.message}`, "destructive");
    } finally {
      setLoading(false);
    }
  };

  const addRequirement = async (formData) => {
    if (!certification) {
      showToast("Error", "La certificación DORA no está inicializada para este cliente.", "destructive");
      return;
    }
    const { data, error } = await supabase
      .from('requisitos_certificacion')
      .insert([{ ...formData, user_id: userId, client_id: clientId, certificacion_id: certification.id }])
      .select()
      .single();
    if (error) {
      showToast("Error", `Error al añadir requisito: ${error.message}`, "destructive");
    } else {
      showToast("Éxito", "Requisito añadido correctamente.", "default");
      setRequirements(prev => [...prev, { ...data, linked_evidences: [] }]);
    }
  };

  const updateRequirement = async (id, formData) => {
    const { data, error } = await supabase
      .from('requisitos_certificacion')
      .update(formData)
      .eq('id', id)
      .select()
      .single();
    if (error) {
      showToast("Error", `Error al actualizar requisito: ${error.message}`, "destructive");
    } else {
      showToast("Éxito", "Requisito actualizado correctamente.", "default");
      setRequirements(prev => prev.map(r => r.id === id ? { ...r, ...data } : r));
    }
  };

  const deleteRequirement = async (id) => {
    const { error } = await supabase.from('requisitos_certificacion').delete().eq('id', id);
    if (error) {
      showToast("Error", `Error al eliminar requisito: ${error.message}`, "destructive");
    } else {
      showToast("Éxito", "Requisito eliminado correctamente.", "default");
      setRequirements(prev => prev.filter(r => r.id !== id));
    }
  };

  const linkEvidenceToRequirement = async (requirementId, evidenceId) => {
    const { error } = await supabase
      .from('normative_document_requirement_link')
      .insert([{
        user_id: userId,
        client_id: clientId,
        requirement_id: requirementId,
        document_id: evidenceId
      }]);

    if (error) {
      showToast("Error", `Error al vincular evidencia: ${error.message}`, "destructive");
    } else {
      showToast("Éxito", "Evidencia vinculada correctamente.", "default");
      await fetchRequirements();
    }
  };

  const unlinkEvidenceFromRequirement = async (requirementId, evidenceId) => {
    const { error } = await supabase
      .from('normative_document_requirement_link')
      .delete()
      .eq('requirement_id', requirementId)
      .eq('document_id', evidenceId);

    if (error) {
      showToast("Error", `Error al desvincular evidencia: ${error.message}`, "destructive");
    } else {
      showToast("Éxito", "Evidencia desvinculada correctamente.", "default");
      await fetchRequirements();
    }
  };

  return {
    ...evidenciasHook,
    requirements,
    certification,
    loading: loading || evidenciasHook.loading,
    stats,
    fetchRequirements,
    seedDORAMethod,
    addRequirement,
    updateRequirement,
    deleteRequirement,
    linkEvidenceToRequirement,
    unlinkEvidenceFromRequirement,
  };
};