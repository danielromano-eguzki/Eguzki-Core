import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/lib/customSupabaseClient';

const BUCKET_NAME = 'supplier_documents';

export const useSuppliers = (userId, clientId, showToast) => {
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(false);

  const refetch = useCallback(async () => {
    if (!userId || !clientId) {
      setSuppliers([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('suppliers')
        .select('*')
        .eq('user_id', userId)
        .eq('client_id', clientId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSuppliers(data || []);
    } catch (error) {
      showToast('Error', 'No se pudieron cargar los proveedores.', 'destructive');
      console.error('Error fetching suppliers:', error);
    } finally {
      setLoading(false);
    }
  }, [userId, clientId, showToast]);

  useEffect(() => {
    refetch();
  }, [refetch]);

  const uploadFile = async (file, supplierId, fileNamePrefix) => {
    if (!file) return null;
    const filePath = `${userId}/${supplierId}/${fileNamePrefix}_${uuidv4()}-${file.name}`;
    const { error } = await supabase.storage
      .from(BUCKET_NAME)
      .upload(filePath, file);

    if (error) {
      throw new Error(`Error al subir el archivo: ${error.message}`);
    }
    return filePath;
  };
  
  const deleteFile = async (filePath) => {
     if (!filePath) return;
     const { error } = await supabase.storage.from(BUCKET_NAME).remove([filePath]);
     if (error) {
       console.error("Error deleting file from storage:", error.message);
     }
  };


  const addSupplier = async (supplierData, contractFile, questionnaireFile) => {
    setLoading(true);
    const supplierId = uuidv4();
    try {
      let contract_path = null;
      let security_questionnaire_path = null;

      if (contractFile) {
        contract_path = await uploadFile(contractFile, supplierId, 'contract');
      }
      if (questionnaireFile) {
        security_questionnaire_path = await uploadFile(questionnaireFile, supplierId, 'questionnaire');
      }

      const { data, error } = await supabase
        .from('suppliers')
        .insert([{ 
          ...supplierData, 
          id: supplierId,
          user_id: userId, 
          client_id: clientId,
          contract_path,
          security_questionnaire_path
        }])
        .select()
        .single();
      
      if (error) throw error;
      
      setSuppliers((prev) => [data, ...prev]);
      showToast('Éxito', 'Proveedor añadido correctamente.', 'default');

    } catch (error) {
      showToast('Error', `No se pudo añadir el proveedor: ${error.message}`, 'destructive');
      console.error('Error adding supplier:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const updateSupplier = async (id, supplierData, contractFile, questionnaireFile) => {
    setLoading(true);
    try {
        const existingSupplier = suppliers.find(s => s.id === id);
        if (!existingSupplier) throw new Error("Proveedor no encontrado");

        let contract_path = existingSupplier.contract_path;
        let security_questionnaire_path = existingSupplier.security_questionnaire_path;

        if (contractFile) {
            if (contract_path) await deleteFile(contract_path);
            contract_path = await uploadFile(contractFile, id, 'contract');
        }
        if (questionnaireFile) {
            if (security_questionnaire_path) await deleteFile(security_questionnaire_path);
            security_questionnaire_path = await uploadFile(questionnaireFile, id, 'questionnaire');
        }

        const { data, error } = await supabase
            .from('suppliers')
            .update({ 
                ...supplierData, 
                contract_path, 
                security_questionnaire_path 
            })
            .eq('id', id)
            .select()
            .single();

        if (error) throw error;

        setSuppliers((prev) => prev.map((s) => (s.id === id ? data : s)));
        showToast('Éxito', 'Proveedor actualizado correctamente.', 'default');
    } catch (error) {
        showToast('Error', `No se pudo actualizar el proveedor: ${error.message}`, 'destructive');
        console.error('Error updating supplier:', error);
    } finally {
        setLoading(false);
    }
  };

  const deleteSupplier = async (id) => {
    setLoading(true);
    const supplierToDelete = suppliers.find(s => s.id === id);
    if (!supplierToDelete) {
        showToast('Error', 'Proveedor no encontrado.', 'destructive');
        setLoading(false);
        return;
    }
    
    if(supplierToDelete.contract_path) await deleteFile(supplierToDelete.contract_path);
    if(supplierToDelete.security_questionnaire_path) await deleteFile(supplierToDelete.security_questionnaire_path);

    const { error } = await supabase.from('suppliers').delete().eq('id', id);

    if (error) {
      showToast('Error', 'No se pudo eliminar el proveedor.', 'destructive');
      console.error('Error deleting supplier:', error);
    } else {
      setSuppliers((prev) => prev.filter((s) => s.id !== id));
      showToast('Éxito', 'Proveedor eliminado correctamente.', 'default');
    }
    setLoading(false);
  };
  
  const getFileUrl = async (filePath) => {
    if(!filePath) return null;
    try {
      const { data, error } = await supabase.storage
        .from(BUCKET_NAME)
        .createSignedUrl(filePath, 3600); // URL válida por 1 hora
      if (error) throw error;
      return data.signedUrl;
    } catch(error) {
        showToast('Error', 'No se pudo obtener la URL del archivo.', 'destructive');
        console.error('Error getting file URL:', error);
        return null;
    }
  };

  return { suppliers, addSupplier, updateSupplier, deleteSupplier, loading, refetch, getFileUrl };
};