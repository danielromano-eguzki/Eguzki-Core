import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/lib/customSupabaseClient';

const calculateHash = async (file) => {
  if (!file) return null;
  const buffer = await file.arrayBuffer();
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
};

export const useCertification = (userId, clientId, showToast) => {
  const [requirements, setRequirements] = useState([]);
  const [evidences, setEvidences] = useState([]);
  const [certification, setCertification] = useState(null);
  const [loading, setLoading] = useState(false);

  const loadCertificationData = useCallback(async (certificationName) => {
    if (!userId || !clientId || !certificationName) {
      setRequirements([]);
      setEvidences([]);
      setCertification(null);
      return;
    }
    setLoading(true);

    // 1. Find the certification ID
    let { data: cert, error: certError } = await supabase
      .from('certificaciones')
      .select('*')
      .eq('user_id', userId)
      .eq('client_id', clientId)
      .eq('name', certificationName)
      .single();

    if (certError && certError.code === 'PGRST116') { // Not found
      const { data: newCert, error: insertError } = await supabase
        .from('certificaciones')
        .insert({ user_id: userId, client_id: clientId, name: certificationName, description: `Certificación ${certificationName}` })
        .select()
        .single();
      if (insertError) {
        showToast('Error', `No se pudo crear la certificación ${certificationName}`, 'destructive');
        setLoading(false);
        return;
      }
      cert = newCert;
    } else if (certError) {
      showToast('Error', `Error al cargar la certificación: ${certError.message}`, 'destructive');
      setLoading(false);
      return;
    }
    
    setCertification(cert);

    if (cert) {
      // 2. Fetch requirements for this certification
      const { data: reqs, error: reqsError } = await supabase
        .from('requisitos_certificacion')
        .select('*, linked_evidences:requisito_evidencia_link!requisito_id(evidencias!evidencia_id(*))')
        .eq('user_id', userId)
        .eq('client_id', clientId)
        .eq('certificacion_id', cert.id)
        .order('created_at', { ascending: false });

      if (reqsError) {
        showToast('Error', `No se pudieron cargar los requisitos: ${reqsError.message}`, 'destructive');
      } else {
        const formattedData = reqs ? reqs.map(req => ({ ...req, linked_evidences: req.linked_evidences.map(link => link.evidencias).filter(Boolean) })) : [];
        setRequirements(formattedData);
      }
    }

    // 3. Fetch all evidences for the client
    const { data: evids, error: evidsError } = await supabase
      .from('evidencias')
      .select('*, linked_requirements:requisito_evidencia_link!evidencia_id(requisitos_certificacion!requisito_id(id, codigo, certificacion:certificacion_id(name)))')
      .eq('user_id', userId)
      .eq('client_id', clientId)
      .order('updated_at', { ascending: false });

    if (evidsError) {
      showToast('Error', 'No se pudieron cargar las evidencias.', 'destructive');
    } else {
      setEvidences(evids || []);
    }

    setLoading(false);
  }, [userId, clientId, showToast]);

  const addRequirement = async (reqData, evidenceId, evidenceFile) => {
    if (!certification) return null;
    const { data, error } = await supabase.from('requisitos_certificacion').insert({ ...reqData, user_id: userId, client_id: clientId, certificacion_id: certification.id }).select().single();
    if (error) { showToast('Error', 'No se pudo añadir el requisito.', 'destructive'); return null; }
    
    let finalEvidenceId = evidenceId;
    if (evidenceFile) {
        const newEvidence = await addEvidence({ nombre: evidenceFile.name, tipo: "Documento" }, evidenceFile);
        if(newEvidence) finalEvidenceId = newEvidence.id;
    }

    if (finalEvidenceId) {
        await linkEvidenceToRequirement(data.id, finalEvidenceId);
    }
    
    await loadCertificationData(certification.name);
    showToast('Éxito', 'Requisito añadido.');
    return data;
  };

  const updateRequirement = async (id, reqData, evidenceId, evidenceFile) => {
    const { data, error } = await supabase.from('requisitos_certificacion').update(reqData).eq('id', id).select().single();
    if (error) { showToast('Error', 'No se pudo actualizar el requisito.', 'destructive'); return null; }
    
    let finalEvidenceId = evidenceId;
    if (evidenceFile) {
        const newEvidence = await addEvidence({ nombre: evidenceFile.name, tipo: "Documento" }, evidenceFile);
        if(newEvidence) finalEvidenceId = newEvidence.id;
    }
    
    await loadCertificationData(certification.name);
    showToast('Éxito', 'Requisito actualizado.');
    return data;
  };

  const deleteRequirement = async (id) => {
    const { error } = await supabase.from('requisitos_certificacion').delete().eq('id', id);
    if (error) { showToast('Error', 'No se pudo eliminar el requisito.', 'destructive'); }
    else { await loadCertificationData(certification.name); showToast('Éxito', 'Requisito eliminado.'); }
  };

  const addEvidence = async (evidenceData, file, linkedReqs) => {
    let filePath = null, fileName = null, fileHash = null;
    if (file) {
      const uniqueName = `${userId}/${clientId}/evidences/${uuidv4()}-${file.name}`;
      const { data: uploadData, error: uploadError } = await supabase.storage.from('evidences').upload(uniqueName, file);
      if (uploadError) { showToast("Error al subir archivo", uploadError.message, "destructive"); return null; }
      filePath = uploadData.path;
      fileName = file.name;
      fileHash = await calculateHash(file);
    }
    const { data, error } = await supabase.from('evidencias').insert({ ...evidenceData, user_id: userId, client_id: clientId, file_path: filePath, file_name: fileName, ubicacion: filePath || evidenceData.ubicacion, hash: fileHash }).select().single();
    if (error) { 
      if (error.code === '23505') {
        showToast('Error', 'El ID de evidencia ya existe para este cliente.', 'destructive');
      } else {
        showToast('Error', 'No se pudo añadir la evidencia.', 'destructive');
      }
      return null; 
    }
    
    if (data && linkedReqs && linkedReqs.length > 0) {
      for (const reqId of linkedReqs) {
        await linkEvidenceToRequirement(reqId, data.id);
      }
    }

    await loadCertificationData(certification.name);
    showToast('Éxito', 'Evidencia añadida.');
    return data;
  };

  const updateEvidence = async (id, evidenceData, file, linkedReqs) => {
    let filePath = evidenceData.file_path, fileName = evidenceData.file_name, fileHash = evidenceData.hash;
    if (file) {
      const uniqueName = `${userId}/${clientId}/evidences/${uuidv4()}-${file.name}`;
      const { data: uploadData, error: uploadError } = await supabase.storage.from('evidences').upload(uniqueName, file);
      if (uploadError) { showToast("Error al subir archivo", uploadError.message, "destructive"); return null; }
      filePath = uploadData.path;
      fileName = file.name;
      fileHash = await calculateHash(file);
    }
    const { data, error } = await supabase.from('evidencias').update({ ...evidenceData, file_path: filePath, file_name: fileName, ubicacion: filePath || evidenceData.ubicacion, hash: fileHash }).eq('id', id).select().single();
    if (error) { 
      if (error.code === '23505') {
        showToast('Error', 'El ID de evidencia ya existe para este cliente.', 'destructive');
      } else {
        showToast('Error', 'No se pudo actualizar la evidencia.', 'destructive');
      }
      return null; 
    }

    if (data && linkedReqs) {
      await supabase.from('requisito_evidencia_link').delete().eq('evidencia_id', id);
      for (const reqId of linkedReqs) {
        await linkEvidenceToRequirement(reqId, id);
      }
    }

    await loadCertificationData(certification.name);
    showToast('Éxito', 'Evidencia actualizada.');
    return data;
  };

  const deleteEvidence = async (id) => {
    const evidenceToDelete = evidences.find(e => e.id === id);
    if (evidenceToDelete && evidenceToDelete.file_path) {
      await supabase.storage.from('evidences').remove([evidenceToDelete.file_path]);
    }
    const { error } = await supabase.from('evidencias').delete().eq('id', id);
    if (error) { showToast('Error', 'No se pudo eliminar la evidencia.', 'destructive'); }
    else { await loadCertificationData(certification.name); showToast('Éxito', 'Evidencia eliminada.'); }
  };

  const getEvidenceFileUrl = async (path) => {
    const { data } = supabase.storage.from('evidences').getPublicUrl(path);
    return data.publicUrl;
  };
  
  const linkEvidenceToRequirement = async (requirementId, evidenceId) => {
    const { error } = await supabase.from('requisito_evidencia_link').insert({ requisito_id: requirementId, evidencia_id: evidenceId, user_id: userId, client_id: clientId });
    if (error) {
      if (error.code === '23505') console.log('Link already exists');
      else showToast('Error', 'No se pudo vincular la evidencia.', 'destructive');
    } else {
      console.log('Link created');
    }
  };

  const unlinkEvidenceFromRequirement = async (requirementId, evidenceId) => {
    const { error } = await supabase.from('requisito_evidencia_link').delete().eq('requisito_id', requirementId).eq('evidencia_id', evidenceId);
    if (error) { showToast('Error', 'No se pudo desvincular la evidencia.', 'destructive'); }
    else { showToast('Éxito', 'Evidencia desvinculada.'); await loadCertificationData(certification.name); }
  };

  return {
    certification, requirements, evidences, loading,
    loadCertificationData,
    addRequirement, updateRequirement, deleteRequirement,
    addEvidence, updateEvidence, deleteEvidence, getEvidenceFileUrl,
    linkEvidenceToRequirement, unlinkEvidenceFromRequirement,
    calculateHash
  };
};