import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

export const useRiesgos = (userId, clientId, showToast, refetchAssets) => {
  const [riesgos, setRiesgos] = useState([]);
  const [actionPlans, setActionPlans] = useState([]);
  const [riskSettings, setRiskSettings] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchRiesgos = useCallback(async () => {
    if (!userId || !clientId) {
      setRiesgos([]);
      setActionPlans([]);
      setRiskSettings(null);
      return;
    }
    setLoading(true);
    
    const [riesgosRes, actionPlansRes, settingsRes] = await Promise.all([
      supabase.from('risks').select('*, asset_risk_link(asset_id)').eq('client_id', clientId).order('created_at', { ascending: false }),
      supabase.from('risk_action_plans').select('*').eq('client_id', clientId),
      supabase.from('risk_settings').select('*').eq('client_id', clientId).maybeSingle()
    ]);

    if (riesgosRes.error) showToast("Error cargando riesgos", riesgosRes.error.message, "destructive");
    else setRiesgos(riesgosRes.data || []);

    if (actionPlansRes.error) showToast("Error cargando planes de acción", actionPlansRes.error.message, "destructive");
    else setActionPlans(actionPlansRes.data || []);

    if (settingsRes.error) {
      showToast("Error cargando configuración de riesgos", settingsRes.error.message, "destructive");
    } else {
      if (!settingsRes.data) {
        const { data: newSettings, error: newSettingsError } = await supabase
          .from('risk_settings')
          .insert({ user_id: userId, client_id: clientId, risk_threshold: 15 })
          .select()
          .single();
        if (newSettingsError) showToast("Error creando configuración por defecto", newSettingsError.message, "destructive");
        else setRiskSettings(newSettings);
      } else {
        setRiskSettings(settingsRes.data);
      }
    }

    setLoading(false);
  }, [userId, clientId, showToast]);

  useEffect(() => {
    fetchRiesgos();
  }, [fetchRiesgos]);

  const addRiesgo = async (riesgoData) => {
    if (!userId || !clientId) return showToast("Error", "Usuario o cliente no seleccionado.", "destructive");
    
    const { asset_ids, ...newRiesgoData } = riesgoData;

    const { data, error } = await supabase
      .from('risks')
      .insert([{ ...newRiesgoData, user_id: userId, client_id: clientId }])
      .select()
      .single();
      
    if (error) {
      showToast("Error al añadir riesgo", error.message, "destructive");
      return;
    }

    if (data && asset_ids && asset_ids.length > 0) {
      const links = asset_ids.map(asset_id => ({
        risk_id: data.id,
        asset_id,
        user_id: userId,
        client_id: clientId,
      }));
      const { error: linkError } = await supabase.from('asset_risk_link').insert(links);
      if (linkError) {
        showToast("Error al vincular activos", linkError.message, "destructive");
      }
    }
    
    if (data) { 
      const { data: fullRiesgo } = await supabase.from('risks').select('*, asset_risk_link(asset_id)').eq('id', data.id).single();
      setRiesgos(prev => [fullRiesgo, ...prev]);
      showToast("¡Riesgo añadido!", `"${data.name}" creado.`, "default"); 
      if (refetchAssets) refetchAssets();
    }
  };

  const addMultipleRiesgos = async (riesgosData) => {
    if (!userId || !clientId) return showToast("Error", "Usuario o cliente no seleccionado.", "destructive");
    
    const riesgosToInsert = riesgosData.map(r => ({
      ...r,
      user_id: userId,
      client_id: clientId,
    }));

    const { data, error } = await supabase
      .from('risks')
      .insert(riesgosToInsert)
      .select();
      
    if (error) {
      showToast("Error al importar riesgos", error.message, "destructive");
      return;
    }
    
    if (data) {
      await fetchRiesgos();
      showToast("¡Éxito!", `${data.length} riesgos importados correctamente.`, "success");
    }
  };

  const updateRiesgo = async (riesgoId, riesgoData) => {
    if (!userId || !clientId) return showToast("Error", "Usuario o cliente no seleccionado.", "destructive");
    
    const { asset_ids, ...updatedRiesgoData } = riesgoData;
    
    const { data, error } = await supabase
      .from('risks')
      .update(updatedRiesgoData)
      .eq('id', riesgoId)
      .select()
      .single();

    if (error) {
      showToast("Error al actualizar riesgo", error.message, "destructive");
      return;
    }
    
    const { error: deleteError } = await supabase.from('asset_risk_link').delete().eq('risk_id', riesgoId);
    if(deleteError) {
      showToast("Error al actualizar vínculos de activos", deleteError.message, "destructive");
    }

    if (asset_ids && asset_ids.length > 0) {
      const links = asset_ids.map(asset_id => ({
        risk_id: riesgoId,
        asset_id,
        user_id: userId,
        client_id: clientId,
      }));
      const { error: linkError } = await supabase.from('asset_risk_link').insert(links);
      if (linkError) {
        showToast("Error al vincular nuevos activos", linkError.message, "destructive");
      }
    }

    if (data) { 
      const { data: fullRiesgo } = await supabase.from('risks').select('*, asset_risk_link(asset_id)').eq('id', data.id).single();
      setRiesgos(prev => prev.map(r => r.id === riesgoId ? fullRiesgo : r)); 
      showToast("¡Riesgo actualizado!", `"${data.name}" modificado.`, "default"); 
      if (refetchAssets) refetchAssets();
    }
  };

  const deleteRiesgo = async (riesgoId) => {
    if (!userId || !clientId) return showToast("Error", "Usuario o cliente no seleccionado.", "destructive");
    
    const { error } = await supabase
      .from('risks')
      .delete()
      .eq('id', riesgoId);
      
    if (error) showToast("Error al eliminar riesgo", error.message, "destructive");
    else { 
      setRiesgos(prev => prev.filter(r => r.id !== riesgoId)); 
      setActionPlans(prev => prev.filter(p => p.risk_id !== riesgoId));
      showToast("¡Riesgo eliminado!", "El riesgo y sus datos asociados han sido borrados.", "default"); 
      if (refetchAssets) refetchAssets();
    }
  };

  const addActionPlan = async (newPlanData) => {
    if (!userId || !clientId) return showToast("Error", "Usuario o cliente no seleccionado.", "destructive");
    const { data, error } = await supabase
      .from('risk_action_plans')
      .insert([{ ...newPlanData, user_id: userId, client_id: clientId }])
      .select();
    if (error) showToast("Error al añadir plan de acción", error.message, "destructive");
    else if (data) { setActionPlans(prev => [...prev, data[0]]); showToast("¡Plan de acción añadido!", "El plan ha sido creado.", "default"); }
  };

  const updateActionPlan = async (planId, updatedPlanData) => {
    if (!userId || !clientId) return showToast("Error", "Usuario o cliente no seleccionado.", "destructive");
    const { data, error } = await supabase
      .from('risk_action_plans')
      .update(updatedPlanData)
      .eq('id', planId)
      .select();
    if (error) showToast("Error al actualizar plan de acción", error.message, "destructive");
    else if (data) { setActionPlans(prev => prev.map(p => p.id === planId ? data[0] : p)); showToast("¡Plan de acción actualizado!", "El plan ha sido modificado.", "default"); }
  };

  const deleteActionPlan = async (planId) => {
    if (!userId || !clientId) return showToast("Error", "Usuario o cliente no seleccionado.", "destructive");
    const { error } = await supabase
      .from('risk_action_plans')
      .delete()
      .eq('id', planId);
    if (error) showToast("Error al eliminar plan de acción", error.message, "destructive");
    else { setActionPlans(prev => prev.filter(p => p.id !== planId)); showToast("¡Plan de acción eliminado!", "El plan ha sido borrado.", "default"); }
  };

  const updateRiskThreshold = async (newThreshold) => {
    if (!riskSettings) return showToast("Error", "Configuración no cargada.", "destructive");
    const { data, error } = await supabase
      .from('risk_settings')
      .update({ risk_threshold: newThreshold })
      .eq('id', riskSettings.id)
      .select()
      .single();
    if (error) showToast("Error al actualizar umbral", error.message, "destructive");
    else { setRiskSettings(data); showToast("¡Umbral actualizado!", `Nuevo umbral de riesgo: ${newThreshold}.`, "default"); }
  };
  
  return { 
    riesgos, 
    actionPlans,
    riskSettings,
    loading, 
    addRiesgo, 
    updateRiesgo, 
    deleteRiesgo, 
    addActionPlan,
    updateActionPlan,
    deleteActionPlan,
    updateRiskThreshold,
    addMultipleRiesgos,
    refetch: fetchRiesgos 
  };
};