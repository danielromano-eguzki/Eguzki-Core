import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/lib/customSupabaseClient';

export const useClients = (userId, showToast) => {
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchClients = useCallback(async () => {
    if (!userId) {
      setClients([]);
      return;
    }
    setLoading(true);
    
    // La RLS se encarga de filtrar los clientes según el rol del usuario (consultor o externo)
    const { data, error } = await supabase
      .from('clients')
      .select(`*`)
      .order('name', { ascending: true });
    
    if (error) {
      showToast("Error cargando clientes", error.message, "destructive");
      setClients([]);
    } else {
      setClients(data || []);
    }
    setLoading(false);
  }, [userId, showToast]);

  useEffect(() => {
    if (userId) {
      fetchClients();
    }
  }, [userId, fetchClients]);
  
  const uploadFile = async (clientId, file, fileType) => {
    if (!file) return null;
    // Se mantiene el userId del creador/gestor en la ruta, lo cual está bien para la organización.
    const filePath = `${userId}/${clientId}/${fileType}_${uuidv4()}_${file.name}`;
    const { error: uploadError } = await supabase.storage
      .from('client_documents')
      .upload(filePath, file);

    if (uploadError) {
      showToast("Error al subir archivo", uploadError.message, "destructive");
      return null;
    }
    return filePath;
  };

  const addClient = async (formData) => {
    if (!userId) {
      showToast("Error", "Debes iniciar sesión.", "destructive");
      return null;
    }
    setLoading(true);
    const { files, ...clientData } = formData;
    
    const insertData = { ...clientData, user_id: userId, status: 'Activo' };
    
    const { data: client, error } = await supabase
      .from('clients')
      .insert([insertData])
      .select()
      .single();
    
    if (error) {
      setLoading(false);
      showToast("Error al añadir cliente", error.message, "destructive");
      return null;
    }

    if (client) {
      // Un consultor, al crear un cliente, se auto-asigna.
      const { error: accessError } = await supabase
        .from('client_access')
        .insert({ client_id: client.id, user_id: userId });
        
      if (accessError) {
        showToast("Advertencia", "No se pudo auto-asignar el cliente, pero fue creado.", "default");
      }

      const filePaths = {};
      if (files.nda) filePaths.nda_path = await uploadFile(client.id, files.nda, 'nda');
      if (files.proposal) filePaths.proposal_path = await uploadFile(client.id, files.proposal, 'proposal');
      if (files.contract) filePaths.contract_path = await uploadFile(client.id, files.contract, 'contract');

      if (Object.keys(filePaths).length > 0) {
        const { error: updateError } = await supabase
          .from('clients')
          .update(filePaths)
          .eq('id', client.id);
        if (updateError) showToast("Error al guardar archivos", updateError.message, "destructive");
      }
      
      await fetchClients();
      showToast("¡Cliente añadido!", `"${client.name}" creado.`, "default");
    }
    
    setLoading(false);
    return client;
  };

  const updateClient = async (clientId, formData) => {
    setLoading(true);
    const { files, ...clientData } = formData;
    
    const filePaths = {};
    if (files.nda) filePaths.nda_path = await uploadFile(clientId, files.nda, 'nda');
    if (files.proposal) filePaths.proposal_path = await uploadFile(clientId, files.proposal, 'proposal');
    if (files.contract) filePaths.contract_path = await uploadFile(clientId, files.contract, 'contract');

    const updateData = { ...clientData, ...filePaths };
    
    const { data, error } = await supabase.from('clients').update(updateData).eq('id', clientId).select().single();

    setLoading(false);
    if (error) {
      showToast("Error al actualizar cliente", error.message, "destructive");
      return null;
    }
    if (data) {
      await fetchClients();
      showToast("¡Cliente actualizado!", `"${data.name}" modificado.`, "default");
      return data;
    }
    return null;
  };
  
  const updateClientStatus = async (clientId, status) => {
    setLoading(true);
    const { error } = await supabase
      .from('clients')
      .update({ status })
      .eq('id', clientId);

    if (error) {
      setLoading(false);
      showToast("Error", `No se pudo actualizar el estado del cliente: ${error.message}`, "destructive");
      return;
    }
    
    await fetchClients();

    const client = clients.find(c => c.id === clientId);
    const clientName = client ? client.name : 'El cliente';
    showToast("Estado actualizado", `${clientName} ahora está ${status}.`, "default");
    
    setLoading(false);
  };

  const deleteClient = async (clientId) => {
    setLoading(true);
    try {
      const { data: dependencies, error: depsError } = await supabase
        .from('client_data_dependencies')
        .select('id')
        .eq('client_id', clientId)
        .limit(1);

      if (depsError) throw depsError;
      if (dependencies.length > 0) {
        showToast("Error", "No se puede eliminar un cliente con datos asociados (activos, riesgos, etc.).", "destructive");
        setLoading(false);
        return false;
      }

      const { error } = await supabase.from('clients').delete().eq('id', clientId);
      if (error) throw error;
      setClients(prev => prev.filter(c => c.id !== clientId));
      showToast("¡Cliente eliminado!", "El cliente ha sido borrado.", "default");
      return true;
    } catch (error) {
      showToast("Error al eliminar cliente", error.message, "destructive");
      return false;
    } finally {
      setLoading(false);
    }
  };
  
  const getClientFileUrl = async (filePath) => {
    if (!filePath) return null;
    const { data } = supabase.storage.from('client_documents').getPublicUrl(filePath);
    return data?.publicUrl;
  };

  return {
    clients,
    addClient,
    updateClient,
    deleteClient,
    updateClientStatus,
    loading,
    refetchClients: fetchClients,
    getClientFileUrl,
  };
};