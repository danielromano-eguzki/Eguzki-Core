import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/lib/customSupabaseClient';

const calculateHash = async (file) => {
  if (!file) return null;
  const buffer = await file.arrayBuffer();
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
};

export const useInternalDocumentation = (userId, clientId, showToast) => {
  const [evidences, setEvidences] = useState([]);
  const [loading, setLoading] = useState(false);

  const loadEvidences = useCallback(async () => {
    if (!userId || !clientId) {
      setEvidences([]);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('evidencias')
      .select('*, linked_requirements:requisito_evidencia_link!evidencia_id(requisitos_certificacion!requisito_id(id, codigo, certificacion:certificacion_id(name)))')
      .eq('user_id', userId)
      .eq('client_id', clientId)
      .order('updated_at', { ascending: false });

    if (error) {
      showToast('Error', 'No se pudieron cargar las evidencias.', 'destructive');
    } else {
      setEvidences(data || []);
    }
    setLoading(false);
  }, [userId, clientId, showToast]);

  useEffect(() => {
    loadEvidences();
  }, [loadEvidences]);

  const linkEvidenceToRequirement = async (requirementId, evidenceId) => {
    const { error } = await supabase.from('requisito_evidencia_link').insert({ requisito_id: requirementId, evidencia_id: evidenceId, user_id: userId, client_id: clientId });
    if (error && error.code !== '23505') {
      showToast('Error', 'No se pudo vincular la evidencia.', 'destructive');
    }
  };

  const addEvidence = async (evidenceData, file, linkedReqs) => {
    let filePath = null, fileName = null, fileHash = null;
    if (file) {
      const uniqueName = `${userId}/${clientId}/evidences/${uuidv4()}-${file.name}`;
      const { data: uploadData, error: uploadError } = await supabase.storage.from('evidences').upload(uniqueName, file);
      if (uploadError) { showToast("Error al subir archivo", uploadError.message, "destructive"); return null; }
      filePath = uploadData.path;
      fileName = file.name;
      fileHash = await calculateHash(file);
    }
    const { data, error } = await supabase.from('evidencias').insert({ ...evidenceData, user_id: userId, client_id: clientId, file_path: filePath, file_name: fileName, hash: fileHash }).select().single();
    if (error) { 
      showToast('Error', 'No se pudo añadir la evidencia.', 'destructive');
      return null; 
    }
    
    if (data && linkedReqs && linkedReqs.length > 0) {
      for (const reqId of linkedReqs) {
        await linkEvidenceToRequirement(reqId, data.id);
      }
    }

    await loadEvidences();
    showToast('Éxito', 'Evidencia añadida.');
    return data;
  };

  const updateEvidence = async (id, evidenceData, file, linkedReqs) => {
    const originalEvidence = evidences.find(e => e.id === id);
    let filePath = originalEvidence.file_path, fileName = originalEvidence.file_name, fileHash = originalEvidence.hash;
    if (file) {
      if (filePath) { await supabase.storage.from('evidences').remove([filePath]); }
      const uniqueName = `${userId}/${clientId}/evidences/${uuidv4()}-${file.name}`;
      const { data: uploadData, error: uploadError } = await supabase.storage.from('evidences').upload(uniqueName, file);
      if (uploadError) { showToast("Error al subir archivo", uploadError.message, "destructive"); return null; }
      filePath = uploadData.path;
      fileName = file.name;
      fileHash = await calculateHash(file);
    }
    const { data, error } = await supabase.from('evidencias').update({ ...evidenceData, file_path: filePath, file_name: fileName, hash: fileHash }).eq('id', id).select().single();
    if (error) { 
      showToast('Error', 'No se pudo actualizar la evidencia.', 'destructive');
      return null; 
    }

    if (data && linkedReqs) {
      await supabase.from('requisito_evidencia_link').delete().eq('evidencia_id', id);
      for (const reqId of linkedReqs) {
        await linkEvidenceToRequirement(reqId, id);
      }
    }

    await loadEvidences();
    showToast('Éxito', 'Evidencia actualizada.');
    return data;
  };

  const deleteEvidence = async (id) => {
    const evidenceToDelete = evidences.find(e => e.id === id);
    if (evidenceToDelete && evidenceToDelete.file_path) {
      await supabase.storage.from('evidences').remove([evidenceToDelete.file_path]);
    }
    await supabase.from('requisito_evidencia_link').delete().eq('evidencia_id', id);
    const { error } = await supabase.from('evidencias').delete().eq('id', id);
    if (error) { showToast('Error', 'No se pudo eliminar la evidencia.', 'destructive'); }
    else { await loadEvidences(); showToast('Éxito', 'Evidencia eliminada.'); }
  };

  const getEvidenceFileUrl = async (path) => {
    const { data } = supabase.storage.from('evidences').getPublicUrl(path);
    return data.publicUrl;
  };

  return {
    evidences, loading,
    addEvidence, updateEvidence, deleteEvidence,
    getEvidenceFileUrl, calculateHash, showToast,
    refetch: loadEvidences,
  };
};