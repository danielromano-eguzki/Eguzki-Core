import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/lib/customSupabaseClient';

export const usePrivacy = (userId, clientId) => {
  const [ropa, setRopa] = useState([]);
  const [pia, setPia] = useState([]);
  const [dsr, setDsr] = useState([]);
  const [breaches, setBreaches] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [internationalTransfers, setInternationalTransfers] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchData = useCallback(async (table, setter) => {
    if (!userId || !clientId) {
      setter([]);
      return;
    }
    const { data, error } = await supabase
      .from(table)
      .select('*')
      .eq('user_id', userId)
      .eq('client_id', clientId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error(`Error fetching ${table}:`, error);
      setter([]);
    } else {
      setter(data || []);
    }
  }, [userId, clientId]);

  useEffect(() => {
    if (userId && clientId) {
      setLoading(true);
      Promise.all([
        fetchData('privacy_ropa', setRopa),
        fetchData('privacy_pia', setPia),
        fetchData('privacy_dsr', setDsr),
        fetchData('privacy_breaches', setBreaches),
        fetchData('privacy_contracts', setContracts),
        fetchData('privacy_international_transfers', setInternationalTransfers),
        fetchData('privacy_policies', setPolicies),
      ]).finally(() => setLoading(false));
    }
  }, [userId, clientId, fetchData]);

  const addRopa = async (ropaData, file) => {
    let attachment_path = null;
    let attachment_name = null;
    if (file) {
      const uniqueName = `${userId}/${clientId}/ropa_attachments/${uuidv4()}-${file.name}`;
      const { data: uploadData, error: uploadError } = await supabase.storage.from('ropa_attachments').upload(uniqueName, file);
      if (uploadError) {
        console.error('Error uploading file:', uploadError);
        return null;
      }
      attachment_path = uploadData.path;
      attachment_name = file.name;
    }

    const { data, error } = await supabase
      .from('privacy_ropa')
      .insert([{ ...ropaData, user_id: userId, client_id: clientId, attachment_path, attachment_name }])
      .select()
      .single();
    if (error) console.error('Error adding ROPA:', error);
    else setRopa(prev => [data, ...prev]);
    return data;
  };

  const updateRopa = async (id, ropaData, file) => {
    let attachment_path = ropaData.attachment_path;
    let attachment_name = ropaData.attachment_name;
    if (file) {
      if (attachment_path) {
        await supabase.storage.from('ropa_attachments').remove([attachment_path]);
      }
      const uniqueName = `${userId}/${clientId}/ropa_attachments/${uuidv4()}-${file.name}`;
      const { data: uploadData, error: uploadError } = await supabase.storage.from('ropa_attachments').upload(uniqueName, file);
      if (uploadError) {
        console.error('Error uploading file:', uploadError);
        return null;
      }
      attachment_path = uploadData.path;
      attachment_name = file.name;
    }

    const { data, error } = await supabase
      .from('privacy_ropa')
      .update({ ...ropaData, attachment_path, attachment_name })
      .eq('id', id)
      .select()
      .single();
    if (error) console.error('Error updating ROPA:', error);
    else setRopa(prev => prev.map(r => r.id === id ? data : r));
    return data;
  };

  const deleteRopa = async (id) => {
    const ropaToDelete = ropa.find(r => r.id === id);
    if (ropaToDelete?.attachment_path) {
      await supabase.storage.from('ropa_attachments').remove([ropaToDelete.attachment_path]);
    }
    const { error } = await supabase.from('privacy_ropa').delete().eq('id', id);
    if (error) console.error('Error deleting ROPA:', error);
    else setRopa(prev => prev.filter(r => r.id !== id));
  };

  const addPia = async (piaData) => {
    const { data, error } = await supabase.from('privacy_pia').insert([{ ...piaData, user_id: userId, client_id: clientId }]).select().single();
    if (error) console.error('Error adding PIA:', error);
    else setPia(prev => [data, ...prev]);
    return data;
  };

  const updatePia = async (id, piaData) => {
    const { data, error } = await supabase.from('privacy_pia').update(piaData).eq('id', id).select().single();
    if (error) console.error('Error updating PIA:', error);
    else setPia(prev => prev.map(p => p.id === id ? data : p));
    return data;
  };

  const deletePia = async (id) => {
    const { error } = await supabase.from('privacy_pia').delete().eq('id', id);
    if (error) console.error('Error deleting PIA:', error);
    else setPia(prev => prev.filter(p => p.id !== id));
  };

  const addDsr = async (dsrData) => {
    const { data, error } = await supabase.from('privacy_dsr').insert([{ ...dsrData, user_id: userId, client_id: clientId }]).select().single();
    if (error) console.error('Error adding DSR:', error);
    else setDsr(prev => [data, ...prev]);
    return data;
  };

  const updateDsr = async (id, dsrData) => {
    const { data, error } = await supabase.from('privacy_dsr').update(dsrData).eq('id', id).select().single();
    if (error) console.error('Error updating DSR:', error);
    else setDsr(prev => prev.map(d => d.id === id ? data : d));
    return data;
  };

  const deleteDsr = async (id) => {
    const { error } = await supabase.from('privacy_dsr').delete().eq('id', id);
    if (error) console.error('Error deleting DSR:', error);
    else setDsr(prev => prev.filter(d => d.id !== id));
  };

  const addBreach = async (breachData) => {
    const { data, error } = await supabase.from('privacy_breaches').insert([{ ...breachData, user_id: userId, client_id: clientId }]).select().single();
    if (error) console.error('Error adding Breach:', error);
    else setBreaches(prev => [data, ...prev]);
    return data;
  };

  const updateBreach = async (id, breachData) => {
    const { data, error } = await supabase.from('privacy_breaches').update(breachData).eq('id', id).select().single();
    if (error) console.error('Error updating Breach:', error);
    else setBreaches(prev => prev.map(b => b.id === id ? data : b));
    return data;
  };

  const deleteBreach = async (id) => {
    const { error } = await supabase.from('privacy_breaches').delete().eq('id', id);
    if (error) console.error('Error deleting Breach:', error);
    else setBreaches(prev => prev.filter(b => b.id !== id));
  };

  const addContract = async (contractData, file) => {
    let attachment_path = null;
    let attachment_name = null;
    if (file) {
      const uniqueName = `${userId}/${clientId}/contract_attachments/${uuidv4()}-${file.name}`;
      const { data: uploadData, error: uploadError } = await supabase.storage.from('contract_attachments').upload(uniqueName, file);
      if (uploadError) {
        console.error('Error uploading file:', uploadError);
        return null;
      }
      attachment_path = uploadData.path;
      attachment_name = file.name;
    }
    const { data, error } = await supabase.from('privacy_contracts').insert([{ ...contractData, user_id: userId, client_id: clientId, attachment_path, attachment_name }]).select().single();
    if (error) console.error('Error adding Contract:', error);
    else setContracts(prev => [data, ...prev]);
    return data;
  };

  const updateContract = async (id, contractData, file) => {
    let attachment_path = contractData.attachment_path;
    let attachment_name = contractData.attachment_name;
    if (file) {
      if (attachment_path) {
        await supabase.storage.from('contract_attachments').remove([attachment_path]);
      }
      const uniqueName = `${userId}/${clientId}/contract_attachments/${uuidv4()}-${file.name}`;
      const { data: uploadData, error: uploadError } = await supabase.storage.from('contract_attachments').upload(uniqueName, file);
      if (uploadError) {
        console.error('Error uploading file:', uploadError);
        return null;
      }
      attachment_path = uploadData.path;
      attachment_name = file.name;
    }
    const { data, error } = await supabase.from('privacy_contracts').update({ ...contractData, attachment_path, attachment_name }).eq('id', id).select().single();
    if (error) console.error('Error updating Contract:', error);
    else setContracts(prev => prev.map(c => c.id === id ? data : c));
    return data;
  };

  const deleteContract = async (id) => {
    const contractToDelete = contracts.find(c => c.id === id);
    if (contractToDelete?.attachment_path) {
      await supabase.storage.from('contract_attachments').remove([contractToDelete.attachment_path]);
    }
    const { error } = await supabase.from('privacy_contracts').delete().eq('id', id);
    if (error) console.error('Error deleting Contract:', error);
    else setContracts(prev => prev.filter(c => c.id !== id));
  };

  const addInternationalTransfer = async (transferData) => {
    const { data, error } = await supabase.from('privacy_international_transfers').insert([{ ...transferData, user_id: userId, client_id: clientId }]).select().single();
    if (error) console.error('Error adding Transfer:', error);
    else setInternationalTransfers(prev => [data, ...prev]);
    return data;
  };

  const updateInternationalTransfer = async (id, transferData) => {
    const { data, error } = await supabase.from('privacy_international_transfers').update(transferData).eq('id', id).select().single();
    if (error) console.error('Error updating Transfer:', error);
    else setInternationalTransfers(prev => prev.map(t => t.id === id ? data : t));
    return data;
  };

  const deleteInternationalTransfer = async (id) => {
    const { error } = await supabase.from('privacy_international_transfers').delete().eq('id', id);
    if (error) console.error('Error deleting Transfer:', error);
    else setInternationalTransfers(prev => prev.filter(t => t.id !== id));
  };

  const savePolicy = async (policyData) => {
    setLoading(true);
    const dataToSave = {
      ...policyData,
      user_id: userId,
      client_id: clientId,
      last_updated: new Date().toISOString().split('T')[0],
    };

    let response;
    if (policyData.id) {
      response = await supabase
        .from('privacy_policies')
        .update(dataToSave)
        .eq('id', policyData.id)
        .select()
        .single();
    } else {
      response = await supabase
        .from('privacy_policies')
        .insert(dataToSave)
        .select()
        .single();
    }

    if (response.error) {
      console.error('Error saving policy:', response.error);
    } else if (response.data) {
      setPolicies(prev => {
        const existing = prev.find(p => p.id === response.data.id);
        if (existing) {
          return prev.map(p => p.id === response.data.id ? response.data : p);
        }
        return [...prev, response.data];
      });
    }
    setLoading(false);
  };

  return {
    ropa, addRopa, updateRopa, deleteRopa,
    pia, addPia, updatePia, deletePia,
    dsr, addDsr, updateDsr, deleteDsr,
    breaches, addBreach, updateBreach, deleteBreach,
    contracts, addContract, updateContract, deleteContract,
    internationalTransfers, addInternationalTransfer, updateInternationalTransfer, deleteInternationalTransfer,
    policies, savePolicy,
    loading,
  };
};