import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/lib/customSupabaseClient';

const ENS_CERTIFICATION_NAME = 'Esquema Nacional de Seguridad';

const calculateHash = async (file) => {
  if (!file) return null;
  const buffer = await file.arrayBuffer();
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
};

export const useEns = (userId, clientId, showToast) => {
  const [requirements, setRequirements] = useState([]);
  const [evidences, setEvidences] = useState([]);
  const [certifications, setCertifications] = useState([]);
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({
    total: 0,
    cumplido: 0,
    parcial: 0,
    no_cumplido: 0,
    no_aplica: 0,
    percentage: 0,
  });

  const getRequirementsForCertification = useCallback(async (certificationId) => {
    if (!userId || !clientId || !certificationId) {
      setRequirements([]);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('requisitos_certificacion')
      .select('*, linked_evidences:requisito_evidencia_link!requisito_id(evidencias!evidencia_id(*))')
      .eq('user_id', userId)
      .eq('client_id', clientId)
      .eq('certificacion_id', certificationId)
      .order('codigo', { ascending: true });

    if (error) {
      showToast('Error', `No se pudieron cargar los requisitos: ${error.message}`, 'destructive');
      setRequirements([]);
    } else {
      const formattedData = data ? data.map(req => ({ ...req, linked_evidences: req.linked_evidences.map(link => link.evidencias).filter(Boolean) })) : [];
      setRequirements(formattedData);
    }
    setLoading(false);
  }, [userId, clientId, showToast]);

  const loadInitialData = useCallback(async () => {
    if (!userId || !clientId) {
      setRequirements([]);
      setEvidences([]);
      setCertifications([]);
      setStats({ total: 0, cumplido: 0, parcial: 0, no_cumplido: 0, no_aplica: 0, percentage: 0 });
      return;
    }
    setLoading(true);

    try {
      const { data: certs, error: certsError } = await supabase
        .from('certificaciones')
        .select('*')
        .eq('user_id', userId)
        .eq('client_id', clientId);

      if (certsError) throw certsError;
      
      setCertifications(certs || []);
      const ensCert = certs.find(c => c.name === ENS_CERTIFICATION_NAME);

      let currentRequirements = [];
      if (ensCert) {
        const { data: reqsData, error: reqsError } = await supabase
            .from('requisitos_certificacion')
            .select('*, linked_evidences:requisito_evidencia_link!requisito_id(evidencias!evidencia_id(*))')
            .eq('user_id', userId)
            .eq('client_id', clientId)
            .eq('certificacion_id', ensCert.id)
            .order('codigo', { ascending: true });
        if (reqsError) throw reqsError;
        currentRequirements = reqsData ? reqsData.map(req => ({ ...req, linked_evidences: req.linked_evidences.map(link => link.evidencias).filter(Boolean) })) : [];
        setRequirements(currentRequirements);
      } else {
        setRequirements([]);
      }

      const { data: evids, error: evidsError } = await supabase
        .from('evidencias')
        .select('*, linked_requirements:requisito_evidencia_link!evidencia_id(requisitos_certificacion!requisito_id(id, codigo, certificacion:certificacion_id(name), tipo_requisito))')
        .eq('user_id', userId)
        .eq('client_id', clientId)
        .order('updated_at', { ascending: false });

      if (evidsError) throw evidsError;
      setEvidences(evids || []);

    } catch (error) {
        showToast('Error', `No se pudieron cargar los datos de ENS: ${error.message}`, 'destructive');
        setRequirements([]);
        setEvidences([]);
        setCertifications([]);
    } finally {
        setLoading(false);
    }
  }, [userId, clientId, showToast]);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  useEffect(() => {
    if (requirements.length > 0) {
      const newStats = requirements.reduce((acc, req) => {
        acc.total++;
        switch (req.estado_cumplimiento) {
          case 'Cumplido': acc.cumplido++; break;
          case 'Parcial': acc.parcial++; break;
          case 'No cumplido': acc.no_cumplido++; break;
          case 'No aplica': acc.no_aplica++; break;
          default: acc.no_cumplido++; break;
        }
        return acc;
      }, { total: 0, cumplido: 0, parcial: 0, no_cumplido: 0, no_aplica: 0 });
      
      const applicableReqs = newStats.total - newStats.no_aplica;
      newStats.percentage = applicableReqs > 0 ? Math.round((newStats.cumplido / applicableReqs) * 100) : 0;
      setStats(newStats);
    } else {
      setStats({ total: 0, cumplido: 0, parcial: 0, no_cumplido: 0, no_aplica: 0, percentage: 0 });
    }
  }, [requirements]);

  const seedEnsRequirements = async () => {
    if (!userId || !clientId) return;
    setLoading(true);
    const { error } = await supabase.rpc('seed_ens_requirements_for_client', {
      p_user_id: userId,
      p_client_id: clientId
    });
    setLoading(false);
    if (error) {
      showToast('Error', `No se pudo inicializar el ENS: ${error.message}`, 'destructive');
    } else {
      showToast('Éxito', 'Requisitos del ENS inicializados correctamente.');
      await loadInitialData();
    }
  };

  const updateRequirement = async (id, reqData) => {
    const { data, error } = await supabase.from('requisitos_certificacion').update(reqData).eq('id', id).select().single();
    if (error) { showToast('Error', 'No se pudo actualizar el requisito.', 'destructive'); return null; }
    await loadInitialData();
    showToast('Éxito', 'Requisito actualizado.');
    return data;
  };

  return {
    requirements,
    evidences,
    certifications,
    loading,
    stats,
    getRequirementsForCertification,
    seedEnsRequirements,
    updateRequirement,
    calculateHash,
    showToast,
  };
};