import { useState, useEffect, useCallback } from 'react';

export const useNormativas = (userId, clientId, showToast, supabase) => {
  const [frameworks, setFrameworks] = useState([]);
  const [controls, setControls] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchFrameworks = useCallback(async () => {
    if (!userId || !clientId) {
      setFrameworks([]);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('certificaciones')
      .select('*')
      .eq('user_id', userId)
      .eq('client_id', clientId)
      .order('created_at', { ascending: true });

    if (error) {
      showToast("Error cargando certificaciones", error.message, "destructive");
    } else {
      setFrameworks(data || []);
    }
    setLoading(false);
  }, [userId, clientId, supabase, showToast]);

  const fetchControls = useCallback(async () => {
     setControls([]);
  }, []);

  useEffect(() => {
    fetchFrameworks();
    fetchControls();
  }, [fetchFrameworks, fetchControls]);

  const addFramework = async (newFrameworkData) => {
    if (!userId || !clientId) return;
    const { data, error } = await supabase
      .from('certificaciones')
      .insert([{ ...newFrameworkData, user_id: userId, client_id: clientId }])
      .select()
      .single();
    if (error) {
      showToast("Error al añadir certificación", error.message, "destructive");
      return null;
    } else if (data) {
      setFrameworks(prev => [...prev, data]);
      showToast("¡Certificación añadida!", "La nueva certificación ha sido creada.", "default");
      return data;
    }
    return null;
  };

  const updateFramework = async (frameworkId, updatedFrameworkData) => {
    if (!userId || !clientId) return;
    const { data, error } = await supabase
      .from('certificaciones')
      .update(updatedFrameworkData)
      .eq('id', frameworkId)
      .eq('user_id', userId)
      .eq('client_id', clientId)
      .select()
      .single();
    if (error) {
      showToast("Error al actualizar certificación", error.message, "destructive");
    } else if (data) {
      setFrameworks(prev => prev.map(f => f.id === frameworkId ? data : f));
      showToast("¡Certificación actualizada!", "La certificación ha sido modificada.", "default");
    }
  };

  const deleteFramework = async (frameworkId) => {
    if (!userId || !clientId) return;
    
    const { error } = await supabase
      .from('certificaciones')
      .delete()
      .eq('id', frameworkId)
      .eq('user_id', userId)
      .eq('client_id', clientId);
    if (error) {
      showToast("Error al eliminar certificación", "Asegúrese que no tiene requisitos asociados.", "destructive");
    } else {
      setFrameworks(prev => prev.filter(f => f.id !== frameworkId));
      showToast("¡Certificación eliminada!", "La certificación y sus controles han sido borrados.", "default");
    }
  };

  const addControl = async (newControlData) => {
    showToast("Funcionalidad obsoleta", "La gestión de controles ha sido reemplazada por 'Requisitos y Evidencias'.", "default");
  };

  const updateControl = async (controlId, updatedControlData) => {
     showToast("Funcionalidad obsoleta", "La gestión de controles ha sido reemplazada por 'Requisitos y Evidencias'.", "default");
  };

  const deleteControl = async (controlId) => {
     showToast("Funcionalidad obsoleta", "La gestión de controles ha sido reemplazada por 'Requisitos y Evidencias'.", "default");
  };
  
  const addFrameworkWithControls = async (frameworkData, controlsData) => {
     showToast("Funcionalidad obsoleta", "La gestión de controles ha sido reemplazada por 'Requisitos y Evidencias'.", "default");
  };

  return {
    frameworks,
    controls,
    loading,
    addFramework,
    updateFramework,
    deleteFramework,
    addControl,
    updateControl,
    deleteControl,
    addFrameworkWithControls,
    refetch: () => {
      fetchFrameworks();
      fetchControls();
    }
  };
};