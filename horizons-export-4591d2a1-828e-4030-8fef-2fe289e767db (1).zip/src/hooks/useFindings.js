import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

export const useFindings = (userId, clientId, showToast) => {
  const [findings, setFindings] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchFindings = useCallback(async () => {
    if (!userId || !clientId) {
      setFindings([]);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('findings')
      .select(`*`)
      .eq('client_id', clientId)
      .order('created_at', { ascending: false });

    if (error) {
      showToast("Error cargando hallazgos", error.message, "destructive");
      setFindings([]);
    } else {
      setFindings(data || []);
    }
    setLoading(false);
  }, [userId, clientId, showToast]);

  useEffect(() => {
    fetchFindings();
  }, [fetchFindings]);

  const addFinding = async (findingData) => {
    if (!userId || !clientId) {
      showToast("Error", "Debes iniciar sesión y seleccionar un cliente.", "destructive");
      return null;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('findings')
      .insert([{ ...findingData, user_id: userId, client_id: clientId }])
      .select(`*`)
      .single();
    
    setLoading(false);
    if (error) {
      showToast("Error al añadir hallazgo", error.message, "destructive");
      return null;
    }
    if (data) {
      setFindings(prev => [data, ...prev]);
      showToast("¡Hallazgo añadido!", `"${data.description.substring(0,20)}..." creado.`, "default");
      return data;
    }
    return null;
  };

  const updateFinding = async (findingId, updatedData) => {
    if (!userId || !clientId) {
      showToast("Error", "Debes iniciar sesión.", "destructive");
      return null;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('findings')
      .update(updatedData)
      .eq('id', findingId)
      .eq('client_id', clientId)
      .select(`*`)
      .single();

    setLoading(false);
    if (error) {
      showToast("Error al actualizar hallazgo", error.message, "destructive");
      return null;
    }
    if (data) {
      setFindings(prev => prev.map(f => f.id === findingId ? data : f));
      showToast("¡Hallazgo actualizado!", `"${data.description.substring(0,20)}..." modificado.`, "default");
      return data;
    }
    return null;
  };

  const deleteFinding = async (findingId) => {
    if (!userId || !clientId) {
      showToast("Error", "Debes iniciar sesión.", "destructive");
      return false;
    }
    setLoading(true);
    const { error } = await supabase
      .from('findings')
      .delete()
      .eq('id', findingId)
      .eq('client_id', clientId);
    
    setLoading(false);
    if (error) {
      showToast("Error al eliminar hallazgo", error.message, "destructive");
      return false;
    }
    setFindings(prev => prev.filter(f => f.id !== findingId));
    showToast("¡Hallazgo eliminado!", "El hallazgo ha sido borrado.", "default");
    return true;
  };

  return {
    findings,
    addFinding,
    updateFinding,
    deleteFinding,
    fetchFindings,
    loading
  };
};