import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/lib/customSupabaseClient';

export const useTrainings = (userId, clientId, showToast) => {
  const [trainings, setTrainings] = useState([]);
  const [loading, setLoading] = useState(false);

  const refetch = useCallback(async () => {
    if (!userId || !clientId) {
      setTrainings([]);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('trainings')
      .select('*')
      .eq('user_id', userId)
      .eq('client_id', clientId)
      .order('training_date', { ascending: false });

    if (error) {
      showToast('Error', 'No se pudieron cargar las formaciones.', 'destructive');
      console.error('Error fetching trainings:', error);
    } else {
      setTrainings(data);
    }
    setLoading(false);
  }, [userId, clientId, showToast]);

  useEffect(() => {
    refetch();
  }, [refetch]);

  const uploadFile = async (file, trainingId) => {
    if (!file) return null;
    const filePath = `${userId}/${clientId}/trainings/${trainingId}/${uuidv4()}-${file.name}`;
    const { error } = await supabase.storage
      .from('training_documents')
      .upload(filePath, file);

    if (error) {
      throw new Error(`Error al subir el archivo: ${error.message}`);
    }
    return filePath;
  };
  
  const deleteFile = async (filePath) => {
     if (!filePath) return;
     const { error } = await supabase.storage.from('training_documents').remove([filePath]);
     if (error) {
       console.error("Error deleting file from storage:", error.message);
     }
  };

  const addTraining = async (trainingData, attachmentFile) => {
    setLoading(true);
    const trainingId = uuidv4();
    try {
      let attachment_path = null;
      if (attachmentFile) {
        attachment_path = await uploadFile(attachmentFile, trainingId);
      }

      const { data, error } = await supabase
        .from('trainings')
        .insert([{ 
          ...trainingData, 
          id: trainingId,
          user_id: userId, 
          client_id: clientId,
          attachment_path,
        }])
        .select()
        .single();
      
      if (error) throw error;
      
      await refetch();
      showToast('Éxito', 'Formación añadida correctamente.', 'default');
    } catch (error) {
      showToast('Error', `No se pudo añadir la formación: ${error.message}`, 'destructive');
      console.error('Error adding training:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const updateTraining = async (id, trainingData, attachmentFile) => {
    setLoading(true);
    try {
        const existingTraining = trainings.find(t => t.id === id);
        if (!existingTraining) throw new Error("Formación no encontrada");

        let attachment_path = existingTraining.attachment_path;
        if (attachmentFile) {
            if (attachment_path) await deleteFile(attachment_path);
            attachment_path = await uploadFile(attachmentFile, id);
        }

        const { data, error } = await supabase
            .from('trainings')
            .update({ ...trainingData, attachment_path })
            .eq('id', id)
            .select()
            .single();

        if (error) throw error;

        setTrainings((prev) => prev.map((t) => (t.id === id ? data : t)));
        showToast('Éxito', 'Formación actualizada correctamente.', 'default');
    } catch (error) {
        showToast('Error', `No se pudo actualizar la formación: ${error.message}`, 'destructive');
        console.error('Error updating training:', error);
    } finally {
        setLoading(false);
    }
  };

  const deleteTraining = async (id) => {
    setLoading(true);
    const trainingToDelete = trainings.find(t => t.id === id);
    if (!trainingToDelete) {
        showToast('Error', 'Formación no encontrada.', 'destructive');
        setLoading(false);
        return;
    }
    
    if(trainingToDelete.attachment_path) await deleteFile(trainingToDelete.attachment_path);

    const { error } = await supabase.from('trainings').delete().eq('id', id);

    if (error) {
      showToast('Error', 'No se pudo eliminar la formación.', 'destructive');
      console.error('Error deleting training:', error);
    } else {
      setTrainings((prev) => prev.filter((t) => t.id !== id));
      showToast('Éxito', 'Formación eliminada correctamente.', 'default');
    }
    setLoading(false);
  };
  
  const getFileUrl = async (filePath) => {
    if(!filePath) return null;
    const { data, error } = await supabase.storage
      .from('training_documents')
      .createSignedUrl(filePath, 3600);
    if (error) {
      showToast('Error', 'No se pudo obtener la URL del archivo.', 'destructive');
      console.error('Error getting file URL:', error);
      return null;
    }
    return data.signedUrl;
  };

  return { trainings, addTraining, updateTraining, deleteTraining, loading, refetch, getFileUrl };
};