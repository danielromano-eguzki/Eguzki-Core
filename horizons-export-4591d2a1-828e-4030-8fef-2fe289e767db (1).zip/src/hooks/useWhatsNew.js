import { useState, useEffect, useCallback } from 'react';

const useWhatsNew = (supabase, showToast) => {
  const [updates, setUpdates] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchMajorUpdates = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('whats_new_items')
        .select('*')
        .eq('is_major', true)
        .order('publish_date', { ascending: false });

      if (error) {
        throw error;
      }
      setUpdates(data || []);
    } catch (error) {
      showToast('Error al cargar las novedades', error.message, 'destructive');
      setUpdates([]);
    } finally {
      setLoading(false);
    }
  }, [supabase, showToast]);

  useEffect(() => {
    fetchMajorUpdates();
  }, [fetchMajorUpdates]);

  return { updates, loading, refetchUpdates: fetchMajorUpdates };
};

export default useWhatsNew;