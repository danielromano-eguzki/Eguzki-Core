import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';

export const useInitialAudit = (userId, selectedClientId, showToast, supabase) => {
  const [questions, setQuestions] = useState([]);
  const [responses, setResponses] = useState({});
  const [actionItems, setActionItems] = useState([]);
  const [complianceIndex, setComplianceIndex] = useState(0);
  
  const [loadingQuestions, setLoadingQuestions] = useState(false);
  const [loadingResponses, setLoadingResponses] = useState(false);
  const [savingResponse, setSavingResponse] = useState(false);

  const fetchQuestions = useCallback(async () => {
    if (!userId) {
      setQuestions([]);
      return;
    }
    setLoadingQuestions(true);
    try {
      const { data, error } = await supabase
        .from('initial_audit_questions')
        .select('*')
        .eq('is_active', true)
        .order('category_order', { ascending: true })
        .order('question_order', { ascending: true });

      if (error) throw error;
      setQuestions(data || []);
    } catch (error) {
      showToast('Error al cargar preguntas de auditoría', error.message, 'destructive');
      setQuestions([]);
    } finally {
      setLoadingQuestions(false);
    }
  }, [userId, supabase, showToast]);

  const fetchResponses = useCallback(async () => {
    if (!userId || !selectedClientId) {
      setResponses({});
      setActionItems([]);
      setComplianceIndex(0);
      return;
    }
    setLoadingResponses(true);
    try {
      const { data, error } = await supabase
        .from('initial_audit_responses')
        .select('*')
        .eq('user_id', userId)
        .eq('client_id', selectedClientId);

      if (error) throw error;
      
      const responsesMap = (data || []).reduce((acc, res) => {
        acc[res.question_id] = res;
        return acc;
      }, {});
      setResponses(responsesMap);
      calculateComplianceAndActions(data || [], questions);

    } catch (error) {
      showToast('Error al cargar respuestas de auditoría', error.message, 'destructive');
      setResponses({});
      setActionItems([]);
      setComplianceIndex(0);
    } finally {
      setLoadingResponses(false);
    }
  }, [userId, selectedClientId, supabase, showToast, questions]);

  const calculateComplianceAndActions = (currentResponsesData, currentQuestions) => {
    if (!currentQuestions || currentQuestions.length === 0) {
      setComplianceIndex(0);
      setActionItems([]);
      return;
    }

    let appliedCount = 0;
    let notAppliedCount = 0;
    const newActionItems = [];

    currentQuestions.forEach(q => {
      const response = currentResponsesData.find(r => r.question_id === q.id);
      if (response) {
        if (response.response === 'Aplicado') {
          appliedCount++;
        } else if (response.response === 'No Aplicado') {
          notAppliedCount++;
        }
        
        if ((response.response === 'No Aplicado' || response.response === 'No Definido') && response.action_item_description) {
          newActionItems.push({
            id: response.id, 
            question_id: q.id,
            question_text: q.question_text,
            category: q.category,
            description: response.action_item_description,
            priority: response.action_item_priority,
            status: response.action_item_status,
            due_date: response.action_item_due_date,
            responsible: response.action_item_responsible,
          });
        }
      }
    });

    const totalRelevant = appliedCount + notAppliedCount;
    const index = totalRelevant > 0 ? (appliedCount / totalRelevant) * 100 : 0;
    setComplianceIndex(parseFloat(index.toFixed(2)));
    setActionItems(newActionItems.sort((a,b) => (a.category + a.question_text).localeCompare(b.category + b.question_text)));
  };
  
  useEffect(() => {
    fetchQuestions();
  }, [fetchQuestions]);

  useEffect(() => {
    if (selectedClientId && questions.length > 0) {
      fetchResponses();
    } else if (!selectedClientId) {
      setResponses({});
      setActionItems([]);
      setComplianceIndex(0);
    }
  }, [selectedClientId, questions, fetchResponses]);


  const saveResponse = async (questionId, responseValue, actionDetails) => {
    if (!userId || !selectedClientId) {
      showToast('Error', 'Cliente o usuario no seleccionado.', 'destructive');
      return null;
    }
    setSavingResponse(true);
    try {
      const existingResponse = responses[questionId];
      let savedData;

      const responsePayload = {
        user_id: userId,
        client_id: selectedClientId,
        question_id: questionId,
        response: responseValue,
        observations: actionDetails?.observations || null,
        action_item_description: actionDetails?.action_item_description || null,
        action_item_priority: actionDetails?.action_item_priority || null,
        action_item_status: actionDetails?.action_item_status || null,
        action_item_due_date: actionDetails?.action_item_due_date || null,
        action_item_responsible: actionDetails?.action_item_responsible || null,
        updated_at: new Date().toISOString(),
      };

      if (existingResponse) {
        const { data, error } = await supabase
          .from('initial_audit_responses')
          .update(responsePayload)
          .eq('id', existingResponse.id)
          .select()
          .single();
        if (error) throw error;
        savedData = data;
      } else {
        responsePayload.id = uuidv4();
        responsePayload.created_at = new Date().toISOString();
        const { data, error } = await supabase
          .from('initial_audit_responses')
          .insert(responsePayload)
          .select()
          .single();
        if (error) throw error;
        savedData = data;
      }
      
      setResponses(prev => ({ ...prev, [questionId]: savedData }));
      
      const updatedResponsesArray = Object.values({ ...responses, [questionId]: savedData });
      calculateComplianceAndActions(updatedResponsesArray, questions);

      showToast('Respuesta guardada', 'La respuesta se ha guardado correctamente.', 'default');
      return savedData;
    } catch (error) {
      showToast('Error al guardar respuesta', error.message, 'destructive');
      return null;
    } finally {
      setSavingResponse(false);
    }
  };
  
  const refetchInitialAudit = () => {
    if (selectedClientId) {
      fetchQuestions(); 
      fetchResponses();
    }
  };

  return {
    questions,
    responses,
    actionItems,
    complianceIndex,
    loadingQuestions,
    loadingResponses,
    savingResponse,
    saveResponse,
    refetchInitialAudit,
  };
};