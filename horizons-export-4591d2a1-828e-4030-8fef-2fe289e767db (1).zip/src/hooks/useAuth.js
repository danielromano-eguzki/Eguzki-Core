import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

export const useAuth = (showToast) => {
  const [session, setSession] = useState(null);
  const [authStep, setAuthStep] = useState('loading'); // 'loading', 'login', 'mfa_required', 'mfa_setup_required', 'password_reset', 'authenticated'
  const [loadingAuth, setLoadingAuth] = useState(true);
  const [isVerifying, setIsVerifying] = useState(false);
  const [userRole, setUserRole] = useState(null);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  
  const handleLogout = useCallback(async () => {
    await supabase.auth.signOut();
    setSession(null);
    setUserRole(null);
    setIsSuperAdmin(false);
    setAuthStep('login');
  }, []);

  const processSession = useCallback(async (currentSession) => {
    setSession(currentSession);
    if (currentSession) {
      const { user } = currentSession;
      
      let { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('role')
        .eq('user_id', user.id)
        .single();
        
      if (profileError && profileError.code === 'PGRST116') {
        console.warn("Profile not found for user, creating one...");
        const { data: newProfile, error: createError } = await supabase
          .from('profiles')
          .insert({ user_id: user.id, email: user.email, role: 'consultant' })
          .select('role')
          .single();
        
        if (createError) {
          console.error("Error creating user profile:", createError);
          showToast('Error de Perfil', 'No se pudo crear el perfil de usuario.', 'destructive');
          await handleLogout();
          return;
        }
        profile = newProfile;
      } else if (profileError) {
        console.error("Error fetching user profile:", profileError);
        showToast('Error de Perfil', `No se pudo cargar el perfil de usuario: ${profileError.message}`, 'destructive');
        await handleLogout();
        return;
      }
      
      const role = profile?.role || 'external_user';
      setUserRole(role);
      setIsSuperAdmin(role === 'consultant');
      
      const { data, error } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
      if (error) {
        if (error.message.includes('Invalid Refresh Token') || error.message.includes('invalid API key') || error.message.includes('Session Expired')) {
          showToast('Sesión Expirada', 'Tu sesión ha expirado. Por favor, inicia sesión de nuevo.', 'destructive');
          await handleLogout();
          return;
        }
        showToast('Error MFA', `No se pudo verificar el nivel de autenticación: ${error.message}`, 'destructive');
        await handleLogout();
        return;
      }
      
      if (data.currentLevel === 'aal2') {
         setAuthStep('authenticated');
      } else if (data.nextLevel === 'aal2') {
         const { data: factorData, error: factorError } = await supabase.auth.mfa.listFactors();
         if(factorError) {
            showToast('Error MFA', `No se pudieron obtener los factores 2FA: ${factorError.message}`, 'destructive');
            await handleLogout();
            return;
         }

         if (factorData.totp.length > 0) {
            setAuthStep('mfa_required');
         } else {
            setAuthStep('mfa_setup_required');
         }
      } else {
        setAuthStep('mfa_setup_required');
      }
    } else {
      setAuthStep('login');
      setUserRole(null);
      setIsSuperAdmin(false);
    }
  }, [showToast, handleLogout]);

  const handleLogin = async (email, password) => {
    setIsVerifying(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
    } catch (error) {
      showToast("Error de inicio de sesión", error.message, "destructive");
      setAuthStep('login');
    } finally {
      setIsVerifying(false);
    }
  };
  
  const handleMfaLogin = async (code) => {
    setIsVerifying(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("No hay una sesión activa para verificar MFA.");
      
      const { data: factorData, error: factorError } = await supabase.auth.mfa.listFactors();
      if (factorError || !factorData.totp || factorData.totp.length === 0) {
        throw new Error("No se encontró un factor 2FA verificado.");
      }
      const factor = factorData.totp[0];

      const { data: challengeData, error: challengeError } = await supabase.auth.mfa.challenge({ factorId: factor.id });
      if (challengeError) throw new Error(`Error al iniciar desafío 2FA: ${challengeError.message}`);
      
      const { error: verifyError } = await supabase.auth.mfa.verify({
        factorId: factor.id,
        challengeId: challengeData.id,
        code: code,
      });

      if (verifyError) {
        if (verifyError.message.includes('Invalid TOTP code')) {
          throw new Error('El código de verificación es incorrecto. Inténtalo de nuevo.');
        }
        throw new Error(`Código incorrecto: ${verifyError.message}`);
      }
      
    } catch (error) {
      showToast("Error de verificación 2FA", error.message, "destructive");
    } finally {
      setIsVerifying(false);
    }
  };

  const updateUserPassword = async (newPassword) => {
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
      showToast("Error al actualizar", error.message, "destructive");
      return { error };
    } else {
      showToast("Éxito", "Tu contraseña ha sido actualizada correctamente.");
      return { error: null };
    }
  };

  const finishMfaSetup = useCallback(() => {
    setAuthStep('authenticated');
  }, []);

  useEffect(() => {
    setLoadingAuth(true);
    supabase.auth.getSession().then(({ data: { session }, error }) => {
      if (error) {
        console.error("Error getting session on initial load:", error.message);
        handleLogout();
      } else if (session) {
        processSession(session);
      } else {
        setAuthStep('login');
      }
      setLoadingAuth(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setLoadingAuth(true);
      if (event === 'PASSWORD_RECOVERY') {
        setSession(session);
        setAuthStep('password_reset');
      } else if (event === 'USER_UPDATED' || event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
        processSession(session);
      } else if (event === 'SIGNED_OUT') {
        setSession(null);
        setUserRole(null);
        setIsSuperAdmin(false);
        setAuthStep('login');
      }
      setLoadingAuth(false);
    });

    return () => subscription.unsubscribe();
  }, [processSession, handleLogout]);

  return { 
    session, 
    authStep,
    loadingAuth, 
    isVerifying,
    userRole,
    isSuperAdmin,
    handleLogin, 
    handleMfaLogin,
    handleLogout,
    updateUserPassword,
    finishMfaSetup,
  };
};