import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

export const useIntegrations = (userId, clientId, showToast) => {
  const [integrations, setIntegrations] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchIntegrations = useCallback(async () => {
    if (!userId || !clientId) {
        setIntegrations([]);
        return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('user_integrations')
        .select('*')
        .eq('user_id', userId)
        .eq('client_id', clientId);

      if (error) throw error;
      setIntegrations(data || []);
    } catch (error) {
      console.error('Error fetching integrations:', error);
      showToast("Error al cargar integraciones", error.message, "destructive");
      setIntegrations([]);
    } finally {
      setLoading(false);
    }
  }, [userId, clientId, showToast]);

  useEffect(() => {
    if (userId && clientId) {
        fetchIntegrations();
    }
  }, [userId, clientId, fetchIntegrations]);

  const upsertIntegrationConfig = async (integrationName, config, isActive, status) => {
    if (!userId || !clientId) return null;
    setLoading(true);
    try {
      const existingIntegration = integrations.find(
        int => int.integration_name === integrationName && int.client_id === clientId
      );

      let result;
      if (existingIntegration) {
        const { data, error } = await supabase
          .from('user_integrations')
          .update({ 
            config_details: config, 
            is_active: isActive,
            status: status || (isActive ? 'Conectado' : 'Desconectado'),
            updated_at: new Date().toISOString()
          })
          .eq('id', existingIntegration.id)
          .select()
          .single();
        if (error) throw error;
        result = data;
      } else {
        const { data, error } = await supabase
          .from('user_integrations')
          .insert({
            user_id: userId,
            client_id: clientId,
            integration_name: integrationName,
            config_details: config,
            is_active: isActive,
            status: status || (isActive ? 'Conectado' : 'Desconectado'),
          })
          .select()
          .single();
        if (error) throw error;
        result = data;
      }
      
      showToast("Configuración guardada", `La configuración para ${integrationName} se ha guardado correctamente.`, "default");
      await fetchIntegrations();
      return result;

    } catch (error) {
      console.error('Error saving integration config:', error);
      showToast("Error al guardar configuración", error.message, "destructive");
      return null;
    } finally {
      setLoading(false);
    }
  };
  
  const getIntegrationStatus = (integrationName) => {
    const config = integrations.find(
      int => int.integration_name === integrationName && int.client_id === clientId
    );
    return config ? config.status : 'No configurado';
  };

  const getIntegrationConfig = (integrationName) => {
    const config = integrations.find(
      int => int.integration_name === integrationName && int.client_id === clientId
    );
    return config || null;
  };


  return {
    integrations,
    loading,
    fetchIntegrations,
    upsertIntegrationConfig,
    getIntegrationStatus,
    getIntegrationConfig,
  };
};