import { useState, useEffect, useCallback } from 'react';

export const useBackupTests = (userId, selectedClientId, showToast, supabase) => {
  const [backupTests, setBackupTests] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleError = useCallback((error, context) => {
    console.error(context, error);
    showToast("Error", `Error en ${context}: ${error.message}`, "destructive");
  }, [showToast]);

  const refetch = useCallback(async () => {
    if (!userId || !selectedClientId) {
      setBackupTests([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('backup_tests')
        .select('*')
        .eq('user_id', userId)
        .eq('client_id', selectedClientId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setBackupTests(data || []);
    } catch (error) {
      handleError(error, 'cargando pruebas de backup');
      setBackupTests([]);
    } finally {
      setLoading(false);
    }
  }, [userId, selectedClientId, supabase, handleError]);

  useEffect(() => {
    if (userId && selectedClientId) {
      refetch();
    }
  }, [userId, selectedClientId, refetch]);

  const addBackupTest = async (testData) => {
    if (!userId || !selectedClientId) return;
    try {
        const { data, error } = await supabase
            .from('backup_tests')
            .insert([{ ...testData, user_id: userId, client_id: selectedClientId }])
            .select();
        if (error) throw error;
        setBackupTests(prev => [data[0], ...prev]);
        showToast('Éxito', 'Prueba de backup registrada.');
        return data[0];
    } catch (error) {
        handleError(error, 'registrando prueba de backup');
        return null;
    }
  };

  return { backupTests, addBackupTest, loading, refetch };
};