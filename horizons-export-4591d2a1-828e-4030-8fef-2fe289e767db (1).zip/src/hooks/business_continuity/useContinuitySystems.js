import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';

export const useContinuitySystems = (userId, selectedClientId, showToast, supabase) => {
  const [continuitySystems, setContinuitySystems] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleError = useCallback((error, context) => {
    console.error(context, error);
    showToast("Error", `Error en ${context}: ${error.message}`, "destructive");
  }, [showToast]);

  const refetch = useCallback(async () => {
    if (!userId || !selectedClientId) {
      setContinuitySystems([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('continuity_systems')
        .select('*')
        .eq('user_id', userId)
        .eq('client_id', selectedClientId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setContinuitySystems(data || []);
    } catch (error) {
      handleError(error, 'cargando sistemas de continuidad');
      setContinuitySystems([]);
    } finally {
      setLoading(false);
    }
  }, [userId, selectedClientId, supabase, handleError]);

  useEffect(() => {
    if (userId && selectedClientId) {
      refetch();
    }
  }, [userId, selectedClientId, refetch]);

  const addContinuitySystem = async (systemData, file) => {
    if (!userId || !selectedClientId) return;
    setLoading(true);
    let filePath = null;
    let fileName = null;

    if (file) {
      const uniqueFileName = `${uuidv4()}-${file.name}`;
      filePath = `${userId}/${selectedClientId}/continuity_systems/${uniqueFileName}`;
      fileName = file.name;
      const { error: uploadError } = await supabase.storage
        .from('continuity_documents')
        .upload(filePath, file);

      if (uploadError) {
        handleError(uploadError, "subiendo documento del sistema de continuidad");
        setLoading(false);
        return null;
      }
    }

    try {
      const { data, error } = await supabase
        .from('continuity_systems')
        .insert([{ ...systemData, user_id: userId, client_id: selectedClientId, document_path: filePath, document_name: fileName }])
        .select();
      if (error) throw error;
      setContinuitySystems(prev => [data[0], ...prev]);
      showToast("Éxito", "Sistema de continuidad añadido.", "default");
      return data[0];
    } catch (error) {
      handleError(error, "añadiendo sistema de continuidad");
      return null;
    } finally {
      setLoading(false);
    }
  };

  const updateContinuitySystem = async (id, systemData, file) => {
    setLoading(true);
    let filePath = systemData.document_path;
    let fileName = systemData.document_name;

    if (file) {
      const uniqueFileName = `${uuidv4()}-${file.name}`;
      filePath = `${userId}/${selectedClientId}/continuity_systems/${uniqueFileName}`;
      fileName = file.name;
      const { error: uploadError } = await supabase.storage
        .from('continuity_documents')
        .upload(filePath, file);

      if (uploadError) {
        handleError(uploadError, "actualizando documento del sistema de continuidad");
        setLoading(false);
        return null;
      }
    }
    
    try {
      const { data, error } = await supabase
        .from('continuity_systems')
        .update({ ...systemData, document_path: filePath, document_name: fileName })
        .eq('id', id)
        .select();
      if (error) throw error;
      setContinuitySystems(prev => prev.map(item => (item.id === id ? data[0] : item)));
      showToast("Éxito", "Sistema de continuidad actualizado.", "default");
      return data[0];
    } catch (error) {
      handleError(error, "actualizando sistema de continuidad");
      return null;
    } finally {
      setLoading(false);
    }
  };

  const deleteContinuitySystem = async (id, documentPath) => {
    setLoading(true);
    if (documentPath) {
      const { error: deleteError } = await supabase.storage
        .from('continuity_documents')
        .remove([documentPath]);
      if (deleteError) {
        handleError(deleteError, "eliminando documento del sistema de continuidad");
      }
    }
    try {
      const { error } = await supabase
        .from('continuity_systems')
        .delete()
        .eq('id', id);
      if (error) throw error;
      setContinuitySystems(prev => prev.filter(item => item.id !== id));
      showToast("Éxito", "Sistema de continuidad eliminado.", "default");
    } catch (error) {
      handleError(error, "eliminando sistema de continuidad");
    } finally {
      setLoading(false);
    }
  };
  
  const getContinuityDocumentUrl = async (documentPath) => {
    if (!documentPath) return null;
    try {
      const { data, error } = await supabase.storage
        .from('continuity_documents')
        .createSignedUrl(documentPath, 3600); // URL válida por 1 hora
      if (error) throw error;
      return data.signedUrl;
    } catch (error) {
      handleError(error, "obteniendo URL del documento de continuidad");
      return null;
    }
  };

  return { continuitySystems, addContinuitySystem, updateContinuitySystem, deleteContinuitySystem, getContinuityDocumentUrl, loading, refetch };
};