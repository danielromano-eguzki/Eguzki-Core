import { useState, useEffect, useCallback } from 'react';

export const useBackupInventory = (userId, selectedClientId, showToast, supabase) => {
  const [backupInventory, setBackupInventory] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleError = useCallback((error, context) => {
    console.error(context, error);
    showToast("Error", `Error en ${context}: ${error.message}`, "destructive");
  }, [showToast]);

  const refetch = useCallback(async () => {
    if (!userId || !selectedClientId) {
      setBackupInventory([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('backup_inventory')
        .select('*')
        .eq('user_id', userId)
        .eq('client_id', selectedClientId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setBackupInventory(data || []);
    } catch (error) {
      handleError(error, 'cargando inventario de backups');
      setBackupInventory([]);
    } finally {
      setLoading(false);
    }
  }, [userId, selectedClientId, supabase, handleError]);

  useEffect(() => {
    if (userId && selectedClientId) {
      refetch();
    }
  }, [userId, selectedClientId, refetch]);

  const addBackupInventoryItem = async (itemData) => {
    if (!userId || !selectedClientId) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('backup_inventory')
        .insert([{ ...itemData, user_id: userId, client_id: selectedClientId }])
        .select();
      if (error) throw error;
      setBackupInventory(prev => [data[0], ...prev]);
      showToast("Éxito", "Elemento de inventario de backup añadido.", "default");
    } catch (error) {
      handleError(error, "añadiendo a inventario de backup");
    } finally {
      setLoading(false);
    }
  };

  const updateBackupInventoryItem = async (id, itemData) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('backup_inventory')
        .update(itemData)
        .eq('id', id)
        .select();
      if (error) throw error;
      setBackupInventory(prev => prev.map(item => (item.id === id ? data[0] : item)));
      showToast("Éxito", "Elemento de inventario de backup actualizado.", "default");
    } catch (error) {
      handleError(error, "actualizando inventario de backup");
    } finally {
      setLoading(false);
    }
  };

  const deleteBackupInventoryItem = async (id) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('backup_inventory')
        .delete()
        .eq('id', id);
      if (error) throw error;
      setBackupInventory(prev => prev.filter(item => item.id !== id));
      showToast("Éxito", "Elemento de inventario de backup eliminado.", "default");
    } catch (error) {
      handleError(error, "eliminando de inventario de backup");
    } finally {
      setLoading(false);
    }
  };

  return { backupInventory, addBackupInventoryItem, updateBackupInventoryItem, deleteBackupInventoryItem, loading, refetch };
};