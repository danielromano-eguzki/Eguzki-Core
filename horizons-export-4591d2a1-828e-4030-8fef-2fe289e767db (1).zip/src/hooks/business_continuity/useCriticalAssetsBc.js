import { useState, useEffect, useCallback } from 'react';

export const useCriticalAssetsBc = (userId, selectedClientId, showToast, supabase) => {
  const [criticalAssetsBc, setCriticalAssetsBc] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleError = useCallback((error, context) => {
    console.error(context, error);
    showToast("Error", `Error en ${context}: ${error.message}`, "destructive");
  }, [showToast]);

  const refetch = useCallback(async () => {
    if (!userId || !selectedClientId) {
      setCriticalAssetsBc([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('critical_assets_inventory_bc')
        .select('*')
        .eq('user_id', userId)
        .eq('client_id', selectedClientId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setCriticalAssetsBc(data || []);
    } catch (error) {
      handleError(error, 'cargando activos críticos de BC');
      setCriticalAssetsBc([]);
    } finally {
      setLoading(false);
    }
  }, [userId, selectedClientId, supabase, handleError]);

  useEffect(() => {
    if (userId && selectedClientId) {
      refetch();
    }
  }, [userId, selectedClientId, refetch]);

  const addCriticalAssetBc = async (assetData) => {
    if (!userId || !selectedClientId) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('critical_assets_inventory_bc')
        .insert([{ ...assetData, user_id: userId, client_id: selectedClientId }])
        .select();
      if (error) throw error;
      setCriticalAssetsBc(prev => [data[0], ...prev]);
      showToast("Éxito", "Activo crítico (BC) añadido.", "default");
    } catch (error) {
      handleError(error, "añadiendo activo crítico (BC)");
    } finally {
      setLoading(false);
    }
  };

  const updateCriticalAssetBc = async (id, assetData) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('critical_assets_inventory_bc')
        .update(assetData)
        .eq('id', id)
        .select();
      if (error) throw error;
      setCriticalAssetsBc(prev => prev.map(item => (item.id === id ? data[0] : item)));
      showToast("Éxito", "Activo crítico (BC) actualizado.", "default");
    } catch (error) {
      handleError(error, "actualizando activo crítico (BC)");
    } finally {
      setLoading(false);
    }
  };

  const deleteCriticalAssetBc = async (id) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('critical_assets_inventory_bc')
        .delete()
        .eq('id', id);
      if (error) throw error;
      setCriticalAssetsBc(prev => prev.filter(item => item.id !== id));
      showToast("Éxito", "Activo crítico (BC) eliminado.", "default");
    } catch (error) {
      handleError(error, "eliminando activo crítico (BC)");
    } finally {
      setLoading(false);
    }
  };

  return { criticalAssetsBc, addCriticalAssetBc, updateCriticalAssetBc, deleteCriticalAssetBc, loading, refetch };
};