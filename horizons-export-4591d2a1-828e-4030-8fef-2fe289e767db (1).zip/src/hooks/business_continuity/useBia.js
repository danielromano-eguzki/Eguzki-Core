import { useState, useEffect, useCallback } from 'react';

export const useBia = (userId, selectedClientId, showToast, supabase) => {
  const [bias, setBias] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleError = useCallback((error, context) => {
    console.error(context, error);
    showToast("Error", `Error en ${context}: ${error.message}`, "destructive");
  }, [showToast]);

  const refetch = useCallback(async () => {
    if (!userId || !selectedClientId) {
      setBias([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('business_impact_analysis')
        .select('*')
        .eq('user_id', userId)
        .eq('client_id', selectedClientId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setBias(data || []);
    } catch (error) {
      handleError(error, 'cargando BIAs');
      setBias([]);
    } finally {
      setLoading(false);
    }
  }, [userId, selectedClientId, supabase, handleError]);

  useEffect(() => {
    if (userId && selectedClientId) {
      refetch();
    }
  }, [userId, selectedClientId, refetch]);

  const addBia = async (biaData) => {
    if (!userId || !selectedClientId) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('business_impact_analysis')
        .insert([{ ...biaData, user_id: userId, client_id: selectedClientId }])
        .select();
      if (error) throw error;
      setBias(prev => [data[0], ...prev]);
      showToast("Éxito", "BIA añadido correctamente.", "default");
    } catch (error) {
      handleError(error, "añadiendo BIA");
    } finally {
      setLoading(false);
    }
  };

  const updateBia = async (id, biaData) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('business_impact_analysis')
        .update(biaData)
        .eq('id', id)
        .select();
      if (error) throw error;
      setBias(prev => prev.map(item => (item.id === id ? data[0] : item)));
      showToast("Éxito", "BIA actualizado correctamente.", "default");
    } catch (error) {
      handleError(error, "actualizando BIA");
    } finally {
      setLoading(false);
    }
  };

  const deleteBia = async (id) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('business_impact_analysis')
        .delete()
        .eq('id', id);
      if (error) throw error;
      setBias(prev => prev.filter(item => item.id !== id));
      showToast("Éxito", "BIA eliminado correctamente.", "default");
    } catch (error) {
      handleError(error, "eliminando BIA");
    } finally {
      setLoading(false);
    }
  };

  return { bias, addBia, updateBia, deleteBia, loading, refetch };
};