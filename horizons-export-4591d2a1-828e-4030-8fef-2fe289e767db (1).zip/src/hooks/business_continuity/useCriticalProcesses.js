import { useState, useEffect, useCallback } from 'react';

export const useCriticalProcesses = (userId, selectedClientId, showToast, supabase) => {
  const [criticalProcesses, setCriticalProcesses] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleError = useCallback((error, context) => {
    console.error(context, error);
    showToast("Error", `Error en ${context}: ${error.message}`, "destructive");
  }, [showToast]);

  const refetch = useCallback(async () => {
    if (!userId || !selectedClientId) {
      setCriticalProcesses([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('critical_processes')
        .select('*')
        .eq('user_id', userId)
        .eq('client_id', selectedClientId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setCriticalProcesses(data || []);
    } catch (error) {
      handleError(error, 'cargando procesos críticos');
      setCriticalProcesses([]);
    } finally {
      setLoading(false);
    }
  }, [userId, selectedClientId, supabase, handleError]);

  useEffect(() => {
    if (userId && selectedClientId) {
      refetch();
    }
  }, [userId, selectedClientId, refetch]);

  const addCriticalProcess = async (processData) => {
    if (!userId || !selectedClientId) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('critical_processes')
        .insert([{ ...processData, user_id: userId, client_id: selectedClientId }])
        .select();
      if (error) throw error;
      setCriticalProcesses(prev => [data[0], ...prev]);
      showToast("Éxito", "Proceso crítico añadido correctamente.", "default");
    } catch (error) {
      handleError(error, "añadiendo proceso crítico");
    } finally {
      setLoading(false);
    }
  };
  
  const updateCriticalProcess = async (id, processData) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('critical_processes')
        .update(processData)
        .eq('id', id)
        .select();
      if (error) throw error;
      setCriticalProcesses(prev => prev.map(item => (item.id === id ? data[0] : item)));
      showToast("Éxito", "Proceso crítico actualizado.", "default");
    } catch (error) {
      handleError(error, "actualizando proceso crítico");
    } finally {
      setLoading(false);
    }
  };

  const deleteCriticalProcess = async (id) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('critical_processes')
        .delete()
        .eq('id', id);
      if (error) throw error;
      setCriticalProcesses(prev => prev.filter(item => item.id !== id));
      showToast("Éxito", "Proceso crítico eliminado.", "default");
    } catch (error) {
      handleError(error, "eliminando proceso crítico");
    } finally {
      setLoading(false);
    }
  };

  return { criticalProcesses, addCriticalProcess, updateCriticalProcess, deleteCriticalProcess, loading, refetch };
};