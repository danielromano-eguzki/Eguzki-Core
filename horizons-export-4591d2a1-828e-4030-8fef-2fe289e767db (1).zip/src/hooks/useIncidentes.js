import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';

export const useIncidentes = (userId, selectedClientId, showToast, supabase) => {
  const [incidents, setIncidents] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchIncidents = useCallback(async () => {
    if (!userId || !selectedClientId) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('incidents')
      .select('*')
      .eq('user_id', userId)
      .eq('client_id', selectedClientId)
      .order('created_at', { ascending: false });

    if (error) {
      showToast('Error', 'No se pudieron cargar los incidentes.', 'destructive');
      console.error('Error fetching incidents:', error);
    } else {
      setIncidents(data);
    }
    setLoading(false);
  }, [userId, selectedClientId, supabase, showToast]);

  useEffect(() => {
    fetchIncidents();
  }, [fetchIncidents]);

  const addIncident = async (incidentData, attachmentFile) => {
    if (!userId || !selectedClientId) return;
    setLoading(true);

    let attachment_path = null;
    let attachment_name = null;

    if (attachmentFile) {
        const fileExt = attachmentFile.name.split('.').pop();
        const fileName = `${uuidv4()}.${fileExt}`;
        const filePath = `${userId}/${selectedClientId}/${fileName}`;
        
        const { error: uploadError } = await supabase.storage
            .from('incident_attachments')
            .upload(filePath, attachmentFile);

        if (uploadError) {
            showToast('Error de subida', 'No se pudo adjuntar el archivo.', 'destructive');
            console.error('Error uploading file:', uploadError);
            setLoading(false);
            return;
        }
        attachment_path = filePath;
        attachment_name = attachmentFile.name;
    }

    const newIncident = {
      ...incidentData,
      user_id: userId,
      client_id: selectedClientId,
      attachment_path,
      attachment_name
    };

    const { data, error } = await supabase
      .from('incidents')
      .insert(newIncident)
      .select()
      .single();

    if (error) {
      showToast('Error', 'No se pudo crear el incidente.', 'destructive');
      console.error('Error adding incident:', error);
    } else {
      setIncidents(prev => [data, ...prev]);
      showToast('Éxito', 'Incidente creado correctamente.', 'default');
    }
    setLoading(false);
  };
  
  const updateIncident = async (id, incidentData, attachmentFile) => {
    setLoading(true);
    let updatedData = { ...incidentData };

    if (attachmentFile) {
      const fileExt = attachmentFile.name.split('.').pop();
      const fileName = `${uuidv4()}.${fileExt}`;
      const filePath = `${userId}/${selectedClientId}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('incident_attachments')
        .upload(filePath, attachmentFile);

      if (uploadError) {
        showToast('Error de subida', 'No se pudo adjuntar el nuevo archivo.', 'destructive');
        setLoading(false);
        return;
      }
      updatedData.attachment_path = filePath;
      updatedData.attachment_name = attachmentFile.name;
    }

    const { data, error } = await supabase
      .from('incidents')
      .update(updatedData)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      showToast('Error', 'No se pudo actualizar el incidente.', 'destructive');
      console.error('Error updating incident:', error);
    } else {
      setIncidents(prev => prev.map(i => (i.id === id ? data : i)));
      showToast('Éxito', 'Incidente actualizado correctamente.', 'default');
    }
    setLoading(false);
  };

  const deleteIncident = async (id) => {
    setLoading(true);
    const { error } = await supabase.from('incidents').delete().eq('id', id);

    if (error) {
      showToast('Error', 'No se pudo eliminar el incidente.', 'destructive');
      console.error('Error deleting incident:', error);
    } else {
      setIncidents(prev => prev.filter(i => i.id !== id));
      showToast('Éxito', 'Incidente eliminado.', 'default');
    }
    setLoading(false);
  };
  
  const getAttachmentUrl = async (path) => {
    const { data, error } = await supabase.storage
      .from('incident_attachments')
      .createSignedUrl(path, 60); // URL válida por 60 segundos
    if (error) {
      showToast('Error', 'No se pudo obtener el enlace del archivo.', 'destructive');
      return null;
    }
    return data.signedUrl;
  };


  return { incidents, loading, addIncident, updateIncident, deleteIncident, getAttachmentUrl, refetch: fetchIncidents };
};