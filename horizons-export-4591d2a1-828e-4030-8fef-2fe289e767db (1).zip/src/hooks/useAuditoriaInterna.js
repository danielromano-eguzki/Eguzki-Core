import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

export const useAuditoriaInterna = (userId, clientId, showToast) => {
  const [loading, setLoading] = useState(false);
  const [auditPrograms, setAuditPrograms] = useState([]);
  const [requirements, setRequirements] = useState([]);
  const [planning, setPlanning] = useState([]);
  const [meetings, setMeetings] = useState([]);
  const [compliance, setCompliance] = useState([]);

  const fetchAuditPrograms = useCallback(async () => {
    if (!userId || !clientId) {
      setAuditPrograms([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase.from('audit_programs').select('*').eq('user_id', userId).eq('client_id', clientId).order('created_at', { ascending: false });
      if (error) {
        throw error;
      }
      setAuditPrograms(data || []);
    } catch (error) {
      showToast("Error cargando programas", error.message, "destructive");
    } finally {
      setLoading(false);
    }
  }, [userId, clientId, showToast]);

  useEffect(() => {
    fetchAuditPrograms();
  }, [fetchAuditPrograms]);

  const fetchProgramData = useCallback(async (programId) => {
    if (!programId || !userId) return;
    setLoading(true);
    try {
      const [reqs, plans, meets, comps] = await Promise.all([
        supabase.from('internal_audit_requirements').select('*').eq('audit_program_id', programId).eq('user_id', userId),
        supabase.from('internal_audit_planning').select('*').eq('audit_program_id', programId).eq('user_id', userId),
        supabase.from('internal_audit_meetings').select('*').eq('audit_program_id', programId).eq('user_id', userId).order('meeting_date', { ascending: false }),
        supabase.from('internal_audit_compliance').select('*, requirement:internal_audit_requirements(*), evidence:evidencias(*)').eq('audit_program_id', programId).eq('user_id', userId)
      ]);

      if(reqs.error) throw reqs.error;
      setRequirements(reqs.data || []);
      
      if(plans.error) throw plans.error;
      setPlanning(plans.data || []);

      if(meets.error) throw meets.error;
      setMeetings(meets.data || []);
      
      if(comps.error) throw comps.error;
      setCompliance(comps.data || []);
    } catch (error) {
      showToast("Error cargando datos del programa", error.message, "destructive");
    } finally {
      setLoading(false);
    }
  }, [userId, showToast]);

  const addAuditProgram = async (programData) => {
    if (!userId || !clientId) return null;
    const { data, error } = await supabase.from('audit_programs').insert([{ ...programData, user_id: userId, client_id: clientId }]).select().single();
    if (error) showToast("Error al añadir programa", error.message, "destructive");
    else {
      showToast("Programa añadido", "", "default");
      setAuditPrograms(prev => [data, ...prev]);
    }
    return data;
  };

  const updateAuditProgram = async (id, programData) => {
    const { data, error } = await supabase.from('audit_programs').update(programData).eq('id', id).select().single();
    if (error) showToast("Error al actualizar", error.message, "destructive");
    else {
      showToast("Programa actualizado", "", "default");
      setAuditPrograms(prev => prev.map(p => p.id === id ? data : p));
    }
    return data;
  };

  const deleteAuditProgram = async (id) => {
    const { error } = await supabase.from('audit_programs').delete().eq('id', id);
    if (error) showToast("Error al eliminar", error.message, "destructive");
    else {
      showToast("Programa eliminado", "", "default");
      setAuditPrograms(prev => prev.filter(p => p.id !== id));
      setRequirements([]); setPlanning([]); setMeetings([]); setCompliance([]);
    }
  };
  
  const addRequirement = async (programId, requirementText) => {
    const { data, error } = await supabase.from('internal_audit_requirements').insert([{ audit_program_id: programId, requirement_text: requirementText, user_id: userId }]).select().single();
    if (error) showToast("Error", error.message, "destructive");
    else setRequirements(prev => [...prev, data]);
  };

  const deleteRequirement = async (id) => {
    const { error } = await supabase.from('internal_audit_requirements').delete().eq('id', id);
    if (error) showToast("Error", error.message, "destructive");
    else setRequirements(prev => prev.filter(r => r.id !== id));
  };
  
  const addPlanningEntry = async (programId, entryData) => {
    const { data, error } = await supabase.from('internal_audit_planning').insert([{ ...entryData, audit_program_id: programId, user_id: userId }]).select().single();
    if (error) showToast("Error", error.message, "destructive");
    else setPlanning(prev => [...prev, data]);
  };
  
  const deletePlanningEntry = async (id) => {
    const { error } = await supabase.from('internal_audit_planning').delete().eq('id', id);
    if (error) showToast("Error", error.message, "destructive");
    else setPlanning(prev => prev.filter(p => p.id !== id));
  };

  const addMeeting = async (programId, meetingData) => {
    const { data, error } = await supabase.from('internal_audit_meetings').insert([{ ...meetingData, audit_program_id: programId, user_id: userId }]).select().single();
    if (error) showToast("Error", error.message, "destructive");
    else setMeetings(prev => [data, ...prev].sort((a,b) => new Date(b.meeting_date) - new Date(a.meeting_date)));
  };

  const updateMeeting = async (id, meetingData) => {
    const { data, error } = await supabase.from('internal_audit_meetings').update(meetingData).eq('id', id).select().single();
    if (error) showToast("Error", error.message, "destructive");
    else setMeetings(prev => prev.map(m => m.id === id ? data : m));
  };

  const deleteMeeting = async (id) => {
    const { error } = await supabase.from('internal_audit_meetings').delete().eq('id', id);
    if (error) showToast("Error", error.message, "destructive");
    else setMeetings(prev => prev.filter(m => m.id !== id));
  };

  const upsertCompliance = async (complianceData) => {
    const payload = {
      ...complianceData,
      user_id: userId,
    };
    if (payload.id) {
      delete payload.id;
    }

    const { data, error } = await supabase
      .from('internal_audit_compliance')
      .upsert(payload, { onConflict: 'audit_program_id, requirement_id' })
      .select('*, requirement:internal_audit_requirements(*), evidence:evidencias(*)').single();

    if (error) {
      showToast("Error guardando cumplimiento", error.message, "destructive");
    } else {
      setCompliance(prev => {
        const index = prev.findIndex(c => c.requirement_id === data.requirement_id);
        if (index > -1) {
          const newCompliance = [...prev];
          newCompliance[index] = data;
          return newCompliance;
        }
        return [...prev, data];
      });
    }
  };

  return {
    loading, auditPrograms, addAuditProgram, updateAuditProgram, deleteAuditProgram,
    requirements, addRequirement, deleteRequirement,
    planning, addPlanningEntry, deletePlanningEntry,
    meetings, addMeeting, updateMeeting, deleteMeeting,
    compliance, upsertCompliance,
    fetchAuditPrograms,
    fetchProgramData
  };
};