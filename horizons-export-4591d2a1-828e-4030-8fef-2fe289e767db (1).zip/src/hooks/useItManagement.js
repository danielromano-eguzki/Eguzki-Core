import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { v4 as uuidv4 } from 'uuid';

const tables = {
  software: 'it_software_inventory',
  hardware: 'it_hardware_inventory',
  access: 'it_access_permissions',
  users: 'it_user_management',
  changes: 'it_change_control',
  guides: 'it_guides_procedures',
  connections: 'it_critical_connections',
  apps: 'it_app_provider_matrix',
  onboarding: 'it_onboarding_offboarding',
  vulnerabilities: 'it_vulnerabilities',
  hardening: 'it_hardening_config',
  cloud: 'it_cloud_services',
  monitoring_docs: 'it_monitoring_docs',
};

export const useItManagement = (userId, clientId, showToast) => {
  const [data, setData] = useState({
    software: [], hardware: [], access: [], users: [], changes: [],
    guides: [], connections: [], apps: [], onboarding: [],
    vulnerabilities: [], hardening: [], cloud: [], monitoring_docs: []
  });
  const [loading, setLoading] = useState(false);

  const fetchData = useCallback(async () => {
    if (!userId || !clientId) {
      setData({
        software: [], hardware: [], access: [], users: [], changes: [],
        guides: [], connections: [], apps: [], onboarding: [],
        vulnerabilities: [], hardening: [], cloud: [], monitoring_docs: []
      });
      return;
    }
    setLoading(true);
    try {
      const promises = Object.values(tables).map(table =>
        supabase.from(table).select('*').eq('user_id', userId).eq('client_id', clientId)
      );
      const results = await Promise.all(promises);
      const newState = {};
      Object.keys(tables).forEach((key, index) => {
        if (results[index].error) throw results[index].error;
        newState[key] = results[index].data || [];
      });
      setData(newState);
    } catch (error) {
      showToast("Error al cargar datos de IT", error.message, "destructive");
    } finally {
      setLoading(false);
    }
  }, [userId, clientId, showToast]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const addItem = async (sectionKey, itemData, file) => {
    const tableName = tables[sectionKey];
    if (!tableName) return;

    let file_path = null;
    let file_name = null;
    let bucket = null;

    if (file) {
      if (sectionKey === 'hardening') bucket = 'hardening_documents';
      if (sectionKey === 'monitoring_docs') bucket = 'monitoring_documents';
    }

    if (file && bucket) {
      const uniqueFileName = `${userId}/${uuidv4()}-${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from(bucket)
        .upload(uniqueFileName, file);

      if (uploadError) {
        showToast("Error al subir archivo", uploadError.message, "destructive");
        return;
      }
      file_path = uniqueFileName;
      file_name = file.name;
    }

    const { error } = await supabase.from(tableName).insert({
      ...itemData,
      user_id: userId,
      client_id: clientId,
      ...(file_path && { file_path }),
      ...(file_name && { file_name }),
    });

    if (error) {
      showToast(`Error al añadir registro en ${sectionKey}`, error.message, "destructive");
    } else {
      showToast("Registro añadido", `Nuevo registro añadido en ${sectionKey}.`, "default");
      fetchData();
    }
  };

  const updateItem = async (sectionKey, itemId, itemData, file) => {
    const tableName = tables[sectionKey];
    if (!tableName) return;

    let file_path = itemData.file_path;
    let file_name = itemData.file_name;
    let bucket = null;

    if (file) {
      if (sectionKey === 'hardening') bucket = 'hardening_documents';
      if (sectionKey === 'monitoring_docs') bucket = 'monitoring_documents';
    }

    if (file && bucket) {
      const uniqueFileName = `${userId}/${uuidv4()}-${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from(bucket)
        .upload(uniqueFileName, file);

      if (uploadError) {
        showToast("Error al subir archivo", uploadError.message, "destructive");
        return;
      }
      file_path = uniqueFileName;
      file_name = file.name;
    }

    const { error } = await supabase.from(tableName).update({
      ...itemData,
      ...(file_path && { file_path }),
      ...(file_name && { file_name }),
    }).eq('id', itemId);

    if (error) {
      showToast(`Error al actualizar registro en ${sectionKey}`, error.message, "destructive");
    } else {
      showToast("Registro actualizado", `Registro actualizado en ${sectionKey}.`, "default");
      fetchData();
    }
  };

  const deleteItem = async (sectionKey, itemId) => {
    const tableName = tables[sectionKey];
    if (!tableName) return;

    const { error } = await supabase.from(tableName).delete().eq('id', itemId);

    if (error) {
      showToast(`Error al eliminar registro en ${sectionKey}`, error.message, "destructive");
    } else {
      showToast("Registro eliminado", `Registro eliminado de ${sectionKey}.`, "default");
      fetchData();
    }
  };

  return {
    ...data,
    loading,
    refetch: fetchData,
    addItem,
    updateItem,
    deleteItem,
  };
};