import { useState, useEffect, useCallback } from 'react';
    import { supabase } from '@/lib/customSupabaseClient';
    
    export const useAssets = (userId, clientId, showToast) => {
      const [assets, setAssets] = useState([]);
      const [loading, setLoading] = useState(false);
    
      const fetchAssets = useCallback(async () => {
        if (!userId || !clientId) {
          setAssets([]);
          return;
        }
        setLoading(true);
        const { data, error } = await supabase
          .from('assets')
          .select('*, asset_risk_link(risk_id)')
          .eq('client_id', clientId)
          .order('created_at', { ascending: false });
          
        if (error) showToast("Error cargando activos", error.message, "destructive");
        else setAssets(data || []);
        setLoading(false);
      }, [userId, clientId, showToast]);
    
      useEffect(() => {
        fetchAssets();
      }, [fetchAssets]);
    
      const addAsset = async (newAssetData) => {
        if (!userId || !clientId) return showToast("Error", "Usuario o cliente no seleccionado.", "destructive");
        const { data, error } = await supabase
          .from('assets')
          .insert([{ ...newAssetData, user_id: userId, client_id: clientId }])
          .select('*, asset_risk_link(risk_id)')
          .single();
          
        if (error) {
          showToast("Error al añadir activo", error.message, "destructive");
          return null;
        }
        
        if (data) { 
          setAssets(prev => [data, ...prev]); 
          showToast("¡Activo añadido!", `"${data.name}" creado.`, "default"); 
        }
        return data;
      };
    
      const addMultipleAssets = async (assetsData) => {
        if (!userId || !clientId) {
          showToast("Error", "Usuario o cliente no seleccionado.", "destructive");
          return { success: false, count: 0 };
        }
        if (!assetsData || assetsData.length === 0) {
          showToast("Información", "No hay activos para importar.", "default");
          return { success: true, count: 0 };
        }
    
        const assetsToInsert = assetsData.map(asset => ({
          ...asset,
          user_id: userId,
          client_id: clientId,
        }));
    
        const { data, error } = await supabase
          .from('assets')
          .insert(assetsToInsert)
          .select('*, asset_risk_link(risk_id)');
    
        if (error) {
          showToast("Error al importar activos", error.message, "destructive");
          return { success: false, count: 0 };
        }
    
        if (data) {
          setAssets(prev => [...data, ...prev]);
          showToast("¡Importación completada!", `${data.length} activos han sido añadidos.`, "default");
          return { success: true, count: data.length };
        }
    
        return { success: false, count: 0 };
      };
    
      const updateAsset = async (assetId, updatedAssetData) => {
        if (!userId || !clientId) return showToast("Error", "Usuario o cliente no seleccionado.", "destructive");
        const { data, error } = await supabase
          .from('assets')
          .update(updatedAssetData)
          .eq('id', assetId)
          .select('*, asset_risk_link(risk_id)')
          .single();
          
        if (error) {
          showToast("Error al actualizar activo", error.message, "destructive");
          return null;
        }
        
        if (data) { 
          setAssets(prev => prev.map(a => a.id === assetId ? data : a)); 
          showToast("¡Activo actualizado!", `"${data.name}" modificado.`, "default"); 
        }
        return data;
      };
    
      const deleteAsset = async (assetId) => {
        if (!userId || !clientId) return showToast("Error", "Usuario o cliente no seleccionado.", "destructive");
        
        const { error } = await supabase
          .from('assets')
          .delete()
          .eq('id', assetId);
          
        if (error) showToast("Error al eliminar activo", error.message, "destructive");
        else { setAssets(prev => prev.filter(a => a.id !== assetId)); showToast("¡Activo eliminado!", "El activo ha sido borrado.", "default"); }
      };
    
      return { assets, addAsset, addMultipleAssets, updateAsset, deleteAsset, loading, refetch: fetchAssets };
    };