import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/lib/customSupabaseClient';

const BUCKET_NAME = 'document_templates';

const sanitizeFileName = (fileName) => {
  if (!fileName) return '';
  return fileName.replace(/[^a-zA-Z0-9_.-]/g, '_');
};

export const useDocumentTemplates = (userId, showToast) => {
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchTemplates = useCallback(async () => {
    if (!userId) {
      setTemplates([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('document_templates')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setTemplates(data || []);
    } catch (error) {
      showToast('Error', 'No se pudieron cargar las plantillas.', 'destructive');
      console.error('Error fetching templates:', error);
    } finally {
      setLoading(false);
    }
  }, [userId, showToast]);

  useEffect(() => {
    fetchTemplates();
  }, [fetchTemplates]);

  const uploadFile = async (file, currentPath) => {
    if (currentPath) {
      const { error: removeError } = await supabase.storage.from(BUCKET_NAME).remove([currentPath]);
      if (removeError) {
        console.error('Error removing old file:', removeError);
      }
    }
    const sanitizedName = sanitizeFileName(file.name);
    const filePath = `${userId}/${uuidv4()}-${sanitizedName}`;
    const { error } = await supabase.storage.from(BUCKET_NAME).upload(filePath, file, {
      cacheControl: '3600',
      upsert: false,
    });
    if (error) throw error;
    return filePath;
  };

  const addTemplate = async (formData, file, silent = false) => {
    if (!userId) return;
    if (!silent) setLoading(true);
    
    try {
      let filePath = null;
      let fileName = null;
      if (file) {
        filePath = await uploadFile(file);
        fileName = file.name;
      }
      
      const newTemplate = {
        ...formData,
        user_id: userId,
        file_path: filePath,
        file_name: fileName,
      };

      const { error } = await supabase.from('document_templates').insert(newTemplate);
      if (error) throw error;

      if (!silent) {
        await fetchTemplates();
        showToast('Éxito', 'Plantilla añadida correctamente.', 'success');
      }
    } catch (error) {
      if (!silent) {
        showToast('Error', 'No se pudo añadir la plantilla.', 'destructive');
      }
      console.error('Error adding template:', error);
      throw error; // Re-throw for bulk handling
    } finally {
      if (!silent) setLoading(false);
    }
  };

  const updateTemplate = async (id, formData, file) => {
    setLoading(true);
    try {
      const templateToUpdate = templates.find(t => t.id === id);
      if (!templateToUpdate) throw new Error('Plantilla no encontrada');

      let filePath = templateToUpdate.file_path;
      let fileName = templateToUpdate.file_name;

      if (file) {
        filePath = await uploadFile(file, templateToUpdate.file_path);
        fileName = file.name;
      }

      const updatedData = {
        ...formData,
        file_path: filePath,
        file_name: fileName,
        updated_at: new Date().toISOString(),
      };

      const { error } = await supabase.from('document_templates').update(updatedData).eq('id', id);
      if (error) throw error;
      
      await fetchTemplates();
      showToast('Éxito', 'Plantilla actualizada.', 'success');
    } catch (error) {
      showToast('Error', 'No se pudo actualizar la plantilla.', 'destructive');
      console.error('Error updating template:', error);
    } finally {
      setLoading(false);
    }
  };

  const deleteTemplate = async (id) => {
    setLoading(true);
    try {
      const templateToDelete = templates.find(t => t.id === id);
      if (!templateToDelete) throw new Error('Plantilla no encontrada');
      
      const { error } = await supabase.from('document_templates').delete().eq('id', id);
      if (error) throw error;
      
      if (templateToDelete.file_path) {
        const { error: storageError } = await supabase.storage.from(BUCKET_NAME).remove([templateToDelete.file_path]);
        if (storageError) {
          console.error('Error deleting file from storage, but record was deleted:', storageError);
        }
      }
      
      setTemplates(prev => prev.filter(t => t.id !== id));
      showToast('Éxito', 'Plantilla eliminada.', 'success');
    } catch (error) {
      showToast('Error', 'No se pudo eliminar la plantilla.', 'destructive');
      console.error('Error deleting template:', error);
    } finally {
      setLoading(false);
    }
  };

  const getFileUrl = async (filePath) => {
    try {
      const { data, error } = await supabase.storage.from(BUCKET_NAME).createSignedUrl(filePath, 3600);
      if (error) throw error;
      return data.signedUrl;
    } catch (error) {
      showToast('Error', 'No se pudo obtener la URL del archivo.', 'destructive');
      console.error('Error getting file URL:', error);
      return null;
    }
  };

  return { templates, addTemplate, updateTemplate, deleteTemplate, getFileUrl, loading, refetchTemplates: fetchTemplates };
};