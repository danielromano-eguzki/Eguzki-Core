import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/lib/customSupabaseClient';
import { generatePdfFromDom } from '@/lib/exportUtils';

const BUCKET_NAME = 'normative_documents';

const sanitizeFileName = (fileName) => {
  if (!fileName) return '';
  return fileName.replace(/[^a-zA-Z0-9_.-]/g, '_');
};

const getSourceType = (docType) => {
  const generatedTypes = ['Informe de Auditoría Interna', 'Informe de Gap Analysis'];
  return generatedTypes.includes(docType) ? 'generated' : 'internal';
};

export const useNormativeDocuments = (userId, clientId, showToast) => {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchDocuments = useCallback(async () => {
    if (!userId || !clientId) {
      setDocuments([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('normative_documents')
        .select(`
          *,
          linked_requirements:normative_document_requirement_link (
            requirement_id
          )
        `)
        .eq('client_id', clientId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setDocuments(data || []);
    } catch (error) {
      showToast('Error', 'No se pudieron cargar los documentos normativos.', 'destructive');
      console.error('Error fetching normative documents:', error);
    } finally {
      setLoading(false);
    }
  }, [userId, clientId, showToast]);

  useEffect(() => {
    fetchDocuments();
  }, [fetchDocuments]);
  
  const uploadFile = async (file, currentPath) => {
    if (currentPath) {
        const { error: removeError } = await supabase.storage.from(BUCKET_NAME).remove([currentPath]);
        if (removeError) {
            console.error('Error removing old file:', removeError);
        }
    }
    const sanitizedName = sanitizeFileName(file.name);
    const filePath = `${userId}/${clientId}/${uuidv4()}-${sanitizedName}`;
    const { error } = await supabase.storage.from(BUCKET_NAME).upload(filePath, file, {
      cacheControl: '3600',
      upsert: false,
    });
    if (error) throw error;
    return filePath;
  };

  const uploadGeneratedPdf = async (pdfBlob, document) => {
    if (document.file_path) {
        const { error: removeError } = await supabase.storage.from(BUCKET_NAME).remove([document.file_path]);
        if (removeError) {
            console.error('Error removing old file:', removeError);
        }
    }
    const fileName = `${document.type.replace(/\s/g, '_')}_${document.doc_id}.pdf`;
    const sanitizedName = sanitizeFileName(fileName);
    const filePath = `${userId}/${clientId}/${uuidv4()}_${sanitizedName}`;
    const { error } = await supabase.storage.from(BUCKET_NAME).upload(filePath, pdfBlob, {
      cacheControl: '3600',
      upsert: false,
      contentType: 'application/pdf'
    });
    if (error) throw error;
    return { filePath, fileName: sanitizedName };
  };

  const manageLinks = async (documentId, requirementIds) => {
    const { error: deleteError } = await supabase
      .from('normative_document_requirement_link')
      .delete()
      .eq('document_id', documentId);

    if (deleteError) {
      console.error('Error deleting old links:', deleteError);
      throw new Error('Could not update links');
    }

    if (requirementIds && requirementIds.length > 0) {
      const linksToInsert = requirementIds.map(reqId => ({
        document_id: documentId,
        requirement_id: reqId,
        user_id: userId,
        client_id: clientId,
      }));
      const { error: insertError } = await supabase
        .from('normative_document_requirement_link')
        .insert(linksToInsert);

      if (insertError) {
        console.error('Error inserting new links:', insertError);
        throw new Error('Could not insert new links');
      }
    }
  };

  const addDocument = async (formData, attachmentFile, linkedReqs) => {
    if (!userId || !clientId) return;
    setLoading(true);
    try {
      let filePath = null;
      let fileName = null;
      if (attachmentFile) {
        filePath = await uploadFile(attachmentFile);
        fileName = attachmentFile.name;
      }
      
      const newDocument = {
        ...formData,
        approval_date: formData.approval_date || null,
        user_id: userId,
        client_id: clientId,
        file_path: filePath,
        file_name: fileName,
        source_type: getSourceType(formData.type),
      };

      const { data, error } = await supabase
        .from('normative_documents')
        .insert(newDocument)
        .select()
        .single();
      
      if (error) throw error;

      if (linkedReqs && linkedReqs.length > 0) {
        await manageLinks(data.id, linkedReqs);
      }

      await fetchDocuments();
      showToast('Éxito', 'Documento normativo añadido correctamente.', 'default');
    } catch (error) {
      showToast('Error', 'No se pudo añadir el documento.', 'destructive');
      console.error('Error adding document:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateDocument = async (id, formData, attachmentFile, linkedReqs) => {
    setLoading(true);
    try {
      const docToUpdate = documents.find(d => d.id === id);
      if (!docToUpdate) throw new Error('Documento no encontrado');

      let filePath = docToUpdate.file_path;
      let fileName = docToUpdate.file_name;

      if (attachmentFile) {
        filePath = await uploadFile(attachmentFile, docToUpdate.file_path);
        fileName = attachmentFile.name;
      }

      const updatedData = {
        ...formData,
        approval_date: formData.approval_date || null,
        file_path: filePath,
        file_name: fileName,
        source_type: getSourceType(formData.type),
        updated_at: new Date().toISOString(),
      };

      const { data, error } = await supabase
        .from('normative_documents')
        .update(updatedData)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      
      await manageLinks(data.id, linkedReqs);
      
      await fetchDocuments();
      showToast('Éxito', 'Documento normativo actualizado.', 'default');
    } catch (error) {
      showToast('Error', 'No se pudo actualizar el documento.', 'destructive');
      console.error('Error updating document:', error);
    } finally {
      setLoading(false);
    }
  };

  const deleteDocument = async (id) => {
    setLoading(true);
    try {
      const docToDelete = documents.find(doc => doc.id === id);
      if (!docToDelete) throw new Error('Documento no encontrado');
      
      const { error } = await supabase.from('normative_documents').delete().eq('id', id);
      if (error) throw error;
      
      if (docToDelete.file_path) {
        const { error: storageError } = await supabase.storage.from(BUCKET_NAME).remove([docToDelete.file_path]);
        if (storageError) {
          console.error('Error deleting file from storage, but record was deleted:', storageError);
        }
      }
      
      setDocuments(prev => prev.filter(doc => doc.id !== id));
      showToast('Éxito', 'Documento normativo eliminado.', 'default');
    } catch (error) {
      showToast('Error', 'No se pudo eliminar el documento.', 'destructive');
      console.error('Error deleting document:', error);
    } finally {
      setLoading(false);
    }
  };

  const getFileUrl = async (filePath, bucket = BUCKET_NAME) => {
    try {
        const { data, error } = await supabase.storage.from(bucket).createSignedUrl(filePath, 3600); // URL válida por 1 hora
        if (error) throw error;
        return data.signedUrl;
    } catch (error) {
        showToast('Error', 'No se pudo obtener la URL del archivo.', 'destructive');
        console.error('Error getting file URL:', error);
        return null;
    }
  };

  const generateAndSaveReport = async (element, document, clientName, responsible) => {
    showToast('Generando informe...', 'El informe se está generando y guardando.', 'default');
    try {
      const { pdfBlob } = await generatePdfFromDom({
        element,
        documentTitle: document.type,
        clientName,
        responsible,
        returnBlob: true,
      });

      const { filePath, fileName } = await uploadGeneratedPdf(pdfBlob, document);
      
      const { error } = await supabase
        .from('normative_documents')
        .update({ 
          file_path: filePath, 
          file_name: fileName, 
          source_type: 'generated',
          updated_at: new Date().toISOString() 
        })
        .eq('id', document.id);

      if (error) throw error;

      await fetchDocuments();
      showToast('Éxito', 'Informe generado y guardado correctamente.', 'default');

    } catch (error) {
      showToast('Error', 'No se pudo generar o guardar el informe.', 'destructive');
      console.error('Error generating and saving report:', error);
    }
  };

  return { documents, addDocument, updateDocument, deleteDocument, getFileUrl, generateAndSaveReport, loading, refetchDocuments: fetchDocuments };
};