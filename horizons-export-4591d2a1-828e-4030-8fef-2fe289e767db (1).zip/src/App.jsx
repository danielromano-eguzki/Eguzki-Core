import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';
import { FileText, BarChart3, Search, Bell, Folder, AlertOctagon, Shield, BookOpen, ClipboardList, Briefcase, GraduationCap, Megaphone, Plug, Eye, ShieldCheck, Anchor, FileLock, LifeBuoy, HeartPulse as Heartbeat, ShieldAlert, Wifi, Server, HardDrive, Award, ShoppingCart, Archive } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";

import DashboardPage from '@/pages/DashboardPage.jsx';
import RiesgosPage from '@/pages/RiesgosPage.jsx';
import ConfiguracionPage from '@/pages/ConfiguracionPage.jsx';
import FindingsPage from '@/pages/FindingsPage.jsx';
import ClientsPage from '@/pages/ClientsPage.jsx'; 
import IntegrationsPage from '@/pages/IntegrationsPage.jsx';
import LoginPage from '@/pages/LoginPage.jsx';
import MfaSetupPage from '@/pages/MfaSetupPage.jsx';
import WelcomePage from '@/pages/WelcomePage.jsx';
import WhatsNewModal from '@/components/novedades/WhatsNewModal.jsx';
import UserMenu from '@/components/auth/UserMenu.jsx';
import InternalDocumentationPage from '@/pages/InternalDocumentationPage.jsx';
import ItPage from '@/pages/ItPage.jsx';
import CertificationsPage from '@/pages/CertificationsPage.jsx';
import ContinuityAndIncidentsPage from '@/pages/ContinuityAndIncidentsPage.jsx';
import FormacionPage from '@/pages/FormacionPage.jsx';
import MarketplacePage from '@/pages/MarketplacePage.jsx';
import AssetsPage from '@/pages/AssetsPage.jsx';

import { useAuth } from '@/hooks/useAuth';
import { useClients } from '@/hooks/useClients';
import { useAssets } from '@/hooks/useAssets';
import { useRiesgos } from '@/hooks/useRiesgos';
import { useFindings } from '@/hooks/useFindings';
import { useTrainings } from '@/hooks/useTrainings.js';
import { useAuditLogs } from '@/hooks/useAuditLogs.js';
import useWhatsNew from '@/hooks/useWhatsNew.js';
import { useNormativeDocuments } from '@/hooks/useNormativeDocuments.js';
import { useIntegrations } from '@/hooks/useIntegrations.js';
import { usePrivacy } from '@/hooks/usePrivacy.js';
import { useItManagement } from '@/hooks/useItManagement.js';
import { useEns } from '@/hooks/useEns.js';
import { useIso27001 } from '@/hooks/useIso27001.js';
import { useCRA } from '@/hooks/useCRA.js';
import { useSOC2 } from '@/hooks/useSOC2.js';
import { useDORA } from '@/hooks/useDORA.js';
import { useNIS2 } from '@/hooks/useNIS2.js';
import { useBusinessContinuity } from '@/hooks/useBusinessContinuity.js';
import { useIncidentes } from '@/hooks/useIncidentes.js';
import { useInternalDocumentation } from '@/hooks/useInternalDocumentation.js';
import { useAuditoriaInterna } from '@/hooks/useAuditoriaInterna.js';
import { useCertification } from '@/hooks/useCertification.js';
import { useSuppliers } from '@/hooks/useSuppliers.js';
import { useLegalDocuments } from '@/hooks/useLegalDocuments.js';
import { supabase } from '@/lib/customSupabaseClient';


const AuditorRoleBanner = () => (
  <div className="fixed top-16 left-0 right-0 bg-gradient-to-r from-amber-500 to-orange-500 text-white text-center py-2 px-4 shadow-lg z-50 flex items-center justify-center">
    <Eye className="w-5 h-5 mr-3" />
    <span className="font-semibold">Rol de Auditor: La aplicación está en modo de solo lectura.</span>
  </div>
);


function App() {
  const { toast } = useToast();
  const showToast = useCallback((title = "🚧 Esta funcionalidad no está implementada aún", description = "¡No te preocupes! Puedes solicitarla en tu próximo prompt 🚀", variant = "default") => {
    toast({
      title: title,
      description: description,
      variant: variant,
    });
  }, [toast]);

  const [activeTab, setActiveTab] = useState('dashboard');
  const auth = useAuth(showToast);
  
  const userId = auth.session?.user?.id;
  const [selectedClientId, setSelectedClientId] = useState('');
  
  const [isWhatsNewOpen, setIsWhatsNewOpen] = useState(false);
  const [hasNewUpdates, setHasNewUpdates] = useState(false);

  const handleClientChange = (clientId) => {
    setSelectedClientId(clientId);
  };

  const clientsHook = useClients(userId, showToast);
  const { clients, loading: loadingClients } = clientsHook;
  const { updates, loading: loadingUpdates } = useWhatsNew(showToast);

  const isReadOnly = auth.userRole === 'auditor';

  useEffect(() => {
    if (updates && updates.length > 0) {
      const latestVersion = updates[0].version;
      const lastSeenVersion = localStorage.getItem('eguzkiCoreLastSeenVersion');
      if (latestVersion && latestVersion !== lastSeenVersion) {
        setHasNewUpdates(true);
      }
    }
  }, [updates]);

  const handleOpenWhatsNew = () => {
    setIsWhatsNewOpen(true);
  };

  const handleCloseWhatsNew = () => {
    setIsWhatsNewOpen(false);
    if (updates && updates.length > 0) {
      const latestVersion = updates[0].version;
      if (latestVersion) {
        localStorage.setItem('eguzkiCoreLastSeenVersion', latestVersion);
      }
      setHasNewUpdates(false);
    }
  };

  useEffect(() => {
    if (clients && clients.length > 0 && !selectedClientId) {
      setSelectedClientId(clients[0].id);
    } else if (clients && clients.length === 0) {
      setSelectedClientId('');
    }
  }, [clients, selectedClientId]);

  const assetsHook = useAssets(userId, selectedClientId, showToast);
  const riesgosHook = useRiesgos(userId, selectedClientId, showToast, assetsHook.refetch);
  const findingsHook = useFindings(userId, selectedClientId, showToast);
  const trainingsHook = useTrainings(userId, selectedClientId, showToast);
  const { logs, loading: loadingLogs, refetchLogs } = useAuditLogs(userId, showToast);
  const normativeDocumentsHook = useNormativeDocuments(userId, selectedClientId, showToast);
  const integrationsHook = useIntegrations(userId, selectedClientId, showToast);
  const privacyHook = usePrivacy(userId, selectedClientId, showToast);
  const itManagementHook = useItManagement(userId, selectedClientId, showToast);
  const ensHook = useEns(userId, selectedClientId, showToast);
  const iso27001Hook = useIso27001(userId, selectedClientId, showToast);
  const craHook = useCRA(userId, selectedClientId, showToast);
  const soc2Hook = useSOC2(userId, selectedClientId, showToast);
  const doraHook = useDORA(userId, selectedClientId, showToast);
  const nis2Hook = useNIS2(userId, selectedClientId, showToast);
  const suppliersHook = useSuppliers(userId, selectedClientId, showToast);
  const businessContinuityHook = useBusinessContinuity(userId, selectedClientId, showToast, supabase);
  const incidentesHook = useIncidentes(userId, selectedClientId, showToast, supabase);
  const evidenciasHook = useInternalDocumentation(userId, selectedClientId, showToast);
  const auditoriaInternaHook = useAuditoriaInterna(userId, selectedClientId, showToast);
  const certificationHook = useCertification(userId, selectedClientId, showToast);
  const legalDocumentsHook = useLegalDocuments(userId, selectedClientId, showToast);


  const loadingData = loadingClients || assetsHook.loading || riesgosHook.loading || findingsHook.loading || trainingsHook.loading || normativeDocumentsHook.loading || integrationsHook.loading || privacyHook.loading || itManagementHook.loading || ensHook.loading || iso27001Hook.loading || craHook.loading || soc2Hook.loading || doraHook.loading || nis2Hook.loading || suppliersHook.loading || businessContinuityHook.loading || incidentesHook.loading || evidenciasHook.loading || auditoriaInternaHook.loading || certificationHook.loading || legalDocumentsHook.loading;
  
  const navigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3, component: DashboardPage },
    { id: 'clients', label: 'Mis Clientes', icon: Briefcase, component: ClientsPage },
    { id: 'assets', label: 'Activos', icon: Archive, component: AssetsPage },
    { id: 'documentacion_interna', label: 'Repositorio', icon: Folder, component: InternalDocumentationPage },
    { id: 'it', label: 'Gestión de IT', icon: HardDrive, component: ItPage },
    { id: 'riesgos', label: 'Riesgos', icon: AlertOctagon, component: RiesgosPage },
    { id: 'certificaciones', label: 'Certificaciones', icon: Award, component: CertificationsPage },
    { id: 'continuity', label: 'Continuidad', icon: ShieldAlert, component: ContinuityAndIncidentsPage },
    { id: 'training', label: 'Formación', icon: GraduationCap, component: FormacionPage },
    { id: 'findings', label: 'Hallazgos', icon: ClipboardList, component: FindingsPage },
    { id: 'integrations', label: 'Integraciones', icon: Plug, component: IntegrationsPage },
    { id: 'marketplace', label: 'Marketplace', icon: ShoppingCart, component: MarketplacePage },
  ];
  
  const pageComponents = {
    ...navigationItems.reduce((acc, item) => ({ ...acc, [item.id]: item.component }), {}),
    configuracion: ConfiguracionPage,
  };

  const ActiveComponent = pageComponents[activeTab] || DashboardPage;

  const handleLogout = useCallback(() => {
    auth.handleLogout();
    showToast("Sesión cerrada", "Tu sesión se ha cerrado por inactividad.", "default");
  }, [auth, showToast]);

  useEffect(() => {
    let inactivityTimer;

    const resetTimer = () => {
      clearTimeout(inactivityTimer);
      if (auth.authStep === 'authenticated') {
        inactivityTimer = setTimeout(handleLogout, 30 * 60 * 1000); // 30 minutes
      }
    };

    if (auth.authStep === 'authenticated') {
      const events = ['mousemove', 'keydown', 'click', 'scroll'];
      events.forEach(event => window.addEventListener(event, resetTimer));
      resetTimer();
    }

    return () => {
      clearTimeout(inactivityTimer);
      const events = ['mousemove', 'keydown', 'click', 'scroll'];
      events.forEach(event => window.removeEventListener(event, resetTimer));
    };
  }, [auth.authStep, handleLogout]);

  if (auth.loadingAuth) { 
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full"
        ></motion.div>
      </div>
    );
  }

  if (auth.authStep === 'login' || auth.authStep === 'mfa_required') {
    return <LoginPage auth={auth} showToast={showToast} />;
  }

  if (auth.authStep === 'password_reset') {
    return <WelcomePage auth={auth} showToast={showToast} supabase={supabase} />;
  }
  
  if (auth.authStep === 'mfa_setup_required') {
    return <MfaSetupPage auth={auth} showToast={showToast} supabase={supabase} />;
  }
  
  const handleSettingsClick = () => {
    setActiveTab('configuracion');
    refetchLogs();
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <Helmet>
        <title>Eguzki Core - GRC</title>
        <meta name="description" content="Plataforma de Gestión 360º para el Cumplimiento Normativo" />
      </Helmet>
      <Toaster />
      {isReadOnly && <AuditorRoleBanner />}
      <WhatsNewModal open={isWhatsNewOpen} onClose={handleCloseWhatsNew} updates={updates} />
      <motion.header 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="bg-white/80 backdrop-blur-lg border-b border-white/20 sticky top-0 z-50"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div 
                className="flex items-center space-x-3 cursor-pointer"
                onClick={() => setActiveTab('dashboard')}
              >
                <div className="w-10 h-10 flex items-center justify-center">
                  <img src="https://storage.googleapis.com/hostinger-horizons-assets-prod/4591d2a1-828e-4030-8fef-2fe289e767db/fbb6eeab9659944dfb76a5c3181c10f8.png" alt="Logo Eguzki Core" className="h-full w-auto object-contain" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gradient-green">Eguzki Core</h1>
                  <p className="text-xs text-gray-500">Plataforma de Gestión 360º para el Cumplimiento Normativo</p>
                </div>
              </div>
               {clients && clients.length > 0 && !['clients', 'configuracion'].includes(activeTab) && (
                <div className="ml-4">
                  <Select onValueChange={handleClientChange} value={selectedClientId}>
                    <SelectTrigger className="w-[200px] h-9 bg-white/70 border-gray-300/70 text-sm">
                      <SelectValue placeholder="Seleccionar Cliente..." />
                    </SelectTrigger>
                    <SelectContent>
                      {clients.map(client => (
                        <SelectItem key={client.id} value={client.id}>
                          {client.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input 
                  type="text" 
                  placeholder="Buscar..."
                  className="pl-10 pr-4 py-2 bg-white/50 border border-white/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  onClick={() => showToast()}
                />
              </div>
              <Button variant="ghost" size="icon" onClick={handleOpenWhatsNew} className="relative">
                <Megaphone className="w-5 h-5" />
                {hasNewUpdates && <div className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></div>}
              </Button>
              <Button variant="ghost" size="icon" onClick={() => showToast()}><Bell className="w-5 h-5" /></Button>
              <UserMenu user={auth.session?.user} onLogout={auth.handleLogout} onSettingsClick={handleSettingsClick} userRole={auth.userRole} />
            </div>
          </div>
        </div>
      </motion.header>

      <div className="flex">
        <motion.aside 
          initial={{ x: -300 }}
          animate={{ x: 0 }}
          className="w-64 bg-white/60 backdrop-blur-lg border-r border-white/20 min-h-screen sidebar-nav"
        >
          <nav className="p-4 space-y-2">
            {navigationItems.map((item) => (
              <motion.button
                key={item.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
                  activeTab === item.id 
                    ? 'bg-primary text-primary-foreground shadow-lg' 
                    : 'text-gray-700 hover:bg-white/50'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </motion.button>
            ))}
          </nav>
        </motion.aside>

        <main className="flex-1 p-6">
          {loadingData && !['dashboard', 'clients', 'configuracion'].includes(activeTab) && !selectedClientId ? (
             <div className="flex items-center justify-center h-full">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full"
                ></motion.div>
             </div>
          ) : (
            <ActiveComponent 
              showToast={showToast} 
              session={auth.session}
              auth={auth}
              user={auth.session?.user}
              userId={userId}
              setActiveTab={setActiveTab}
              isReadOnly={isReadOnly}
              supabase={supabase}

              clientsHook={clientsHook}
              clients={clients}
              loadingClients={loadingClients}
              selectedClientId={selectedClientId}
              handleClientChange={handleClientChange}
              
              assetsHook={assetsHook}
              
              riesgosHook={riesgosHook}
              
              findingsHook={findingsHook}
              
              trainingsHook={trainingsHook}

              integrationsHook={integrationsHook}
              
              privacyHook={privacyHook}
              
              itHook={itManagementHook}

              ensHook={ensHook}
              iso27001Hook={iso27001Hook}
              craHook={craHook}
              soc2Hook={soc2Hook}
              doraHook={doraHook}
              nis2Hook={nis2Hook}
              suppliersHook={suppliersHook}
              evidenciasHook={evidenciasHook}
              businessContinuityHook={businessContinuityHook}
              incidentesHook={incidentesHook}
              auditoriaInternaHook={auditoriaInternaHook}
              certificationHook={certificationHook}
              normativeDocumentsHook={normativeDocumentsHook}
              legalDocumentsHook={legalDocumentsHook}


              logs={logs} loadingLogs={loadingLogs}
            />
          )}
        </main>
      </div>
    </div>
  );
}

export default App;