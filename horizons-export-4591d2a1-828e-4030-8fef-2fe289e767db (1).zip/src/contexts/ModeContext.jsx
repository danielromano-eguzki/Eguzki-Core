import React, { createContext, useState, useContext } from 'react';

const ModeContext = createContext();

export const useMode = () => {
  return useContext(ModeContext);
};

export const ModeProvider = ({ children }) => {
  const [isAuditorMode, setIsAuditorMode] = useState(false);

  const value = {
    isAuditorMode,
    setIsAuditorMode,
  };

  return (
    <ModeContext.Provider value={value}>
      {children}
    </ModeContext.Provider>
  );
};